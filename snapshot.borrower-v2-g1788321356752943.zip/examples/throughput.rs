//! How fast the reduction actually is, on this machine, today.
//!
//! Not a benchmark harness. It builds a synthetic survey of a size that
//! resembles a morning of shallow water acquisition, runs it, and prints
//! soundings per second. That is the number worth watching, because it is the
//! one that decides whether a day of data can be turned round overnight.
//!
//! Run it with: cargo run --release --example throughput

use std::time::Instant;

use plumbline::cli::simulate::{generate, Scene};
use plumbline::config::survey::SurveyConfig;
use plumbline::geodesy::{Ellipsoid, Geodetic};
use plumbline::ping::line::Line;
use plumbline::pipeline::parallel::{reduce_lines, Progress, Threads};
use plumbline::pipeline::reduce_line::Pipeline;
use plumbline::svp::library::{LibraryEntry, ProfileLibrary, ProfileSelection};
use plumbline::svp::profile::{Sample, SoundSpeedProfile};
use plumbline::time::Timestamp;
use plumbline::vertical::reference::VerticalReference;
use plumbline::vertical::tide::{TideGauge, TideModel};

const CONFIG: &str = "
[survey]
name = \"throughput\"
utm_zone = 36

[vessel]
name = \"bench launch\"
draft = 1.8

[grid]
cell_size = 0.5

[cleaning]
min_depth = 2.0
max_depth = 90.0
";

fn main() {
    let config = SurveyConfig::parse(CONFIG).expect("the built in configuration should parse");

    // A cast with structure in it, so the tracer has real layers to walk
    // rather than one isovelocity slab.
    let profile = SoundSpeedProfile::new(vec![
        Sample::new(0.0, 1462.0),
        Sample::new(8.0, 1461.2),
        Sample::new(19.0, 1455.0),
        Sample::new(37.0, 1451.5),
        Sample::new(64.0, 1453.0),
        Sample::new(120.0, 1458.0),
    ])
    .expect("the built in profile should be valid");

    let profiles = ProfileLibrary::new(
        vec![LibraryEntry {
            label: "bench cast".into(),
            time: Timestamp::from_unix_seconds(1_750_000_000.0),
            position: Some(Geodetic::from_degrees(69.0, 33.0, 0.0)),
            profile,
        }],
        ProfileSelection::NearestInTime,
    )
    .expect("one cast is a library");

    let gauge = TideGauge::new(
        "bench",
        Geodetic::from_degrees(69.0, 33.0, 0.0),
        vec![
            (Timestamp::from_unix_seconds(1_749_000_000.0), 0.4),
            (Timestamp::from_unix_seconds(1_751_000_000.0), 0.4),
        ],
        3_000_000.0,
    )
    .expect("two observations are a gauge");
    let vertical = VerticalReference::Tide {
        model: Box::new(TideModel::single_gauge(gauge).expect("a gauge is a model")),
        zone: "whole survey".into(),
    };

    let lines: Vec<Line> = (0..12)
        .map(|i| {
            let scene = Scene {
                depth: 32.0,
                slope: 1.5,
                pings: 900,
                beams: 256,
                swath: 62.0,
                start_position: Geodetic::from_degrees(69.0, 33.0 + i as f64 * 0.0008, 0.0),
                ..Scene::default()
            };
            Line::new(
                format!("line {:02}", i + 1),
                generate(&scene).expect("the scene should generate"),
            )
        })
        .collect();

    let beams: usize = lines.iter().map(|l| l.beam_count()).sum();
    println!("{} lines, {beams} beams", lines.len());

    let pipeline = Pipeline {
        config: &config,
        profiles: &profiles,
        vertical: &vertical,
        ellipsoid: Ellipsoid::WGS84,
    };

    for threads in [Threads::One, Threads::Available] {
        let count = threads.count(lines.len());
        let progress = Progress::new();
        let started = Instant::now();
        let results =
            reduce_lines(&pipeline, &lines, threads, &progress).expect("the run should finish");
        let elapsed = started.elapsed().as_secs_f64();
        let soundings: usize = results.iter().map(|r| r.soundings.len()).sum();
        println!(
            "{count:>2} thread(s): {elapsed:6.2} s, {:.0} soundings per second",
            soundings as f64 / elapsed
        );
    }
}
