# The ping file format

`plumbline` reads one binary format, written by `plumbline simulate` and by
whatever converter a particular sonar needs. It is deliberately dull. All
values are little endian.

## File

```
offset  size  contents
0       4     magic, the ascii bytes PLMB
4       2     format version, currently 1
6       2     reserved, written as zero
8       4     number of pings
12      4     length of the ping records in bytes
16      n     the ping records
16+n    4     crc32 of the ping records
```

The checksum is the ordinary reflected CRC-32, so it can be verified with any
standard tool. It is checked before anything is decoded: the failure that
happens in practice is a truncated copy, and half of one decodes perfectly up
to the cut.

## Ping record

```
size  type  contents
8     f64   time, seconds since the unix epoch, UTC
8     u64   sequence number within the line
4     f32   sound speed at the transducer face, m/s
2     u16   number of beams
1     u8    1 when navigation follows, 0 when it does not
1     u8    reserved
```

If the navigation flag is set, this follows:

```
8     f64   latitude, degrees, positive north
8     f64   longitude, degrees, positive east
8     f64   ellipsoidal height of the reference point, metres
4     f32   roll, degrees, positive starboard down
4     f32   pitch, degrees, positive bow up
4     f32   heading, degrees, clockwise from true north
4     f32   heave, metres, positive up
4     f32   speed over ground, m/s
1     u8    1 when the transducer height is present
8     f64   ellipsoidal height of the transducer, metres
```

Then one of these per beam:

```
2     u16   beam number as the sonar reported it
8     f64   two way travel time, seconds
4     f32   pointing angle, degrees from vertical, positive starboard
4     f32   steering angle, degrees, positive forward
4     f32   detection quality, 0 to 1
1     u8    detection type: 0 none, 1 amplitude, 2 phase, 3 unknown
2     u16   beam flags
```

## Why f32 in places

Travel times and timestamps are `f64` because they have no slack: a
microsecond of travel time is a millimetre of depth. Angles, speeds and
qualities are `f32` because the fourth decimal of a degree of beam angle is
already an order below what any sonar resolves, and halving the file is worth
more than digits nobody measured.

## Unknown values

A reader that meets a detection type it does not recognise treats it as
unknown rather than failing. A newer writer adding a detection type should not
stop an older reader getting the depths out. A version number higher than the
reader understands is refused, because that is the case where the record
layout itself may have changed.
