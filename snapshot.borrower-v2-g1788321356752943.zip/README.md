# plumbline

Reduction of multibeam echosounder observations to chart datum bathymetry.

This is the processing core I keep rewriting on every survey: refraction,
attitude, vertical referencing, uncertainty and gridding, without the rest of
a hydrographic office suite bolted on. It is a library with a command line
tool on top of it, and it is meant to be small enough to read.

## What it does

A multibeam echosounder measures a two way travel time and a beam angle. Six
things have to happen to that before it is a depth anyone can put on a chart,
and this crate does all six:

1. the ray is bent through the water column, layer by layer, using a sound
   speed cast (`raytrace`, `svp`),
2. the resulting vector is rotated out of the transducer frame through the
   mounting angles and the vessel attitude (`motion`),
3. it is placed on the ground through a projection (`geodesy`),
4. the vertical is referred to a datum, from a tide gauge or from the
   ellipsoid and a separation model (`vertical`),
5. an uncertainty is propagated alongside the depth and judged against an
   order (`tpu`),
6. the soundings are cleaned, gridded and reported on (`qc`, `grid`).

There is also a patch test solver (`calibration`), a line planner
(`planning`), and a simulator that writes a seabed whose depth you already
know, which is the fastest way to find out whether a configuration is right.

## Using it

```
plumbline simulate line01.pbf --depth 25 --pings 400
plumbline reduce line01.pbf --config survey.toml --svp casts.svp \
    --tide gauge.tide --out soundings.xyz --report survey.txt
plumbline grid soundings.xyz --cell 0.5 --out surface.asc
plumbline compare reference.asc check.asc --order "order 1"
```

`plumbline <command> --help` describes each one. The library is the same code
underneath, so anything the tool does can be done from Rust directly.

## Configuration

Everything that changes a depth lives in one file, which is meant to be
archived with the deliverable:

```toml
[survey]
name = "berth 4"
order = "special"
utm_zone = 36

[vessel]
draft = 1.85
transducer_forward = -0.85
roll_offset = -0.42

[sound_speed]
equation = "del-grosso"
selection = "previous in time"

[grid]
cell_size = 0.25

[cleaning]
max_swath_angle = 60.0
max_deviation = 0.75
```

Anything the file sets that nothing reads is reported back, because a
misspelled key that is silently ignored is the worst failure a configuration
file has.

## Dependencies

None, outside the standard library, and one dev dependency for float
comparison in the tests. That is not a principle, it is a consequence: the
crate is pinned to the toolchain in `rust-toolchain.toml` and most of what it
would have depended on has moved past that. The parsers and the argument
handling are small enough that writing them was cheaper than moving the pin.

## Conventions

The two that cause the most trouble elsewhere, written down here as well as in
the code:

- Angles: roll is positive with the starboard side down, pitch is positive
  with the bow up, heading is positive clockwise from true north. The body
  frame is forward, starboard, down.
- Depths are positive down. Heights, including heave and separations, are
  positive up.

## Licence

MIT, see `LICENSE`.
