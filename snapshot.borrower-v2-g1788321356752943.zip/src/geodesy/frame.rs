//! Local level frames.
//!
//! Once a survey is under way everything is done in a local east north up
//! frame pinned to a point near the middle of the block. It keeps the numbers
//! small, the trigonometry linear, and the vertical axis genuinely vertical,
//! which a projected grid does not.

use super::ellipsoid::{ecef_to_geodetic, geodetic_to_ecef, Ecef, Ellipsoid, Geodetic};

/// A displacement in a local east north up frame, in metres.
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub struct Enu {
    /// East component.
    pub east: f64,
    /// North component.
    pub north: f64,
    /// Up component.
    pub up: f64,
}

impl Enu {
    /// Build from components.
    pub const fn new(east: f64, north: f64, up: f64) -> Self {
        Enu { east, north, up }
    }

    /// Length of the vector.
    pub fn norm(&self) -> f64 {
        (self.east * self.east + self.north * self.north + self.up * self.up).sqrt()
    }

    /// Length of the horizontal part only, which is what a positional
    /// uncertainty is quoted against.
    pub fn horizontal_norm(&self) -> f64 {
        (self.east * self.east + self.north * self.north).sqrt()
    }

    /// Scale the vector.
    pub fn scale(&self, k: f64) -> Enu {
        Enu {
            east: self.east * k,
            north: self.north * k,
            up: self.up * k,
        }
    }
}

impl std::ops::Add for Enu {
    type Output = Enu;
    fn add(self, other: Enu) -> Enu {
        Enu {
            east: self.east + other.east,
            north: self.north + other.north,
            up: self.up + other.up,
        }
    }
}

impl std::ops::Sub for Enu {
    type Output = Enu;
    fn sub(self, other: Enu) -> Enu {
        Enu {
            east: self.east - other.east,
            north: self.north - other.north,
            up: self.up - other.up,
        }
    }
}

/// A local level frame, tangent to the ellipsoid at `origin`.
#[derive(Debug, Clone, Copy)]
pub struct LocalFrame {
    /// The point the frame is pinned to.
    pub origin: Geodetic,
    /// Ellipsoid the origin is expressed on.
    pub ellipsoid: Ellipsoid,
    origin_ecef: Ecef,
    sin_lat: f64,
    cos_lat: f64,
    sin_lon: f64,
    cos_lon: f64,
}

impl LocalFrame {
    /// Pin a frame at a geodetic origin.
    pub fn new(origin: Geodetic, ellipsoid: Ellipsoid) -> Self {
        let (sin_lat, cos_lat) = origin.lat.sin_cos();
        let (sin_lon, cos_lon) = origin.lon.sin_cos();
        LocalFrame {
            origin,
            ellipsoid,
            origin_ecef: geodetic_to_ecef(origin, &ellipsoid),
            sin_lat,
            cos_lat,
            sin_lon,
            cos_lon,
        }
    }

    /// Displacement from the frame origin to a geodetic point.
    pub fn to_local(&self, p: Geodetic) -> Enu {
        let q = geodetic_to_ecef(p, &self.ellipsoid);
        let dx = q.x - self.origin_ecef.x;
        let dy = q.y - self.origin_ecef.y;
        let dz = q.z - self.origin_ecef.z;
        Enu {
            east: -self.sin_lon * dx + self.cos_lon * dy,
            north: -self.sin_lat * self.cos_lon * dx - self.sin_lat * self.sin_lon * dy
                + self.cos_lat * dz,
            up: self.cos_lat * self.cos_lon * dx
                + self.cos_lat * self.sin_lon * dy
                + self.sin_lat * dz,
        }
    }

    /// The geodetic point at a local displacement from the origin.
    pub fn to_geodetic(&self, v: Enu) -> Geodetic {
        let dx = -self.sin_lon * v.east - self.sin_lat * self.cos_lon * v.north
            + self.cos_lat * self.cos_lon * v.up;
        let dy = self.cos_lon * v.east - self.sin_lat * self.sin_lon * v.north
            + self.cos_lat * self.sin_lon * v.up;
        let dz = self.cos_lat * v.north + self.sin_lat * v.up;
        ecef_to_geodetic(
            Ecef {
                x: self.origin_ecef.x + dx,
                y: self.origin_ecef.y + dy,
                z: self.origin_ecef.z + dz,
            },
            &self.ellipsoid,
        )
    }
}
