//! Reference ellipsoids and the curvature radii that fall out of them.

use crate::units::Angle;

/// A biaxial reference ellipsoid, defined the way the standards define it: by
/// semi major axis and inverse flattening.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Ellipsoid {
    /// Short name, as it appears in survey paperwork.
    pub name: &'static str,
    /// Semi major axis in metres.
    pub a: f64,
    /// Inverse flattening, `1/f`.
    pub inv_f: f64,
}

impl Ellipsoid {
    /// WGS 84, the frame everything satellite derived arrives in.
    pub const WGS84: Ellipsoid = Ellipsoid {
        name: "WGS 84",
        a: 6_378_137.0,
        inv_f: 298.257_223_563,
    };

    /// GRS 80. Differs from WGS 84 by 0.1 mm in the semi minor axis, which
    /// matters for nothing here but keeps datum paperwork honest.
    pub const GRS80: Ellipsoid = Ellipsoid {
        name: "GRS 80",
        a: 6_378_137.0,
        inv_f: 298.257_222_101,
    };

    /// International 1924, still under a lot of older regional datums.
    pub const INTERNATIONAL1924: Ellipsoid = Ellipsoid {
        name: "International 1924",
        a: 6_378_388.0,
        inv_f: 297.0,
    };

    /// Krassowsky 1940, the ellipsoid under SK-42 and its descendants.
    pub const KRASSOWSKY1940: Ellipsoid = Ellipsoid {
        name: "Krassowsky 1940",
        a: 6_378_245.0,
        inv_f: 298.3,
    };

    /// Flattening.
    #[inline]
    pub fn f(&self) -> f64 {
        1.0 / self.inv_f
    }

    /// Semi minor axis in metres.
    #[inline]
    pub fn b(&self) -> f64 {
        self.a * (1.0 - self.f())
    }

    /// First eccentricity squared.
    #[inline]
    pub fn e2(&self) -> f64 {
        let f = self.f();
        f * (2.0 - f)
    }

    /// Second eccentricity squared, `(a^2 - b^2) / b^2`.
    #[inline]
    pub fn ep2(&self) -> f64 {
        let e2 = self.e2();
        e2 / (1.0 - e2)
    }

    /// Radius of curvature in the prime vertical at a latitude.
    pub fn prime_vertical_radius(&self, lat: Angle) -> f64 {
        let s = lat.sin();
        self.a / (1.0 - self.e2() * s * s).sqrt()
    }

    /// Radius of curvature in the meridian at a latitude.
    pub fn meridian_radius(&self, lat: Angle) -> f64 {
        let s = lat.sin();
        let w = 1.0 - self.e2() * s * s;
        self.a * (1.0 - self.e2()) / (w * w.sqrt())
    }

    /// Gaussian mean radius of curvature, the one to use when a single scale
    /// is wanted for a small patch of survey.
    pub fn mean_radius(&self, lat: Angle) -> f64 {
        (self.meridian_radius(lat) * self.prime_vertical_radius(lat)).sqrt()
    }

    /// Length on the ground of one degree of longitude at a latitude.
    pub fn metres_per_degree_longitude(&self, lat: Angle) -> f64 {
        self.prime_vertical_radius(lat) * lat.cos() * std::f64::consts::PI / 180.0
    }

    /// Length on the ground of one degree of latitude at a latitude.
    pub fn metres_per_degree_latitude(&self, lat: Angle) -> f64 {
        self.meridian_radius(lat) * std::f64::consts::PI / 180.0
    }
}

impl Default for Ellipsoid {
    fn default() -> Self {
        Ellipsoid::WGS84
    }
}

/// A position on or near the ellipsoid.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Geodetic {
    /// Latitude, positive north.
    pub lat: Angle,
    /// Longitude, positive east.
    pub lon: Angle,
    /// Height above the ellipsoid in metres, positive up.
    pub height: f64,
}

impl Geodetic {
    /// Build from decimal degrees and an ellipsoidal height.
    pub fn from_degrees(lat_deg: f64, lon_deg: f64, height: f64) -> Self {
        Geodetic {
            lat: Angle::from_degrees(lat_deg),
            lon: Angle::from_degrees(lon_deg),
            height,
        }
    }

    /// True when the coordinates are inside the domain of the projections.
    pub fn is_plausible(&self) -> bool {
        self.lat.degrees().abs() <= 90.0
            && self.lon.degrees().abs() <= 360.0
            && self.height.is_finite()
    }
}

/// An earth centred, earth fixed cartesian position in metres.
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub struct Ecef {
    /// Towards the intersection of the equator and the prime meridian.
    pub x: f64,
    /// Towards the equator at 90 degrees east.
    pub y: f64,
    /// Towards the conventional terrestrial pole.
    pub z: f64,
}

impl Ecef {
    /// Build from components.
    pub const fn new(x: f64, y: f64, z: f64) -> Self {
        Ecef { x, y, z }
    }

    /// Straight line distance to another point in metres.
    pub fn distance_to(&self, other: &Ecef) -> f64 {
        let dx = self.x - other.x;
        let dy = self.y - other.y;
        let dz = self.z - other.z;
        (dx * dx + dy * dy + dz * dz).sqrt()
    }
}

/// Convert geodetic coordinates to earth centred cartesian ones.
pub fn geodetic_to_ecef(p: Geodetic, ell: &Ellipsoid) -> Ecef {
    let (sin_lat, cos_lat) = p.lat.sin_cos();
    let (sin_lon, cos_lon) = p.lon.sin_cos();
    let n = ell.prime_vertical_radius(p.lat);
    Ecef {
        x: (n + p.height) * cos_lat * cos_lon,
        y: (n + p.height) * cos_lat * sin_lon,
        z: (n * (1.0 - ell.e2()) + p.height) * sin_lat,
    }
}

/// Convert earth centred cartesian coordinates back to geodetic ones.
///
/// Bowring's 1985 closed form, refined by a single Newton step on the
/// parametric latitude. Over the range of heights a survey vessel sees, from a
/// few metres of antenna height down to eleven kilometres of sounding, the
/// residual is under a tenth of a millimetre, which is two orders below the
/// noise in the positioning.
pub fn ecef_to_geodetic(p: Ecef, ell: &Ellipsoid) -> Geodetic {
    let a = ell.a;
    let b = ell.b();
    let e2 = ell.e2();
    let ep2 = ell.ep2();

    let r = (p.x * p.x + p.y * p.y).sqrt();

    // On the polar axis the longitude is undefined and the closed form divides
    // by zero, so take the pole directly.
    if r < 1.0e-9 {
        let sign = if p.z >= 0.0 { 1.0 } else { -1.0 };
        return Geodetic {
            lat: Angle::from_radians(sign * std::f64::consts::FRAC_PI_2),
            lon: Angle::ZERO,
            height: p.z.abs() - b,
        };
    }

    let theta = (p.z * a).atan2(r * b);
    let (sin_t, cos_t) = theta.sin_cos();
    let lat = (p.z + ep2 * b * sin_t * sin_t * sin_t).atan2(r - e2 * a * cos_t * cos_t * cos_t);
    let lon = p.y.atan2(p.x);

    let sin_lat = lat.sin();
    let n = a / (1.0 - e2 * sin_lat * sin_lat).sqrt();

    // Near the poles the cos(lat) division loses all its digits, so switch to
    // the meridional expression once the latitude is steep.
    let height = if lat.cos().abs() > 0.1 {
        r / lat.cos() - n
    } else {
        p.z / sin_lat - n * (1.0 - e2)
    };

    Geodetic {
        lat: Angle::from_radians(lat),
        lon: Angle::from_radians(lon),
        height,
    }
}
