//! Geodesics on the ellipsoid, by the Vincenty method.
//!
//! Line planning and crossline analysis both need a distance and a bearing
//! between two positions that are tens of kilometres apart, where a plane
//! approximation is already worth several metres. Vincenty converges in a
//! handful of iterations everywhere except on nearly antipodal pairs, which no
//! survey block ever contains.

use crate::error::{Error, Result};
use crate::units::Angle;

use super::ellipsoid::{Ellipsoid, Geodetic};

/// Iteration limit for the inverse problem.
const MAX_ITERATIONS: usize = 200;
/// Convergence threshold on the change in lambda, in radians.
const TOLERANCE: f64 = 1.0e-12;

/// The answer to the inverse geodesic problem.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Geodesic {
    /// Distance along the geodesic in metres.
    pub distance: f64,
    /// Azimuth at the first point, clockwise from true north.
    pub initial_bearing: Angle,
    /// Azimuth at the second point, clockwise from true north.
    pub final_bearing: Angle,
}

/// Distance and bearings between two points on an ellipsoid.
pub fn inverse(a: Geodetic, b: Geodetic, ell: &Ellipsoid) -> Result<Geodesic> {
    let f = ell.f();
    let semi_major = ell.a;
    let semi_minor = ell.b();

    let u1 = ((1.0 - f) * a.lat.radians().tan()).atan();
    let u2 = ((1.0 - f) * b.lat.radians().tan()).atan();
    let l = a.lon.delta_to(b.lon).radians();

    let (sin_u1, cos_u1) = u1.sin_cos();
    let (sin_u2, cos_u2) = u2.sin_cos();

    let mut lambda = l;
    let mut sin_sigma = 0.0;
    let mut cos_sigma = 0.0;
    let mut sigma = 0.0;
    let mut cos_sq_alpha = 0.0;
    let mut cos2_sigma_m = 0.0;
    let mut converged = false;

    for _ in 0..MAX_ITERATIONS {
        let (sin_lambda, cos_lambda) = lambda.sin_cos();
        sin_sigma = ((cos_u2 * sin_lambda).powi(2)
            + (cos_u1 * sin_u2 - sin_u1 * cos_u2 * cos_lambda).powi(2))
        .sqrt();

        // Coincident points: the bearings are undefined but the distance is
        // definitely zero, so say so rather than dividing by it.
        if sin_sigma == 0.0 {
            return Ok(Geodesic {
                distance: 0.0,
                initial_bearing: Angle::ZERO,
                final_bearing: Angle::ZERO,
            });
        }

        cos_sigma = sin_u1 * sin_u2 + cos_u1 * cos_u2 * cos_lambda;
        sigma = sin_sigma.atan2(cos_sigma);
        let sin_alpha = cos_u1 * cos_u2 * sin_lambda / sin_sigma;
        cos_sq_alpha = 1.0 - sin_alpha * sin_alpha;

        // On an equatorial line cos^2(alpha) is zero and the midpoint term
        // blows up. Zero is the value that collapses the series to the
        // equatorial form, which is the right answer there.
        cos2_sigma_m = if cos_sq_alpha.abs() < 1.0e-16 {
            0.0
        } else {
            cos_sigma - 2.0 * sin_u1 * sin_u2 / cos_sq_alpha
        };

        let c = f / 16.0 * cos_sq_alpha * (4.0 + f * (4.0 - 3.0 * cos_sq_alpha));
        let lambda_prev = lambda;
        lambda = l
            + (1.0 - c)
                * f
                * sin_alpha
                * (sigma
                    + c * sin_sigma
                        * (cos2_sigma_m
                            + c * cos_sigma * (-1.0 + 2.0 * cos2_sigma_m * cos2_sigma_m)));

        if (lambda - lambda_prev).abs() < TOLERANCE {
            converged = true;
            break;
        }
    }

    if !converged {
        return Err(Error::Config(
            "vincenty inverse did not converge, the points are close to antipodal".into(),
        ));
    }

    let u_sq = cos_sq_alpha * (semi_major * semi_major - semi_minor * semi_minor)
        / (semi_minor * semi_minor);
    let big_a = 1.0 + u_sq / 16384.0 * (4096.0 + u_sq * (-768.0 + u_sq * (320.0 - 175.0 * u_sq)));
    let big_b = u_sq / 1024.0 * (256.0 + u_sq * (-128.0 + u_sq * (74.0 - 47.0 * u_sq)));
    let delta_sigma = big_b
        * sin_sigma
        * (cos2_sigma_m
            + big_b / 4.0
                * (cos_sigma * (-1.0 + 2.0 * cos2_sigma_m * cos2_sigma_m)
                    - big_b / 6.0
                        * cos2_sigma_m
                        * (-3.0 + 4.0 * sin_sigma * sin_sigma)
                        * (-3.0 + 4.0 * cos2_sigma_m * cos2_sigma_m)));

    let (sin_lambda, cos_lambda) = lambda.sin_cos();
    Ok(Geodesic {
        distance: semi_minor * big_a * (sigma - delta_sigma),
        initial_bearing: Angle::from_radians(
            (cos_u2 * sin_lambda).atan2(cos_u1 * sin_u2 - sin_u1 * cos_u2 * cos_lambda),
        )
        .wrapped(),
        final_bearing: Angle::from_radians(
            (cos_u1 * sin_lambda).atan2(-sin_u1 * cos_u2 + cos_u1 * sin_u2 * cos_lambda),
        )
        .wrapped(),
    })
}

/// Position reached by running a bearing and a distance out from a point.
pub fn direct(start: Geodetic, bearing: Angle, distance: f64, ell: &Ellipsoid) -> Geodetic {
    let f = ell.f();
    let semi_major = ell.a;
    let semi_minor = ell.b();

    let (sin_alpha1, cos_alpha1) = bearing.sin_cos();
    let tan_u1 = (1.0 - f) * start.lat.radians().tan();
    let cos_u1 = 1.0 / (1.0 + tan_u1 * tan_u1).sqrt();
    let sin_u1 = tan_u1 * cos_u1;

    let sigma1 = tan_u1.atan2(cos_alpha1);
    let sin_alpha = cos_u1 * sin_alpha1;
    let cos_sq_alpha = 1.0 - sin_alpha * sin_alpha;
    let u_sq = cos_sq_alpha * (semi_major * semi_major - semi_minor * semi_minor)
        / (semi_minor * semi_minor);
    let big_a = 1.0 + u_sq / 16384.0 * (4096.0 + u_sq * (-768.0 + u_sq * (320.0 - 175.0 * u_sq)));
    let big_b = u_sq / 1024.0 * (256.0 + u_sq * (-128.0 + u_sq * (74.0 - 47.0 * u_sq)));

    let mut sigma = distance / (semi_minor * big_a);
    let mut sin_sigma = 0.0;
    let mut cos_sigma = 0.0;
    let mut cos2_sigma_m = 0.0;

    for _ in 0..MAX_ITERATIONS {
        cos2_sigma_m = (2.0 * sigma1 + sigma).cos();
        let (ss, cs) = sigma.sin_cos();
        sin_sigma = ss;
        cos_sigma = cs;
        let delta_sigma = big_b
            * sin_sigma
            * (cos2_sigma_m
                + big_b / 4.0
                    * (cos_sigma * (-1.0 + 2.0 * cos2_sigma_m * cos2_sigma_m)
                        - big_b / 6.0
                            * cos2_sigma_m
                            * (-3.0 + 4.0 * sin_sigma * sin_sigma)
                            * (-3.0 + 4.0 * cos2_sigma_m * cos2_sigma_m)));
        let sigma_next = distance / (semi_minor * big_a) + delta_sigma;
        let converged = (sigma_next - sigma).abs() < TOLERANCE;
        sigma = sigma_next;
        if converged {
            break;
        }
    }

    let tmp = sin_u1 * sin_sigma - cos_u1 * cos_sigma * cos_alpha1;
    let lat = (sin_u1 * cos_sigma + cos_u1 * sin_sigma * cos_alpha1)
        .atan2((1.0 - f) * (sin_alpha * sin_alpha + tmp * tmp).sqrt());
    let lambda =
        (sin_sigma * sin_alpha1).atan2(cos_u1 * cos_sigma - sin_u1 * sin_sigma * cos_alpha1);
    let c = f / 16.0 * cos_sq_alpha * (4.0 + f * (4.0 - 3.0 * cos_sq_alpha));
    let l = lambda
        - (1.0 - c)
            * f
            * sin_alpha
            * (sigma
                + c * sin_sigma
                    * (cos2_sigma_m + c * cos_sigma * (-1.0 + 2.0 * cos2_sigma_m * cos2_sigma_m)));

    Geodetic {
        lat: Angle::from_radians(lat),
        lon: Angle::from_radians(start.lon.radians() + l).wrapped_signed(),
        height: start.height,
    }
}
