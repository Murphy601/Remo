//! Reference frames.
//!
//! A sounding is born in the transducer frame, gets rotated into a local level
//! frame, and has to end up in a projected grid before it can be gridded.
//! These are the pieces that move between those frames.

pub mod ellipsoid;
pub mod frame;
pub mod utm;
pub mod vincenty;

pub use ellipsoid::{ecef_to_geodetic, geodetic_to_ecef, Ecef, Ellipsoid, Geodetic};
pub use frame::{Enu, LocalFrame};
pub use utm::{Projected, TransverseMercator};
pub use vincenty::{direct, inverse, Geodesic};
