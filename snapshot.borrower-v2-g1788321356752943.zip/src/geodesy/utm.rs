//! Transverse Mercator, in the UTM arrangement.
//!
//! The series here is the one in Snyder's Map Projections, truncated at the
//! sixth order term. Inside the 3 degree half width of a UTM zone it agrees
//! with the exact projection to well under a millimetre, and it stays sane out
//! to about 6 degrees from the central meridian, which covers the zone
//! overlaps a survey line inevitably crosses.

use crate::error::{Error, Result};
use crate::units::Angle;

use super::ellipsoid::{Ellipsoid, Geodetic};

/// Scale factor on the central meridian of a UTM zone.
pub const UTM_SCALE_FACTOR: f64 = 0.9996;
/// False easting applied in every UTM zone, in metres.
pub const UTM_FALSE_EASTING: f64 = 500_000.0;
/// False northing applied in southern hemisphere zones, in metres.
pub const UTM_FALSE_NORTHING_SOUTH: f64 = 10_000_000.0;

/// A transverse Mercator projection with all its parameters pinned down.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct TransverseMercator {
    /// Ellipsoid the projection is defined on.
    pub ellipsoid: Ellipsoid,
    /// Longitude of the central meridian.
    pub central_meridian: Angle,
    /// Latitude the northings are measured from.
    pub latitude_of_origin: Angle,
    /// Scale factor on the central meridian.
    pub scale_factor: f64,
    /// False easting in metres.
    pub false_easting: f64,
    /// False northing in metres.
    pub false_northing: f64,
}

/// A projected coordinate in metres.
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub struct Projected {
    /// Easting.
    pub east: f64,
    /// Northing.
    pub north: f64,
}

impl Projected {
    /// Build from components.
    pub const fn new(east: f64, north: f64) -> Self {
        Projected { east, north }
    }

    /// Plane distance to another projected point.
    pub fn distance_to(&self, other: &Projected) -> f64 {
        let de = self.east - other.east;
        let dn = self.north - other.north;
        (de * de + dn * dn).sqrt()
    }
}

impl TransverseMercator {
    /// The UTM zone that covers a longitude, 1 to 60.
    pub fn zone_for_longitude(lon: Angle) -> u8 {
        // Normalise into [-180, 180) and not into (-180, 180]. The dateline
        // itself belongs to zone 1, and the signed wrap would hand it to
        // zone 60 instead.
        let mut deg = lon.wrapped().degrees();
        if deg >= 180.0 {
            deg -= 360.0;
        }
        let z = ((deg + 180.0) / 6.0).floor() as i32 + 1;
        z.clamp(1, 60) as u8
    }

    /// Central meridian of a UTM zone.
    pub fn zone_central_meridian(zone: u8) -> Angle {
        Angle::from_degrees(-183.0 + 6.0 * zone as f64)
    }

    /// Build the projection for a UTM zone and hemisphere.
    pub fn utm(zone: u8, north_hemisphere: bool, ellipsoid: Ellipsoid) -> Result<Self> {
        if !(1..=60).contains(&zone) {
            return Err(Error::domain("utm zone", zone as f64, "1 to 60"));
        }
        Ok(TransverseMercator {
            ellipsoid,
            central_meridian: Self::zone_central_meridian(zone),
            latitude_of_origin: Angle::ZERO,
            scale_factor: UTM_SCALE_FACTOR,
            false_easting: UTM_FALSE_EASTING,
            false_northing: if north_hemisphere {
                0.0
            } else {
                UTM_FALSE_NORTHING_SOUTH
            },
        })
    }

    /// Pick the UTM zone a position falls in and build that projection.
    pub fn utm_for(p: Geodetic, ellipsoid: Ellipsoid) -> Result<Self> {
        let zone = Self::zone_for_longitude(p.lon);
        Self::utm(zone, p.lat.radians() >= 0.0, ellipsoid)
    }

    /// Meridional arc length from the equator to a latitude.
    fn meridian_arc(&self, lat: Angle) -> f64 {
        let e2 = self.ellipsoid.e2();
        let e4 = e2 * e2;
        let e6 = e4 * e2;
        let a = self.ellipsoid.a;
        let phi = lat.radians();
        a * ((1.0 - e2 / 4.0 - 3.0 * e4 / 64.0 - 5.0 * e6 / 256.0) * phi
            - (3.0 * e2 / 8.0 + 3.0 * e4 / 32.0 + 45.0 * e6 / 1024.0) * (2.0 * phi).sin()
            + (15.0 * e4 / 256.0 + 45.0 * e6 / 1024.0) * (4.0 * phi).sin()
            - (35.0 * e6 / 3072.0) * (6.0 * phi).sin())
    }

    /// Project a geodetic position onto the grid.
    ///
    /// The ellipsoidal height is ignored; a projection is a two dimensional
    /// object and mixing the height in here is how scale errors get hidden.
    pub fn forward(&self, p: Geodetic) -> Result<Projected> {
        if p.lat.degrees().abs() > 89.999 {
            return Err(Error::domain(
                "latitude",
                p.lat.degrees(),
                "within 89.999 degrees of the equator",
            ));
        }

        let e2 = self.ellipsoid.e2();
        let ep2 = self.ellipsoid.ep2();
        let (sin_lat, cos_lat) = p.lat.sin_cos();
        let tan_lat = sin_lat / cos_lat;

        let n = self.ellipsoid.a / (1.0 - e2 * sin_lat * sin_lat).sqrt();
        let t = tan_lat * tan_lat;
        let c = ep2 * cos_lat * cos_lat;
        let arc = self.central_meridian.delta_to(p.lon).radians() * cos_lat;

        let a2 = arc * arc;
        let a3 = a2 * arc;
        let a4 = a2 * a2;
        let a5 = a4 * arc;
        let a6 = a4 * a2;

        let east = self.scale_factor
            * n
            * (arc
                + (1.0 - t + c) * a3 / 6.0
                + (5.0 - 18.0 * t + t * t + 72.0 * c - 58.0 * ep2) * a5 / 120.0)
            + self.false_easting;

        let m = self.meridian_arc(p.lat);
        let m0 = self.meridian_arc(self.latitude_of_origin);
        let north = self.scale_factor
            * (m - m0
                + n * tan_lat
                    * (a2 / 2.0
                        + (5.0 - t + 9.0 * c + 4.0 * c * c) * a4 / 24.0
                        + (61.0 - 58.0 * t + t * t + 600.0 * c - 330.0 * ep2) * a6 / 720.0))
            + self.false_northing;

        Ok(Projected { east, north })
    }

    /// Footpoint latitude for a meridional arc length.
    ///
    /// The inverse of [`TransverseMercator::meridian_arc`], written as the
    /// standard series in the third flattening rather than as a Newton
    /// iteration, so the cost of the inverse projection does not depend on
    /// where on the ellipsoid you happen to be.
    fn footpoint_latitude(&self, m: f64) -> Angle {
        let e2 = self.ellipsoid.e2();
        let e1 = (1.0 - (1.0 - e2).sqrt()) / (1.0 + (1.0 - e2).sqrt());
        let e1_2 = e1 * e1;
        let e1_3 = e1_2 * e1;
        let e1_4 = e1_2 * e1_2;
        let mu = m
            / (self.ellipsoid.a
                * (1.0 - e2 / 4.0 - 3.0 * e2 * e2 / 64.0 - 5.0 * e2 * e2 * e2 / 256.0));
        Angle::from_radians(
            mu + (3.0 * e1 / 2.0 - 27.0 * e1_3 / 32.0) * (2.0 * mu).sin()
                + (21.0 * e1_2 / 16.0 - 55.0 * e1_4 / 32.0) * (4.0 * mu).sin()
                + (151.0 * e1_3 / 96.0) * (6.0 * mu).sin()
                + (1097.0 * e1_4 / 512.0) * (8.0 * mu).sin(),
        )
    }

    /// Unproject a grid coordinate back to geodetic.
    ///
    /// The returned height is always zero, because the projection never
    /// carried one in the first place.
    pub fn inverse(&self, p: Projected) -> Result<Geodetic> {
        let e2 = self.ellipsoid.e2();
        let ep2 = self.ellipsoid.ep2();
        let a = self.ellipsoid.a;

        let m = self.meridian_arc(self.latitude_of_origin)
            + (p.north - self.false_northing) / self.scale_factor;
        let phi1 = self.footpoint_latitude(m);

        let (sin1, cos1) = phi1.sin_cos();
        if cos1.abs() < 1.0e-12 {
            return Err(Error::domain(
                "northing",
                p.north,
                "a northing that does not land on a pole",
            ));
        }
        let tan1 = sin1 / cos1;

        let c1 = ep2 * cos1 * cos1;
        let t1 = tan1 * tan1;
        let w = 1.0 - e2 * sin1 * sin1;
        let n1 = a / w.sqrt();
        let r1 = a * (1.0 - e2) / (w * w.sqrt());
        let d = (p.east - self.false_easting) / (n1 * self.scale_factor);

        let d2 = d * d;
        let d3 = d2 * d;
        let d4 = d2 * d2;
        let d5 = d4 * d;
        let d6 = d4 * d2;

        let lat = phi1.radians()
            - (n1 * tan1 / r1)
                * (d2 / 2.0 - (5.0 + 3.0 * t1 + 10.0 * c1 - 4.0 * c1 * c1 - 9.0 * ep2) * d4 / 24.0
                    + (61.0 + 90.0 * t1 + 298.0 * c1 + 45.0 * t1 * t1
                        - 252.0 * ep2
                        - 3.0 * c1 * c1)
                        * d6
                        / 720.0);

        let lon = self.central_meridian.radians()
            + (d - (1.0 + 2.0 * t1 + c1) * d3 / 6.0
                + (5.0 - 2.0 * c1 + 28.0 * t1 - 3.0 * c1 * c1 + 8.0 * ep2 + 24.0 * t1 * t1) * d5
                    / 120.0)
                / cos1;

        Ok(Geodetic {
            lat: Angle::from_radians(lat),
            lon: Angle::from_radians(lon).wrapped_signed(),
            height: 0.0,
        })
    }

    /// Angle from grid north to true north at a position, positive east.
    ///
    /// A line steered on a grid heading is not on a true heading, and the
    /// difference reaches the better part of a degree at the edge of a zone in
    /// high latitudes. The attitude chain works in true, so this is what
    /// reconciles the two.
    pub fn convergence(&self, p: Geodetic) -> Angle {
        let (sin_lat, cos_lat) = p.lat.sin_cos();
        let tan_lat = sin_lat / cos_lat;
        let dlon = self.central_meridian.delta_to(p.lon).radians();
        let c = self.ellipsoid.ep2() * cos_lat * cos_lat;
        let t = tan_lat * tan_lat;
        let l = dlon * cos_lat;
        Angle::from_radians(
            dlon * sin_lat
                + dlon * sin_lat * l * l * (1.0 + 3.0 * c + 2.0 * c * c) / 3.0
                + dlon * sin_lat * l * l * l * l * (2.0 - t) / 15.0,
        )
    }

    /// Point scale factor, the ratio of a grid distance to a ground distance.
    pub fn point_scale(&self, p: Geodetic) -> f64 {
        let cos_lat = p.lat.cos();
        let tan_lat = p.lat.sin() / cos_lat;
        let t = tan_lat * tan_lat;
        let c = self.ellipsoid.ep2() * cos_lat * cos_lat;
        let l = self.central_meridian.delta_to(p.lon).radians() * cos_lat;
        let l2 = l * l;
        self.scale_factor
            * (1.0 + (1.0 + c) * l2 / 2.0 + (5.0 - 4.0 * t + 42.0 * c) * l2 * l2 / 24.0)
    }
}
