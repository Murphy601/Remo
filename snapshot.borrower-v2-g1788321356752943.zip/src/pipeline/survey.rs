//! From a set of reduced lines to a surface and a set of numbers about it.

use crate::config::survey::SurveyConfig;
use crate::error::{Error, Result};
use crate::geodesy::utm::{Projected, TransverseMercator};
use crate::grid::estimator::{render, DepthRaster, Estimator};
use crate::grid::geometry::GridGeometry;
use crate::grid::surface::Surface;
use crate::ping::sounding::Sounding;
use crate::qc::coverage::{analyse, Coverage};
use crate::tpu::s44::{self, Order};

use super::reduce_line::LineResult;

/// Everything the run produced, in the form a report wants it.
#[derive(Debug, Clone)]
pub struct SurveySummary {
    /// Name of the survey.
    pub name: String,
    /// How many lines were reduced.
    pub lines: usize,
    /// Soundings produced, accepted and rejected together.
    pub soundings: usize,
    /// Soundings that survived every rule.
    pub accepted: usize,
    /// Shallowest accepted depth.
    pub min_depth: f64,
    /// Deepest accepted depth.
    pub max_depth: f64,
    /// Largest vertical uncertainty on an accepted sounding.
    pub max_tvu: f64,
    /// Fraction of accepted soundings that meet the order, when there is one.
    pub order_compliance: Option<f64>,
    /// Coverage of the grid.
    pub coverage: Coverage,
    /// Cells with data.
    pub populated_cells: usize,
}

impl SurveySummary {
    /// Fraction of soundings that survived.
    pub fn acceptance_rate(&self) -> f64 {
        if self.soundings == 0 {
            0.0
        } else {
            self.accepted as f64 / self.soundings as f64
        }
    }
}

/// The projected bounding box of every accepted sounding in a set of results.
pub fn bounds(
    results: &[LineResult],
    projection: &TransverseMercator,
) -> Result<(Projected, Projected)> {
    let mut min = Projected::new(f64::INFINITY, f64::INFINITY);
    let mut max = Projected::new(f64::NEG_INFINITY, f64::NEG_INFINITY);
    let mut any = false;

    for result in results {
        for s in result.soundings.iter().filter(|s| s.is_accepted()) {
            let p = projection.forward(s.position)?;
            min.east = min.east.min(p.east);
            min.north = min.north.min(p.north);
            max.east = max.east.max(p.east);
            max.north = max.north.max(p.north);
            any = true;
        }
    }
    if !any {
        return Err(Error::Config(
            "there are no accepted soundings to grid".into(),
        ));
    }
    Ok((min, max))
}

/// Build a surface covering everything in the results.
///
/// The grid is grown by one cell in every direction so that soundings sitting
/// exactly on the far edge of the block still land inside it, rather than
/// being counted as outside and quietly lost.
pub fn build_surface(
    results: &[LineResult],
    config: &SurveyConfig,
    projection: TransverseMercator,
) -> Result<Surface> {
    let (min, max) = bounds(results, &projection)?;
    let cell = config.cell_size;
    let geometry = GridGeometry::covering(
        min.east - cell,
        min.north - cell,
        max.east + cell,
        max.north + cell,
        cell,
    )?;

    let mut surface = Surface::new(geometry, projection);
    for result in results {
        surface.add_all(&result.soundings)?;
    }
    Ok(surface)
}

/// Summarise a run.
pub fn summarise(
    results: &[LineResult],
    surface: &Surface,
    config: &SurveyConfig,
    estimator: Estimator,
) -> SurveySummary {
    let mut soundings = 0;
    let mut accepted = 0;
    let mut min_depth = f64::INFINITY;
    let mut max_depth = f64::NEG_INFINITY;
    let mut max_tvu: f64 = 0.0;
    let mut within_order = 0;

    for result in results {
        soundings += result.soundings.len();
        for s in result.soundings.iter().filter(|s| s.is_accepted()) {
            accepted += 1;
            min_depth = min_depth.min(s.depth);
            max_depth = max_depth.max(s.depth);
            max_tvu = max_tvu.max(s.tvu);
            if let Some(order) = config.order {
                if s44::check(s, order).passes() {
                    within_order += 1;
                }
            }
        }
    }

    let raster: DepthRaster = render(surface, estimator);
    let coverage = analyse(&raster, surface.geometry());

    SurveySummary {
        name: config.name.clone(),
        lines: results.len(),
        soundings,
        accepted,
        min_depth: if accepted == 0 { 0.0 } else { min_depth },
        max_depth: if accepted == 0 { 0.0 } else { max_depth },
        max_tvu,
        order_compliance: match (config.order, accepted) {
            (Some(_), n) if n > 0 => Some(within_order as f64 / n as f64),
            _ => None,
        },
        coverage,
        populated_cells: surface.populated_cells(),
    }
}

/// Every accepted sounding from every line, in one vector.
///
/// Copies rather than borrows because the caller almost always wants to sort
/// or write them and the alternative is a lifetime that infects the whole
/// export path for no benefit at this size.
pub fn accepted_soundings(results: &[LineResult]) -> Vec<Sounding> {
    results
        .iter()
        .flat_map(|r| r.soundings.iter().filter(|s| s.is_accepted()).copied())
        .collect()
}

/// The tightest order every accepted sounding in the run would pass.
pub fn achieved_order(results: &[LineResult]) -> Option<Order> {
    let mut worst: Option<Order> = None;
    for result in results {
        for s in result.soundings.iter().filter(|s| s.is_accepted()) {
            let best = s44::best_order(s)?;
            worst = Some(match worst {
                None => best,
                Some(w) => {
                    if s44::check(s, w).passes() {
                        w
                    } else {
                        best
                    }
                }
            });
        }
    }
    worst
}
