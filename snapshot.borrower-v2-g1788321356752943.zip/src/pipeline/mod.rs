//! Putting the stages together and running them over a survey.

pub mod parallel;
pub mod reduce_line;
pub mod survey;

pub use parallel::{reduce_lines, Progress, Threads};
pub use reduce_line::{LineResult, LineWarning, Pipeline};
pub use survey::{build_surface, summarise, SurveySummary};
