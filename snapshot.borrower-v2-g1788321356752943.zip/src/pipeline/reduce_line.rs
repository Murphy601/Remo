//! Running a whole line through the reduction.
//!
//! Everything the individual stages need is assembled here once per line and
//! then reused across every ping, because the expensive parts, choosing a cast
//! and building the vertical solution, do not change from one ping to the next
//! anything like as often as the naive loop would recompute them.

use crate::config::survey::SurveyConfig;
use crate::error::Result;
use crate::geodesy::utm::TransverseMercator;
use crate::geodesy::Ellipsoid;
use crate::motion::attitude::Attitude;
use crate::ping::line::Line;
use crate::ping::reduce::Reducer;
use crate::ping::sounding::{Sounding, SoundingStats};
use crate::qc::rules::{clean_ping, CleaningRules, CleaningTally, DepthWindow};
use crate::raytrace::table::RayTable;
use crate::svp::library::ProfileLibrary;
use crate::units::Angle;
use crate::vertical::reference::VerticalReference;

/// Something worth telling the operator about a line, short of a failure.
#[derive(Debug, Clone, PartialEq)]
pub enum LineWarning {
    /// The chosen cast was a long way from the ping in time.
    ProfileGap {
        /// Seconds between the ping and the cast.
        seconds: f64,
    },
    /// The chosen cast was a long way from the ping in position.
    ProfileDistance {
        /// Metres between the ping and the cast.
        metres: f64,
    },
    /// The line has a gap in it longer than a few pings.
    PingGap {
        /// Seconds of the gap.
        seconds: f64,
    },
    /// Every beam of some ping was rejected.
    EmptyPings {
        /// How many pings came out with nothing.
        count: usize,
    },
}

/// What came out of reducing one line.
#[derive(Debug, Clone)]
pub struct LineResult {
    /// Name of the line.
    pub name: String,
    /// Every sounding, including the rejected ones.
    pub soundings: Vec<Sounding>,
    /// Depth statistics over the accepted soundings.
    pub stats: SoundingStats,
    /// What the cleaning rules caught.
    pub tally: CleaningTally,
    /// Anything worth saying about the line.
    pub warnings: Vec<LineWarning>,
    /// Which cast was used, by label.
    pub profile_used: String,
}

/// Everything needed to reduce lines, borrowed for the run.
#[derive(Debug, Clone, Copy)]
pub struct Pipeline<'a> {
    /// The survey configuration.
    pub config: &'a SurveyConfig,
    /// The casts and the rule for choosing between them.
    pub profiles: &'a ProfileLibrary,
    /// How depths reach a datum.
    pub vertical: &'a VerticalReference,
    /// Ellipsoid the positions are on.
    pub ellipsoid: Ellipsoid,
}

impl Pipeline<'_> {
    /// The projection this configuration works in.
    pub fn projection(&self) -> Result<TransverseMercator> {
        TransverseMercator::utm(self.config.utm_zone, self.config.northern, self.ellipsoid)
    }

    /// The cleaning rules this configuration asks for.
    pub fn cleaning_rules(&self) -> CleaningRules {
        CleaningRules {
            window: DepthWindow::new(self.config.depth_window.0, self.config.depth_window.1),
            max_swath_angle: self.config.swath_limit,
            max_tvu: None,
            max_deviation: self.config.max_deviation,
            median_window: 7,
        }
    }

    /// Build the ray table this line wants, if one is worth building.
    ///
    /// Returns nothing when the line is short enough that the table costs more
    /// than it saves, or when the vessel geometry moves the acoustic centre
    /// with the roll, in which case the table would be rebuilt per ping and
    /// there is no point.
    fn build_table(
        &self,
        line: &Line,
        profile: &crate::svp::profile::SoundSpeedProfile,
    ) -> Option<RayTable> {
        if line.beam_count() < 5_000 {
            return None;
        }
        if self.config.vessel.transducer.starboard.abs() > 1.0e-6 {
            return None;
        }
        let depth = self
            .config
            .vessel
            .dynamic_transducer_depth(&Attitude::LEVEL)
            .max(0.0);
        let max_angle = Angle::from_degrees(self.config.swath_limit.unwrap_or(75.0).min(85.0));
        let max_time = line.max_two_way_time() / 2.0 * 1.05;
        RayTable::build(
            profile,
            depth,
            max_angle,
            max_time,
            Angle::from_degrees(0.25),
            0.005,
        )
        .ok()
    }

    /// Reduce one line.
    pub fn reduce_line(&self, line: &Line) -> Result<LineResult> {
        let mut warnings = Vec::new();

        // One cast for the whole line, chosen at the middle of it. Switching
        // cast part way through a line puts a step in the seabed at the ping
        // where it changed, which is worse than being slightly stale at one
        // end of the line.
        let midpoint = line
            .span()
            .map(|s| s.start.offset(s.duration() / 2.0))
            .unwrap_or_else(|| line.start().unwrap_or(crate::time::Timestamp::EPOCH));
        let position = line
            .pings()
            .iter()
            .find_map(|p| p.navigation.map(|n| n.position));
        let entry = self.profiles.select(midpoint, position);
        let (dt, dx) = self.profiles.selection_gap(midpoint, position);
        if dt > 3.0 * 3600.0 {
            warnings.push(LineWarning::ProfileGap { seconds: dt });
        }
        if let Some(metres) = dx {
            if metres > 20_000.0 {
                warnings.push(LineWarning::ProfileDistance { metres });
            }
        }
        for gap in line.gaps(5.0) {
            warnings.push(LineWarning::PingGap {
                seconds: gap.duration(),
            });
        }

        // One table per line, sized from the widest beam and the longest
        // travel time actually present. Building it costs a few thousand
        // traces and saves one per beam for the rest of the line.
        let table = self.build_table(line, &entry.profile);

        let reducer = Reducer {
            vessel: &self.config.vessel,
            profile: &entry.profile,
            vertical: self.vertical,
            draft: &self.config.draft,
            ellipsoid: self.ellipsoid,
            budget: &self.config.budget,
            order: self.config.order,
            table: table.as_ref(),
        };
        let rules = self.cleaning_rules();

        let mut soundings = Vec::with_capacity(line.beam_count());
        let mut tally = CleaningTally::default();
        let mut empty_pings = 0;

        for ping in line.pings() {
            let mut ping = ping.clone();
            if let Some(limit) = self.config.swath_limit {
                ping.limit_swath(Angle::from_degrees(limit));
            }
            let mut reduced = reducer.reduce(&ping)?;
            let caught = clean_ping(&mut reduced, &rules);
            tally.outside_window += caught.outside_window;
            tally.outside_swath += caught.outside_swath;
            tally.too_uncertain += caught.too_uncertain;
            tally.outlier += caught.outlier;
            if reduced.iter().all(|s| !s.is_accepted()) {
                empty_pings += 1;
            }
            soundings.append(&mut reduced);
        }

        if empty_pings > 0 {
            warnings.push(LineWarning::EmptyPings { count: empty_pings });
        }

        Ok(LineResult {
            stats: SoundingStats::of(&soundings),
            name: line.name.clone(),
            soundings,
            tally,
            warnings,
            profile_used: entry.label.clone(),
        })
    }
}
