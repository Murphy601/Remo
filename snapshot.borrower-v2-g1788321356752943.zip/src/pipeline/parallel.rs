//! Running the lines of a survey across several threads.
//!
//! Lines are independent, which makes this the one place in the crate where
//! parallelism is worth anything and also the one place it is safe. Nothing is
//! shared mutably: each thread borrows the configuration and the casts, and
//! hands back a finished result.
//!
//! Scoped threads rather than a work stealing pool. A survey has tens of
//! lines, not millions of tasks, and the whole scheduling problem is dealt
//! with by handing every thread a stripe of the list.

use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Mutex;

use crate::error::Result;
use crate::ping::line::Line;

use super::reduce_line::{LineResult, Pipeline};

/// How many threads to run.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum Threads {
    /// One thread, which is also what a debugger wants.
    One,
    /// As many as the machine reports, capped at the number of lines.
    #[default]
    Available,
    /// A fixed number.
    Fixed(usize),
}

impl Threads {
    /// How many threads this actually means for a given amount of work.
    pub fn count(&self, lines: usize) -> usize {
        let wanted = match self {
            Threads::One => 1,
            Threads::Available => std::thread::available_parallelism()
                .map(std::num::NonZero::get)
                .unwrap_or(1),
            Threads::Fixed(n) => *n,
        };
        wanted.clamp(1, lines.max(1))
    }
}

/// Progress as a run goes along, safe to read from another thread.
#[derive(Debug, Default)]
pub struct Progress {
    lines_done: AtomicUsize,
    soundings: AtomicUsize,
}

impl Progress {
    /// A fresh counter.
    pub fn new() -> Self {
        Progress::default()
    }

    /// How many lines have finished.
    pub fn lines_done(&self) -> usize {
        self.lines_done.load(Ordering::Relaxed)
    }

    /// How many soundings have been produced.
    pub fn soundings(&self) -> usize {
        self.soundings.load(Ordering::Relaxed)
    }

    fn record(&self, result: &LineResult) {
        self.lines_done.fetch_add(1, Ordering::Relaxed);
        self.soundings
            .fetch_add(result.soundings.len(), Ordering::Relaxed);
    }
}

/// Reduce every line, in parallel, keeping the input order in the output.
///
/// The first failure stops the run and is returned; the rest of the lines are
/// abandoned. That is the right behaviour for a configuration mistake, which
/// is what almost every failure here turns out to be, and the wrong one for a
/// single corrupt file, which is why a corrupt file produces flagged soundings
/// and not an error.
pub fn reduce_lines(
    pipeline: &Pipeline<'_>,
    lines: &[Line],
    threads: Threads,
    progress: &Progress,
) -> Result<Vec<LineResult>> {
    let count = threads.count(lines.len());
    if lines.is_empty() {
        return Ok(Vec::new());
    }
    if count == 1 {
        let mut out = Vec::with_capacity(lines.len());
        for line in lines {
            let result = pipeline.reduce_line(line)?;
            progress.record(&result);
            out.push(result);
        }
        return Ok(out);
    }

    // One slot per line, filled in place, so the order of the output does not
    // depend on which thread happened to finish first. A survey report that
    // lists its lines in a different order on every run is not reproducible.
    let slots: Vec<Mutex<Option<Result<LineResult>>>> =
        (0..lines.len()).map(|_| Mutex::new(None)).collect();

    std::thread::scope(|scope| {
        for stripe in 0..count {
            let slots = &slots;
            let progress = &progress;
            scope.spawn(move || {
                for (index, line) in lines.iter().enumerate().skip(stripe).step_by(count) {
                    let result = pipeline.reduce_line(line);
                    if let Ok(ref r) = result {
                        progress.record(r);
                    }
                    *slots[index].lock().expect("a worker panicked") = Some(result);
                }
            });
        }
    });

    let mut out = Vec::with_capacity(lines.len());
    for slot in slots {
        match slot.into_inner().expect("a worker panicked") {
            Some(Ok(result)) => out.push(result),
            Some(Err(e)) => return Err(e),
            None => {
                return Err(crate::Error::Config(
                    "a line was never processed, which should not be possible".into(),
                ))
            }
        }
    }
    Ok(out)
}
