//! The area to be surveyed.
//!
//! A block is a closed polygon in projected coordinates. Everything about
//! planning depends on being able to ask two questions of it, whether a point
//! is inside and where a straight line crosses it, so those are what this
//! provides and nothing else.

use crate::error::{Error, Result};
use crate::geodesy::utm::Projected;

/// A closed polygon.
#[derive(Debug, Clone, PartialEq)]
pub struct Block {
    /// Name of the block, carried into the plan.
    pub name: String,
    corners: Vec<Projected>,
}

impl Block {
    /// Build a block from its corners.
    ///
    /// The polygon is closed implicitly, so the last corner does not have to
    /// repeat the first. A repeated closing corner is accepted and dropped,
    /// because half the files in the world have one and half do not.
    pub fn new(name: impl Into<String>, mut corners: Vec<Projected>) -> Result<Self> {
        if corners.len() >= 2 {
            let first = corners[0];
            let last = corners[corners.len() - 1];
            if (first.east - last.east).abs() < 1.0e-9 && (first.north - last.north).abs() < 1.0e-9
            {
                corners.pop();
            }
        }
        if corners.len() < 3 {
            return Err(Error::Config(
                "a survey block needs at least three corners".into(),
            ));
        }
        Ok(Block {
            name: name.into(),
            corners,
        })
    }

    /// A rectangular block, which is what most jobs actually are.
    pub fn rectangle(
        name: impl Into<String>,
        min_east: f64,
        min_north: f64,
        max_east: f64,
        max_north: f64,
    ) -> Result<Self> {
        Block::new(
            name,
            vec![
                Projected::new(min_east, min_north),
                Projected::new(max_east, min_north),
                Projected::new(max_east, max_north),
                Projected::new(min_east, max_north),
            ],
        )
    }

    /// The corners, in the order they were given.
    pub fn corners(&self) -> &[Projected] {
        &self.corners
    }

    /// Bounding box, as the lower left and upper right corners.
    pub fn bounds(&self) -> (Projected, Projected) {
        let mut min = Projected::new(f64::INFINITY, f64::INFINITY);
        let mut max = Projected::new(f64::NEG_INFINITY, f64::NEG_INFINITY);
        for c in &self.corners {
            min.east = min.east.min(c.east);
            min.north = min.north.min(c.north);
            max.east = max.east.max(c.east);
            max.north = max.north.max(c.north);
        }
        (min, max)
    }

    /// Area in square metres, by the shoelace formula.
    ///
    /// The absolute value is taken, so a block whose corners run clockwise
    /// comes back with the same area as one that runs the other way. Nothing
    /// here cares about winding.
    pub fn area(&self) -> f64 {
        let mut sum = 0.0;
        for i in 0..self.corners.len() {
            let a = self.corners[i];
            let b = self.corners[(i + 1) % self.corners.len()];
            sum += a.east * b.north - b.east * a.north;
        }
        sum.abs() / 2.0
    }

    /// Length of the boundary in metres.
    pub fn perimeter(&self) -> f64 {
        let mut total = 0.0;
        for i in 0..self.corners.len() {
            let a = self.corners[i];
            let b = self.corners[(i + 1) % self.corners.len()];
            total += a.distance_to(&b);
        }
        total
    }

    /// True when a point is inside the polygon.
    ///
    /// Ray casting along the positive easting axis, counting crossings. A
    /// point exactly on an edge may come back either way, which is fine: a
    /// planned line that starts a millimetre outside the block is not a
    /// problem anybody has.
    pub fn contains(&self, point: Projected) -> bool {
        let mut inside = false;
        let n = self.corners.len();
        for i in 0..n {
            let a = self.corners[i];
            let b = self.corners[(i + 1) % n];
            let crosses = (a.north > point.north) != (b.north > point.north);
            if crosses {
                let t = (point.north - a.north) / (b.north - a.north);
                if point.east < a.east + t * (b.east - a.east) {
                    inside = !inside;
                }
            }
        }
        inside
    }

    /// Where an infinite line crosses the boundary, as distances along it.
    ///
    /// The line is given as a point and a unit direction. The returned values
    /// are sorted, so consecutive pairs bound the parts of the line that are
    /// inside the polygon for any polygon without self intersections.
    pub fn crossings(&self, origin: Projected, direction: (f64, f64)) -> Vec<f64> {
        let mut hits = Vec::new();
        let n = self.corners.len();
        for i in 0..n {
            let a = self.corners[i];
            let b = self.corners[(i + 1) % n];
            let edge = (b.east - a.east, b.north - a.north);
            let denominator = direction.0 * edge.1 - direction.1 * edge.0;
            if denominator.abs() < 1.0e-12 {
                continue;
            }
            let dx = a.east - origin.east;
            let dy = a.north - origin.north;
            let along_edge = (dx * direction.1 - dy * direction.0) / denominator;
            if !(0.0..1.0).contains(&along_edge) {
                continue;
            }
            let along_line = (dx * edge.1 - dy * edge.0) / denominator;
            hits.push(along_line);
        }
        hits.sort_by(f64::total_cmp);
        hits
    }
}
