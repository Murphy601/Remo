//! Planning the lines before anything gets wet.

pub mod block;
pub mod lines;

pub use block::Block;
pub use lines::{plan_crosslines, plan_lines, spacing_for, Plan, PlannedLine};
