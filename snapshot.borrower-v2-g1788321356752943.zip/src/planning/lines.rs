//! Laying out the run lines.
//!
//! Line spacing is the one number a survey plan turns on. Too wide and there
//! are gaps between the swaths that have to be filled later at twice the cost;
//! too narrow and half the time is spent surveying the same seabed twice. It
//! comes from the shallowest depth in the block, because that is where the
//! swath is narrowest, and from the angular limit the specification allows.

use crate::error::{Error, Result};
use crate::geodesy::utm::Projected;
use crate::units::Angle;

use super::block::Block;

/// One planned run line.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct PlannedLine {
    /// Line number, counting from one across the block.
    pub number: usize,
    /// Where the line starts.
    pub start: Projected,
    /// Where it ends.
    pub end: Projected,
}

impl PlannedLine {
    /// Length in metres.
    pub fn length(&self) -> f64 {
        self.start.distance_to(&self.end)
    }

    /// Heading from start to end, clockwise from grid north.
    pub fn heading(&self) -> Angle {
        Angle::from_radians(
            (self.end.east - self.start.east).atan2(self.end.north - self.start.north),
        )
        .wrapped()
    }

    /// The line with its ends swapped, for running it the other way.
    pub fn reversed(&self) -> PlannedLine {
        PlannedLine {
            number: self.number,
            start: self.end,
            end: self.start,
        }
    }
}

/// A whole plan.
#[derive(Debug, Clone, PartialEq)]
pub struct Plan {
    /// Name of the block.
    pub block: String,
    /// Spacing between lines in metres.
    pub spacing: f64,
    /// Heading the lines run on.
    pub heading: Angle,
    /// The lines, in the order they should be run.
    pub lines: Vec<PlannedLine>,
}

impl Plan {
    /// Total distance on line, in metres.
    pub fn line_length(&self) -> f64 {
        self.lines.iter().map(PlannedLine::length).sum()
    }

    /// Distance spent turning between lines, in metres.
    ///
    /// Counted as the straight run from the end of one line to the start of
    /// the next, which understates a real turn and is the number every
    /// estimate uses anyway.
    pub fn turn_length(&self) -> f64 {
        self.lines
            .windows(2)
            .map(|w| w[0].end.distance_to(&w[1].start))
            .sum()
    }

    /// Hours to run the plan at a survey speed in metres per second.
    pub fn hours_at(&self, speed: f64) -> f64 {
        if speed <= 0.0 {
            return f64::INFINITY;
        }
        (self.line_length() + self.turn_length()) / speed / 3600.0
    }

    /// Reverse every other line, which is how a plan is actually run.
    pub fn alternate_directions(&mut self) {
        for (i, line) in self.lines.iter_mut().enumerate() {
            if i % 2 == 1 {
                *line = line.reversed();
            }
        }
    }
}

/// Line spacing that gives a wanted overlap at a depth.
///
/// The swath at a depth is twice the depth times the tangent of the angular
/// limit. Overlap is the fraction of a swath that the next line repeats, so a
/// twenty percent overlap means the spacing is eight tenths of the swath.
pub fn spacing_for(depth: f64, swath_half_angle: Angle, overlap: f64) -> Result<f64> {
    if depth <= 0.0 {
        return Err(Error::domain("depth", depth, "positive"));
    }
    if !(0.0..0.95).contains(&overlap) {
        return Err(Error::domain("overlap", overlap, "between 0 and 0.95"));
    }
    let half = swath_half_angle.degrees();
    if !(0.0..89.0).contains(&half) {
        return Err(Error::domain("swath half angle", half, "between 0 and 89"));
    }
    Ok(2.0 * depth * swath_half_angle.tan() * (1.0 - overlap))
}

/// Lay lines across a block.
///
/// Lines run on `heading` and are spaced across it. The first line is placed
/// half a spacing in from the edge of the bounding box, so that the swath of
/// the outermost line covers the boundary rather than being centred on it.
pub fn plan_lines(block: &Block, heading: Angle, spacing: f64) -> Result<Plan> {
    if !(spacing.is_finite() && spacing > 0.0) {
        return Err(Error::domain("spacing", spacing, "finite and positive"));
    }
    let (min, max) = block.bounds();
    let diagonal = min.distance_to(&max);
    let centre = Projected::new((min.east + max.east) / 2.0, (min.north + max.north) / 2.0);

    let (sin_hd, cos_hd) = heading.sin_cos();
    let along = (sin_hd, cos_hd);
    let across = (cos_hd, -sin_hd);

    let half_width = diagonal / 2.0 + spacing;
    let count = (2.0 * half_width / spacing).ceil() as usize;

    let mut offsets: Vec<f64> = (0..count)
        .map(|i| -half_width + spacing * (i as f64 + 0.5))
        .collect();

    let mut lines = Vec::new();
    for offset in offsets.drain(..) {
        let origin = Projected::new(
            centre.east + across.0 * offset - along.0 * diagonal,
            centre.north + across.1 * offset - along.1 * diagonal,
        );
        let hits = block.crossings(origin, along);
        if hits.len() < 2 {
            continue;
        }
        let first = hits[0];
        let last = hits[hits.len() - 1];
        if (last - first) < spacing * 0.05 {
            continue;
        }
        lines.push(PlannedLine {
            number: lines.len() + 1,
            start: Projected::new(
                origin.east + along.0 * first,
                origin.north + along.1 * first,
            ),
            end: Projected::new(origin.east + along.0 * last, origin.north + along.1 * last),
        });
    }

    // A spacing wider than the block can put every offset outside it and plan
    // nothing at all. One line down the middle is the right answer there: the
    // block is narrower than a single swath and one pass covers it.
    if lines.is_empty() {
        let origin = Projected::new(
            centre.east - along.0 * diagonal,
            centre.north - along.1 * diagonal,
        );
        let hits = block.crossings(origin, along);
        if hits.len() >= 2 {
            let first = hits[0];
            let last = hits[hits.len() - 1];
            lines.push(PlannedLine {
                number: 1,
                start: Projected::new(
                    origin.east + along.0 * first,
                    origin.north + along.1 * first,
                ),
                end: Projected::new(origin.east + along.0 * last, origin.north + along.1 * last),
            });
        }
    }

    if lines.is_empty() {
        return Err(Error::Config(
            "no lines fit in this block, check the spacing against its size".into(),
        ));
    }
    Ok(Plan {
        block: block.name.clone(),
        spacing,
        heading: heading.wrapped(),
        lines,
    })
}

/// Crosslines: a few lines run across the main scheme for the independent
/// check.
///
/// Convention is one crossline for every fifteen or so main lines, and never
/// fewer than two, because one crossline that disagrees tells you there is a
/// problem and nothing about where.
pub fn plan_crosslines(block: &Block, main: &Plan) -> Result<Plan> {
    let wanted = (main.lines.len() / 15).max(2);
    let (min, max) = block.bounds();
    let extent = min.distance_to(&max);
    let spacing = extent / wanted as f64;
    let heading = Angle::from_radians(main.heading.radians() + std::f64::consts::FRAC_PI_2);
    plan_lines(block, heading, spacing)
}
