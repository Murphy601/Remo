//! The output of the whole reduction: one depth, in one place, with an
//! uncertainty on it.

use crate::geodesy::Geodetic;
use crate::time::Timestamp;

use super::beam::{BeamFlags, Detection};

/// A reduced sounding.
///
/// Everything about the sounding is in here, including the identifiers that
/// take it back to the beam it came from, because the first thing anyone asks
/// about a suspicious depth is which ping it was in.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Sounding {
    /// Time of the ping that produced it.
    pub time: Timestamp,
    /// Sequence number of that ping.
    pub ping: u64,
    /// Beam number within the ping.
    pub beam: u16,
    /// Position of the sounding on the seabed.
    pub position: Geodetic,
    /// Depth below the vertical datum, positive down.
    pub depth: f64,
    /// Across track distance from the vessel, positive to starboard.
    pub across: f64,
    /// Along track distance from the vessel, positive forward.
    pub along: f64,
    /// Total vertical uncertainty at ninety five percent, in metres.
    pub tvu: f64,
    /// Total horizontal uncertainty at ninety five percent, in metres.
    pub thu: f64,
    /// How the bottom was detected.
    pub detection: Detection,
    /// Flags carried through from the beam.
    pub flags: BeamFlags,
}

impl Sounding {
    /// True when nothing has flagged this sounding out.
    pub fn is_accepted(&self) -> bool {
        self.flags.is_clear()
    }

    /// Horizontal distance from the vessel to the sounding.
    pub fn horizontal_range(&self) -> f64 {
        (self.across * self.across + self.along * self.along).sqrt()
    }

    /// Ratio of across track distance to depth, which is how a hydrographer
    /// thinks about where in the swath a sounding sits.
    pub fn swath_ratio(&self) -> f64 {
        if self.depth.abs() < 1.0e-6 {
            0.0
        } else {
            self.across / self.depth
        }
    }
}

/// Summary of a set of soundings, for the log and the report.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct SoundingStats {
    /// How many soundings were looked at.
    pub count: usize,
    /// How many of them are accepted.
    pub accepted: usize,
    /// Shallowest accepted depth.
    pub min_depth: f64,
    /// Deepest accepted depth.
    pub max_depth: f64,
    /// Mean accepted depth.
    pub mean_depth: f64,
    /// Largest accepted vertical uncertainty.
    pub max_tvu: f64,
}

impl SoundingStats {
    /// Summarise a slice of soundings.
    ///
    /// Rejected soundings are counted but contribute nothing to the depth
    /// statistics; a rejected beam is often rejected precisely because its
    /// depth is absurd, and letting it into the mean hides the good data.
    pub fn of(soundings: &[Sounding]) -> SoundingStats {
        let mut stats = SoundingStats {
            count: soundings.len(),
            accepted: 0,
            min_depth: f64::INFINITY,
            max_depth: f64::NEG_INFINITY,
            mean_depth: 0.0,
            max_tvu: 0.0,
        };
        let mut sum = 0.0;
        for s in soundings.iter().filter(|s| s.is_accepted()) {
            stats.accepted += 1;
            stats.min_depth = stats.min_depth.min(s.depth);
            stats.max_depth = stats.max_depth.max(s.depth);
            stats.max_tvu = stats.max_tvu.max(s.tvu);
            sum += s.depth;
        }
        if stats.accepted == 0 {
            stats.min_depth = 0.0;
            stats.max_depth = 0.0;
        } else {
            stats.mean_depth = sum / stats.accepted as f64;
        }
        stats
    }

    /// Fraction of soundings that survived, zero when there were none.
    pub fn acceptance_rate(&self) -> f64 {
        if self.count == 0 {
            0.0
        } else {
            self.accepted as f64 / self.count as f64
        }
    }
}
