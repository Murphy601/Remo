//! One beam of one ping, as it comes off the sonar.

use crate::units::Angle;

/// How the sonar decided there was a bottom in this beam.
///
/// Amplitude detection is used near nadir where the echo is short and strong,
/// phase detection further out where it is long and weak, and the changeover
/// is visible in the noise of the data, so it is worth carrying.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Detection {
    /// Amplitude detection, normally the inner beams.
    Amplitude,
    /// Phase detection, normally the outer beams.
    Phase,
    /// The sonar reported a detection but not which kind.
    Unknown,
    /// No bottom was found in this beam.
    None,
}

/// Reasons a beam can be set aside.
///
/// A flag is a bit rather than an enum because a beam is often rejected for
/// more than one reason and the report wants all of them; knowing that a beam
/// was both outside the swath limit and below the quality threshold says
/// something an ordered first reason does not.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct BeamFlags(u16);

impl BeamFlags {
    /// No flags at all: a good beam.
    pub const NONE: BeamFlags = BeamFlags(0);
    /// The sonar found no bottom.
    pub const NO_DETECTION: BeamFlags = BeamFlags(1 << 0);
    /// Beyond the angular limit set for the survey.
    pub const OUTSIDE_SWATH: BeamFlags = BeamFlags(1 << 1);
    /// Below the detection quality threshold.
    pub const LOW_QUALITY: BeamFlags = BeamFlags(1 << 2);
    /// The ray turned before the travel time ran out.
    pub const RAY_TURNED: BeamFlags = BeamFlags(1 << 3);
    /// No sound speed profile covers this ping.
    pub const NO_PROFILE: BeamFlags = BeamFlags(1 << 4);
    /// No attitude or position covers this ping.
    pub const NO_NAVIGATION: BeamFlags = BeamFlags(1 << 5);
    /// Rejected by hand in an editor.
    pub const MANUAL: BeamFlags = BeamFlags(1 << 6);
    /// Outside the depth window set for the survey.
    pub const OUTSIDE_DEPTH_WINDOW: BeamFlags = BeamFlags(1 << 7);
    /// Uncertainty above what the order allows.
    pub const FAILS_ORDER: BeamFlags = BeamFlags(1 << 8);

    /// True when no flag is set.
    pub fn is_clear(self) -> bool {
        self.0 == 0
    }

    /// True when any of the flags in `other` are set.
    pub fn has(self, other: BeamFlags) -> bool {
        self.0 & other.0 != 0
    }

    /// The union of two sets of flags.
    pub fn with(self, other: BeamFlags) -> BeamFlags {
        BeamFlags(self.0 | other.0)
    }

    /// Set flags in place.
    pub fn set(&mut self, other: BeamFlags) {
        self.0 |= other.0;
    }

    /// Clear flags in place.
    pub fn clear(&mut self, other: BeamFlags) {
        self.0 &= !other.0;
    }

    /// The raw bits, for writing to a file.
    pub fn bits(self) -> u16 {
        self.0
    }

    /// Rebuild from raw bits.
    pub fn from_bits(bits: u16) -> BeamFlags {
        BeamFlags(bits)
    }

    /// Names of every flag that is set, in bit order.
    pub fn names(self) -> Vec<&'static str> {
        const NAMES: [(u16, &str); 9] = [
            (1 << 0, "no detection"),
            (1 << 1, "outside swath"),
            (1 << 2, "low quality"),
            (1 << 3, "ray turned"),
            (1 << 4, "no profile"),
            (1 << 5, "no navigation"),
            (1 << 6, "manual"),
            (1 << 7, "outside depth window"),
            (1 << 8, "fails order"),
        ];
        NAMES
            .iter()
            .filter(|(bit, _)| self.0 & bit != 0)
            .map(|(_, name)| *name)
            .collect()
    }
}

/// A beam as the sonar reports it, before anything has been done to it.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Beam {
    /// Index of the beam within the ping, as the sonar numbered it.
    pub number: u16,
    /// Two way travel time in seconds.
    pub two_way_time: f64,
    /// Pointing angle in the transducer frame, from the vertical, positive to
    /// starboard.
    pub pointing_angle: Angle,
    /// Steering angle along track, positive forward. Zero on a flat array.
    pub steering_angle: Angle,
    /// Detection quality, as the sonar scales it, zero to one.
    pub quality: f32,
    /// How the bottom was detected.
    pub detection: Detection,
    /// Flags set so far.
    pub flags: BeamFlags,
}

impl Beam {
    /// Build a beam with no flags set.
    pub fn new(number: u16, two_way_time: f64, pointing_angle: Angle) -> Self {
        Beam {
            number,
            two_way_time,
            pointing_angle,
            steering_angle: Angle::ZERO,
            quality: 1.0,
            detection: Detection::Unknown,
            flags: BeamFlags::NONE,
        }
    }

    /// One way travel time, which is what the ray tracer wants.
    pub fn one_way_time(&self) -> f64 {
        self.two_way_time / 2.0
    }

    /// True when the beam is still usable.
    pub fn is_good(&self) -> bool {
        self.flags.is_clear() && self.detection != Detection::None && self.two_way_time > 0.0
    }
}
