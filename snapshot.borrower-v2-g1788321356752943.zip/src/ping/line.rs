//! A survey line: the pings between turning onto a heading and turning off it.
//!
//! Almost every decision in processing is made per line rather than per ping.
//! The sound speed cast in force, the tide zone, the vessel configuration and
//! the acceptance statistics are all line wide, and a line is the unit that
//! gets reprocessed when one of them turns out to be wrong.

use crate::time::{TimeSpan, Timestamp};

use super::record::Ping;

/// A run of pings acquired together.
#[derive(Debug, Clone, PartialEq)]
pub struct Line {
    /// Line name, normally the file name the pings came out of.
    pub name: String,
    /// The pings, in time order.
    pings: Vec<Ping>,
}

impl Line {
    /// Build a line, sorting the pings into time order.
    ///
    /// Sorting rather than trusting the file is deliberate. A logger that
    /// restarts mid line writes its buffer out of order, and every downstream
    /// interpolation assumes monotonic time.
    pub fn new(name: impl Into<String>, mut pings: Vec<Ping>) -> Self {
        pings.sort_by(|a, b| a.time.cmp(&b.time));
        Line {
            name: name.into(),
            pings,
        }
    }

    /// The pings.
    pub fn pings(&self) -> &[Ping] {
        &self.pings
    }

    /// The pings, mutably, for the stages that flag beams.
    pub fn pings_mut(&mut self) -> &mut [Ping] {
        &mut self.pings
    }

    /// How many pings the line holds.
    pub fn len(&self) -> usize {
        self.pings.len()
    }

    /// True when the line holds no pings at all.
    pub fn is_empty(&self) -> bool {
        self.pings.is_empty()
    }

    /// Time range the line covers.
    pub fn span(&self) -> Option<TimeSpan> {
        match (self.pings.first(), self.pings.last()) {
            (Some(a), Some(b)) => Some(TimeSpan::new(a.time, b.time)),
            _ => None,
        }
    }

    /// Time the line started.
    pub fn start(&self) -> Option<Timestamp> {
        self.pings.first().map(|p| p.time)
    }

    /// Total beams over every ping.
    pub fn beam_count(&self) -> usize {
        self.pings.iter().map(|p| p.beams.len()).sum()
    }

    /// Beams that are still usable.
    pub fn good_beam_count(&self) -> usize {
        self.pings.iter().map(Ping::good_beams).sum()
    }

    /// Mean interval between pings, which is the ping rate upside down.
    pub fn mean_ping_interval(&self) -> Option<f64> {
        let span = self.span()?;
        if self.pings.len() < 2 {
            return None;
        }
        Some(span.duration() / (self.pings.len() - 1) as f64)
    }

    /// Gaps between consecutive pings longer than a threshold.
    ///
    /// A line with a four second gap in the middle of it is two lines, and
    /// treating it as one hides a hole from the coverage analysis.
    pub fn gaps(&self, longer_than: f64) -> Vec<TimeSpan> {
        self.pings
            .windows(2)
            .filter(|w| w[1].time - w[0].time > longer_than)
            .map(|w| TimeSpan::new(w[0].time, w[1].time))
            .collect()
    }

    /// Longest two way travel time anywhere in the line, which sizes the ray
    /// table the line needs.
    pub fn max_two_way_time(&self) -> f64 {
        self.pings
            .iter()
            .map(Ping::max_two_way_time)
            .fold(0.0, f64::max)
    }

    /// Split the line at every gap longer than a threshold.
    ///
    /// The pieces keep the line name with an index appended, so a sounding can
    /// still be traced back to the file it came out of.
    pub fn split_at_gaps(self, longer_than: f64) -> Vec<Line> {
        if self.pings.len() < 2 {
            return vec![self];
        }
        let mut out = Vec::new();
        let mut current: Vec<Ping> = Vec::new();
        let name = self.name.clone();

        for ping in self.pings {
            if let Some(previous) = current.last() {
                if ping.time - previous.time > longer_than {
                    out.push(Line::new(
                        format!("{name} part {}", out.len() + 1),
                        std::mem::take(&mut current),
                    ));
                }
            }
            current.push(ping);
        }
        if !current.is_empty() {
            if out.is_empty() {
                return vec![Line::new(name, current)];
            }
            out.push(Line::new(format!("{name} part {}", out.len() + 1), current));
        }
        out
    }
}

impl Line {
    /// Pings that cannot be reduced, with what is wrong with each.
    ///
    /// Returned rather than logged, because a line with three bad pings and a
    /// line with thirty thousand are different problems and only the caller
    /// knows which one matters today.
    pub fn problems(&self) -> Vec<(usize, Vec<super::record::PingProblem>)> {
        self.pings
            .iter()
            .enumerate()
            .filter_map(|(i, p)| {
                let problems = p.validate();
                if problems.is_empty() {
                    None
                } else {
                    Some((i, problems))
                }
            })
            .collect()
    }

    /// True when the ping times never go backwards.
    ///
    /// Always true for a line built through [`Line::new`], which sorts. It is
    /// here for a line assembled some other way, and for the test that says
    /// the sort actually happens.
    pub fn is_monotonic(&self) -> bool {
        self.pings.windows(2).all(|w| w[0].time <= w[1].time)
    }
}
