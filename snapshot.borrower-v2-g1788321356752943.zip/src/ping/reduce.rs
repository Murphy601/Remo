//! Turning a ping into soundings.
//!
//! This is where the rest of the crate is assembled. For each beam the
//! pointing angle becomes a direction in space, the direction and the travel
//! time become a bent ray, the ray becomes a displacement from the transducer,
//! and the displacement becomes a position and a depth on a datum.

use crate::error::Result;
use crate::geodesy::{Ellipsoid, Geodetic, LocalFrame};
use crate::motion::rotation::Vec3;
use crate::motion::vessel::VesselGeometry;
use crate::raytrace::table::RayTable;
use crate::raytrace::Tracer;
use crate::svp::profile::SoundSpeedProfile;
use crate::tpu::propagate::{propagate, SoundingGeometry};
use crate::tpu::s44::{self, Order};
use crate::tpu::sensors::UncertaintyBudget;
use crate::units::Angle;
use crate::vertical::draft::DraftModel;
use crate::vertical::reference::{VerticalInput, VerticalReference};

use super::beam::{Beam, BeamFlags};
use super::record::{Navigation, Ping};
use super::sounding::Sounding;

/// Everything needed to reduce a ping, borrowed for the duration.
#[derive(Debug, Clone, Copy)]
pub struct Reducer<'a> {
    /// Where the sensors are on the boat.
    pub vessel: &'a VesselGeometry,
    /// Sound speed profile in force for this ping.
    pub profile: &'a SoundSpeedProfile,
    /// What the depths are referred to.
    pub vertical: &'a VerticalReference,
    /// Static and dynamic draft.
    pub draft: &'a DraftModel,
    /// Ellipsoid the positions are on.
    pub ellipsoid: Ellipsoid,
    /// One sigma uncertainty of every input.
    pub budget: &'a UncertaintyBudget,
    /// A precomputed table of rays, when one has been built for this profile.
    ///
    /// The table is built at one transducer depth. A vessel with an
    /// athwartships offset on the head moves its acoustic centre with the
    /// roll, so the table is only used when the dynamic depth agrees with the
    /// depth the table was built at to within a centimetre, and the full trace
    /// runs otherwise. That keeps the fast path fast and the slow path
    /// correct rather than choosing between them.
    pub table: Option<&'a RayTable>,
    /// Order to judge the soundings against, when the survey has one.
    ///
    /// A sounding that misses its order is flagged rather than dropped. It is
    /// still the best measurement of that patch of seabed that exists, and
    /// whether to keep it is a decision for whoever signs the report.
    pub order: Option<Order>,
}

/// Direction a beam points, resolved into a local level frame.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct BeamDirection {
    /// Angle from the vertical, always positive.
    pub from_vertical: Angle,
    /// Azimuth of the vertical plane the ray travels in, clockwise from north.
    pub azimuth: Angle,
}

/// Resolve a beam into a direction in the local level frame.
///
/// The pointing angle is measured in the transducer frame, so it goes through
/// the mounting angles first and the vessel attitude second. Doing those two
/// in the other order is a mistake that only shows up when the vessel is both
/// rolled and the transducer is misaligned, which is to say on the day the
/// patch test is being analysed.
pub fn beam_direction(beam: &Beam, nav: &Navigation, vessel: &VesselGeometry) -> BeamDirection {
    let (sin_steer, cos_steer) = beam.steering_angle.sin_cos();
    let (sin_point, cos_point) = beam.pointing_angle.sin_cos();
    let in_transducer = Vec3::new(sin_steer, cos_steer * sin_point, cos_steer * cos_point);

    let in_body = vessel.transducer_to_body(in_transducer);
    let ned = nav.attitude.rotate(in_body).normalised();

    let horizontal = (ned.x * ned.x + ned.y * ned.y).sqrt();
    BeamDirection {
        from_vertical: Angle::from_radians(horizontal.atan2(ned.z)),
        azimuth: Angle::from_radians(ned.y.atan2(ned.x)).wrapped(),
    }
}

/// Correct a launch angle for the sound speed the sonar steered with.
///
/// The sonar formed the beam using the speed its surface sensor reported. If
/// the profile disagrees with that sensor, and it always does a little, the
/// ray leaves the face at a different angle than the sonar thinks. Snell at
/// the transducer face is the whole correction.
pub fn refract_at_face(pointing: Angle, sensor_speed: f64, profile_speed: f64) -> Option<Angle> {
    if sensor_speed <= 0.0 || profile_speed <= 0.0 {
        return None;
    }
    let sin_new = pointing.sin() * profile_speed / sensor_speed;
    if sin_new.abs() >= 1.0 {
        return None;
    }
    Some(Angle::from_radians(sin_new.asin()))
}

impl Reducer<'_> {
    /// Reduce every beam of a ping.
    ///
    /// Beams that cannot be reduced come back flagged rather than missing, so
    /// that the beam count of a ping is the same before and after and a
    /// rejection can be counted.
    pub fn reduce(&self, ping: &Ping) -> Result<Vec<Sounding>> {
        let Some(nav) = ping.navigation else {
            let mut out = Vec::with_capacity(ping.beams.len());
            for b in &ping.beams {
                out.push(self.rejected(ping, b, BeamFlags::NO_NAVIGATION));
            }
            return Ok(out);
        };

        let transducer_depth = self.vessel.dynamic_transducer_depth(&nav.attitude).max(0.0);
        let solution = self.vertical.solve(
            VerticalInput {
                time: ping.time,
                position: nav.position,
                transducer_height: nav.transducer_height,
                heave: nav.heave,
                speed: nav.speed,
            },
            self.draft,
        )?;

        let tracer = Tracer::new(self.profile, transducer_depth)?;
        // A table built for a different transducer depth is not this table.
        let table_ready = self
            .table
            .filter(|t| (t.transducer_depth() - transducer_depth).abs() < 0.01);
        let frame = LocalFrame::new(nav.position, self.ellipsoid);
        let transducer_offset = self.vessel.transducer_offset_enu(&nav.attitude);
        let heading = nav.attitude.heading;

        let mut out = Vec::with_capacity(ping.beams.len());
        for beam in &ping.beams {
            if !beam.is_good() {
                out.push(self.rejected(ping, beam, beam.flags));
                continue;
            }

            let direction = beam_direction(beam, &nav, self.vessel);
            let Some(launch) = refract_at_face(
                direction.from_vertical,
                ping.surface_sound_speed,
                tracer.launch_speed(),
            ) else {
                out.push(self.rejected(ping, beam, BeamFlags::RAY_TURNED));
                continue;
            };

            let bent = match table_ready {
                Some(table) => table.lookup(launch, beam.one_way_time()),
                None => None,
            };
            let (depth_below_transducer, across) = match bent {
                Some(bend) => (bend.depth, bend.across),
                None => {
                    let ray = tracer.trace(launch, beam.one_way_time())?;
                    if ray.turned {
                        out.push(self.rejected(ping, beam, BeamFlags::RAY_TURNED));
                        continue;
                    }
                    (ray.depth - transducer_depth, ray.across)
                }
            };

            let (sin_az, cos_az) = direction.azimuth.sin_cos();
            let east = transducer_offset.east + across * sin_az;
            let north = transducer_offset.north + across * cos_az;
            let position = frame.to_geodetic(crate::geodesy::Enu::new(east, north, 0.0));

            let uncertainty = propagate(
                SoundingGeometry {
                    depth: depth_below_transducer,
                    across,
                    launch_angle: launch,
                    surface_speed: ping.surface_sound_speed,
                    mean_speed: self
                        .profile
                        .harmonic_mean_speed(depth_below_transducer + transducer_depth),
                    heave: nav.heave,
                    vessel_speed: nav.speed,
                    ellipsoidal: self.vertical.needs_height(),
                },
                self.budget,
            );

            let (sin_hd, cos_hd) = heading.sin_cos();
            let mut sounding = Sounding {
                time: ping.time,
                ping: ping.sequence,
                beam: beam.number,
                position,
                depth: solution.to_datum(depth_below_transducer),
                across: east * cos_hd - north * sin_hd,
                along: east * sin_hd + north * cos_hd,
                tvu: uncertainty.tvu,
                thu: uncertainty.thu,
                detection: beam.detection,
                flags: beam.flags,
            };
            if let Some(order) = self.order {
                if !s44::check(&sounding, order).passes() {
                    sounding.flags.set(BeamFlags::FAILS_ORDER);
                }
            }
            out.push(sounding);
        }
        Ok(out)
    }

    fn rejected(&self, ping: &Ping, beam: &Beam, flags: BeamFlags) -> Sounding {
        Sounding {
            time: ping.time,
            ping: ping.sequence,
            beam: beam.number,
            position: ping
                .navigation
                .map(|n| n.position)
                .unwrap_or(Geodetic::from_degrees(0.0, 0.0, 0.0)),
            depth: 0.0,
            across: 0.0,
            along: 0.0,
            tvu: 0.0,
            thu: 0.0,
            detection: beam.detection,
            flags: beam.flags.with(flags),
        }
    }
}
