//! A ping record: one transmission and everything that came back from it.

use crate::geodesy::Geodetic;
use crate::motion::attitude::Attitude;
use crate::time::Timestamp;
use crate::units::Angle;

use super::beam::{Beam, BeamFlags, Detection};

/// The state of the vessel at the instant of a ping.
///
/// Assembled by the pipeline from the ancillary series, not read from a file,
/// because the sensors are all on their own clocks and the interpolation to
/// ping time is where their disagreement gets resolved.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Navigation {
    /// Position of the positioning reference point.
    pub position: Geodetic,
    /// Attitude of the vessel.
    pub attitude: Attitude,
    /// Instantaneous heave, positive up.
    pub heave: f64,
    /// Speed over ground in metres per second.
    pub speed: f64,
    /// Ellipsoidal height of the transducer, when the positioning gives one.
    pub transducer_height: Option<f64>,
}

impl Navigation {
    /// A vessel sitting still, level, at a position. Useful in tests and
    /// nowhere else.
    pub fn stationary(position: Geodetic) -> Self {
        Navigation {
            position,
            attitude: Attitude::LEVEL,
            heave: 0.0,
            speed: 0.0,
            transducer_height: None,
        }
    }
}

/// One transmission and its detections.
#[derive(Debug, Clone, PartialEq)]
pub struct Ping {
    /// Time of transmission.
    pub time: Timestamp,
    /// Sequence number within the line, as the sonar counted it.
    pub sequence: u64,
    /// Sound speed at the transducer face, from the surface sensor.
    ///
    /// This is the speed the sonar used to steer the beams, and it is not the
    /// speed the profile gives at that depth. Reconciling the two is what
    /// [`crate::ping::reduce`] does with it.
    pub surface_sound_speed: f64,
    /// The beams, in the order the sonar reported them.
    pub beams: Vec<Beam>,
    /// Navigation at ping time, once it has been resolved.
    pub navigation: Option<Navigation>,
}

impl Ping {
    /// Build a ping with no navigation attached yet.
    pub fn new(time: Timestamp, sequence: u64, surface_sound_speed: f64, beams: Vec<Beam>) -> Self {
        Ping {
            time,
            sequence,
            surface_sound_speed,
            beams,
            navigation: None,
        }
    }

    /// Number of beams that are still usable.
    pub fn good_beams(&self) -> usize {
        self.beams.iter().filter(|b| b.is_good()).count()
    }

    /// The beam closest to nadir that still has a detection.
    ///
    /// Nadir is where the depth is least sensitive to everything, so this is
    /// the beam a quality check looks at first.
    pub fn nadir_beam(&self) -> Option<&Beam> {
        self.beams.iter().filter(|b| b.is_good()).min_by(|a, b| {
            a.pointing_angle
                .radians()
                .abs()
                .total_cmp(&b.pointing_angle.radians().abs())
        })
    }

    /// Widest pointing angles on each side, port first, over good beams only.
    pub fn swath_extent(&self) -> Option<(Angle, Angle)> {
        let mut port = 0.0f64;
        let mut stbd = 0.0f64;
        let mut any = false;
        for b in self.beams.iter().filter(|b| b.is_good()) {
            any = true;
            let a = b.pointing_angle.radians();
            if a < port {
                port = a;
            }
            if a > stbd {
                stbd = a;
            }
        }
        if any {
            Some((Angle::from_radians(port), Angle::from_radians(stbd)))
        } else {
            None
        }
    }

    /// Longest two way travel time over the good beams, which sizes the ray
    /// table this ping needs.
    pub fn max_two_way_time(&self) -> f64 {
        self.beams
            .iter()
            .filter(|b| b.is_good())
            .map(|b| b.two_way_time)
            .fold(0.0, f64::max)
    }

    /// Flag every beam outside an angular limit.
    ///
    /// Survey specifications routinely cut the swath back to sixty degrees or
    /// so, because the outer beams carry most of the uncertainty and most of
    /// the refraction error for a fraction of the coverage.
    pub fn limit_swath(&mut self, half_angle: Angle) {
        let limit = half_angle.radians().abs();
        for b in self.beams.iter_mut() {
            if b.pointing_angle.radians().abs() > limit {
                b.flags.set(BeamFlags::OUTSIDE_SWATH);
            }
        }
    }

    /// Flag every beam whose detection quality is below a threshold.
    pub fn reject_below_quality(&mut self, threshold: f32) {
        for b in self.beams.iter_mut() {
            if b.quality < threshold || b.detection == Detection::None {
                b.flags.set(BeamFlags::LOW_QUALITY);
            }
        }
    }

    /// Set a flag on every beam, used when something ping wide has failed.
    pub fn flag_all(&mut self, flags: BeamFlags) {
        for b in self.beams.iter_mut() {
            b.flags.set(flags);
        }
    }
}

/// Something wrong with a ping, found before any of it is reduced.
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum PingProblem {
    /// No beams at all.
    NoBeams,
    /// The time is not a usable instant.
    BadTime,
    /// The surface sound speed is outside anything the ocean does.
    ImplausibleSoundSpeed(f64),
    /// A travel time that is zero, negative or not a number.
    BadTravelTime {
        /// Which beam.
        beam: u16,
        /// The offending value.
        value: f64,
    },
    /// A pointing angle at or beyond the horizontal.
    BadPointingAngle {
        /// Which beam.
        beam: u16,
        /// The offending angle in degrees.
        degrees: f64,
    },
    /// The attitude holds an angle no vessel reaches.
    ImplausibleAttitude,
}

impl Ping {
    /// Check a ping for the things that make it unreducible.
    ///
    /// Reading a file should not fail on one bad ping in a hundred thousand,
    /// so nothing here refuses anything: it returns a list, the caller decides,
    /// and the reduction flags the beams it cannot use anyway. What this is
    /// for is the moment somebody asks why a whole line came out empty.
    pub fn validate(&self) -> Vec<PingProblem> {
        let mut out = Vec::new();
        if self.beams.is_empty() {
            out.push(PingProblem::NoBeams);
        }
        if !self.time.is_valid() {
            out.push(PingProblem::BadTime);
        }
        if !(1300.0..1700.0).contains(&self.surface_sound_speed) {
            out.push(PingProblem::ImplausibleSoundSpeed(self.surface_sound_speed));
        }
        if let Some(nav) = self.navigation {
            if !nav.attitude.is_plausible() {
                out.push(PingProblem::ImplausibleAttitude);
            }
        }
        for beam in &self.beams {
            if beam.detection == Detection::None {
                continue;
            }
            if !beam.two_way_time.is_finite() || beam.two_way_time <= 0.0 {
                out.push(PingProblem::BadTravelTime {
                    beam: beam.number,
                    value: beam.two_way_time,
                });
            }
            let degrees = beam.pointing_angle.degrees();
            if !degrees.is_finite() || degrees.abs() >= 90.0 {
                out.push(PingProblem::BadPointingAngle {
                    beam: beam.number,
                    degrees,
                });
            }
        }
        out
    }

    /// True when nothing in the ping stops it being reduced.
    pub fn is_reducible(&self) -> bool {
        self.validate().is_empty()
    }
}
