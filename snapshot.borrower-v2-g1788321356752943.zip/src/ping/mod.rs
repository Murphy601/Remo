//! Pings, beams, and turning one into soundings.

pub mod beam;
pub mod decimate;
pub mod line;
pub mod record;
pub mod reduce;
pub mod sounding;

pub use beam::{Beam, BeamFlags, Detection};
pub use decimate::{decimate, Keep};
pub use line::Line;
pub use record::{Navigation, Ping};
pub use reduce::{beam_direction, Reducer};
pub use sounding::{Sounding, SoundingStats};
