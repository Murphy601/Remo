//! Thinning a sounding set down to what a delivery needs.
//!
//! Nobody wants three hundred million soundings in a chart product, and the
//! usual answer is to grid them. Sometimes the client asks for soundings, at a
//! spacing, and then the question of which ones to throw away becomes a
//! question about safety rather than about file size.
//!
//! The rule here is the same one the chart uses: keep the shallowest sounding
//! in each bin. It is the only rule that cannot make a hazard disappear, and
//! it is why nothing in this module averages anything.

use std::collections::HashMap;

use crate::error::{Error, Result};
use crate::geodesy::utm::TransverseMercator;

use super::sounding::Sounding;

/// Which sounding to keep out of each bin.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Keep {
    /// The shallowest. The only safe answer for anything navigational.
    Shoalest,
    /// The deepest, which is what a dredging clearance survey wants.
    Deepest,
    /// The one with the smallest vertical uncertainty.
    MostCertain,
}

impl Keep {
    /// True when `candidate` should replace `current`.
    fn prefers(&self, candidate: &Sounding, current: &Sounding) -> bool {
        match self {
            Keep::Shoalest => candidate.depth < current.depth,
            Keep::Deepest => candidate.depth > current.depth,
            Keep::MostCertain => candidate.tvu < current.tvu,
        }
    }

    /// Short name for the log.
    pub fn name(&self) -> &'static str {
        match self {
            Keep::Shoalest => "shoalest",
            Keep::Deepest => "deepest",
            Keep::MostCertain => "most certain",
        }
    }
}

/// Thin soundings to one per square of a given size.
///
/// Only accepted soundings are considered. The bins are the same squares the
/// gridder would use at that cell size, snapped to a multiple of it, so a
/// decimated set and a grid of the same spacing pick their values from the
/// same patches of seabed and can be compared.
pub fn decimate(
    soundings: &[Sounding],
    projection: &TransverseMercator,
    spacing: f64,
    keep: Keep,
) -> Result<Vec<Sounding>> {
    if !(spacing.is_finite() && spacing > 0.0) {
        return Err(Error::domain("spacing", spacing, "finite and positive"));
    }

    let mut bins: HashMap<(i64, i64), Sounding> = HashMap::new();
    for sounding in soundings.iter().filter(|s| s.is_accepted()) {
        let grid = projection.forward(sounding.position)?;
        let key = (
            (grid.east / spacing).floor() as i64,
            (grid.north / spacing).floor() as i64,
        );
        match bins.get(&key) {
            Some(current) if !keep.prefers(sounding, current) => {}
            _ => {
                bins.insert(key, *sounding);
            }
        }
    }

    // Sorted by time and then by beam, so the output is the same on every run
    // and a diff between two deliveries means something.
    let mut out: Vec<Sounding> = bins.into_values().collect();
    out.sort_by(|a, b| {
        a.time
            .cmp(&b.time)
            .then(a.ping.cmp(&b.ping))
            .then(a.beam.cmp(&b.beam))
    });
    Ok(out)
}

/// Keep every nth sounding, in the order they were acquired.
///
/// A blunt instrument, and the only honest use for it is making a quick look
/// file small enough to open in something else. It is not safe for a
/// deliverable and the doc comment says so because somebody will try.
pub fn every_nth(soundings: &[Sounding], n: usize) -> Vec<Sounding> {
    if n <= 1 {
        return soundings.to_vec();
    }
    soundings
        .iter()
        .filter(|s| s.is_accepted())
        .step_by(n)
        .copied()
        .collect()
}

/// How much a decimation threw away, for the log.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct DecimationReport {
    /// Soundings that went in, accepted ones only.
    pub considered: usize,
    /// Soundings that came out.
    pub kept: usize,
    /// Bin size used.
    pub spacing: f64,
    /// Shallowest depth in the input.
    pub shoalest_in: f64,
    /// Shallowest depth in the output.
    pub shoalest_out: f64,
}

impl DecimationReport {
    /// Build the report for a decimation.
    pub fn of(input: &[Sounding], output: &[Sounding], spacing: f64) -> DecimationReport {
        let shoalest = |set: &[Sounding]| {
            set.iter()
                .filter(|s| s.is_accepted())
                .map(|s| s.depth)
                .fold(f64::INFINITY, f64::min)
        };
        DecimationReport {
            considered: input.iter().filter(|s| s.is_accepted()).count(),
            kept: output.len(),
            spacing,
            shoalest_in: shoalest(input),
            shoalest_out: shoalest(output),
        }
    }

    /// True when the shallowest sounding survived, which for a shoalest
    /// decimation it always must.
    pub fn kept_the_shoalest(&self) -> bool {
        (self.shoalest_in - self.shoalest_out).abs() < 1.0e-9
    }

    /// Fraction of the input that came through.
    pub fn fraction(&self) -> f64 {
        if self.considered == 0 {
            0.0
        } else {
            self.kept as f64 / self.considered as f64
        }
    }
}
