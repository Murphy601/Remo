//! The plumbline command line tool.

use std::process::ExitCode;

use plumbline::cli::args::Args;
use plumbline::cli::{cast, compare, grid, help, info, plan, reduce, simulate};

fn main() -> ExitCode {
    let raw: Vec<String> = std::env::args().skip(1).collect();
    let args = match Args::parse(&raw) {
        Ok(a) => a,
        Err(e) => {
            eprintln!("plumbline: {e}");
            return ExitCode::from(2);
        }
    };

    if args.flag("help") || args.command.is_none() {
        print!("{}", help::for_command(args.command.as_deref()));
        return ExitCode::SUCCESS;
    }
    if args.flag("version") {
        println!("plumbline {}", plumbline::VERSION);
        return ExitCode::SUCCESS;
    }

    let outcome = match args.command.as_deref() {
        Some("info") => info::run(&args),
        Some("cast") => cast::run(&args),
        Some("compare") => compare::run(&args),
        Some("grid") => grid::run(&args),
        Some("plan") => plan::run(&args),
        Some("reduce") => reduce::run(&args),
        Some("simulate") => simulate::run(&args),
        Some(other) => {
            eprintln!("plumbline: there is no command called {other}");
            eprint!("{}", help::USAGE);
            return ExitCode::from(2);
        }
        None => unreachable!("handled above"),
    };

    match outcome {
        Ok(text) => {
            print!("{text}");
            ExitCode::SUCCESS
        }
        Err(e) => {
            eprintln!("plumbline: {e}");
            ExitCode::FAILURE
        }
    }
}
