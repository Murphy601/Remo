//! Angles and the handful of unit conversions hydrography still needs.
//!
//! Depths, ranges and travel times are plain `f64` in metres and seconds
//! throughout the crate; wrapping those in newtypes buys nothing because they
//! never get confused for one another in practice. Angles are different. Half
//! the literature is in degrees, the trigonometry is in radians, and headings
//! wrap while roll does not. [`Angle`] exists so that the wrapping rule is
//! written down once.

use std::f64::consts::{PI, TAU};
use std::fmt;
use std::ops::{Add, AddAssign, Div, Mul, Neg, Sub, SubAssign};

/// An angle held internally in radians.
///
/// The type is deliberately not `Ord`: two angles that differ by a full turn
/// compare unequal, which is the right answer for a roll offset and the wrong
/// one for a heading, so the caller has to say which they meant by calling
/// [`Angle::wrapped`] or [`Angle::wrapped_signed`] first.
#[derive(Debug, Clone, Copy, PartialEq, PartialOrd, Default)]
pub struct Angle(f64);

impl Angle {
    /// Zero.
    pub const ZERO: Angle = Angle(0.0);
    /// A quarter turn.
    pub const QUARTER_TURN: Angle = Angle(PI / 2.0);
    /// A half turn.
    pub const HALF_TURN: Angle = Angle(PI);
    /// A full turn.
    pub const FULL_TURN: Angle = Angle(TAU);

    /// Build an angle from radians.
    #[inline]
    pub const fn from_radians(r: f64) -> Self {
        Angle(r)
    }

    /// Build an angle from decimal degrees.
    #[inline]
    pub fn from_degrees(d: f64) -> Self {
        Angle(d * PI / 180.0)
    }

    /// Build an angle from degrees, minutes and decimal seconds.
    ///
    /// The sign is taken from `deg`, so negative zero degrees cannot be
    /// expressed; pass the whole thing through [`Angle::neg`] instead.
    pub fn from_dms(deg: f64, min: f64, sec: f64) -> Self {
        let mag = deg.abs() + min / 60.0 + sec / 3600.0;
        Angle::from_degrees(if deg.is_sign_negative() { -mag } else { mag })
    }

    /// The angle in radians.
    #[inline]
    pub const fn radians(self) -> f64 {
        self.0
    }

    /// The angle in decimal degrees.
    #[inline]
    pub fn degrees(self) -> f64 {
        self.0 * 180.0 / PI
    }

    /// Reduce to `[0, 2pi)`, the convention for headings and bearings.
    pub fn wrapped(self) -> Angle {
        let mut r = self.0 % TAU;
        if r < 0.0 {
            r += TAU;
        }
        Angle(r)
    }

    /// Reduce to `(-pi, pi]`, the convention for differences between headings.
    pub fn wrapped_signed(self) -> Angle {
        let mut r = self.0 % TAU;
        if r <= -PI {
            r += TAU;
        } else if r > PI {
            r -= TAU;
        }
        Angle(r)
    }

    /// Shortest signed rotation that takes `self` onto `other`.
    ///
    /// ```
    /// use plumbline::units::Angle;
    ///
    /// let steady = Angle::from_degrees(359.0);
    /// let turned = Angle::from_degrees(3.0);
    /// // Four degrees to starboard, not three hundred and fifty six to port.
    /// assert!((steady.delta_to(turned).degrees() - 4.0).abs() < 1.0e-9);
    /// ```
    pub fn delta_to(self, other: Angle) -> Angle {
        (other - self).wrapped_signed()
    }

    /// Sine of the angle.
    #[inline]
    pub fn sin(self) -> f64 {
        self.0.sin()
    }

    /// Cosine of the angle.
    #[inline]
    pub fn cos(self) -> f64 {
        self.0.cos()
    }

    /// Tangent of the angle.
    #[inline]
    pub fn tan(self) -> f64 {
        self.0.tan()
    }

    /// Sine and cosine together, which is what the rotation code always wants.
    #[inline]
    pub fn sin_cos(self) -> (f64, f64) {
        self.0.sin_cos()
    }

    /// True when the angle is finite.
    #[inline]
    pub fn is_finite(self) -> bool {
        self.0.is_finite()
    }
}

impl Add for Angle {
    type Output = Angle;
    fn add(self, rhs: Angle) -> Angle {
        Angle(self.0 + rhs.0)
    }
}

impl Sub for Angle {
    type Output = Angle;
    fn sub(self, rhs: Angle) -> Angle {
        Angle(self.0 - rhs.0)
    }
}

impl Neg for Angle {
    type Output = Angle;
    fn neg(self) -> Angle {
        Angle(-self.0)
    }
}

impl Mul<f64> for Angle {
    type Output = Angle;
    fn mul(self, rhs: f64) -> Angle {
        Angle(self.0 * rhs)
    }
}

impl Div<f64> for Angle {
    type Output = Angle;
    fn div(self, rhs: f64) -> Angle {
        Angle(self.0 / rhs)
    }
}

impl AddAssign for Angle {
    fn add_assign(&mut self, rhs: Angle) {
        self.0 += rhs.0;
    }
}

impl SubAssign for Angle {
    fn sub_assign(&mut self, rhs: Angle) {
        self.0 -= rhs.0;
    }
}

impl fmt::Display for Angle {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{:.4} deg", self.degrees())
    }
}

/// Metres in one international foot.
pub const METRES_PER_FOOT: f64 = 0.3048;
/// Metres in one fathom, which is six international feet.
pub const METRES_PER_FATHOM: f64 = 6.0 * METRES_PER_FOOT;
/// Metres per second in one knot.
pub const METRES_PER_SECOND_PER_KNOT: f64 = 1852.0 / 3600.0;

/// Convert fathoms to metres, for the old lead line records.
pub fn fathoms_to_metres(f: f64) -> f64 {
    f * METRES_PER_FATHOM
}

/// Convert metres to fathoms.
pub fn metres_to_fathoms(m: f64) -> f64 {
    m / METRES_PER_FATHOM
}

/// Convert knots to metres per second.
pub fn knots_to_mps(k: f64) -> f64 {
    k * METRES_PER_SECOND_PER_KNOT
}
