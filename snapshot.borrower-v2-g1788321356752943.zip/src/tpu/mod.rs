//! Propagating the uncertainty of every input into the uncertainty of a
//! sounding.

pub mod propagate;
pub mod s44;
pub mod sensors;

pub use propagate::{propagate, Component, Propagated, SoundingGeometry};
pub use s44::{best_order, check, Compliance, Order};
pub use sensors::{UncertaintyBudget, ONE_DIMENSIONAL_95, TWO_DIMENSIONAL_95};
