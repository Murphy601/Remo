//! Propagating the budget onto one sounding.
//!
//! Every term is a partial derivative of the sounding with respect to one
//! input, times the uncertainty of that input. They are combined in quadrature
//! because the inputs are independent, which is very nearly true and is the
//! assumption every published budget makes.
//!
//! The components are kept rather than summed on the spot. Half the value of
//! doing this at all is being able to say which term dominates, and that
//! answer changes across the swath: near nadir it is the tide and the heave,
//! at the edge it is the sound speed and the roll, and nothing else ever wins.

use crate::units::Angle;

use super::sensors::{UncertaintyBudget, ONE_DIMENSIONAL_95, TWO_DIMENSIONAL_95};

/// What the propagation needs to know about one sounding.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct SoundingGeometry {
    /// Depth below the transducer in metres.
    pub depth: f64,
    /// Across track distance from the transducer in metres.
    pub across: f64,
    /// Angle the ray left the transducer at, from the vertical.
    pub launch_angle: Angle,
    /// Sound speed at the transducer face.
    pub surface_speed: f64,
    /// Mean sound speed over the ray path.
    pub mean_speed: f64,
    /// Instantaneous heave, for the amplitude dependent part of its budget.
    pub heave: f64,
    /// Speed over ground, for the timing term.
    pub vessel_speed: f64,
    /// True when the depths are referred to the ellipsoid rather than a gauge.
    pub ellipsoidal: bool,
}

impl SoundingGeometry {
    /// Slant range from the transducer to the sounding.
    pub fn slant_range(&self) -> f64 {
        self.depth.hypot(self.across)
    }
}

/// One vertical or horizontal contribution, kept separately for the report.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Component {
    /// What the term is called in the report.
    pub name: &'static str,
    /// Its one sigma contribution in metres.
    pub sigma: f64,
}

/// The result of a propagation.
#[derive(Debug, Clone, PartialEq)]
pub struct Propagated {
    /// Total vertical uncertainty at ninety five percent, in metres.
    pub tvu: f64,
    /// Total horizontal uncertainty at ninety five percent, in metres.
    pub thu: f64,
    /// Vertical contributions, one sigma each.
    pub vertical: Vec<Component>,
    /// Horizontal contributions, one sigma each.
    pub horizontal: Vec<Component>,
}

impl Propagated {
    /// The largest vertical contribution, which is the one worth spending
    /// money on.
    pub fn dominant_vertical(&self) -> Option<Component> {
        self.vertical
            .iter()
            .copied()
            .max_by(|a, b| a.sigma.total_cmp(&b.sigma))
    }

    /// The largest horizontal contribution.
    pub fn dominant_horizontal(&self) -> Option<Component> {
        self.horizontal
            .iter()
            .copied()
            .max_by(|a, b| a.sigma.total_cmp(&b.sigma))
    }
}

fn quadrature(components: &[Component]) -> f64 {
    components
        .iter()
        .map(|c| c.sigma * c.sigma)
        .sum::<f64>()
        .sqrt()
}

/// Propagate the budget onto one sounding.
pub fn propagate(geometry: SoundingGeometry, budget: &UncertaintyBudget) -> Propagated {
    let theta = geometry.launch_angle;
    let (sin_t, cos_t) = theta.sin_cos();
    let range = geometry.slant_range();
    let depth = geometry.depth.abs();
    let across = geometry.across.abs();

    // An angular error moves the sounding along the arc of constant range, so
    // it lands in the vertical as R sin(theta) and in the horizontal as
    // R cos(theta). That swap is why the outer beams are vertically bad and
    // the inner ones horizontally good.
    let angular_vertical = range * sin_t.abs();
    let angular_horizontal = range * cos_t.abs();

    // An error in the surface sound speed refracts the beam at the face, which
    // is an angular error proportional to the tangent.
    let face_angle = if geometry.surface_speed > 0.0 {
        (budget.surface_sound_speed / geometry.surface_speed) * sin_t.abs() / cos_t.abs().max(0.05)
    } else {
        0.0
    };

    let speed_fraction = if geometry.mean_speed > 0.0 {
        budget.profile_sound_speed / geometry.mean_speed
    } else {
        0.0
    };

    // An error in the mean sound speed does two things at once: it stretches
    // the path, and it changes the angle the ray refracted to. Both push the
    // depth the same way, and adding them gives a secant squared rather than
    // the flat depth term this used to carry. At sixty degrees that is four
    // times the nadir figure, which is what the outer beams of a real swath
    // actually do when the cast is stale.
    let secant = 1.0 / cos_t.abs().max(0.1);
    let refraction_vertical = depth * speed_fraction * secant * secant;
    let refraction_horizontal = across * speed_fraction * secant;

    let mut vertical = vec![
        Component {
            name: "roll",
            sigma: angular_vertical * budget.roll.radians(),
        },
        Component {
            name: "beam angle",
            sigma: angular_vertical * budget.beam_angle.radians(),
        },
        Component {
            name: "face refraction",
            sigma: angular_vertical * face_angle,
        },
        Component {
            name: "range",
            sigma: range * budget.range_fraction * cos_t.abs(),
        },
        Component {
            name: "sound speed",
            sigma: refraction_vertical,
        },
        Component {
            name: "heave",
            sigma: budget.heave_sigma(geometry.heave),
        },
        Component {
            name: "draft",
            sigma: budget.draft,
        },
        Component {
            name: "lever arm",
            sigma: budget.lever_arm,
        },
    ];

    if geometry.ellipsoidal {
        vertical.push(Component {
            name: "positioning height",
            sigma: budget.position_vertical,
        });
        vertical.push(Component {
            name: "separation",
            sigma: budget.separation,
        });
    } else {
        vertical.push(Component {
            name: "tide",
            sigma: budget.tide,
        });
    }

    let horizontal = vec![
        Component {
            name: "positioning",
            sigma: budget.position_horizontal,
        },
        Component {
            name: "heading",
            sigma: across * budget.heading.radians(),
        },
        Component {
            name: "roll",
            sigma: angular_horizontal * budget.roll.radians(),
        },
        Component {
            name: "beam angle",
            sigma: angular_horizontal * budget.beam_angle.radians(),
        },
        Component {
            name: "range",
            sigma: range * budget.range_fraction * sin_t.abs(),
        },
        Component {
            name: "sound speed",
            sigma: refraction_horizontal,
        },
        Component {
            name: "timing",
            sigma: budget.timing * geometry.vessel_speed,
        },
        Component {
            name: "lever arm",
            sigma: budget.lever_arm,
        },
    ];

    Propagated {
        tvu: ONE_DIMENSIONAL_95 * quadrature(&vertical),
        thu: TWO_DIMENSIONAL_95 * quadrature(&horizontal),
        vertical,
        horizontal,
    }
}

impl Component {
    /// This term as a fraction of a total, in variance rather than in sigma.
    ///
    /// Quoting the share in sigma looks tidier and is wrong: the terms combine
    /// in quadrature, so a term that is half the sigma is a quarter of the
    /// problem, and the number that says where to spend money is the variance
    /// share.
    pub fn variance_share(&self, total_sigma: f64) -> f64 {
        if total_sigma <= 0.0 {
            0.0
        } else {
            (self.sigma * self.sigma) / (total_sigma * total_sigma)
        }
    }
}

impl Propagated {
    /// One sigma total in the vertical, before the confidence factor.
    pub fn vertical_sigma(&self) -> f64 {
        quadrature(&self.vertical)
    }

    /// One sigma total in the horizontal, before the confidence factor.
    pub fn horizontal_sigma(&self) -> f64 {
        quadrature(&self.horizontal)
    }

    /// The vertical budget as lines of text, biggest contributor first.
    ///
    /// This is what goes in the survey report when somebody asks why the
    /// uncertainty is what it is. Terms that contribute under a tenth of a
    /// percent of the variance are left out; there are a dozen of them and
    /// they say nothing.
    pub fn vertical_breakdown(&self) -> Vec<String> {
        breakdown(&self.vertical, self.vertical_sigma())
    }

    /// The horizontal budget in the same form.
    pub fn horizontal_breakdown(&self) -> Vec<String> {
        breakdown(&self.horizontal, self.horizontal_sigma())
    }
}

fn breakdown(components: &[Component], total: f64) -> Vec<String> {
    let mut sorted: Vec<&Component> = components.iter().collect();
    sorted.sort_by(|a, b| b.sigma.total_cmp(&a.sigma));
    sorted
        .iter()
        .filter(|c| c.variance_share(total) >= 0.001)
        .map(|c| {
            format!(
                "{:<20} {:>7.3} m  {:>5.1}%",
                c.name,
                c.sigma,
                100.0 * c.variance_share(total)
            )
        })
        .collect()
}
