//! Orders of survey, and whether a sounding meets one.
//!
//! The allowable vertical uncertainty of a survey is a depth dependent
//! envelope with two coefficients, a constant part covering everything that
//! does not scale and a fraction covering everything that does. The horizontal
//! allowance is a constant plus a percentage of depth. Both are quoted at
//! ninety five percent, which is why the propagation scales its result before
//! anything gets compared to them.

use crate::ping::sounding::Sounding;

/// A survey order, with the allowances that define it.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Order {
    /// The tightest order, for areas where under keel clearance is critical.
    Exclusive,
    /// For harbours and berthing areas.
    Special,
    /// Shallow water where the seabed is a hazard to surface shipping.
    One,
    /// Areas where a general description of the seabed is enough.
    Two,
}

impl Order {
    /// Constant part of the vertical allowance, in metres.
    pub fn a(&self) -> f64 {
        match self {
            Order::Exclusive => 0.15,
            Order::Special => 0.25,
            Order::One => 0.5,
            Order::Two => 1.0,
        }
    }

    /// Depth dependent part of the vertical allowance.
    pub fn b(&self) -> f64 {
        match self {
            Order::Exclusive => 0.0075,
            Order::Special => 0.0075,
            Order::One => 0.013,
            Order::Two => 0.023,
        }
    }

    /// Maximum allowable vertical uncertainty at a depth, at ninety five
    /// percent.
    pub fn max_tvu(&self, depth: f64) -> f64 {
        let a = self.a();
        let bd = self.b() * depth.abs();
        (a * a + bd * bd).sqrt()
    }

    /// Maximum allowable horizontal uncertainty at a depth, at ninety five
    /// percent.
    pub fn max_thu(&self, depth: f64) -> f64 {
        match self {
            Order::Exclusive => 1.0,
            Order::Special => 2.0,
            Order::One => 5.0 + 0.05 * depth.abs(),
            Order::Two => 20.0 + 0.10 * depth.abs(),
        }
    }

    /// Smallest cubic feature the survey has to detect at a depth, or `None`
    /// where the order does not require feature detection.
    pub fn feature_size(&self, depth: f64) -> Option<f64> {
        match self {
            Order::Exclusive => Some(0.5),
            Order::Special => Some(1.0),
            Order::One => {
                if depth <= 40.0 {
                    Some(2.0)
                } else {
                    Some(0.1 * depth)
                }
            }
            Order::Two => None,
        }
    }

    /// Short name as it appears in a specification.
    pub fn name(&self) -> &'static str {
        match self {
            Order::Exclusive => "exclusive",
            Order::Special => "special",
            Order::One => "order 1",
            Order::Two => "order 2",
        }
    }

    /// Parse the name back.
    pub fn from_name(name: &str) -> Option<Order> {
        match name.trim().to_ascii_lowercase().as_str() {
            "exclusive" => Some(Order::Exclusive),
            "special" => Some(Order::Special),
            "order 1" | "order1" | "1" | "1a" | "1b" => Some(Order::One),
            "order 2" | "order2" | "2" => Some(Order::Two),
            _ => None,
        }
    }

    /// Every order, tightest first.
    pub fn all() -> [Order; 4] {
        [Order::Exclusive, Order::Special, Order::One, Order::Two]
    }
}

/// How a sounding stands against an order.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Compliance {
    /// True when the vertical uncertainty is inside the allowance.
    pub vertical_ok: bool,
    /// True when the horizontal uncertainty is inside the allowance.
    pub horizontal_ok: bool,
    /// Vertical uncertainty as a fraction of what is allowed.
    pub vertical_ratio: f64,
    /// Horizontal uncertainty as a fraction of what is allowed.
    pub horizontal_ratio: f64,
}

impl Compliance {
    /// True when both directions pass.
    pub fn passes(&self) -> bool {
        self.vertical_ok && self.horizontal_ok
    }
}

/// Check one sounding against an order.
pub fn check(sounding: &Sounding, order: Order) -> Compliance {
    let allowed_v = order.max_tvu(sounding.depth);
    let allowed_h = order.max_thu(sounding.depth);
    Compliance {
        vertical_ok: sounding.tvu <= allowed_v,
        horizontal_ok: sounding.thu <= allowed_h,
        vertical_ratio: if allowed_v > 0.0 {
            sounding.tvu / allowed_v
        } else {
            f64::INFINITY
        },
        horizontal_ratio: if allowed_h > 0.0 {
            sounding.thu / allowed_h
        } else {
            f64::INFINITY
        },
    }
}

/// The tightest order a sounding would pass, or `None` if it fails them all.
pub fn best_order(sounding: &Sounding) -> Option<Order> {
    Order::all()
        .into_iter()
        .find(|o| check(sounding, *o).passes())
}
