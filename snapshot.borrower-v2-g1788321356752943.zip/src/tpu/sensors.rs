//! The uncertainty budget: what every sensor on the boat is worth.
//!
//! Everything here is a one sigma standard deviation in the natural unit of
//! the quantity. They come from calibration certificates, from the patch test
//! residuals, and in a couple of cases from an honest guess written down where
//! somebody can argue with it. The point of collecting them in one struct is
//! that the survey report can print the budget it was run with, and two
//! surveys with different budgets are then visibly different.

use crate::units::Angle;

/// One sigma uncertainties for every input to the reduction.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct UncertaintyBudget {
    /// Roll, one sigma.
    pub roll: Angle,
    /// Pitch, one sigma.
    pub pitch: Angle,
    /// Heading, one sigma.
    pub heading: Angle,
    /// Heave, as a constant part in metres.
    pub heave_constant: f64,
    /// Heave, as a fraction of the heave amplitude.
    pub heave_fraction: f64,
    /// Horizontal positioning, one sigma in metres.
    pub position_horizontal: f64,
    /// Vertical positioning, one sigma in metres. Only used when working from
    /// the ellipsoid.
    pub position_vertical: f64,
    /// Timing, one sigma in seconds, covering every latency that has not been
    /// measured out.
    pub timing: f64,
    /// Beam angle, one sigma, covering the angular resolution of the sonar.
    pub beam_angle: Angle,
    /// Range, as a fraction of the measured range.
    pub range_fraction: f64,
    /// Sound speed at the transducer face, one sigma in metres per second.
    pub surface_sound_speed: f64,
    /// Sound speed through the column, one sigma in metres per second.
    ///
    /// This is the one that dominates the outer beams and the one that is
    /// hardest to justify. A cast an hour old in stratified water is worth
    /// several metres per second, not the tenth of a metre the probe resolves.
    pub profile_sound_speed: f64,
    /// Tide, one sigma in metres, covering the gauge and the zoning together.
    pub tide: f64,
    /// Separation model, one sigma in metres.
    pub separation: f64,
    /// Draft and settlement together, one sigma in metres.
    pub draft: f64,
    /// Lever arm measurements, one sigma in metres.
    pub lever_arm: f64,
}

impl UncertaintyBudget {
    /// A budget for a small launch with a good inertial system and a modern
    /// shallow water sonar.
    ///
    /// These are numbers I would defend for the boats I work off. They are not
    /// numbers anybody should use without checking against their own kit.
    pub fn shallow_water_launch() -> Self {
        UncertaintyBudget {
            roll: Angle::from_degrees(0.02),
            pitch: Angle::from_degrees(0.02),
            heading: Angle::from_degrees(0.05),
            heave_constant: 0.05,
            heave_fraction: 0.05,
            position_horizontal: 0.30,
            position_vertical: 0.10,
            timing: 0.005,
            beam_angle: Angle::from_degrees(0.05),
            range_fraction: 0.0005,
            surface_sound_speed: 0.2,
            profile_sound_speed: 2.0,
            tide: 0.05,
            separation: 0.08,
            draft: 0.03,
            lever_arm: 0.02,
        }
    }

    /// A budget with everything at zero, for isolating one term in a test.
    pub const ZERO: UncertaintyBudget = UncertaintyBudget {
        roll: Angle::ZERO,
        pitch: Angle::ZERO,
        heading: Angle::ZERO,
        heave_constant: 0.0,
        heave_fraction: 0.0,
        position_horizontal: 0.0,
        position_vertical: 0.0,
        timing: 0.0,
        beam_angle: Angle::ZERO,
        range_fraction: 0.0,
        surface_sound_speed: 0.0,
        profile_sound_speed: 0.0,
        tide: 0.0,
        separation: 0.0,
        draft: 0.0,
        lever_arm: 0.0,
    };

    /// Heave uncertainty for a given heave amplitude.
    pub fn heave_sigma(&self, heave: f64) -> f64 {
        self.heave_constant.hypot(self.heave_fraction * heave.abs())
    }

    /// True when nothing in the budget is negative or a NaN.
    pub fn is_valid(&self) -> bool {
        let terms = [
            self.heave_constant,
            self.heave_fraction,
            self.position_horizontal,
            self.position_vertical,
            self.timing,
            self.range_fraction,
            self.surface_sound_speed,
            self.profile_sound_speed,
            self.tide,
            self.separation,
            self.draft,
            self.lever_arm,
        ];
        terms.iter().all(|t| t.is_finite() && *t >= 0.0)
            && self.roll.is_finite()
            && self.pitch.is_finite()
            && self.heading.is_finite()
            && self.beam_angle.is_finite()
    }
}

impl Default for UncertaintyBudget {
    fn default() -> Self {
        UncertaintyBudget::shallow_water_launch()
    }
}

/// The factor that turns a one sigma value into a ninety five percent one, for
/// a quantity in one dimension.
pub const ONE_DIMENSIONAL_95: f64 = 1.96;

/// The same factor for a quantity in two dimensions, which is what a
/// horizontal uncertainty is.
///
/// The two numbers differ because a horizontal error has two components and
/// the ninety five percent contour is a circle around both of them. Quoting
/// 1.96 for a horizontal uncertainty understates it by a fifth, and it is a
/// common enough mistake to be worth naming both constants.
pub const TWO_DIMENSIONAL_95: f64 = 2.45;
