//! Where the cells of a surface actually live.
//!
//! A dense array of cells is the right answer almost always: a survey block is
//! mostly covered, a cell is under a hundred bytes, and random access with no
//! hashing is what the gridding loop wants. It stops being the right answer
//! when the grid is enormous and the coverage is thin, which happens whenever
//! somebody grids a transit at the resolution of the survey block, and then a
//! dense grid asks for tens of gigabytes and the process dies.
//!
//! So the storage is a choice, made once when the surface is built, and both
//! options behave identically apart from what they cost.

use std::collections::HashMap;

use super::cell::Cell;

/// Cells above which a dense grid is refused unless asked for explicitly.
///
/// A hundred million cells of a hundred bytes is ten gigabytes, which is
/// past what any machine on a boat has.
pub const DENSE_CELL_LIMIT: usize = 100_000_000;

/// How the cells are held.
#[derive(Debug, Clone, PartialEq)]
pub enum CellStore {
    /// One cell per square, allocated up front.
    Dense(Vec<Cell>),
    /// Only the squares that have something in them.
    Sparse {
        /// Cells by flat offset.
        cells: HashMap<usize, Cell>,
        /// How many squares the grid has, for iteration.
        len: usize,
    },
}

impl CellStore {
    /// A dense store of a given size.
    pub fn dense(len: usize) -> CellStore {
        CellStore::Dense(vec![Cell::EMPTY; len])
    }

    /// A sparse store of a given size.
    pub fn sparse(len: usize) -> CellStore {
        CellStore::Sparse {
            cells: HashMap::new(),
            len,
        }
    }

    /// Pick a store for a grid of this size.
    ///
    /// Dense below the limit, sparse above it. The threshold is about memory
    /// and nothing else, so it is a constant rather than a guess about what
    /// the data looks like.
    pub fn for_size(len: usize) -> CellStore {
        if len <= DENSE_CELL_LIMIT / 100 {
            CellStore::dense(len)
        } else {
            CellStore::sparse(len)
        }
    }

    /// How many squares the grid has.
    pub fn len(&self) -> usize {
        match self {
            CellStore::Dense(cells) => cells.len(),
            CellStore::Sparse { len, .. } => *len,
        }
    }

    /// True when the grid has no squares at all.
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// True when this store only holds what has been written to it.
    pub fn is_sparse(&self) -> bool {
        matches!(self, CellStore::Sparse { .. })
    }

    /// The cell at an offset, or the empty cell.
    pub fn get(&self, offset: usize) -> Cell {
        match self {
            CellStore::Dense(cells) => cells.get(offset).copied().unwrap_or(Cell::EMPTY),
            CellStore::Sparse { cells, .. } => cells.get(&offset).copied().unwrap_or(Cell::EMPTY),
        }
    }

    /// Add a sounding to the cell at an offset.
    pub fn add(&mut self, offset: usize, depth: f64, uncertainty: f64) {
        match self {
            CellStore::Dense(cells) => {
                if let Some(cell) = cells.get_mut(offset) {
                    cell.add(depth, uncertainty);
                }
            }
            CellStore::Sparse { cells, len } => {
                if offset < *len {
                    cells
                        .entry(offset)
                        .or_insert(Cell::EMPTY)
                        .add(depth, uncertainty);
                }
            }
        }
    }

    /// Fold another store of the same size into this one.
    pub fn merge(&mut self, other: &CellStore) {
        for offset in 0..self.len().min(other.len()) {
            let theirs = other.get(offset);
            if theirs.is_empty() {
                continue;
            }
            match self {
                CellStore::Dense(cells) => cells[offset].merge(&theirs),
                CellStore::Sparse { cells, .. } => {
                    cells.entry(offset).or_insert(Cell::EMPTY).merge(&theirs)
                }
            }
        }
    }

    /// How many squares have anything in them.
    pub fn populated(&self) -> usize {
        match self {
            CellStore::Dense(cells) => cells.iter().filter(|c| !c.is_empty()).count(),
            CellStore::Sparse { cells, .. } => cells.values().filter(|c| !c.is_empty()).count(),
        }
    }

    /// Every cell in offset order, empty ones included.
    ///
    /// A sparse store materialises the empty cells as it goes rather than
    /// storing them, so this is the same sequence either way and the callers
    /// that render a raster do not care which store they have.
    pub fn iter(&self) -> impl Iterator<Item = Cell> + '_ {
        (0..self.len()).map(move |offset| self.get(offset))
    }

    /// Bytes this store is holding, roughly, for the log.
    pub fn footprint(&self) -> usize {
        let cell = size_of::<Cell>();
        match self {
            CellStore::Dense(cells) => cells.len() * cell,
            CellStore::Sparse { cells, .. } => cells.len() * (cell + size_of::<usize>()),
        }
    }
}
