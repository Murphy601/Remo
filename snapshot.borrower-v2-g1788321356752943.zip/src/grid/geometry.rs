//! Where the cells of a surface are.
//!
//! A grid is defined on a projection, not on the ellipsoid, because cells have
//! to be square and a degree of longitude is not a degree of latitude. The
//! origin is the lower left corner of the lower left cell, and a position on a
//! cell boundary belongs to the cell above and to the right of it, which is
//! the convention that makes adjacent grids tile without overlap.

use crate::error::{Error, Result};
use crate::geodesy::utm::Projected;

/// The index of one cell.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct CellIndex {
    /// Column, counting east from the origin.
    pub column: i64,
    /// Row, counting north from the origin.
    pub row: i64,
}

impl CellIndex {
    /// Build an index.
    pub const fn new(column: i64, row: i64) -> Self {
        CellIndex { column, row }
    }

    /// The eight cells around this one, plus this one, in a fixed order.
    pub fn neighbourhood(&self) -> [CellIndex; 9] {
        let mut out = [*self; 9];
        let mut i = 0;
        for dr in -1..=1 {
            for dc in -1..=1 {
                out[i] = CellIndex::new(self.column + dc, self.row + dr);
                i += 1;
            }
        }
        out
    }
}

/// A regular square grid on a projected plane.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct GridGeometry {
    /// Easting of the lower left corner.
    pub origin_east: f64,
    /// Northing of the lower left corner.
    pub origin_north: f64,
    /// Side of a cell in metres.
    pub cell_size: f64,
    /// Number of columns.
    pub columns: usize,
    /// Number of rows.
    pub rows: usize,
}

impl GridGeometry {
    /// Build a grid.
    pub fn new(
        origin_east: f64,
        origin_north: f64,
        cell_size: f64,
        columns: usize,
        rows: usize,
    ) -> Result<Self> {
        if !(cell_size.is_finite() && cell_size > 0.0) {
            return Err(Error::domain("cell size", cell_size, "finite and positive"));
        }
        if columns == 0 || rows == 0 {
            return Err(Error::Config("a grid needs at least one cell".into()));
        }
        Ok(GridGeometry {
            origin_east,
            origin_north,
            cell_size,
            columns,
            rows,
        })
    }

    /// Build a grid that covers a bounding box, rounded out to whole cells.
    ///
    /// The origin is snapped down to a multiple of the cell size so that two
    /// grids built at the same resolution from different survey blocks line up
    /// and can be merged without resampling.
    pub fn covering(
        min_east: f64,
        min_north: f64,
        max_east: f64,
        max_north: f64,
        cell_size: f64,
    ) -> Result<Self> {
        if !(cell_size.is_finite() && cell_size > 0.0) {
            return Err(Error::domain("cell size", cell_size, "finite and positive"));
        }
        if max_east < min_east || max_north < min_north {
            return Err(Error::Config("bounding box is inside out".into()));
        }
        let origin_east = (min_east / cell_size).floor() * cell_size;
        let origin_north = (min_north / cell_size).floor() * cell_size;
        let columns = (((max_east - origin_east) / cell_size).ceil() as usize).max(1);
        let rows = (((max_north - origin_north) / cell_size).ceil() as usize).max(1);
        GridGeometry::new(origin_east, origin_north, cell_size, columns, rows)
    }

    /// Total number of cells.
    pub fn cell_count(&self) -> usize {
        self.columns * self.rows
    }

    /// Easting of the right hand edge.
    pub fn max_east(&self) -> f64 {
        self.origin_east + self.cell_size * self.columns as f64
    }

    /// Northing of the top edge.
    pub fn max_north(&self) -> f64 {
        self.origin_north + self.cell_size * self.rows as f64
    }

    /// Which cell a projected position falls in, whether or not it is inside
    /// the grid.
    pub fn index_of(&self, p: Projected) -> CellIndex {
        CellIndex::new(
            ((p.east - self.origin_east) / self.cell_size).floor() as i64,
            ((p.north - self.origin_north) / self.cell_size).floor() as i64,
        )
    }

    /// True when an index is inside the grid.
    pub fn contains(&self, index: CellIndex) -> bool {
        index.column >= 0
            && index.row >= 0
            && (index.column as usize) < self.columns
            && (index.row as usize) < self.rows
    }

    /// Position of the centre of a cell.
    pub fn centre_of(&self, index: CellIndex) -> Projected {
        Projected::new(
            self.origin_east + (index.column as f64 + 0.5) * self.cell_size,
            self.origin_north + (index.row as f64 + 0.5) * self.cell_size,
        )
    }

    /// Flat offset of a cell into a row major array, or `None` when it is
    /// outside the grid.
    pub fn offset_of(&self, index: CellIndex) -> Option<usize> {
        if !self.contains(index) {
            return None;
        }
        Some(index.row as usize * self.columns + index.column as usize)
    }

    /// The index that a flat offset corresponds to.
    pub fn index_at_offset(&self, offset: usize) -> Option<CellIndex> {
        if offset >= self.cell_count() {
            return None;
        }
        Some(CellIndex::new(
            (offset % self.columns) as i64,
            (offset / self.columns) as i64,
        ))
    }
}
