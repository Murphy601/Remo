//! A whole surface of contested cells, and the two pass resolution over it.
//!
//! Accumulation is per cell and order independent. Resolution is not: a cell
//! with two equally supported hypotheses is settled by looking at what its
//! neighbours decided, and its neighbours have the same problem. The way out
//! is two passes. The first settles every cell that can be settled without
//! outside help, the second uses those answers as the guide for the rest.

use crate::error::Result;
use crate::geodesy::utm::TransverseMercator;
use crate::ping::sounding::Sounding;

use super::estimator::DepthRaster;
use super::estimator::Estimator;
use super::geometry::{CellIndex, GridGeometry};
use super::hypothesis::{Disambiguation, HypothesisSet};

/// Default agreement threshold in standard deviations.
pub const DEFAULT_THRESHOLD: f64 = 2.5;

/// A grid where every cell can hold several answers.
#[derive(Debug, Clone)]
pub struct ContestedSurface {
    geometry: GridGeometry,
    projection: TransverseMercator,
    cells: Vec<HypothesisSet>,
    threshold: f64,
    outside: u64,
}

impl ContestedSurface {
    /// Build an empty surface.
    pub fn new(geometry: GridGeometry, projection: TransverseMercator, threshold: f64) -> Self {
        ContestedSurface {
            cells: vec![HypothesisSet::new(); geometry.cell_count()],
            geometry,
            projection,
            threshold,
            outside: 0,
        }
    }

    /// The geometry.
    pub fn geometry(&self) -> &GridGeometry {
        &self.geometry
    }

    /// How many soundings fell outside the grid.
    pub fn outside_count(&self) -> u64 {
        self.outside
    }

    /// The hypothesis set in a cell.
    pub fn cell(&self, index: CellIndex) -> Option<&HypothesisSet> {
        self.geometry.offset_of(index).map(|o| &self.cells[o])
    }

    /// Add one accepted sounding.
    pub fn add(&mut self, sounding: &Sounding) -> Result<bool> {
        if !sounding.is_accepted() {
            return Ok(false);
        }
        let projected = self.projection.forward(sounding.position)?;
        let index = self.geometry.index_of(projected);
        match self.geometry.offset_of(index) {
            Some(offset) => {
                self.cells[offset].add(sounding.depth, sounding.tvu, self.threshold);
                Ok(true)
            }
            None => {
                self.outside += 1;
                Ok(false)
            }
        }
    }

    /// Add every sounding in a slice, returning how many landed on the grid.
    pub fn add_all(&mut self, soundings: &[Sounding]) -> Result<usize> {
        let mut landed = 0;
        for s in soundings {
            if self.add(s)? {
                landed += 1;
            }
        }
        Ok(landed)
    }

    /// Cells holding more than one hypothesis.
    pub fn contested_cells(&self) -> usize {
        self.cells.iter().filter(|c| c.len() > 1).count()
    }

    /// Resolve the whole surface to one depth per cell.
    ///
    /// The first pass takes every uncontested cell, and every contested one
    /// under a rule that needs no guide. The second pass revisits the cells
    /// the first left open, using the median of whatever their neighbours
    /// settled on as the guide.
    pub fn resolve(&self, rule: Disambiguation) -> DepthRaster {
        let mut depths: Vec<Option<f64>> = self
            .cells
            .iter()
            .map(|set| {
                if set.len() <= 1 || rule != Disambiguation::NearestToGuide {
                    set.resolve(rule, None).map(|h| h.depth)
                } else {
                    None
                }
            })
            .collect();

        if rule == Disambiguation::NearestToGuide {
            let first_pass = depths.clone();
            for (offset, settled) in depths.iter_mut().enumerate() {
                if settled.is_some() || self.cells[offset].is_empty() {
                    continue;
                }
                let Some(index) = self.geometry.index_at_offset(offset) else {
                    continue;
                };
                let guide = self.neighbour_median(&first_pass, index);
                *settled = self.cells[offset].resolve(rule, guide).map(|h| h.depth);
            }
        }

        DepthRaster {
            columns: self.geometry.columns,
            rows: self.geometry.rows,
            depths,
            estimator: Estimator::WeightedMean,
        }
    }

    /// Median of the settled depths around a cell, ignoring the cell itself.
    fn neighbour_median(&self, settled: &[Option<f64>], index: CellIndex) -> Option<f64> {
        let mut values: Vec<f64> = index
            .neighbourhood()
            .into_iter()
            .filter(|n| *n != index)
            .filter_map(|n| self.geometry.offset_of(n))
            .filter_map(|o| settled[o])
            .collect();
        if values.is_empty() {
            return None;
        }
        values.sort_by(f64::total_cmp);
        Some(values[values.len() / 2])
    }

    /// A raster of the contention of every cell, for the plot that tells a
    /// hydrographer where to look.
    pub fn contention_raster(&self) -> DepthRaster {
        DepthRaster {
            columns: self.geometry.columns,
            rows: self.geometry.rows,
            depths: self
                .cells
                .iter()
                .map(|c| {
                    if c.is_empty() {
                        None
                    } else {
                        Some(c.contention())
                    }
                })
                .collect(),
            estimator: Estimator::Mean,
        }
    }
}
