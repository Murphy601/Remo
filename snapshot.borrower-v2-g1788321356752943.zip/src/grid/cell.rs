//! What one cell of a surface remembers about the soundings in it.
//!
//! A cell cannot keep its soundings. A day of shallow water multibeam is a few
//! hundred million of them, and the whole point of gridding is to stop
//! carrying them around. So the cell keeps running statistics instead, updated
//! one sounding at a time, and everything it can report has to be derivable
//! from those.
//!
//! The mean and variance are accumulated by Welford recurrence rather than by
//! summing squares. Depths in a harbour are all within a metre of each other
//! and a few hundred metres from zero, which is exactly the case where the
//! naive sum of squares loses most of its significant figures.

/// Running statistics over the soundings that landed in one cell.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Cell {
    count: u32,
    mean: f64,
    m2: f64,
    shoalest: f64,
    deepest: f64,
    weight_sum: f64,
    weighted_depth_sum: f64,
    min_uncertainty: f64,
}

impl Cell {
    /// An empty cell.
    pub const EMPTY: Cell = Cell {
        count: 0,
        mean: 0.0,
        m2: 0.0,
        shoalest: f64::INFINITY,
        deepest: f64::NEG_INFINITY,
        weight_sum: 0.0,
        weighted_depth_sum: 0.0,
        min_uncertainty: f64::INFINITY,
    };

    /// Add a sounding, weighted by the inverse square of its uncertainty.
    ///
    /// A sounding with no uncertainty at all would have infinite weight, so a
    /// floor is applied. A millimetre is well below anything a multibeam can
    /// actually deliver and keeps the arithmetic finite.
    pub fn add(&mut self, depth: f64, uncertainty: f64) {
        if !depth.is_finite() {
            return;
        }
        self.count += 1;
        let delta = depth - self.mean;
        self.mean += delta / self.count as f64;
        self.m2 += delta * (depth - self.mean);

        if depth < self.shoalest {
            self.shoalest = depth;
        }
        if depth > self.deepest {
            self.deepest = depth;
        }

        let sigma = uncertainty.abs().max(0.001);
        let weight = 1.0 / (sigma * sigma);
        self.weight_sum += weight;
        self.weighted_depth_sum += weight * depth;
        if sigma < self.min_uncertainty {
            self.min_uncertainty = sigma;
        }
    }

    /// How many soundings landed here.
    pub fn count(&self) -> u32 {
        self.count
    }

    /// True when nothing has landed here.
    pub fn is_empty(&self) -> bool {
        self.count == 0
    }

    /// Arithmetic mean depth.
    pub fn mean(&self) -> Option<f64> {
        if self.count == 0 {
            None
        } else {
            Some(self.mean)
        }
    }

    /// Shallowest depth seen, which is what goes on a navigation chart.
    pub fn shoalest(&self) -> Option<f64> {
        if self.count == 0 {
            None
        } else {
            Some(self.shoalest)
        }
    }

    /// Deepest depth seen.
    pub fn deepest(&self) -> Option<f64> {
        if self.count == 0 {
            None
        } else {
            Some(self.deepest)
        }
    }

    /// Sample standard deviation of the depths, needing two soundings.
    pub fn standard_deviation(&self) -> Option<f64> {
        if self.count < 2 {
            None
        } else {
            Some((self.m2 / (self.count - 1) as f64).sqrt())
        }
    }

    /// Depth weighted by the inverse square of each uncertainty.
    ///
    /// This is the estimate to use when the cell holds soundings from
    /// different parts of the swath, because an outer beam is worth several
    /// times less than a nadir one and averaging them evenly throws that away.
    pub fn weighted_mean(&self) -> Option<f64> {
        if self.count == 0 || self.weight_sum <= 0.0 {
            None
        } else {
            Some(self.weighted_depth_sum / self.weight_sum)
        }
    }

    /// Uncertainty of the weighted mean, one sigma.
    pub fn weighted_uncertainty(&self) -> Option<f64> {
        if self.count == 0 || self.weight_sum <= 0.0 {
            None
        } else {
            Some((1.0 / self.weight_sum).sqrt())
        }
    }

    /// Smallest uncertainty of any sounding in the cell.
    pub fn best_uncertainty(&self) -> Option<f64> {
        if self.count == 0 {
            None
        } else {
            Some(self.min_uncertainty)
        }
    }

    /// Spread between the shallowest and deepest sounding.
    pub fn range(&self) -> Option<f64> {
        if self.count == 0 {
            None
        } else {
            Some(self.deepest - self.shoalest)
        }
    }

    /// Fold another cell into this one.
    ///
    /// Used when two surfaces of the same geometry are merged. The variance
    /// combines by the parallel form of the Welford recurrence, which is exact
    /// rather than a reconstruction from the two means.
    pub fn merge(&mut self, other: &Cell) {
        if other.count == 0 {
            return;
        }
        if self.count == 0 {
            *self = *other;
            return;
        }
        let n_a = self.count as f64;
        let n_b = other.count as f64;
        let delta = other.mean - self.mean;
        let total = n_a + n_b;

        self.mean += delta * n_b / total;
        self.m2 += other.m2 + delta * delta * n_a * n_b / total;
        self.count += other.count;

        self.shoalest = self.shoalest.min(other.shoalest);
        self.deepest = self.deepest.max(other.deepest);
        self.weight_sum += other.weight_sum;
        self.weighted_depth_sum += other.weighted_depth_sum;
        self.min_uncertainty = self.min_uncertainty.min(other.min_uncertainty);
    }
}

impl Default for Cell {
    fn default() -> Self {
        Cell::EMPTY
    }
}
