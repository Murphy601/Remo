//! Turning the statistics in a cell into the one number that goes on a chart.
//!
//! Which number that is depends entirely on what the surface is for. A
//! navigation product takes the shoalest sounding, because the thing that
//! matters is the least depth a ship will find. An engineering volume takes a
//! weighted mean, because a shoal bias integrates into a volume that is
//! systematically wrong. Nobody should have to guess which one a delivered
//! surface used, so it is carried with the surface.

use super::cell::Cell;
use super::surface::Surface;

/// How a cell reports its depth.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Estimator {
    /// Shallowest sounding in the cell. The navigation choice.
    Shoalest,
    /// Deepest sounding in the cell. Used for dredging clearance.
    Deepest,
    /// Arithmetic mean of the soundings.
    Mean,
    /// Mean weighted by the inverse square of the uncertainties.
    WeightedMean,
    /// Shoalest, but only counting cells with enough soundings to believe.
    ///
    /// A single shallow return in an otherwise empty cell is as likely to be a
    /// fish as a rock, and this is the estimator that says so.
    ShoalestOfConfident {
        /// Least number of soundings a cell needs.
        min_soundings: u32,
    },
}

impl Estimator {
    /// The depth this estimator would report for a cell.
    ///
    /// ```
    /// use plumbline::grid::cell::Cell;
    /// use plumbline::grid::estimator::Estimator;
    ///
    /// let mut cell = Cell::EMPTY;
    /// cell.add(18.4, 0.5); // one poor sounding, shallow
    /// cell.add(19.9, 0.1);
    /// cell.add(20.1, 0.1);
    ///
    /// // The chart wants the shallowest thing anybody found.
    /// assert_eq!(Estimator::Shoalest.depth(&cell), Some(18.4));
    /// // A volume wants the estimate the good soundings support.
    /// let weighted = Estimator::WeightedMean.depth(&cell).unwrap();
    /// assert!(weighted > 19.8 && weighted < 20.1);
    /// ```
    pub fn depth(&self, cell: &Cell) -> Option<f64> {
        match self {
            Estimator::Shoalest => cell.shoalest(),
            Estimator::Deepest => cell.deepest(),
            Estimator::Mean => cell.mean(),
            Estimator::WeightedMean => cell.weighted_mean(),
            Estimator::ShoalestOfConfident { min_soundings } => {
                if cell.count() >= *min_soundings {
                    cell.shoalest()
                } else {
                    None
                }
            }
        }
    }

    /// Short name for the log and for the file header.
    pub fn name(&self) -> &'static str {
        match self {
            Estimator::Shoalest => "shoalest",
            Estimator::Deepest => "deepest",
            Estimator::Mean => "mean",
            Estimator::WeightedMean => "weighted mean",
            Estimator::ShoalestOfConfident { .. } => "shoalest of confident",
        }
    }

    /// Parse the name back, without the threshold, which comes from elsewhere.
    pub fn from_name(name: &str) -> Option<Estimator> {
        match name.trim().to_ascii_lowercase().as_str() {
            "shoalest" => Some(Estimator::Shoalest),
            "deepest" => Some(Estimator::Deepest),
            "mean" => Some(Estimator::Mean),
            "weighted mean" | "weighted-mean" => Some(Estimator::WeightedMean),
            "shoalest of confident" | "shoalest-of-confident" => {
                Some(Estimator::ShoalestOfConfident { min_soundings: 3 })
            }
            _ => None,
        }
    }

    /// True when this estimator is biased towards the shallow side, which the
    /// report has to say for a volume calculation to be believed.
    pub fn is_shoal_biased(&self) -> bool {
        matches!(
            self,
            Estimator::Shoalest | Estimator::ShoalestOfConfident { .. }
        )
    }
}

/// A surface rendered down to one depth per cell.
#[derive(Debug, Clone, PartialEq)]
pub struct DepthRaster {
    /// Number of columns, matching the surface geometry.
    pub columns: usize,
    /// Number of rows.
    pub rows: usize,
    /// Depths in row major order, lower left first, with holes as `None`.
    pub depths: Vec<Option<f64>>,
    /// Which estimator produced it.
    pub estimator: Estimator,
}

impl DepthRaster {
    /// How many cells carry a depth.
    pub fn populated(&self) -> usize {
        self.depths.iter().filter(|d| d.is_some()).count()
    }

    /// Shallowest and deepest value in the raster.
    pub fn range(&self) -> Option<(f64, f64)> {
        let mut lo = f64::INFINITY;
        let mut hi = f64::NEG_INFINITY;
        for d in self.depths.iter().flatten() {
            lo = lo.min(*d);
            hi = hi.max(*d);
        }
        if lo.is_finite() {
            Some((lo, hi))
        } else {
            None
        }
    }

    /// The depth at a row and column.
    pub fn at(&self, column: usize, row: usize) -> Option<f64> {
        if column >= self.columns || row >= self.rows {
            return None;
        }
        self.depths[row * self.columns + column]
    }
}

/// Render a surface with an estimator.
pub fn render(surface: &Surface, estimator: Estimator) -> DepthRaster {
    let geometry = surface.geometry();
    DepthRaster {
        columns: geometry.columns,
        rows: geometry.rows,
        depths: surface.cells().map(|c| estimator.depth(&c)).collect(),
        estimator,
    }
}

/// Render the uncertainty of a surface alongside its depth.
///
/// A depth surface without an uncertainty surface beside it is half a
/// deliverable, and the two have to come off the same cells or they disagree
/// at the edges of coverage.
pub fn render_uncertainty(surface: &Surface, estimator: Estimator) -> DepthRaster {
    let geometry = surface.geometry();
    let depths = surface
        .cells()
        .map(|c| match estimator {
            Estimator::WeightedMean | Estimator::Mean => c.weighted_uncertainty(),
            _ => c.best_uncertainty(),
        })
        .collect();
    DepthRaster {
        columns: geometry.columns,
        rows: geometry.rows,
        depths,
        estimator,
    }
}
