//! A gridded surface: the geometry, the projection, and one cell per square.

use crate::error::Result;
use crate::geodesy::utm::{Projected, TransverseMercator};
use crate::geodesy::Geodetic;
use crate::ping::sounding::Sounding;

use super::cell::Cell;
use super::geometry::{CellIndex, GridGeometry};
use super::store::CellStore;

/// A grid of cells with the projection that puts soundings into them.
#[derive(Debug, Clone)]
pub struct Surface {
    geometry: GridGeometry,
    projection: TransverseMercator,
    cells: CellStore,
    outside: u64,
}

impl Surface {
    /// Build an empty surface, choosing the storage to suit its size.
    pub fn new(geometry: GridGeometry, projection: TransverseMercator) -> Self {
        Surface {
            cells: CellStore::for_size(geometry.cell_count()),
            geometry,
            projection,
            outside: 0,
        }
    }

    /// Build an empty surface with the storage named rather than chosen.
    pub fn with_store(
        geometry: GridGeometry,
        projection: TransverseMercator,
        cells: CellStore,
    ) -> Self {
        Surface {
            cells,
            geometry,
            projection,
            outside: 0,
        }
    }

    /// How the cells are held, and roughly what that costs.
    pub fn store(&self) -> &CellStore {
        &self.cells
    }

    /// The geometry.
    pub fn geometry(&self) -> &GridGeometry {
        &self.geometry
    }

    /// The projection soundings are put through.
    pub fn projection(&self) -> &TransverseMercator {
        &self.projection
    }

    /// How many soundings fell outside the grid.
    ///
    /// Worth reporting rather than hiding: a run where a tenth of the
    /// soundings missed the grid usually means the grid was defined from the
    /// wrong block, not that the survey overshot.
    pub fn outside_count(&self) -> u64 {
        self.outside
    }

    /// A cell by index.
    pub fn cell(&self, index: CellIndex) -> Option<Cell> {
        self.geometry.offset_of(index).map(|o| self.cells.get(o))
    }

    /// Every cell in row major order, lower left first.
    pub fn cells(&self) -> impl Iterator<Item = Cell> + '_ {
        self.cells.iter()
    }

    /// How many cells have at least one sounding in them.
    pub fn populated_cells(&self) -> usize {
        self.cells.populated()
    }

    /// Fraction of the grid that has any data at all.
    pub fn coverage(&self) -> f64 {
        if self.cells.is_empty() {
            0.0
        } else {
            self.populated_cells() as f64 / self.cells.len() as f64
        }
    }

    /// Add one accepted sounding.
    ///
    /// Rejected soundings are ignored here rather than at the call site, so
    /// that no caller can accidentally grid the flagged ones by forgetting to
    /// filter first.
    pub fn add(&mut self, sounding: &Sounding) -> Result<bool> {
        if !sounding.is_accepted() {
            return Ok(false);
        }
        let projected = self.projection.forward(sounding.position)?;
        Ok(self.add_at(projected, sounding.depth, sounding.tvu))
    }

    /// Add a depth at a projected position, bypassing the projection.
    pub fn add_at(&mut self, position: Projected, depth: f64, uncertainty: f64) -> bool {
        let index = self.geometry.index_of(position);
        match self.geometry.offset_of(index) {
            Some(offset) => {
                self.cells.add(offset, depth, uncertainty);
                true
            }
            None => {
                self.outside += 1;
                false
            }
        }
    }

    /// Add every sounding in a slice, returning how many landed on the grid.
    pub fn add_all(&mut self, soundings: &[Sounding]) -> Result<usize> {
        let mut landed = 0;
        for s in soundings {
            if self.add(s)? {
                landed += 1;
            }
        }
        Ok(landed)
    }

    /// Geographic position of the centre of a cell.
    pub fn position_of(&self, index: CellIndex) -> Result<Geodetic> {
        self.projection.inverse(self.geometry.centre_of(index))
    }

    /// Merge another surface into this one.
    ///
    /// The two have to share a geometry exactly. Resampling one grid onto
    /// another is a different operation with different error properties and it
    /// does not belong hidden inside a merge.
    pub fn merge(&mut self, other: &Surface) -> Result<()> {
        if other.geometry != self.geometry {
            return Err(crate::Error::Config(
                "cannot merge surfaces with different geometry".into(),
            ));
        }
        self.cells.merge(&other.cells);
        self.outside += other.outside;
        Ok(())
    }

    /// Shallowest and deepest cell value over the whole surface.
    pub fn depth_range(&self) -> Option<(f64, f64)> {
        let mut lo = f64::INFINITY;
        let mut hi = f64::NEG_INFINITY;
        for c in self.cells.iter() {
            if let (Some(s), Some(d)) = (c.shoalest(), c.deepest()) {
                lo = lo.min(s);
                hi = hi.max(d);
            }
        }
        if lo.is_finite() {
            Some((lo, hi))
        } else {
            None
        }
    }
}
