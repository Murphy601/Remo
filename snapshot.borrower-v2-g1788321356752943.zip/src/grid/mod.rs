//! Combining soundings into a surface.

pub mod cell;
pub mod contested;
pub mod estimator;
pub mod geometry;
pub mod hypothesis;
pub mod resample;
pub mod slope;
pub mod store;
pub mod surface;

pub use cell::Cell;
pub use contested::ContestedSurface;
pub use estimator::{render, DepthRaster, Estimator};
pub use geometry::{CellIndex, GridGeometry};
pub use hypothesis::{Disambiguation, Hypothesis, HypothesisSet};
pub use resample::{coarsen_shoalest, resample, Method};
pub use slope::{gradients, hillshade, slope_raster, Gradient};
pub use store::CellStore;
pub use surface::Surface;
