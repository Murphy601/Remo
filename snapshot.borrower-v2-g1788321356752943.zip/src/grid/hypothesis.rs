//! Keeping more than one answer for a cell.
//!
//! A single mean per cell is wrong wherever the soundings in that cell
//! disagree for a real reason: a wreck standing off the seabed, a pier with
//! water under it, two survey lines a year apart over a mobile bank. Averaging
//! them produces a depth that is nowhere on the seabed at all.
//!
//! The answer, following the idea behind the CUBE algorithm, is to let a cell
//! hold several competing depth hypotheses, feed each sounding to whichever
//! one it agrees with, and choose between them at the end with a rule that is
//! written down. This is a small version of that: no propagation between
//! neighbouring cells during accumulation, only at the disambiguation step.

/// One competing answer for a cell.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Hypothesis {
    /// Current depth estimate.
    pub depth: f64,
    /// Variance of that estimate.
    pub variance: f64,
    /// How many soundings support it.
    pub count: u32,
}

impl Hypothesis {
    /// Start a hypothesis from one sounding.
    pub fn seed(depth: f64, uncertainty: f64) -> Self {
        let sigma = uncertainty.abs().max(0.001);
        Hypothesis {
            depth,
            variance: sigma * sigma,
            count: 1,
        }
    }

    /// One sigma of the estimate.
    pub fn sigma(&self) -> f64 {
        self.variance.sqrt()
    }

    /// How many standard deviations a depth is from this hypothesis.
    ///
    /// The comparison uses the uncertainty of the incoming sounding as well as
    /// that of the hypothesis. A precise sounding two decimetres off a shaky
    /// hypothesis is a weaker disagreement than the same gap between two
    /// precise ones.
    pub fn distance_to(&self, depth: f64, uncertainty: f64) -> f64 {
        let sigma = uncertainty.abs().max(0.001);
        let combined = (self.variance + sigma * sigma).sqrt();
        if combined <= 0.0 {
            f64::INFINITY
        } else {
            (depth - self.depth).abs() / combined
        }
    }

    /// Fold a sounding into this hypothesis.
    ///
    /// Inverse variance weighting, which for two independent estimates is the
    /// minimum variance combination and is what a Kalman update reduces to
    /// when the state does not move between observations.
    pub fn update(&mut self, depth: f64, uncertainty: f64) {
        let sigma = uncertainty.abs().max(0.001);
        let r = sigma * sigma;
        let gain = self.variance / (self.variance + r);
        self.depth += gain * (depth - self.depth);
        self.variance *= 1.0 - gain;
        self.count += 1;
    }
}

/// How to choose between the hypotheses in a cell.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Disambiguation {
    /// The one with the most soundings behind it.
    MostSounded,
    /// The shallowest one, which is the safe choice for navigation.
    Shoalest,
    /// The one with the smallest variance.
    LeastUncertain,
    /// The one closest to a depth taken from somewhere else, normally the
    /// resolved depth of the neighbouring cells.
    NearestToGuide,
}

impl Disambiguation {
    /// Short name for the log.
    pub fn name(&self) -> &'static str {
        match self {
            Disambiguation::MostSounded => "most sounded",
            Disambiguation::Shoalest => "shoalest",
            Disambiguation::LeastUncertain => "least uncertain",
            Disambiguation::NearestToGuide => "nearest to guide",
        }
    }
}

/// The set of hypotheses one cell is carrying.
#[derive(Debug, Clone, PartialEq, Default)]
pub struct HypothesisSet {
    hypotheses: Vec<Hypothesis>,
}

impl HypothesisSet {
    /// An empty set.
    pub fn new() -> Self {
        HypothesisSet {
            hypotheses: Vec::new(),
        }
    }

    /// The hypotheses, in the order they were created.
    pub fn hypotheses(&self) -> &[Hypothesis] {
        &self.hypotheses
    }

    /// How many competing answers this cell holds.
    pub fn len(&self) -> usize {
        self.hypotheses.len()
    }

    /// True when nothing has been added.
    pub fn is_empty(&self) -> bool {
        self.hypotheses.is_empty()
    }

    /// Total soundings across every hypothesis.
    pub fn total_soundings(&self) -> u32 {
        self.hypotheses.iter().map(|h| h.count).sum()
    }

    /// Add a sounding, joining the nearest hypothesis it agrees with or
    /// starting a new one.
    ///
    /// `threshold` is in standard deviations. Around two and a half, a real
    /// wreck stays separate from the seabed under it and ordinary noise does
    /// not split into two hypotheses.
    pub fn add(&mut self, depth: f64, uncertainty: f64, threshold: f64) {
        if !depth.is_finite() {
            return;
        }
        let mut best: Option<(usize, f64)> = None;
        for (i, h) in self.hypotheses.iter().enumerate() {
            let d = h.distance_to(depth, uncertainty);
            if d <= threshold && best.map(|(_, bd)| d < bd).unwrap_or(true) {
                best = Some((i, d));
            }
        }
        match best {
            Some((i, _)) => self.hypotheses[i].update(depth, uncertainty),
            None => self.hypotheses.push(Hypothesis::seed(depth, uncertainty)),
        }
    }

    /// Choose one hypothesis.
    ///
    /// The guide is only used by the nearest to guide rule and is ignored
    /// otherwise, so a caller with no neighbours resolved yet can pass
    /// anything.
    pub fn resolve(&self, rule: Disambiguation, guide: Option<f64>) -> Option<Hypothesis> {
        if self.hypotheses.is_empty() {
            return None;
        }
        let chosen = match rule {
            Disambiguation::MostSounded => self.hypotheses.iter().max_by(|a, b| {
                a.count
                    .cmp(&b.count)
                    .then(b.variance.total_cmp(&a.variance))
            }),
            Disambiguation::Shoalest => self
                .hypotheses
                .iter()
                .min_by(|a, b| a.depth.total_cmp(&b.depth)),
            Disambiguation::LeastUncertain => self
                .hypotheses
                .iter()
                .min_by(|a, b| a.variance.total_cmp(&b.variance)),
            Disambiguation::NearestToGuide => match guide {
                Some(g) => self
                    .hypotheses
                    .iter()
                    .min_by(|a, b| (a.depth - g).abs().total_cmp(&(b.depth - g).abs())),
                // With nothing to compare against, fall back to the rule that
                // needs no outside information.
                None => self.hypotheses.iter().max_by(|a, b| a.count.cmp(&b.count)),
            },
        };
        chosen.copied()
    }

    /// A measure of how contested the cell is, between zero and one.
    ///
    /// One hypothesis with everything behind it scores zero. Two hypotheses
    /// with the same support score one. This is the number that tells a
    /// hydrographer which cells to go and look at by hand.
    pub fn contention(&self) -> f64 {
        if self.hypotheses.len() < 2 {
            return 0.0;
        }
        let total = self.total_soundings();
        if total == 0 {
            return 0.0;
        }
        let mut counts: Vec<u32> = self.hypotheses.iter().map(|h| h.count).collect();
        counts.sort_unstable_by(|a, b| b.cmp(a));
        counts[1] as f64 / counts[0] as f64
    }
}
