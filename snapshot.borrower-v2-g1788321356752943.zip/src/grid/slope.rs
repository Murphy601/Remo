//! Slope, aspect and hillshade over a depth raster.
//!
//! Depth on its own hides everything. A ten centimetre step across a swath
//! edge is invisible in a colour ramp over thirty metres of water and obvious
//! the moment the surface is shaded, which is why every hydrographer looks at
//! the shaded relief before they look at the depths. The gradient is also what
//! a slope limit for an order is judged against.
//!
//! The derivative is the Horn third order estimate over the eight neighbours,
//! which is what the whole terrain analysis world uses and is far less noisy
//! than a two cell difference on data with any scatter in it.

use crate::grid::estimator::{DepthRaster, Estimator};
use crate::units::Angle;

/// Slope and aspect of one cell.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Gradient {
    /// Steepest slope, as an angle from horizontal.
    pub slope: Angle,
    /// Direction the seabed falls away towards, clockwise from grid north.
    pub aspect: Angle,
    /// Rate of change east, in metres of depth per metre.
    pub d_east: f64,
    /// Rate of change north.
    pub d_north: f64,
}

/// The gradient of every cell, with holes where the eight neighbours are not
/// all present.
///
/// Refusing to compute a gradient at the edge of coverage is deliberate. A one
/// sided difference at the edge of a swath produces a slope that looks like a
/// real feature and is an artefact of where the data stops.
pub fn gradients(raster: &DepthRaster, cell_size: f64) -> Vec<Option<Gradient>> {
    let columns = raster.columns;
    let rows = raster.rows;
    let mut out = vec![None; columns * rows];
    if columns < 3 || rows < 3 || cell_size <= 0.0 {
        return out;
    }

    for row in 1..rows - 1 {
        for column in 1..columns - 1 {
            let mut window = [0.0f64; 9];
            let mut complete = true;
            for (i, (dc, dr)) in [
                (-1i64, -1i64),
                (0, -1),
                (1, -1),
                (-1, 0),
                (0, 0),
                (1, 0),
                (-1, 1),
                (0, 1),
                (1, 1),
            ]
            .into_iter()
            .enumerate()
            {
                let c = (column as i64 + dc) as usize;
                let r = (row as i64 + dr) as usize;
                match raster.at(c, r) {
                    Some(v) => window[i] = v,
                    None => {
                        complete = false;
                        break;
                    }
                }
            }
            if !complete {
                continue;
            }

            // Horn, with the window laid out south row first.
            let d_east = ((window[2] + 2.0 * window[5] + window[8])
                - (window[0] + 2.0 * window[3] + window[6]))
                / (8.0 * cell_size);
            let d_north = ((window[6] + 2.0 * window[7] + window[8])
                - (window[0] + 2.0 * window[1] + window[2]))
                / (8.0 * cell_size);

            let magnitude = (d_east * d_east + d_north * d_north).sqrt();
            out[row * columns + column] = Some(Gradient {
                slope: Angle::from_radians(magnitude.atan()),
                aspect: Angle::from_radians(d_east.atan2(d_north)).wrapped(),
                d_east,
                d_north,
            });
        }
    }
    out
}

/// Slope of every cell in degrees, as a raster.
pub fn slope_raster(raster: &DepthRaster, cell_size: f64) -> DepthRaster {
    DepthRaster {
        columns: raster.columns,
        rows: raster.rows,
        depths: gradients(raster, cell_size)
            .into_iter()
            .map(|g| g.map(|g| g.slope.degrees()))
            .collect(),
        estimator: Estimator::Mean,
    }
}

/// Shaded relief, from zero in shadow to one in full light.
///
/// Depth increases downwards, so the sign of the gradient is flipped on the
/// way in: a surface shaded without that flip is lit from the wrong side and
/// every bank reads as a channel. It is a mistake that survives review because
/// the picture still looks like a seabed.
pub fn hillshade(
    raster: &DepthRaster,
    cell_size: f64,
    azimuth: Angle,
    altitude: Angle,
) -> DepthRaster {
    let (sin_alt, cos_alt) = altitude.sin_cos();
    let depths = gradients(raster, cell_size)
        .into_iter()
        .map(|g| {
            g.map(|g| {
                let slope = Angle::from_radians((-g.d_east).hypot(-g.d_north).atan());
                let aspect = Angle::from_radians((-g.d_east).atan2(-g.d_north));
                let shade =
                    sin_alt * slope.cos() + cos_alt * slope.sin() * (azimuth - aspect).cos();
                shade.clamp(0.0, 1.0)
            })
        })
        .collect();
    DepthRaster {
        columns: raster.columns,
        rows: raster.rows,
        depths,
        estimator: Estimator::Mean,
    }
}

/// The standard light for a shaded relief plot: north west, thirty degrees up.
///
/// Lighting from the north west is a convention rather than a physical choice,
/// and it exists because a human eye reads a surface lit from any other
/// direction as inverted about half the time.
pub fn standard_hillshade(raster: &DepthRaster, cell_size: f64) -> DepthRaster {
    hillshade(
        raster,
        cell_size,
        Angle::from_degrees(315.0),
        Angle::from_degrees(30.0),
    )
}
