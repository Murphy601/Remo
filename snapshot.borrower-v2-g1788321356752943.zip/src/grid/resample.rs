//! Putting one surface onto another grid.
//!
//! Two blocks gridded at the same cell size line up cell for cell, which is
//! what the origin snapping in the geometry is for, and merging those is
//! exact. Anything else needs resampling, and resampling is lossy in a way
//! that matters: a shoalest surface resampled by interpolation is no longer a
//! shoalest surface, because the interpolated value is not any sounding.
//!
//! So there are two methods here and the choice is the caller's. Nearest
//! keeps every value a real cell value and moves it by up to half a cell.
//! Bilinear puts the value in the right place and invents it. For a
//! navigation product the answer is nearest, every time.

use crate::error::{Error, Result};
use crate::grid::estimator::DepthRaster;
use crate::grid::geometry::GridGeometry;

/// How to get a value from the source grid.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Method {
    /// The value of the nearest source cell.
    Nearest,
    /// Bilinear over the four surrounding cells, refusing where any is a hole.
    Bilinear,
}

impl Method {
    /// Short name for the log.
    pub fn name(&self) -> &'static str {
        match self {
            Method::Nearest => "nearest",
            Method::Bilinear => "bilinear",
        }
    }

    /// True when this method can produce a value no sounding ever had.
    pub fn invents_values(&self) -> bool {
        matches!(self, Method::Bilinear)
    }
}

/// Resample a raster onto another geometry.
///
/// Both geometries have to be in the same projection; nothing here checks
/// that, because a raster does not carry one, and resampling between two
/// projections is a different job that has to go through positions.
pub fn resample(
    raster: &DepthRaster,
    from: &GridGeometry,
    to: &GridGeometry,
    method: Method,
) -> Result<DepthRaster> {
    if raster.columns != from.columns || raster.rows != from.rows {
        return Err(Error::Config(
            "the raster and the geometry it came from disagree about its shape".into(),
        ));
    }

    let mut depths = vec![None; to.cell_count()];
    for row in 0..to.rows {
        for column in 0..to.columns {
            let centre = to.centre_of(crate::grid::geometry::CellIndex::new(
                column as i64,
                row as i64,
            ));
            // Where that centre falls in source cell coordinates, with the
            // half cell taken off so that whole numbers land on cell centres.
            let x = (centre.east - from.origin_east) / from.cell_size - 0.5;
            let y = (centre.north - from.origin_north) / from.cell_size - 0.5;
            depths[row * to.columns + column] = match method {
                Method::Nearest => sample_nearest(raster, x, y),
                Method::Bilinear => sample_bilinear(raster, x, y),
            };
        }
    }

    Ok(DepthRaster {
        columns: to.columns,
        rows: to.rows,
        depths,
        estimator: raster.estimator,
    })
}

fn sample_nearest(raster: &DepthRaster, x: f64, y: f64) -> Option<f64> {
    let column = x.round();
    let row = y.round();
    if column < 0.0 || row < 0.0 {
        return None;
    }
    raster.at(column as usize, row as usize)
}

fn sample_bilinear(raster: &DepthRaster, x: f64, y: f64) -> Option<f64> {
    if x < 0.0 || y < 0.0 {
        return None;
    }
    let column = x.floor();
    let row = y.floor();
    let fx = x - column;
    let fy = y - row;
    let column = column as usize;
    let row = row as usize;

    // Landing exactly on a cell centre must not demand the neighbour to its
    // right, or the last row and column of a grid come back empty even when
    // the two grids are identical.
    let next_column = if fx > 0.0 { column + 1 } else { column };
    let next_row = if fy > 0.0 { row + 1 } else { row };

    let v00 = raster.at(column, row)?;
    let v10 = raster.at(next_column, row)?;
    let v01 = raster.at(column, next_row)?;
    let v11 = raster.at(next_column, next_row)?;
    Some((1.0 - fy) * ((1.0 - fx) * v00 + fx * v10) + fy * ((1.0 - fx) * v01 + fx * v11))
}

/// Coarsen a raster by an integer factor, taking the shoalest of each block.
///
/// This is the safe way to make a delivery grid smaller: every value in the
/// result is a value that was in the input, and taking the shallowest of each
/// block cannot make a hazard disappear. Averaging can, and does.
pub fn coarsen_shoalest(raster: &DepthRaster, factor: usize) -> Result<DepthRaster> {
    if factor < 2 {
        return Err(Error::Config(
            "coarsening wants a factor of two or more".into(),
        ));
    }
    let columns = raster.columns.div_ceil(factor);
    let rows = raster.rows.div_ceil(factor);
    let mut depths = vec![None; columns * rows];

    for row in 0..raster.rows {
        for column in 0..raster.columns {
            let Some(value) = raster.at(column, row) else {
                continue;
            };
            let slot = (row / factor) * columns + column / factor;
            depths[slot] = Some(match depths[slot] {
                Some(current) if current <= value => current,
                _ => value,
            });
        }
    }

    Ok(DepthRaster {
        columns,
        rows,
        depths,
        estimator: raster.estimator,
    })
}
