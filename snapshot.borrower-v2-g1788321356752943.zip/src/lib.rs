//! `plumbline` reduces raw multibeam echosounder observations into
//! vertically referenced, uncertainty bearing soundings.
//!
//! The crate is organised along the stages a hydrographic surveyor works
//! through when turning a raw ping into something that can go on a chart:
//!
//! 1. the acoustic observation (a two way travel time and a beam pointing
//!    angle) is bent through the water column,
//! 2. the resulting vector is rotated out of the transducer frame and into a
//!    local level frame using the vessel attitude,
//! 3. the vertical component is referred to a datum,
//! 4. an uncertainty is propagated alongside the depth,
//! 5. the soundings are combined into a surface.
//!
//! Nothing in the crate reaches for the network or spawns threads on its own.
//! Parallelism is opt in and lives in the pipeline layer.
//!
//! # Reducing one beam
//!
//! The short version of the whole crate: a travel time and a beam angle go in,
//! a depth and an across track distance come out.
//!
//! ```
//! use plumbline::raytrace::Tracer;
//! use plumbline::svp::profile::{Sample, SoundSpeedProfile};
//! use plumbline::units::Angle;
//!
//! // A cast with a thermocline in it.
//! let profile = SoundSpeedProfile::new(vec![
//!     Sample::new(0.0, 1462.0),
//!     Sample::new(20.0, 1461.0),
//!     Sample::new(60.0, 1452.0),
//!     Sample::new(200.0, 1458.0),
//! ])?;
//!
//! // The transducer sits 1.8 m under the waterline.
//! let tracer = Tracer::new(&profile, 1.8)?;
//! let ray = tracer.trace(Angle::from_degrees(45.0), 0.04)?;
//!
//! assert!(!ray.turned);
//! // Roughly 1500 m/s for 40 ms, at 45 degrees, from 1.8 m down.
//! assert!((ray.depth - 43.0).abs() < 1.0, "depth {}", ray.depth);
//! assert!((ray.across - 41.0).abs() < 1.0, "across {}", ray.across);
//! # Ok::<(), plumbline::Error>(())
//! ```
//!
//! # Judging a sounding against an order
//!
//! ```
//! use plumbline::tpu::propagate::{propagate, SoundingGeometry};
//! use plumbline::tpu::s44::Order;
//! use plumbline::tpu::sensors::UncertaintyBudget;
//! use plumbline::units::Angle;
//!
//! let budget = UncertaintyBudget::shallow_water_launch();
//! let geometry = SoundingGeometry {
//!     depth: 28.0,
//!     across: 15.0,
//!     launch_angle: Angle::from_degrees(28.0),
//!     surface_speed: 1500.0,
//!     mean_speed: 1495.0,
//!     heave: 0.2,
//!     vessel_speed: 3.2,
//!     ellipsoidal: false,
//! };
//!
//! let uncertainty = propagate(geometry, &budget);
//! assert!(uncertainty.tvu < Order::One.max_tvu(28.0));
//! // And the report can say which term is doing the damage.
//! assert!(uncertainty.dominant_vertical().is_some());
//! ```

#![forbid(unsafe_code)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![warn(unreachable_pub)]
#![warn(unused_qualifications)]
#![warn(rust_2018_idioms)]
#![warn(clippy::doc_markdown)]
#![warn(clippy::needless_continue)]
#![warn(clippy::redundant_closure_for_method_calls)]
#![warn(clippy::uninlined_format_args)]

pub mod calibration;
pub mod cli;
pub mod config;
pub mod error;
pub mod geodesy;
pub mod grid;
pub mod io;
pub mod motion;
pub mod ping;
pub mod pipeline;
pub mod planning;
pub mod qc;
pub mod raytrace;
pub mod svp;
pub mod time;
pub mod tpu;
pub mod units;
pub mod vertical;

pub use error::{Error, FormatError, InFile, Result};
pub use geodesy::{Ellipsoid, Geodetic};
pub use svp::SoundSpeedProfile;
pub use time::{TimeSpan, Timestamp};
pub use units::Angle;

/// Version string of the library, taken from `Cargo.toml`.
pub const VERSION: &str = env!("CARGO_PKG_VERSION");
