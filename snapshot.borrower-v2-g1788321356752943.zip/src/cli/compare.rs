//! The compare command: two surfaces in, a crossline verdict out.

use std::path::Path;

use crate::cli::args::{Args, Spec};
use crate::error::{Error, Result};
use crate::grid::estimator::{DepthRaster, Estimator};
use crate::io::ascii_grid::{read_ascii_grid, write_ascii_grid, AsciiGrid};
use crate::qc::crossline::{compare, difference_raster};
use crate::tpu::s44::Order;

/// What this command accepts.
pub fn spec() -> Spec {
    Spec::new()
        .option("order")
        .option("out")
        .positional(2, Some(2))
}

fn to_raster(grid: &AsciiGrid) -> DepthRaster {
    DepthRaster {
        columns: grid.geometry.columns,
        rows: grid.geometry.rows,
        depths: grid.values.clone(),
        estimator: Estimator::Mean,
    }
}

/// Run the command.
pub fn run(args: &Args) -> Result<String> {
    args.check(&spec())?;
    let reference_grid = read_ascii_grid(Path::new(&args.positional[0]))?;
    let check_grid = read_ascii_grid(Path::new(&args.positional[1]))?;

    if reference_grid.geometry != check_grid.geometry {
        return Err(Error::Config(
            "the two surfaces are on different grids, regrid one of them first".into(),
        ));
    }

    let reference = to_raster(&reference_grid);
    let check = to_raster(&check_grid);
    let comparison = compare(&reference, &check)
        .ok_or_else(|| Error::Config("the two surfaces are different shapes".into()))?;

    if comparison.matched() == 0 {
        return Ok(format!(
            "the two surfaces do not overlap anywhere, {} cells covered by one and not the other\n",
            comparison.unmatched
        ));
    }

    let mut report = format!(
        "{} cells in common, {} covered by only one\n",
        comparison.matched(),
        comparison.unmatched
    );
    report.push_str(&format!(
        "mean difference {:+.3} m, standard deviation {:.3} m\n",
        comparison.mean().unwrap_or(0.0),
        comparison.standard_deviation().unwrap_or(0.0)
    ));
    report.push_str(&format!(
        "ninety five percent inside {:.3} m, largest {:.3} m\n",
        comparison.percentile(0.95).unwrap_or(0.0),
        comparison.largest().unwrap_or(0.0)
    ));

    // A mean much bigger than the spread is a systematic problem and worth
    // saying out loud, because the fix is completely different from the fix
    // for a noisy comparison.
    let mean = comparison.mean().unwrap_or(0.0).abs();
    let spread = comparison.standard_deviation().unwrap_or(0.0);
    if mean > spread && mean > 0.02 {
        report.push_str(
            "the difference is mostly systematic, look at draft, tide and sound speed first\n",
        );
    } else if spread > 0.0 && spread > 2.0 * mean {
        report
            .push_str("the difference is mostly scatter, look at the motion and the swath edge\n");
    }

    if args.has("order") {
        let name = args.value("order")?;
        let order = Order::from_name(name)
            .ok_or_else(|| Error::Config(format!("there is no order called {name}")))?;
        let fraction = comparison.fraction_within_order(order).unwrap_or(0.0);
        report.push_str(&format!(
            "{:.1}% of cells agree inside the {} envelope\n",
            100.0 * fraction,
            order.name()
        ));
    }

    if args.has("out") {
        let path = args.value("out")?;
        let difference = difference_raster(&reference, &check)
            .ok_or_else(|| Error::Config("the two surfaces are different shapes".into()))?;
        write_ascii_grid(path, &difference, &reference_grid.geometry, 3)?;
        report.push_str(&format!("wrote the difference surface to {path}\n"));
    }
    Ok(report)
}
