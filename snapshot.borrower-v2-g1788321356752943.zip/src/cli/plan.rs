//! The plan command: a block in, a set of run lines out.

use std::fs::File;
use std::io::{BufWriter, Write};
use std::path::Path;

use crate::cli::args::{Args, Spec};
use crate::error::{Error, Result};
use crate::geodesy::utm::Projected;
use crate::io::xyz::read_xyz;
use crate::planning::block::Block;
use crate::planning::lines::{plan_crosslines, plan_lines, spacing_for, Plan};
use crate::units::Angle;

/// What this command accepts.
pub fn spec() -> Spec {
    Spec::new()
        .option("block")
        .option("rect")
        .option("depth")
        .option("swath")
        .option("overlap")
        .option("heading")
        .option("spacing")
        .option("speed")
        .option("out")
        .flag("crosslines")
        .positional(0, Some(0))
}

/// Read a block from a file of easting and northing pairs.
///
/// The same reader as the sounding files, because a boundary file and a
/// sounding file are the same two columns and there is no reason to have two
/// parsers for that.
pub fn read_block(path: &Path) -> Result<Block> {
    let rows = read_xyz(path)?;
    let corners = rows
        .into_iter()
        .map(|r| Projected::new(r.east, r.north))
        .collect();
    let name = path
        .file_stem()
        .and_then(|s| s.to_str())
        .unwrap_or("block")
        .to_string();
    Block::new(name, corners)
}

/// Read a block written on the command line as four numbers.
fn read_rectangle(text: &str) -> Result<Block> {
    let numbers: Vec<f64> = text
        .split([',', ' '])
        .filter(|f| !f.is_empty())
        .map(|f| {
            f.parse::<f64>()
                .map_err(|_| Error::Config(format!("--rect holds {f} which is not a number")))
        })
        .collect::<Result<Vec<f64>>>()?;
    if numbers.len() != 4 {
        return Err(Error::Config(
            "--rect wants four numbers: min easting, min northing, max easting, max northing"
                .into(),
        ));
    }
    Block::rectangle("rectangle", numbers[0], numbers[1], numbers[2], numbers[3])
}

fn write_plan(path: &Path, plan: &Plan) -> Result<()> {
    let file = File::create(path).map_err(|e| Error::io(path, e))?;
    let mut out = BufWriter::new(file);
    writeln!(out, "# line start_east start_north end_east end_north")
        .map_err(|e| Error::io(path, e))?;
    for line in &plan.lines {
        writeln!(
            out,
            "{} {:.2} {:.2} {:.2} {:.2}",
            line.number, line.start.east, line.start.north, line.end.east, line.end.north
        )
        .map_err(|e| Error::io(path, e))?;
    }
    out.flush().map_err(|e| Error::io(path, e))?;
    Ok(())
}

/// Run the command.
pub fn run(args: &Args) -> Result<String> {
    args.check(&spec())?;

    let block = match (args.has("block"), args.has("rect")) {
        (true, false) => read_block(Path::new(args.value("block")?))?,
        (false, true) => read_rectangle(args.value("rect")?)?,
        (true, true) => {
            return Err(Error::Config(
                "give either --block or --rect, not both".into(),
            ))
        }
        (false, false) => return Err(Error::Config("--block or --rect is needed".into())),
    };

    let spacing = if args.has("spacing") {
        args.number("spacing")?
    } else {
        let depth = args.number("depth").map_err(|_| {
            Error::Config(
                "either --spacing, or --depth so the spacing can be worked out from the swath"
                    .into(),
            )
        })?;
        spacing_for(
            depth,
            Angle::from_degrees(args.number_or("swath", 60.0)?),
            args.number_or("overlap", 0.2)?,
        )?
    };

    let heading = Angle::from_degrees(args.number_or("heading", 0.0)?);
    let mut plan = plan_lines(&block, heading, spacing)?;
    plan.alternate_directions();

    let speed = args.number_or("speed", 3.0)?;
    let mut report = format!(
        "{}: {:.1} hectares, {:.0} m of boundary\n",
        block.name,
        block.area() / 10_000.0,
        block.perimeter()
    );
    report.push_str(&format!(
        "{} lines at {:.1} m spacing on {:.0} degrees\n",
        plan.lines.len(),
        plan.spacing,
        plan.heading.degrees()
    ));
    report.push_str(&format!(
        "{:.1} km on line, {:.1} km turning, {:.1} hours at {:.1} m/s\n",
        plan.line_length() / 1000.0,
        plan.turn_length() / 1000.0,
        plan.hours_at(speed),
        speed
    ));

    if args.flag("crosslines") {
        let mut cross = plan_crosslines(&block, &plan)?;
        cross.alternate_directions();
        report.push_str(&format!(
            "{} crosslines, {:.1} km, {:.1} hours\n",
            cross.lines.len(),
            cross.line_length() / 1000.0,
            cross.hours_at(speed)
        ));
        if args.has("out") {
            let path = format!("{}.crosslines", args.value("out")?);
            write_plan(Path::new(&path), &cross)?;
            report.push_str(&format!("wrote {path}\n"));
        }
    }

    if args.has("out") {
        let path = args.value("out")?;
        write_plan(Path::new(path), &plan)?;
        report.push_str(&format!("wrote {path}\n"));
    }
    Ok(report)
}
