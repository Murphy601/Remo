//! The info command.

use std::path::Path;

use crate::cli::args::{Args, Spec};
use crate::error::Result;
use crate::io::pbf;
use crate::svp::parse::read_svp_file;

/// What this command accepts.
pub fn spec() -> Spec {
    Spec::new().flag("full").positional(1, None)
}

/// Describe every file named on the command line.
pub fn run(args: &Args) -> Result<String> {
    args.check(&spec())?;
    let mut out = String::new();
    for name in &args.positional {
        let path = Path::new(name);
        let extension = path
            .extension()
            .and_then(|e| e.to_str())
            .unwrap_or("")
            .to_ascii_lowercase();
        let description = match extension.as_str() {
            "svp" | "asvp" => describe_svp(path)?,
            _ => describe_pings(path, args.flag("full"))?,
        };
        out.push_str(&format!("{name}\n{description}\n"));
    }
    Ok(out)
}

fn describe_pings(path: &Path, full: bool) -> Result<String> {
    let header = pbf::read_header(path)?;
    let mut text = format!(
        "  ping file version {}, {} pings, {} bytes of records\n",
        header.version, header.ping_count, header.body_len
    );
    if !full {
        return Ok(text);
    }

    let pings = pbf::read_pings(path)?;
    let beams: usize = pings.iter().map(|p| p.beams.len()).sum();
    let good: usize = pings
        .iter()
        .map(super::super::ping::record::Ping::good_beams)
        .sum();
    text.push_str(&format!("  {beams} beams, {good} with a detection\n"));
    if let (Some(first), Some(last)) = (pings.first(), pings.last()) {
        text.push_str(&format!("  from {} to {}\n", first.time, last.time));
        let seconds = last.time - first.time;
        if seconds > 0.0 && pings.len() > 1 {
            text.push_str(&format!(
                "  {:.2} pings per second\n",
                (pings.len() - 1) as f64 / seconds
            ));
        }
    }
    if let Some(nav) = pings.iter().find_map(|p| p.navigation) {
        text.push_str(&format!(
            "  first fix {:.6} {:.6}\n",
            nav.position.lat.degrees(),
            nav.position.lon.degrees()
        ));
    } else {
        text.push_str("  no navigation in this file\n");
    }
    Ok(text)
}

fn describe_svp(path: &Path) -> Result<String> {
    let records = read_svp_file(path)?;
    let mut text = format!("  {} cast(s)\n", records.len());
    for record in &records {
        text.push_str(&format!(
            "  {} samples from {:.1} m to {:.1} m, surface {:.1} m/s",
            record.profile.len(),
            record.profile.shallowest(),
            record.profile.deepest(),
            record.profile.surface_speed()
        ));
        match record.time {
            Some(t) => text.push_str(&format!(", taken {t}\n")),
            None => text.push('\n'),
        }
    }
    Ok(text)
}
