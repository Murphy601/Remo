//! The reduce command: raw pings in, soundings out.

use std::path::Path;

use crate::cli::args::{Args, Spec};
use crate::config::survey::{SurveyConfig, VerticalMode};
use crate::error::{Error, Result};
use crate::geodesy::Ellipsoid;
use crate::grid::estimator::render;
use crate::grid::estimator::Estimator;
use crate::io::pbf::read_pings;
use crate::io::tide_file::read_tide_file;
use crate::io::xyz::{write_xyz, XyzColumns};
use crate::ping::decimate::{decimate, DecimationReport, Keep};
use crate::ping::line::Line;
use crate::pipeline::parallel::{reduce_lines, Progress, Threads};
use crate::pipeline::reduce_line::{LineResult, Pipeline};
use crate::pipeline::survey::{accepted_soundings, build_surface, summarise};
use crate::qc::features::{find_features, FeatureSearch};
use crate::qc::machine::summary_json;
use crate::qc::report::{survey_report, verdict, ReportInputs};
use crate::svp::extend::{extend_to, extend_to_surface, Extension};
use crate::svp::library::{LibraryEntry, ProfileLibrary};
use crate::svp::parse::read_svp_file;
use crate::svp::thin::thin;
use crate::time::Timestamp;
use crate::vertical::reference::VerticalReference;
use crate::vertical::separation::SeparationModel;
use crate::vertical::tide::TideModel;

/// What this command accepts.
pub fn spec() -> Spec {
    Spec::new()
        .option("config")
        .option("svp")
        .option("tide")
        .option("out")
        .option("threads")
        .option("separation")
        .option("extend-to")
        .option("report")
        .option("decimate")
        .option("keep")
        .option("estimator")
        .flag("features")
        .option("json")
        .flag("full-columns")
        .positional(1, None)
}

/// Load the casts and prepare them for the tracer.
///
/// Each cast is carried up to the surface, thinned, and carried down to the
/// depth the survey needs. Doing that once here rather than per ping is worth
/// most of the run time of a reduction.
pub fn load_profiles(
    path: &Path,
    config: &SurveyConfig,
    extend_to_depth: f64,
) -> Result<ProfileLibrary> {
    let records = read_svp_file(path)?;
    let mut entries = Vec::with_capacity(records.len());
    for (i, record) in records.into_iter().enumerate() {
        let profile = extend_to_surface(&record.profile)?;
        let profile = thin(&profile, config.thin_tolerance)?;
        let profile = extend_to(&profile, extend_to_depth, &Extension::default())?;
        entries.push(LibraryEntry {
            label: if record.label.is_empty() {
                format!("cast {}", i + 1)
            } else {
                record.label
            },
            time: record.time.unwrap_or(Timestamp::EPOCH),
            position: record.position,
            profile,
        });
    }
    ProfileLibrary::new(entries, config.profile_selection)
}

/// Build the vertical reference the configuration asks for.
pub fn load_vertical(args: &Args, config: &SurveyConfig) -> Result<VerticalReference> {
    match &config.vertical {
        VerticalMode::Tide { zone } => {
            let path = args.value("tide").map_err(|_| {
                Error::Config(
                    "this configuration works from a tide gauge, so --tide is needed".into(),
                )
            })?;
            let gauge = read_tide_file(path)?;
            let model = TideModel::single_gauge(gauge)?;
            Ok(VerticalReference::Tide {
                model: Box::new(model),
                zone: zone.clone(),
            })
        }
        VerticalMode::Ellipsoid => {
            let separation = args.number_or("separation", 0.0)?;
            Ok(VerticalReference::Ellipsoid {
                separation: Box::new(SeparationModel::constant("constant", separation)?),
            })
        }
    }
}

/// Run the command.
pub fn run(args: &Args) -> Result<String> {
    args.check(&spec())?;
    let config = SurveyConfig::read(args.value("config")?)?;
    let mut report = String::new();

    if !config.unread_keys.is_empty() {
        report.push_str(&format!(
            "warning: the configuration sets {} nothing reads: {}\n",
            config.unread_keys.len(),
            config.unread_keys.join(", ")
        ));
    }

    let mut lines = Vec::with_capacity(args.positional.len());
    for name in &args.positional {
        let path = Path::new(name);
        let pings = read_pings(path)?;
        let label = path
            .file_stem()
            .and_then(|s| s.to_str())
            .unwrap_or(name)
            .to_string();
        lines.push(Line::new(label, pings));
    }

    // Size the profile extension from the data rather than from a guess. The
    // deepest possible sounding is the longest travel time at the fastest
    // plausible speed, and a profile carried past that is wasted layers.
    let deepest = lines.iter().map(Line::max_two_way_time).fold(0.0, f64::max) * 1650.0 / 2.0;
    let extend_to_depth = args.number_or("extend-to", deepest.max(50.0))?;

    let profiles = load_profiles(Path::new(args.value("svp")?), &config, extend_to_depth)?;
    let vertical = load_vertical(args, &config)?;
    let pipeline = Pipeline {
        config: &config,
        profiles: &profiles,
        vertical: &vertical,
        ellipsoid: Ellipsoid::WGS84,
    };

    let threads = match args.has("threads") {
        true => Threads::Fixed(args.number("threads")? as usize),
        false => Threads::Available,
    };
    let progress = Progress::new();
    let results = reduce_lines(&pipeline, &lines, threads, &progress)?;

    for result in &results {
        report.push_str(&summarise_line(result));
    }

    let all = accepted_soundings(&results);
    let projection_for_thinning = pipeline.projection()?;
    let soundings = if args.has("decimate") {
        let spacing = args.number("decimate")?;
        let keep = match args.value_or("keep", "shoalest") {
            "shoalest" => Keep::Shoalest,
            "deepest" => Keep::Deepest,
            "most certain" | "most-certain" => Keep::MostCertain,
            other => {
                return Err(Error::Config(format!(
                    "--keep does not accept {other}, try shoalest, deepest or most certain"
                )))
            }
        };
        let thinned = decimate(&all, &projection_for_thinning, spacing, keep)?;
        let summary = DecimationReport::of(&all, &thinned, spacing);
        report.push_str(&format!(
            "decimated to {:.1} m keeping the {}: {} of {} soundings, {:.1}%\n",
            spacing,
            keep.name(),
            summary.kept,
            summary.considered,
            100.0 * summary.fraction()
        ));
        if keep == Keep::Shoalest && !summary.kept_the_shoalest() {
            return Err(Error::Config(
                "the decimation lost the shallowest sounding, which cannot happen and means something is wrong".into(),
            ));
        }
        thinned
    } else {
        all
    };
    let out = args.value_or("out", "soundings.xyz");
    let columns = if args.flag("full-columns") {
        XyzColumns::FULL
    } else {
        XyzColumns::PLAIN
    };
    let projection = pipeline.projection()?;
    let written = write_xyz(out, &soundings, &projection, columns)?;
    report.push_str(&format!("wrote {written} soundings to {out}\n"));

    // The full report needs a surface, and building one is not free, so it
    // only happens when somebody asked for the report.
    if args.has("report") {
        let estimator_name = args.value_or("estimator", "shoalest");
        let estimator = Estimator::from_name(estimator_name).ok_or_else(|| {
            Error::Config(format!("there is no estimator called {estimator_name}"))
        })?;
        let surface = build_surface(&results, &config, projection)?;
        let summary = summarise(&results, &surface, &config, estimator);
        let features = if args.flag("features") {
            find_features(
                &surface,
                &render(&surface, Estimator::Shoalest),
                &FeatureSearch::default(),
            )
        } else {
            Vec::new()
        };
        let path = args.value("report")?;
        let text = survey_report(&ReportInputs {
            summary: &summary,
            results: &results,
            config: &config,
            estimator,
            cell_size: config.cell_size,
            features: &features,
        });
        std::fs::write(path, text).map_err(|e| Error::io(path, e))?;
        if args.has("json") {
            let json_path = args.value("json")?;
            std::fs::write(
                json_path,
                summary_json(&summary, &results, &config, &features),
            )
            .map_err(|e| Error::io(json_path, e))?;
            report.push_str(&format!("wrote the machine summary to {json_path}\n"));
        }
        if !features.is_empty() {
            report.push_str(&format!("{} features found\n", features.len()));
        }
        report.push_str(&format!("wrote the report to {path}\n"));
        report.push_str(&verdict(&summary, config.order));
        report.push('\n');
    }
    Ok(report)
}

fn summarise_line(result: &LineResult) -> String {
    let mut text = format!(
        "{}: {} of {} soundings kept, {:.1} to {:.1} m, cast {}\n",
        result.name,
        result.stats.accepted,
        result.stats.count,
        result.stats.min_depth,
        result.stats.max_depth,
        result.profile_used
    );
    if result.tally.total() > 0 {
        text.push_str(&format!(
            "  flagged: {} outside the window, {} outside the swath, {} too uncertain, {} outliers\n",
            result.tally.outside_window,
            result.tally.outside_swath,
            result.tally.too_uncertain,
            result.tally.outlier
        ));
    }
    for warning in &result.warnings {
        text.push_str(&format!("  {warning:?}\n"));
    }
    text
}
