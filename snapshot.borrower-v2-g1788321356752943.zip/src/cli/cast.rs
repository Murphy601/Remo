//! The cast command: what two sound speed profiles do to the same beams.

use std::path::Path;

use crate::cli::args::{Args, Spec};
use crate::error::{Error, Result};
use crate::svp::compare::compare_casts;
use crate::svp::parse::read_svp_file;
use crate::units::Angle;

/// What this command accepts.
pub fn spec() -> Spec {
    Spec::new()
        .option("depth")
        .option("draft")
        .option("swath")
        .option("beams")
        .option("allowance")
        .flag("table")
        .positional(1, Some(2))
}

/// Run the command.
///
/// With one file it compares the casts inside it against each other, in the
/// order they were taken, which is the question anybody with a day of casts
/// actually wants answered. With two files it compares the first cast of one
/// against the first cast of the other.
pub fn run(args: &Args) -> Result<String> {
    args.check(&spec())?;
    let depth = args.number_or("depth", 30.0)?;
    let draft = args.number_or("draft", 1.5)?;
    let swath = Angle::from_degrees(args.number_or("swath", 60.0)?);
    let beams = args.number_or("beams", 21.0)? as usize;
    let allowance = args.number_or("allowance", 0.10)?;

    let mut casts = Vec::new();
    for name in &args.positional {
        let records = read_svp_file(Path::new(name))?;
        for record in records {
            casts.push((record.label, record.profile));
        }
    }
    if casts.len() < 2 {
        return Err(Error::Config(
            "two casts are needed to compare anything, give a file with two in it or two files"
                .into(),
        ));
    }

    let mut report = format!(
        "comparing {} casts at {depth:.0} m nominal depth, {:.0} degree swath\n",
        casts.len(),
        swath.degrees()
    );

    for pair in casts.windows(2) {
        let (first_label, first) = &pair[0];
        let (second_label, second) = &pair[1];
        let comparison = compare_casts(first, second, depth, draft, swath, beams)?;

        let worst = comparison.worst_depth_difference();
        let nadir = comparison.at_nadir().unwrap_or(0.0);
        report.push_str(&format!(
            "{first_label} against {second_label}: {nadir:+.3} m at nadir, {worst:.3} m worst\n"
        ));
        if !comparison.within(allowance) {
            report.push_str(&format!(
                "  outside the {allowance:.3} m allowance, these two casts are not interchangeable\n"
            ));
        }

        if args.flag("table") {
            for beam in &comparison.beams {
                report.push_str(&format!(
                    "  {:>6.1} deg  depth {:>7.2}  difference {:+.3} m  across {:+.3} m\n",
                    beam.angle.degrees(),
                    beam.depth,
                    beam.depth_difference,
                    beam.across_difference
                ));
            }
        }
    }
    Ok(report)
}
