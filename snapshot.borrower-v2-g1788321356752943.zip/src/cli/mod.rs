//! The pieces the command line tool is built from.
//!
//! Kept in the library rather than in the binary so that the argument handling
//! and the commands can be tested without spawning a process.

pub mod args;
pub mod cast;
pub mod compare;
pub mod grid;
pub mod help;
pub mod info;
pub mod plan;
pub mod reduce;
pub mod simulate;

pub use args::{Args, Spec};
