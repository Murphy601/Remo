//! The simulate command: write a ping file with a known answer in it.
//!
//! Every processing mistake I have ever made would have been caught in ten
//! minutes by running the configuration over a seabed whose depth was known in
//! advance. This writes that seabed. The geometry is deliberately simple, a
//! straight line at a constant speed over a plane, so that anything that comes
//! out of the reduction other than that plane is the configuration talking.

use std::path::Path;

use crate::cli::args::{Args, Spec};
use crate::error::{Error, Result};
use crate::geodesy::Geodetic;
use crate::io::pbf::write_pings;
use crate::motion::attitude::Attitude;
use crate::ping::beam::{Beam, Detection};
use crate::ping::record::{Navigation, Ping};
use crate::time::Timestamp;
use crate::units::Angle;

/// What this command accepts.
pub fn spec() -> Spec {
    Spec::new()
        .option("depth")
        .option("slope")
        .option("pings")
        .option("beams")
        .option("swath")
        .option("sound-speed")
        .option("lat")
        .option("lon")
        .option("heading")
        .option("speed")
        .option("start")
        .positional(1, Some(1))
}

/// Everything the synthetic survey needs.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Scene {
    /// Seabed below the transducer at nadir, in metres.
    pub depth: f64,
    /// Across track slope of the seabed, in degrees, positive deepening to
    /// starboard.
    pub slope: f64,
    /// How many pings.
    pub pings: usize,
    /// How many beams in each.
    pub beams: usize,
    /// Half angle of the swath in degrees.
    pub swath: f64,
    /// Sound speed, constant through the column.
    pub sound_speed: f64,
    /// Where the line starts.
    pub start_position: Geodetic,
    /// Heading of the line in degrees.
    pub heading: f64,
    /// Speed over ground in metres per second.
    pub speed: f64,
    /// Time of the first ping.
    pub start_time: Timestamp,
}

impl Default for Scene {
    fn default() -> Self {
        Scene {
            depth: 30.0,
            slope: 0.0,
            pings: 200,
            beams: 61,
            swath: 60.0,
            sound_speed: 1500.0,
            start_position: Geodetic::from_degrees(69.0, 33.0, 0.0),
            heading: 0.0,
            speed: 3.0,
            start_time: Timestamp::from_utc(2025, 5, 26, 8, 0, 0.0),
        }
    }
}

/// Build the pings a scene describes.
///
/// The seabed is a plane through a point `depth` below the transducer at the
/// start of the line, tilted across track. Every travel time is worked out by
/// intersecting the beam with that plane, so the answer is exact and any
/// disagreement afterwards is the processing.
pub fn generate(scene: &Scene) -> Result<Vec<Ping>> {
    if scene.beams < 2 {
        return Err(Error::Config("a ping needs at least two beams".into()));
    }
    if !(0.0..90.0).contains(&scene.swath) {
        return Err(Error::domain(
            "swath",
            scene.swath,
            "between 0 and 90 degrees",
        ));
    }
    let slope = Angle::from_degrees(scene.slope);
    let interval = 0.2;
    let heading = Angle::from_degrees(scene.heading);
    let (sin_hd, cos_hd) = heading.sin_cos();

    let mut pings = Vec::with_capacity(scene.pings);
    for p in 0..scene.pings {
        let along = p as f64 * scene.speed * interval;
        let north = along * cos_hd;
        let east = along * sin_hd;
        let lat = scene.start_position.lat.degrees() + north / 111_320.0;
        let lon = scene.start_position.lon.degrees()
            + east / (111_320.0 * scene.start_position.lat.cos().max(1.0e-6));

        let mut beams = Vec::with_capacity(scene.beams);
        for b in 0..scene.beams {
            let fraction = b as f64 / (scene.beams - 1) as f64;
            let angle = Angle::from_degrees(-scene.swath + 2.0 * scene.swath * fraction);
            // Range to a plane tilted by the slope, for a ray at this angle.
            let denominator = (angle - slope).cos();
            if denominator <= 1.0e-6 {
                continue;
            }
            let slant = scene.depth * slope.cos() / denominator;
            let mut beam = Beam::new(b as u16, 2.0 * slant / scene.sound_speed, angle);
            beam.detection = if angle.degrees().abs() < 25.0 {
                Detection::Amplitude
            } else {
                Detection::Phase
            };
            beam.quality = (0.95 - 0.3 * fraction.mul_add(2.0, -1.0).abs()) as f32;
            beams.push(beam);
        }

        let mut ping = Ping::new(
            scene.start_time.offset(p as f64 * interval),
            p as u64,
            scene.sound_speed,
            beams,
        );
        ping.navigation = Some(Navigation {
            position: Geodetic::from_degrees(lat, lon, 0.0),
            attitude: Attitude::from_degrees(0.0, 0.0, scene.heading),
            heave: 0.0,
            speed: scene.speed,
            transducer_height: None,
        });
        pings.push(ping);
    }
    Ok(pings)
}

/// Run the command.
pub fn run(args: &Args) -> Result<String> {
    args.check(&spec())?;
    let mut scene = Scene::default();
    scene.depth = args.number_or("depth", scene.depth)?;
    scene.slope = args.number_or("slope", scene.slope)?;
    scene.pings = args.number_or("pings", scene.pings as f64)? as usize;
    scene.beams = args.number_or("beams", scene.beams as f64)? as usize;
    scene.swath = args.number_or("swath", scene.swath)?;
    scene.sound_speed = args.number_or("sound-speed", scene.sound_speed)?;
    scene.heading = args.number_or("heading", scene.heading)?;
    scene.speed = args.number_or("speed", scene.speed)?;
    scene.start_position = Geodetic::from_degrees(
        args.number_or("lat", scene.start_position.lat.degrees())?,
        args.number_or("lon", scene.start_position.lon.degrees())?,
        0.0,
    );

    let pings = generate(&scene)?;
    let path = Path::new(&args.positional[0]);
    let checksum = write_pings(path, &pings)?;
    Ok(format!(
        "wrote {} pings to {} with {} beams each, checksum {checksum:08x}\n",
        pings.len(),
        path.display(),
        pings.first().map(|p| p.beams.len()).unwrap_or(0)
    ))
}
