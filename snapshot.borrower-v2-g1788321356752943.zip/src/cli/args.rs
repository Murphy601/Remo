//! Argument parsing for the command line tool.
//!
//! The same story as the configuration reader: the obvious crate for this
//! wants a newer language edition than the compiler this project is pinned
//! to. What the tool needs is a subcommand, a handful of long options and a
//! handful of flags, which is a morning of work and no dependency at all.
//!
//! The one rule worth stating: an option this parser does not recognise is an
//! error. Ignoring unknown arguments means a mistyped option silently does
//! nothing, and on this tool a mistyped option is usually the one that decides
//! how deep the seabed is.

use std::collections::BTreeMap;

use crate::error::{Error, Result};

/// A parsed command line.
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Args {
    /// The subcommand, if one was given.
    pub command: Option<String>,
    /// Positional arguments after the subcommand.
    pub positional: Vec<String>,
    options: BTreeMap<String, String>,
    flags: Vec<String>,
}

/// What a command expects, so that unknown options can be rejected.
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct Spec {
    /// Long option names that take a value.
    pub options: Vec<&'static str>,
    /// Long option names that do not.
    pub flags: Vec<&'static str>,
    /// How many positional arguments are required.
    pub min_positional: usize,
    /// How many are allowed, or none for any number.
    pub max_positional: Option<usize>,
}

impl Spec {
    /// A specification taking no options at all.
    pub fn new() -> Spec {
        Spec::default()
    }

    /// Add an option that takes a value.
    pub fn option(mut self, name: &'static str) -> Spec {
        self.options.push(name);
        self
    }

    /// Add a flag.
    pub fn flag(mut self, name: &'static str) -> Spec {
        self.flags.push(name);
        self
    }

    /// Set how many positional arguments are wanted.
    pub fn positional(mut self, min: usize, max: Option<usize>) -> Spec {
        self.min_positional = min;
        self.max_positional = max;
        self
    }
}

impl Args {
    /// Parse a command line, not counting the program name.
    ///
    /// Options are written as two dashes and a name, either with an equals
    /// sign or with the value as the next argument. Everything else is
    /// positional, and the first positional is taken as the subcommand.
    pub fn parse<I, S>(arguments: I) -> Result<Args>
    where
        I: IntoIterator<Item = S>,
        S: AsRef<str>,
    {
        let raw: Vec<String> = arguments
            .into_iter()
            .map(|a| a.as_ref().to_string())
            .collect();
        let mut args = Args::default();
        let mut i = 0;

        while i < raw.len() {
            let item = raw[i].clone();
            if let Some(rest) = item.strip_prefix("--") {
                if rest.is_empty() {
                    return Err(Error::Config(
                        "a bare double dash means nothing here".into(),
                    ));
                }
                match rest.split_once('=') {
                    Some((name, value)) => {
                        args.options.insert(name.to_string(), value.to_string());
                    }
                    None => {
                        // A name followed by something that is not another
                        // option is a value; on its own it is a flag. That is
                        // ambiguous in general and unambiguous for this tool,
                        // because every flag here is a genuine yes or no.
                        match raw.get(i + 1) {
                            Some(v) if !v.starts_with("--") => {
                                args.options.insert(rest.to_string(), v.clone());
                                i += 1;
                            }
                            _ => args.flags.push(rest.to_string()),
                        }
                    }
                }
            } else if args.command.is_none() {
                args.command = Some(item);
            } else {
                args.positional.push(item);
            }
            i += 1;
        }
        Ok(args)
    }
}

impl Args {
    /// Check the parsed arguments against what a command accepts.
    pub fn check(&self, spec: &Spec) -> Result<()> {
        for name in self.options.keys() {
            if !spec.options.contains(&name.as_str()) {
                if spec.flags.contains(&name.as_str()) {
                    return Err(Error::Config(format!("--{name} does not take a value")));
                }
                return Err(Error::Config(format!("unknown option --{name}")));
            }
        }
        for name in &self.flags {
            if !spec.flags.contains(&name.as_str()) {
                if spec.options.contains(&name.as_str()) {
                    return Err(Error::Config(format!("--{name} needs a value")));
                }
                return Err(Error::Config(format!("unknown flag --{name}")));
            }
        }
        if self.positional.len() < spec.min_positional {
            return Err(Error::Config(format!(
                "expected at least {} arguments, got {}",
                spec.min_positional,
                self.positional.len()
            )));
        }
        if let Some(max) = spec.max_positional {
            if self.positional.len() > max {
                return Err(Error::Config(format!(
                    "expected at most {max} arguments, got {}",
                    self.positional.len()
                )));
            }
        }
        Ok(())
    }

    /// True when a flag was given.
    pub fn flag(&self, name: &str) -> bool {
        self.flags.iter().any(|f| f == name)
    }

    /// An option that has to be there.
    pub fn value(&self, name: &str) -> Result<&str> {
        self.options
            .get(name)
            .map(String::as_str)
            .ok_or_else(|| Error::Config(format!("--{name} is required")))
    }

    /// An option with a default.
    pub fn value_or<'a>(&'a self, name: &str, fallback: &'a str) -> &'a str {
        self.options
            .get(name)
            .map(String::as_str)
            .unwrap_or(fallback)
    }

    /// A numeric option that has to be there.
    pub fn number(&self, name: &str) -> Result<f64> {
        let text = self.value(name)?;
        text.parse()
            .map_err(|_| Error::Config(format!("--{name} should be a number, it is {text}")))
    }

    /// A numeric option with a default.
    pub fn number_or(&self, name: &str, fallback: f64) -> Result<f64> {
        match self.options.get(name) {
            None => Ok(fallback),
            Some(text) => text
                .parse()
                .map_err(|_| Error::Config(format!("--{name} should be a number, it is {text}"))),
        }
    }

    /// True when an option was given at all.
    pub fn has(&self, name: &str) -> bool {
        self.options.contains_key(name)
    }
}
