//! The grid command: soundings in, a surface out.

use std::path::Path;

use crate::cli::args::{Args, Spec};
use crate::error::{Error, Result};
use crate::geodesy::utm::Projected;
use crate::grid::estimator::{render, render_uncertainty, Estimator};
use crate::grid::geometry::GridGeometry;
use crate::grid::surface::Surface;
use crate::io::ascii_grid::write_ascii_grid;
use crate::io::xyz::read_xyz;
use crate::qc::coverage::analyse;

/// What this command accepts.
pub fn spec() -> Spec {
    Spec::new()
        .option("cell")
        .option("estimator")
        .option("out")
        .option("uncertainty")
        .option("min-soundings")
        .option("zone")
        .flag("south")
        .positional(1, None)
}

/// Run the command.
///
/// The soundings come in as projected coordinates from an XYZ file, so the
/// projection is never used here. That is why the zone is only an option: it
/// goes into the surface for the sake of anything that later asks a cell where
/// it is, and it changes no depth.
pub fn run(args: &Args) -> Result<String> {
    args.check(&spec())?;
    let cell = args.number("cell")?;
    if !(cell.is_finite() && cell > 0.0) {
        return Err(Error::domain("cell", cell, "finite and positive"));
    }

    let mut rows = Vec::new();
    for name in &args.positional {
        let mut file_rows = read_xyz(Path::new(name))?;
        rows.append(&mut file_rows);
    }
    if rows.is_empty() {
        return Err(Error::Config("no soundings in the files given".into()));
    }

    let mut min = Projected::new(f64::INFINITY, f64::INFINITY);
    let mut max = Projected::new(f64::NEG_INFINITY, f64::NEG_INFINITY);
    for row in &rows {
        min.east = min.east.min(row.east);
        min.north = min.north.min(row.north);
        max.east = max.east.max(row.east);
        max.north = max.north.max(row.north);
    }

    let geometry = GridGeometry::covering(
        min.east - cell,
        min.north - cell,
        max.east + cell,
        max.north + cell,
        cell,
    )?;
    let zone = args.number_or("zone", 36.0)? as u8;
    let projection = crate::geodesy::utm::TransverseMercator::utm(
        zone,
        !args.flag("south"),
        Default::default(),
    )?;
    let mut surface = Surface::new(geometry, projection);

    // An XYZ file carries no uncertainty, so every sounding weighs the same.
    // Anything that wants weights has to come through the reduction rather
    // than through a text file.
    for row in &rows {
        surface.add_at(Projected::new(row.east, row.north), row.depth, 1.0);
    }

    let estimator = match args.value_or("estimator", "shoalest") {
        "shoalest of confident" | "shoalest-of-confident" => Estimator::ShoalestOfConfident {
            min_soundings: args.number_or("min-soundings", 3.0)? as u32,
        },
        name => Estimator::from_name(name)
            .ok_or_else(|| Error::Config(format!("there is no estimator called {name}")))?,
    };

    let raster = render(&surface, estimator);
    let out = args.value_or("out", "surface.asc");
    write_ascii_grid(out, &raster, surface.geometry(), 3)?;

    let mut report = format!(
        "{} soundings into {} by {} cells of {cell} m, {} populated\n",
        rows.len(),
        geometry.columns,
        geometry.rows,
        raster.populated()
    );
    if let Some((lo, hi)) = raster.range() {
        report.push_str(&format!(
            "depths {lo:.2} to {hi:.2} m by {}\n",
            estimator.name()
        ));
    }

    let coverage = analyse(&raster, surface.geometry());
    report.push_str(&format!(
        "coverage {:.1}%, {} interior gaps\n",
        100.0 * coverage.fraction(),
        coverage.interior_holidays().count()
    ));
    if let Some(worst) = coverage.worst_interior(cell) {
        report.push_str(&format!("largest interior gap {worst:.1} m across\n"));
    }
    report.push_str(&format!("wrote {out}\n"));

    if args.has("uncertainty") {
        let sigma = render_uncertainty(&surface, estimator);
        let path = args.value("uncertainty")?;
        write_ascii_grid(path, &sigma, surface.geometry(), 3)?;
        report.push_str(&format!("wrote {path}\n"));
    }
    Ok(report)
}
