//! The help text.
//!
//! Written out by hand rather than generated, because the useful part of a
//! help text is the sentence saying when you would want the command, and no
//! generator writes that.

/// Usage for the tool as a whole.
pub const USAGE: &str = "\
plumbline, reduction of multibeam observations to chart datum

usage: plumbline <command> [options]

commands:
  info      what is in a ping file or a sound speed file
  reduce    reduce ping files into soundings
  grid      grid soundings into a surface
  cast      what two sound speed casts do to the same beams
  compare   compare two surfaces, for crossline analysis
  plan      lay out run lines over a survey block
  simulate  write a synthetic ping file, for testing a configuration

run plumbline <command> --help for the options of one command
";

/// Usage for the info command.
pub const INFO: &str = "\
plumbline info <file>...

Reports what is in a file without processing it. Ping files are read as far as
their header and checksum, sound speed files are read in full.

options:
  --full   check every ping rather than just the header
";

/// Usage for the reduce command.
pub const REDUCE: &str = "\
plumbline reduce <ping file>...

Reduces raw pings into soundings and writes them out.

options:
  --config <file>    survey configuration, required
  --svp <file>       sound speed file, required
  --tide <file>      tide gauge file, required unless working off the ellipsoid
  --out <file>       where to write the soundings, default soundings.xyz
  --threads <n>      how many threads to use, default all of them
  --decimate <m>     thin to one sounding per square of this size
  --keep <rule>      which one to keep in each square, default shoalest
  --report <file>    write the survey report, which needs a surface built
  --estimator <name> estimator for that surface, default shoalest
  --features         search the surface for features and list them
  --json <file>      write the same numbers as json, for collecting later
  --full-columns     write uncertainty, ping and beam numbers and time
";

/// Usage for the grid command.
pub const GRID: &str = "\
plumbline grid <xyz file>...

Grids soundings into a surface and writes an ascii grid.

options:
  --cell <metres>      cell size, required
  --estimator <name>   shoalest, deepest, mean or weighted mean
  --out <file>         where to write the surface, default surface.asc
  --uncertainty <file> also write the uncertainty surface
";

/// Usage for the cast command.
pub const CAST: &str = "plumbline cast <file.svp> [file.svp]

Traces the same beams through two casts and reports how far apart the depths
land. With one file the casts inside it are compared in the order they were
taken, which is how you find out whether hourly casting is worth the day.

options:
  --depth <metres>     nominal depth to compare at, default 30
  --draft <metres>     transducer depth, default 1.5
  --swath <degrees>    half angle, default 60
  --beams <n>          how many angles to try, default 21
  --allowance <m>      difference above which the casts are not
                       interchangeable, default 0.1
  --table              print every beam rather than the summary
";

/// Usage for the compare command.
pub const COMPARE: &str = "\
plumbline compare <reference.asc> <check.asc>

Compares two surfaces of the same geometry and reports the difference
statistics, which is how a crossline gets assessed.

options:
  --order <name>   report compliance against exclusive, special, order 1 or 2
  --out <file>     write the difference surface as well
";

/// Usage for the plan command.
pub const PLAN: &str = "plumbline plan --rect <e,n,E,N> | --block <file>

Lays run lines over a block and says how long they will take.

options:
  --depth <metres>    shallowest depth, so the spacing can come off the swath
  --swath <degrees>   half angle of the usable swath, default 60
  --overlap <0 to 1>  how much of each swath the next line repeats, default 0.2
  --spacing <metres>  set the spacing directly instead
  --heading <degrees> which way the lines run, default 0
  --speed <m/s>       survey speed for the time estimate, default 3
  --crosslines        plan crosslines as well
  --out <file>        write the lines out
";

/// Usage for the simulate command.
pub const SIMULATE: &str = "\
plumbline simulate <output.pbf>

Writes a synthetic ping file over a flat or sloping seabed. Useful for checking
that a configuration produces the depths it should before any real data is put
through it.

options:
  --depth <metres>   seabed below the transducer, default 30
  --slope <degrees>  across track slope of the seabed, default 0
  --pings <n>        how many pings, default 200
  --beams <n>        how many beams per ping, default 61
  --swath <degrees>  half angle of the swath, default 60
";

/// Help for a named command, or the general usage.
pub fn for_command(command: Option<&str>) -> &'static str {
    match command {
        Some("info") => INFO,
        Some("reduce") => REDUCE,
        Some("grid") => GRID,
        Some("cast") => CAST,
        Some("compare") => COMPARE,
        Some("plan") => PLAN,
        Some("simulate") => SIMULATE,
        _ => USAGE,
    }
}
