//! Error taxonomy for the whole crate.
//!
//! Every fallible operation in `plumbline` returns [`Result`]. The variants are
//! deliberately coarse: a caller almost always wants to know *which stage* of
//! the reduction refused the data, not the exact line of the file that upset
//! the parser. The detail lives in the message.

use std::fmt;
use std::path::{Path, PathBuf};

/// Crate-wide result alias.
pub type Result<T> = std::result::Result<T, Error>;

/// Anything that can go wrong while reducing soundings.
#[derive(Debug, thiserror::Error)]
pub enum Error {
    /// An underlying I/O failure, tagged with the file it happened on.
    #[error("io error on {path}: {source}")]
    Io {
        /// File the operation was working on.
        path: PathBuf,
        /// The operating system error.
        #[source]
        source: std::io::Error,
    },

    /// A file was syntactically or structurally wrong.
    #[error("{0}")]
    Format(FormatError),

    /// A numeric argument was outside the domain the routine is defined on.
    #[error("{quantity} out of range: {value} (expected {expected})")]
    Domain {
        /// Human readable name of the quantity, e.g. `"latitude"`.
        quantity: &'static str,
        /// The offending value.
        value: f64,
        /// Description of the accepted range.
        expected: &'static str,
    },

    /// The configuration described a survey that cannot be reduced.
    #[error("configuration error: {0}")]
    Config(String),
}

impl Error {
    /// Wrap an [`std::io::Error`] together with the path that produced it.
    pub fn io(path: impl AsRef<Path>, source: std::io::Error) -> Self {
        Error::Io {
            path: path.as_ref().to_path_buf(),
            source,
        }
    }

    /// Build a [`Error::Domain`] for a value that failed a range check.
    pub fn domain(quantity: &'static str, value: f64, expected: &'static str) -> Self {
        Error::Domain {
            quantity,
            value,
            expected,
        }
    }

    /// Attach a file to a format error, leaving every other kind alone.
    ///
    /// A parser works on text and does not know where the text came from. The
    /// caller does, and this is how it says so without every parser taking a
    /// path it has no use for.
    pub fn in_file(self, path: impl AsRef<Path>) -> Self {
        match self {
            Error::Format(f) => Error::Format(f.in_file(path)),
            other => other,
        }
    }
}

/// Attaching a file to whatever a fallible call came back with.
///
/// Three modules had the same six line match on the way out of a parser. This
/// is that match, once.
pub trait InFile<T> {
    /// Name the file any format error inside this result came from.
    fn in_file(self, path: impl AsRef<Path>) -> Result<T>;
}

impl<T> InFile<T> for Result<T> {
    fn in_file(self, path: impl AsRef<Path>) -> Result<T> {
        self.map_err(|e| e.in_file(path))
    }
}

/// A structural problem in an input file.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FormatError {
    /// File the problem was found in, when one is known.
    pub path: Option<PathBuf>,
    /// One based line number, when the format is line oriented.
    pub line: Option<usize>,
    /// What was wrong.
    pub detail: String,
}

impl FormatError {
    /// A problem that is not tied to a particular line.
    pub fn new(detail: impl Into<String>) -> Self {
        FormatError {
            path: None,
            line: None,
            detail: detail.into(),
        }
    }

    /// A problem on a specific one based line.
    pub fn at_line(line: usize, detail: impl Into<String>) -> Self {
        FormatError {
            path: None,
            line: Some(line),
            detail: detail.into(),
        }
    }

    /// Attach the file the problem came from.
    pub fn in_file(mut self, path: impl AsRef<Path>) -> Self {
        self.path = Some(path.as_ref().to_path_buf());
        self
    }
}

impl fmt::Display for FormatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match (&self.path, self.line) {
            (Some(p), Some(l)) => write!(f, "{}:{}: {}", p.display(), l, self.detail),
            (Some(p), None) => write!(f, "{}: {}", p.display(), self.detail),
            (None, Some(l)) => write!(f, "line {}: {}", l, self.detail),
            (None, None) => f.write_str(&self.detail),
        }
    }
}

impl std::error::Error for FormatError {}

impl From<FormatError> for Error {
    fn from(e: FormatError) -> Self {
        Error::Format(e)
    }
}
