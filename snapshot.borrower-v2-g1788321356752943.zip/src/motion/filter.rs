//! Smoothing and despiking a sensor series.
//!
//! Motion data mostly needs nothing done to it. The two exceptions are a
//! sensor that drops a sample and reports a spike instead of a gap, and a
//! heading from a magnetic compass, which is noisy enough that differentiating
//! it is useless without smoothing first.
//!
//! Everything here is zero phase: the filter is run forwards and then
//! backwards over the same data, so the output is not delayed with respect to
//! the input. A phase shift in a motion series is indistinguishable from a
//! latency, and a latency in the motion is worth a decimetre at the edge of
//! the swath, so a filter that introduced one would be silently undoing the
//! calibration.

use crate::time::Timestamp;

use super::series::{Entry, Interpolate, TimeSeries};

/// Smooth a series of numbers with a moving average, run both ways.
///
/// The window is a number of samples, not a time, because a series with a
/// dropout in it has neither and the sample count is the one that does not
/// silently change meaning. An even window is rounded up to an odd one so it
/// stays centred.
pub fn smooth(values: &[f64], window: usize) -> Vec<f64> {
    if window <= 1 || values.len() < 3 {
        return values.to_vec();
    }
    let window = if window % 2 == 0 { window + 1 } else { window };
    let forward = moving_average(values, window);
    let mut backward: Vec<f64> = forward.iter().rev().copied().collect();
    backward = moving_average(&backward, window);
    backward.reverse();
    backward
}

fn moving_average(values: &[f64], window: usize) -> Vec<f64> {
    let half = window / 2;
    let mut out = Vec::with_capacity(values.len());
    for i in 0..values.len() {
        let lo = i.saturating_sub(half);
        let hi = (i + half + 1).min(values.len());
        let slice = &values[lo..hi];
        out.push(slice.iter().sum::<f64>() / slice.len() as f64);
    }
    out
}

/// Replace samples that sit far from their neighbours with the local median.
///
/// A spike is defined against the median of the window rather than the mean,
/// because a mean that includes the spike is dragged towards it and a big
/// enough spike hides itself.
///
/// It also has to differ from the sample either side of it. Without that the
/// first sample after a genuine step is a spike by every other definition, and
/// a tide that steps and stays stepped is data. Returns the cleaned values and
/// how many were replaced.
pub fn despike(values: &[f64], window: usize, tolerance: f64) -> (Vec<f64>, usize) {
    let window = window.max(3);
    let half = window / 2;
    let mut out = values.to_vec();
    let mut replaced = 0;

    for i in 0..values.len() {
        let lo = i.saturating_sub(half);
        let hi = (i + half + 1).min(values.len());
        let mut around: Vec<f64> = values[lo..hi]
            .iter()
            .enumerate()
            .filter(|(j, _)| lo + j != i)
            .map(|(_, v)| *v)
            .collect();
        if around.len() < 2 {
            continue;
        }
        around.sort_by(f64::total_cmp);
        let median = around[around.len() / 2];
        if (values[i] - median).abs() <= tolerance {
            continue;
        }

        let differs_from = |neighbour: Option<&f64>| match neighbour {
            Some(v) => (values[i] - v).abs() > tolerance,
            None => true,
        };
        if differs_from(values.get(i.wrapping_sub(1))) && differs_from(values.get(i + 1)) {
            out[i] = median;
            replaced += 1;
        }
    }
    (out, replaced)
}

/// Smooth the values of a time series, keeping its times and its gap rule.
pub fn smooth_series(series: &TimeSeries<f64>, window: usize) -> TimeSeries<f64> {
    let values: Vec<f64> = series.entries().iter().map(|e| e.value).collect();
    let smoothed = smooth(&values, window);
    let entries: Vec<Entry<f64>> = series
        .entries()
        .iter()
        .zip(smoothed)
        .map(|(e, value)| Entry {
            time: e.time,
            value,
        })
        .collect();
    TimeSeries::new(entries, series.max_gap())
}

/// Rate of change of a series, by central difference, in units per second.
///
/// Used for the heave rate, which is what the timing term of the uncertainty
/// budget is really multiplied by, and for spotting a heading that is turning
/// faster than the vessel can.
pub fn rate_of_change<T>(series: &TimeSeries<T>, at: Timestamp, step: f64) -> Option<f64>
where
    T: Interpolate + Into<f64>,
{
    let before: f64 = series.at(at.offset(-step / 2.0))?.into();
    let after: f64 = series.at(at.offset(step / 2.0))?.into();
    if step <= 0.0 {
        return None;
    }
    Some((after - before) / step)
}

/// The largest jump between consecutive samples, which is the quickest way to
/// see whether a series needs anything doing to it at all.
pub fn largest_step(values: &[f64]) -> f64 {
    values
        .windows(2)
        .map(|w| (w[1] - w[0]).abs())
        .fold(0.0, f64::max)
}
