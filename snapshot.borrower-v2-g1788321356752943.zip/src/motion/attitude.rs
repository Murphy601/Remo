//! Vessel attitude and the frames it moves between.
//!
//! The body frame has its first axis forward along the keel, its second to
//! starboard and its third down. Roll is positive with the starboard side
//! down, pitch is positive with the bow up, and heading is positive clockwise
//! from true north. That is the aerospace convention and it is what every
//! motion sensor worth buying reports in, but the signs are the single most
//! common source of a processed survey that is wrong by exactly twice the
//! roll, so they are written down here and asserted in the tests.
//!
//! The rotation from body to north east down is heading, then pitch, then
//! roll, applied in that order to the vector.

use crate::geodesy::Enu;
use crate::units::Angle;

use super::rotation::{Mat3, Vec3};

/// Roll, pitch and heading at one instant.
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub struct Attitude {
    /// Positive starboard side down.
    pub roll: Angle,
    /// Positive bow up.
    pub pitch: Angle,
    /// True heading, positive clockwise from north.
    pub heading: Angle,
}

impl Attitude {
    /// A vessel sitting level and pointing north.
    pub const LEVEL: Attitude = Attitude {
        roll: Angle::ZERO,
        pitch: Angle::ZERO,
        heading: Angle::ZERO,
    };

    /// Build from degrees.
    pub fn from_degrees(roll: f64, pitch: f64, heading: f64) -> Self {
        Attitude {
            roll: Angle::from_degrees(roll),
            pitch: Angle::from_degrees(pitch),
            heading: Angle::from_degrees(heading),
        }
    }

    /// The rotation that takes a body frame vector into north east down.
    pub fn body_to_ned(&self) -> Mat3 {
        Mat3::rot_z(self.heading)
            .times(&Mat3::rot_y(self.pitch))
            .times(&Mat3::rot_x(self.roll))
    }

    /// The inverse rotation, north east down into the body frame.
    pub fn ned_to_body(&self) -> Mat3 {
        self.body_to_ned().transpose()
    }

    /// Rotate a body frame vector into north east down.
    pub fn rotate(&self, v: Vec3) -> Vec3 {
        self.body_to_ned().apply(v)
    }

    /// Rotate a body frame vector straight into a local level displacement.
    ///
    /// This is the form the reduction actually wants, so the sign flip on the
    /// third axis lives here rather than being repeated at every call site.
    pub fn rotate_to_enu(&self, v: Vec3) -> Enu {
        let ned = self.rotate(v);
        Enu::new(ned.y, ned.x, -ned.z)
    }

    /// Attitude with the heading reduced to the range a compass reads.
    pub fn normalised(&self) -> Attitude {
        Attitude {
            roll: self.roll.wrapped_signed(),
            pitch: self.pitch.wrapped_signed(),
            heading: self.heading.wrapped(),
        }
    }

    /// Linear interpolation between two attitudes.
    ///
    /// Heading goes the short way round, which is the whole reason this is not
    /// three separate interpolations at the call site. A vessel swinging
    /// through north with a naive interpolation reports a three hundred and
    /// fifty nine degree turn between two pings twenty milliseconds apart.
    pub fn interpolate(a: Attitude, b: Attitude, t: f64) -> Attitude {
        Attitude {
            roll: a.roll + (b.roll - a.roll) * t,
            pitch: a.pitch + (b.pitch - a.pitch) * t,
            heading: (a.heading + a.heading.delta_to(b.heading) * t).wrapped(),
        }
    }

    /// True when nothing is a NaN and the angles are inside their ranges.
    pub fn is_plausible(&self) -> bool {
        self.roll.is_finite()
            && self.pitch.is_finite()
            && self.heading.is_finite()
            && self.roll.degrees().abs() <= 90.0
            && self.pitch.degrees().abs() <= 90.0
    }
}

/// A rigid offset between two points on the vessel, in the body frame.
///
/// Measured forward, starboard and down from the reference point, which is
/// normally the centre of the motion sensor because that is the point its
/// angles are about.
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub struct LeverArm {
    /// Forward, positive towards the bow.
    pub forward: f64,
    /// Athwartships, positive to starboard.
    pub starboard: f64,
    /// Vertical, positive down.
    pub down: f64,
}

impl LeverArm {
    /// No offset at all.
    pub const ZERO: LeverArm = LeverArm {
        forward: 0.0,
        starboard: 0.0,
        down: 0.0,
    };

    /// Build an offset.
    pub const fn new(forward: f64, starboard: f64, down: f64) -> Self {
        LeverArm {
            forward,
            starboard,
            down,
        }
    }

    /// The offset as a body frame vector.
    pub fn as_vec3(&self) -> Vec3 {
        Vec3::new(self.forward, self.starboard, self.down)
    }

    /// Where this offset lands in a local level frame for a given attitude.
    pub fn to_enu(&self, attitude: &Attitude) -> Enu {
        attitude.rotate_to_enu(self.as_vec3())
    }

    /// The offset from this point to another one.
    pub fn to(&self, other: &LeverArm) -> LeverArm {
        LeverArm {
            forward: other.forward - self.forward,
            starboard: other.starboard - self.starboard,
            down: other.down - self.down,
        }
    }

    /// Length of the offset.
    pub fn magnitude(&self) -> f64 {
        self.as_vec3().norm()
    }
}
