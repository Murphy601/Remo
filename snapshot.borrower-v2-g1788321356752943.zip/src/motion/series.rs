//! Time series of sensor values, and the interpolation between samples.
//!
//! Every ancillary sensor on the boat arrives as a stream of timestamped
//! values at its own rate, and every one of them has to be evaluated at the
//! time of a ping that falls between two of its samples. The rules for doing
//! that are the same whatever the value is, so they live here once.

use crate::time::{TimeSpan, Timestamp};

use super::attitude::Attitude;
use crate::geodesy::Enu;

/// A value that can be interpolated between two samples.
pub trait Interpolate: Copy {
    /// Value a fraction `t` of the way from `a` to `b`, with `t` in zero to
    /// one.
    fn interpolate(a: Self, b: Self, t: f64) -> Self;
}

impl Interpolate for f64 {
    fn interpolate(a: f64, b: f64, t: f64) -> f64 {
        a + (b - a) * t
    }
}

impl Interpolate for Attitude {
    fn interpolate(a: Attitude, b: Attitude, t: f64) -> Attitude {
        Attitude::interpolate(a, b, t)
    }
}

impl Interpolate for Enu {
    fn interpolate(a: Enu, b: Enu, t: f64) -> Enu {
        Enu::new(
            a.east + (b.east - a.east) * t,
            a.north + (b.north - a.north) * t,
            a.up + (b.up - a.up) * t,
        )
    }
}

/// One timestamped value.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Entry<T> {
    /// When the value was measured.
    pub time: Timestamp,
    /// The value.
    pub value: T,
}

/// What happened when a series was asked for a value.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Coverage {
    /// The time fell between two samples.
    Interpolated,
    /// The time fell before the first sample or after the last one.
    Extrapolated,
    /// The time fell inside a gap longer than the series allows.
    InGap,
}

/// A series of timestamped values, sorted by time.
#[derive(Debug, Clone, Default)]
pub struct TimeSeries<T> {
    entries: Vec<Entry<T>>,
    max_gap: f64,
}

impl<T: Interpolate> TimeSeries<T> {
    /// Build a series. Entries are sorted and any at a repeated time are
    /// dropped, keeping the first.
    ///
    /// `max_gap` is how long a hole in the data may be before the series
    /// refuses to interpolate across it, in seconds. A motion sensor dropping
    /// out for two seconds and being interpolated straight through is a hole
    /// in a survey that nothing downstream can see.
    pub fn new(mut entries: Vec<Entry<T>>, max_gap: f64) -> Self {
        entries.sort_by(|a, b| a.time.cmp(&b.time));
        entries.dedup_by(|a, b| (a.time - b.time).abs() < 1.0e-9);
        TimeSeries { entries, max_gap }
    }

    /// The entries, oldest first.
    pub fn entries(&self) -> &[Entry<T>] {
        &self.entries
    }

    /// Number of samples.
    pub fn len(&self) -> usize {
        self.entries.len()
    }

    /// True when the series holds nothing.
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    /// Longest gap the series will interpolate across.
    pub fn max_gap(&self) -> f64 {
        self.max_gap
    }

    /// Time range the series covers, or `None` when it is empty.
    pub fn span(&self) -> Option<TimeSpan> {
        match (self.entries.first(), self.entries.last()) {
            (Some(a), Some(b)) => Some(TimeSpan::new(a.time, b.time)),
            _ => None,
        }
    }

    /// Value at a time, with a note on how it was arrived at.
    ///
    /// Outside the series the nearest end value is held rather than
    /// extrapolated, and the coverage says so. Extrapolating a heading off the
    /// end of a run produces a number that is confidently wrong.
    pub fn value_at(&self, t: Timestamp) -> Option<(T, Coverage)> {
        if self.entries.is_empty() {
            return None;
        }
        let first = self.entries[0];
        let last = self.entries[self.entries.len() - 1];
        if t <= first.time {
            return Some((first.value, Coverage::Extrapolated));
        }
        if t >= last.time {
            return Some((last.value, Coverage::Extrapolated));
        }

        let idx = self.entries.partition_point(|e| e.time < t);
        let b = self.entries[idx];
        let a = self.entries[idx - 1];
        let dt = b.time - a.time;
        if self.max_gap > 0.0 && dt > self.max_gap {
            return Some((a.value, Coverage::InGap));
        }
        let f = if dt <= 0.0 { 0.0 } else { (t - a.time) / dt };
        Some((T::interpolate(a.value, b.value, f), Coverage::Interpolated))
    }

    /// Value at a time, ignoring how it was arrived at.
    pub fn at(&self, t: Timestamp) -> Option<T> {
        self.value_at(t).map(|(v, _)| v)
    }

    /// Every hole in the series longer than a threshold.
    pub fn gaps(&self, longer_than: f64) -> Vec<TimeSpan> {
        self.entries
            .windows(2)
            .filter(|w| w[1].time - w[0].time > longer_than)
            .map(|w| TimeSpan::new(w[0].time, w[1].time))
            .collect()
    }

    /// Mean interval between samples, or zero for a series of one.
    pub fn mean_interval(&self) -> f64 {
        if self.entries.len() < 2 {
            return 0.0;
        }
        let span = self.entries[self.entries.len() - 1].time - self.entries[0].time;
        span / (self.entries.len() - 1) as f64
    }
}
