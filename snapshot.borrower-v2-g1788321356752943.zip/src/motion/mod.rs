//! Vessel motion: attitude, offsets, and the time series they arrive in.

pub mod attitude;
pub mod filter;
pub mod rotation;
pub mod series;
pub mod vessel;

pub use attitude::{Attitude, LeverArm};
pub use filter::{despike, smooth, smooth_series};
pub use rotation::{Mat3, Vec3};
pub use series::{Coverage, Entry, TimeSeries};
pub use vessel::{Latency, MountAngles, VesselGeometry};
