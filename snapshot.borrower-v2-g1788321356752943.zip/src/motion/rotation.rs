//! Three element vectors and three by three rotations.
//!
//! Small enough to write out and keep in the crate rather than take a linear
//! algebra dependency for. Everything here is column vector convention: a
//! rotation matrix multiplies a vector on its left, and composing two
//! rotations applies the right hand one first.

use crate::units::Angle;

/// A vector in whatever frame the caller is working in.
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub struct Vec3 {
    /// First component.
    pub x: f64,
    /// Second component.
    pub y: f64,
    /// Third component.
    pub z: f64,
}

impl Vec3 {
    /// The zero vector.
    pub const ZERO: Vec3 = Vec3 {
        x: 0.0,
        y: 0.0,
        z: 0.0,
    };

    /// Build a vector.
    pub const fn new(x: f64, y: f64, z: f64) -> Self {
        Vec3 { x, y, z }
    }

    /// Vector scaled by a number.
    pub fn scale(self, k: f64) -> Vec3 {
        Vec3::new(self.x * k, self.y * k, self.z * k)
    }

    /// Dot product.
    pub fn dot(self, o: Vec3) -> f64 {
        self.x * o.x + self.y * o.y + self.z * o.z
    }

    /// Cross product.
    pub fn cross(self, o: Vec3) -> Vec3 {
        Vec3::new(
            self.y * o.z - self.z * o.y,
            self.z * o.x - self.x * o.z,
            self.x * o.y - self.y * o.x,
        )
    }

    /// Length of the vector.
    pub fn norm(self) -> f64 {
        self.dot(self).sqrt()
    }

    /// The same direction with unit length, or zero for a zero vector.
    pub fn normalised(self) -> Vec3 {
        let n = self.norm();
        if n <= 0.0 {
            Vec3::ZERO
        } else {
            self.scale(1.0 / n)
        }
    }

    /// True when every component is finite.
    pub fn is_finite(self) -> bool {
        self.x.is_finite() && self.y.is_finite() && self.z.is_finite()
    }
}

impl std::ops::Add for Vec3 {
    type Output = Vec3;
    fn add(self, o: Vec3) -> Vec3 {
        Vec3::new(self.x + o.x, self.y + o.y, self.z + o.z)
    }
}

impl std::ops::Sub for Vec3 {
    type Output = Vec3;
    fn sub(self, o: Vec3) -> Vec3 {
        Vec3::new(self.x - o.x, self.y - o.y, self.z - o.z)
    }
}

impl std::ops::Neg for Vec3 {
    type Output = Vec3;
    fn neg(self) -> Vec3 {
        Vec3::new(-self.x, -self.y, -self.z)
    }
}

/// A three by three matrix, stored by rows.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Mat3 {
    /// Rows of the matrix.
    pub rows: [[f64; 3]; 3],
}

impl Mat3 {
    /// The identity.
    pub const IDENTITY: Mat3 = Mat3 {
        rows: [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]],
    };

    /// Build from rows.
    pub const fn from_rows(rows: [[f64; 3]; 3]) -> Self {
        Mat3 { rows }
    }

    /// Rotation about the first axis, right handed.
    pub fn rot_x(a: Angle) -> Mat3 {
        let (s, c) = a.sin_cos();
        Mat3::from_rows([[1.0, 0.0, 0.0], [0.0, c, -s], [0.0, s, c]])
    }

    /// Rotation about the second axis, right handed.
    pub fn rot_y(a: Angle) -> Mat3 {
        let (s, c) = a.sin_cos();
        Mat3::from_rows([[c, 0.0, s], [0.0, 1.0, 0.0], [-s, 0.0, c]])
    }

    /// Rotation about the third axis, right handed.
    pub fn rot_z(a: Angle) -> Mat3 {
        let (s, c) = a.sin_cos();
        Mat3::from_rows([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])
    }

    /// Matrix times vector.
    pub fn apply(&self, v: Vec3) -> Vec3 {
        let r = &self.rows;
        Vec3::new(
            r[0][0] * v.x + r[0][1] * v.y + r[0][2] * v.z,
            r[1][0] * v.x + r[1][1] * v.y + r[1][2] * v.z,
            r[2][0] * v.x + r[2][1] * v.y + r[2][2] * v.z,
        )
    }

    /// Matrix times matrix, applying `other` first.
    pub fn times(&self, other: &Mat3) -> Mat3 {
        let mut out = [[0.0; 3]; 3];
        for (i, row) in out.iter_mut().enumerate() {
            for (j, cell) in row.iter_mut().enumerate() {
                *cell = (0..3).map(|k| self.rows[i][k] * other.rows[k][j]).sum();
            }
        }
        Mat3::from_rows(out)
    }

    /// Transpose, which for a rotation is also its inverse.
    pub fn transpose(&self) -> Mat3 {
        let r = &self.rows;
        Mat3::from_rows([
            [r[0][0], r[1][0], r[2][0]],
            [r[0][1], r[1][1], r[2][1]],
            [r[0][2], r[1][2], r[2][2]],
        ])
    }

    /// Determinant, which is one for any rotation and is worth asserting when
    /// a matrix has been built from numbers off a file.
    pub fn determinant(&self) -> f64 {
        let r = &self.rows;
        r[0][0] * (r[1][1] * r[2][2] - r[1][2] * r[2][1])
            - r[0][1] * (r[1][0] * r[2][2] - r[1][2] * r[2][0])
            + r[0][2] * (r[1][0] * r[2][1] - r[1][1] * r[2][0])
    }
}

impl Default for Mat3 {
    fn default() -> Self {
        Mat3::IDENTITY
    }
}
