//! Where everything is bolted to the boat, and how late it says it is.
//!
//! A survey vessel carries at least three reference points that matter: the
//! phase centre of the positioning antenna, the reference point of the motion
//! sensor, and the acoustic centre of the transducer. Every one of the offsets
//! between them has to be measured, and every one of the three has a clock
//! that does not quite agree with the others.

use crate::error::{Error, Result};
use crate::units::Angle;

use super::attitude::{Attitude, LeverArm};
use super::rotation::{Mat3, Vec3};

/// The mounting angles of a transducer relative to the vessel frame.
///
/// These come out of a patch test and they are corrections, not measurements:
/// the roll bias is what has to be added to the observed roll to make the
/// swath flat over a flat seabed.
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub struct MountAngles {
    /// Roll offset of the transducer.
    pub roll: Angle,
    /// Pitch offset of the transducer.
    pub pitch: Angle,
    /// Heading offset of the transducer.
    pub heading: Angle,
}

impl MountAngles {
    /// No mounting offset at all.
    pub const ZERO: MountAngles = MountAngles {
        roll: Angle::ZERO,
        pitch: Angle::ZERO,
        heading: Angle::ZERO,
    };

    /// Build from degrees.
    pub fn from_degrees(roll: f64, pitch: f64, heading: f64) -> Self {
        MountAngles {
            roll: Angle::from_degrees(roll),
            pitch: Angle::from_degrees(pitch),
            heading: Angle::from_degrees(heading),
        }
    }

    /// The rotation from the transducer frame into the vessel frame.
    pub fn to_matrix(&self) -> Mat3 {
        Mat3::rot_z(self.heading)
            .times(&Mat3::rot_y(self.pitch))
            .times(&Mat3::rot_x(self.roll))
    }

    /// True when every angle is small enough to be a mounting offset rather
    /// than a mistake in the units.
    pub fn is_plausible(&self) -> bool {
        self.roll.degrees().abs() < 30.0
            && self.pitch.degrees().abs() < 30.0
            && self.heading.degrees().abs() < 90.0
    }
}

/// Timing offsets between the sensors, in seconds.
///
/// Positive means the sensor timestamps its data later than it should, so the
/// correction subtracts the latency from the reported time.
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub struct Latency {
    /// Positioning latency.
    pub position: f64,
    /// Motion sensor latency.
    pub attitude: f64,
    /// Heading latency, which is often a different device from the attitude.
    pub heading: f64,
}

/// The geometry of one survey vessel.
#[derive(Debug, Clone, PartialEq)]
pub struct VesselGeometry {
    /// Name of the vessel or of the configuration, for the log.
    pub name: String,
    /// Offset from the motion sensor to the positioning antenna.
    pub antenna: LeverArm,
    /// Offset from the motion sensor to the acoustic centre.
    pub transducer: LeverArm,
    /// Depth of the transducer below the waterline, positive down.
    ///
    /// Kept separate from the transducer offset because it changes with the
    /// loading of the vessel and the offset does not.
    pub waterline_to_transducer: f64,
    /// Mounting angles of the transducer.
    pub mount: MountAngles,
    /// Timing offsets.
    pub latency: Latency,
}

impl VesselGeometry {
    /// A vessel with everything at the origin and no offsets, which is a
    /// useful starting point for a test and a useless one for a survey.
    pub fn identity(name: impl Into<String>) -> Self {
        VesselGeometry {
            name: name.into(),
            antenna: LeverArm::ZERO,
            transducer: LeverArm::ZERO,
            waterline_to_transducer: 0.0,
            mount: MountAngles::ZERO,
            latency: Latency::default(),
        }
    }

    /// Check the geometry for the mistakes that show up as a metre of static
    /// error in every sounding.
    pub fn validate(&self) -> Result<()> {
        if !self.mount.is_plausible() {
            return Err(Error::Config(format!(
                "mounting angles for {} look like a units mistake",
                self.name
            )));
        }
        if self.antenna.magnitude() > 100.0 || self.transducer.magnitude() > 100.0 {
            return Err(Error::Config(format!(
                "a lever arm on {} is over a hundred metres",
                self.name
            )));
        }
        if !(0.0..30.0).contains(&self.waterline_to_transducer) {
            return Err(Error::domain(
                "waterline to transducer",
                self.waterline_to_transducer,
                "between 0 and 30 metres",
            ));
        }
        Ok(())
    }

    /// Rotate a transducer frame vector into the vessel frame.
    pub fn transducer_to_body(&self, v: Vec3) -> Vec3 {
        self.mount.to_matrix().apply(v)
    }

    /// Offset from the antenna to the transducer, in the body frame.
    ///
    /// This is the vector that has to be rotated by the attitude and taken off
    /// the position before anything else happens.
    pub fn antenna_to_transducer(&self) -> LeverArm {
        self.antenna.to(&self.transducer)
    }

    /// Where the transducer is relative to the antenna in a local level frame.
    pub fn transducer_offset_enu(&self, attitude: &Attitude) -> crate::geodesy::Enu {
        self.antenna_to_transducer().to_enu(attitude)
    }

    /// Vertical distance from the waterline down to the acoustic centre with
    /// the vessel at a given attitude.
    ///
    /// A vessel with a two metre athwartships offset on the transducer and
    /// five degrees of roll moves its acoustic centre by the better part of
    /// twenty centimetres, which is more than the whole vertical budget in
    /// shallow water.
    pub fn dynamic_transducer_depth(&self, attitude: &Attitude) -> f64 {
        let enu = self.transducer.to_enu(attitude);
        self.waterline_to_transducer - (enu.up + self.transducer.down)
    }
}
