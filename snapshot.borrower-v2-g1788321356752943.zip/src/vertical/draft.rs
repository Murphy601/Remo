//! Draft: how far the transducer sits below the water, and how that changes.
//!
//! The static draft comes off a tape measure alongside. The dynamic part does
//! not: a hull settles and trims as it makes way, by a few centimetres on a
//! small launch and by a quarter of a metre on a ship, and it is measured by
//! running a speed trial over a flat patch of seabed. The result is a table of
//! settlement against speed, which is what this holds.

use crate::error::{Error, Result};

/// One row of a settlement trial.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct DraftPoint {
    /// Speed through the water in metres per second.
    pub speed: f64,
    /// Settlement in metres, positive when the transducer goes deeper.
    pub settlement: f64,
}

impl DraftPoint {
    /// Build a row.
    pub const fn new(speed: f64, settlement: f64) -> Self {
        DraftPoint { speed, settlement }
    }
}

/// Static draft plus a settlement table.
#[derive(Debug, Clone, PartialEq)]
pub struct DraftModel {
    /// Depth of the transducer below the waterline at rest, in metres.
    pub static_draft: f64,
    points: Vec<DraftPoint>,
}

impl DraftModel {
    /// A vessel with a fixed draft and no settlement measured.
    pub fn fixed(static_draft: f64) -> Result<Self> {
        if !(0.0..30.0).contains(&static_draft) {
            return Err(Error::domain(
                "static draft",
                static_draft,
                "between 0 and 30 metres",
            ));
        }
        Ok(DraftModel {
            static_draft,
            points: Vec::new(),
        })
    }

    /// A vessel with a settlement table from a speed trial.
    ///
    /// The table is sorted on the way in and has to hold at least two speeds
    /// to be worth interpolating; one point is a constant, and a constant
    /// belongs in the static draft where somebody will see it.
    pub fn with_table(static_draft: f64, mut points: Vec<DraftPoint>) -> Result<Self> {
        if points.len() < 2 {
            return Err(Error::Config(
                "a settlement table needs at least two speeds".into(),
            ));
        }
        points.sort_by(|a, b| a.speed.total_cmp(&b.speed));
        points.dedup_by(|a, b| (a.speed - b.speed).abs() < 1.0e-9);
        if points.iter().any(|p| p.speed < 0.0) {
            return Err(Error::Config(
                "a settlement table cannot hold a negative speed".into(),
            ));
        }
        let mut model = DraftModel::fixed(static_draft)?;
        model.points = points;
        Ok(model)
    }

    /// The settlement table, slowest first.
    pub fn table(&self) -> &[DraftPoint] {
        &self.points
    }

    /// Settlement at a speed, linearly interpolated.
    ///
    /// Outside the table the end values are held. A trial run between four and
    /// eight knots says nothing about twelve, and pretending the trend
    /// continues is how a transit line ends up a decimetre deep.
    pub fn settlement_at(&self, speed: f64) -> f64 {
        if self.points.is_empty() {
            return 0.0;
        }
        let first = self.points[0];
        let last = self.points[self.points.len() - 1];
        if speed <= first.speed {
            return first.settlement;
        }
        if speed >= last.speed {
            return last.settlement;
        }
        let idx = self.points.partition_point(|p| p.speed < speed);
        let b = self.points[idx];
        let a = self.points[idx - 1];
        let span = b.speed - a.speed;
        if span <= 0.0 {
            return a.settlement;
        }
        a.settlement + (b.settlement - a.settlement) * (speed - a.speed) / span
    }

    /// Total draft at a speed, static plus settlement.
    pub fn draft_at(&self, speed: f64) -> f64 {
        self.static_draft + self.settlement_at(speed)
    }

    /// True when the table has been extrapolated for this speed, so the report
    /// can say so.
    pub fn is_outside_table(&self, speed: f64) -> bool {
        match (self.points.first(), self.points.last()) {
            (Some(a), Some(b)) => speed < a.speed || speed > b.speed,
            _ => true,
        }
    }

    /// Largest settlement anywhere in the table, for a quick sanity check on
    /// whether a trial was worth doing at all.
    pub fn max_settlement(&self) -> f64 {
        self.points
            .iter()
            .map(|p| p.settlement.abs())
            .fold(0.0, f64::max)
    }
}
