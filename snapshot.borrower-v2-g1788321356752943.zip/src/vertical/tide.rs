//! Observed water level, and how it gets from a gauge to the vessel.
//!
//! A tide reduction is the difference between the instantaneous water level
//! and the datum the chart is drawn to. That number is measured at a gauge on
//! the shore and it has to be carried out to a vessel that may be forty
//! kilometres away in water that behaves differently, which is what zoning is
//! for: each zone gets a time shift and a range factor against the gauge, and
//! the survey is worked in zones.

use crate::error::{Error, Result};
use crate::geodesy::Geodetic;
use crate::motion::series::{Coverage, Entry, TimeSeries};
use crate::time::Timestamp;

/// A tide gauge and the water levels it recorded.
#[derive(Debug, Clone)]
pub struct TideGauge {
    /// Name as it appears in the survey report.
    pub name: String,
    /// Where the gauge is.
    pub position: Geodetic,
    /// Height of the water above chart datum, in metres.
    heights: TimeSeries<f64>,
}

impl TideGauge {
    /// Build a gauge from its observations.
    ///
    /// The maximum gap is generous because a gauge samples every few minutes
    /// and the tide is smooth; an hour of missing record still interpolates to
    /// a couple of centimetres.
    pub fn new(
        name: impl Into<String>,
        position: Geodetic,
        observations: Vec<(Timestamp, f64)>,
        max_gap: f64,
    ) -> Result<Self> {
        if observations.len() < 2 {
            return Err(Error::Config(
                "a tide gauge needs at least two observations".into(),
            ));
        }
        let heights = TimeSeries::new(
            observations
                .into_iter()
                .map(|(time, value)| Entry { time, value })
                .collect(),
            max_gap,
        );
        Ok(TideGauge {
            name: name.into(),
            position,
            heights,
        })
    }

    /// Water level above datum at a time, with the coverage that produced it.
    pub fn level_at(&self, time: Timestamp) -> Option<(f64, Coverage)> {
        self.heights.value_at(time)
    }

    /// The observations.
    pub fn observations(&self) -> &TimeSeries<f64> {
        &self.heights
    }

    /// Range of the record, highest minus lowest.
    pub fn range(&self) -> f64 {
        let mut lo = f64::INFINITY;
        let mut hi = f64::NEG_INFINITY;
        for e in self.heights.entries() {
            lo = lo.min(e.value);
            hi = hi.max(e.value);
        }
        if lo.is_finite() && hi.is_finite() {
            hi - lo
        } else {
            0.0
        }
    }
}

/// One zone of a zoned tide scheme.
#[derive(Debug, Clone, PartialEq)]
pub struct TideZone {
    /// Zone name, usually a letter and a number off the zoning diagram.
    pub name: String,
    /// Which gauge the zone is worked from.
    pub gauge: String,
    /// Time shift applied to the gauge record, in seconds.
    ///
    /// Positive means the tide arrives at the zone later than at the gauge.
    pub time_offset: f64,
    /// Multiplier on the gauge range.
    pub range_factor: f64,
    /// Constant offset between the zone datum and the gauge datum.
    pub datum_offset: f64,
}

impl TideZone {
    /// A zone that reproduces its gauge exactly.
    pub fn transparent(name: impl Into<String>, gauge: impl Into<String>) -> Self {
        TideZone {
            name: name.into(),
            gauge: gauge.into(),
            time_offset: 0.0,
            range_factor: 1.0,
            datum_offset: 0.0,
        }
    }

    /// Apply the zone to a gauge level.
    pub fn apply(&self, gauge_level: f64) -> f64 {
        gauge_level * self.range_factor + self.datum_offset
    }
}

/// A set of gauges and zones, which together answer the only question the
/// reduction asks: what was the water level here, then.
#[derive(Debug, Clone)]
pub struct TideModel {
    gauges: Vec<TideGauge>,
    zones: Vec<TideZone>,
}

impl TideModel {
    /// Build a model. Every zone has to name a gauge that exists.
    pub fn new(gauges: Vec<TideGauge>, zones: Vec<TideZone>) -> Result<Self> {
        if gauges.is_empty() {
            return Err(Error::Config("no tide gauges supplied".into()));
        }
        for z in &zones {
            if !gauges.iter().any(|g| g.name == z.gauge) {
                return Err(Error::Config(format!(
                    "zone {} refers to gauge {} which is not loaded",
                    z.name, z.gauge
                )));
            }
        }
        Ok(TideModel { gauges, zones })
    }

    /// A model with one gauge and no zoning, which is what a small survey uses.
    pub fn single_gauge(gauge: TideGauge) -> Result<Self> {
        let zone = TideZone::transparent("whole survey", gauge.name.clone());
        TideModel::new(vec![gauge], vec![zone])
    }

    /// The gauges.
    pub fn gauges(&self) -> &[TideGauge] {
        &self.gauges
    }

    /// The zones.
    pub fn zones(&self) -> &[TideZone] {
        &self.zones
    }

    /// Water level above datum in a named zone at a time.
    pub fn level_in_zone(&self, zone_name: &str, time: Timestamp) -> Result<(f64, Coverage)> {
        let zone = self
            .zones
            .iter()
            .find(|z| z.name == zone_name)
            .ok_or_else(|| Error::Config(format!("no tide zone called {zone_name}")))?;
        let gauge = self
            .gauges
            .iter()
            .find(|g| g.name == zone.gauge)
            .ok_or_else(|| Error::Config(format!("no tide gauge called {}", zone.gauge)))?;
        let shifted = time.offset(-zone.time_offset);
        let (level, coverage) = gauge
            .level_at(shifted)
            .ok_or_else(|| Error::Config(format!("gauge {} has no record", gauge.name)))?;
        Ok((zone.apply(level), coverage))
    }
}
