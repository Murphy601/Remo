//! Separation models, the grids that relate one vertical datum to another.
//!
//! Working from the ellipsoid instead of from a tide gauge replaces a tide
//! record with a surface: the height of chart datum above the ellipsoid, on a
//! regular grid, interpolated at the position of the sounding. The surface is
//! smooth over tens of kilometres, so bilinear interpolation is enough, but it
//! has holes over land and the holes have to stay holes rather than being
//! filled with a plausible number.

use crate::error::{Error, Result};
use crate::geodesy::Geodetic;
use crate::units::Angle;

/// The value a cell carries when the model says nothing there.
pub const NO_DATA: f64 = -9999.0;

/// A regular grid of separations in geographic coordinates.
#[derive(Debug, Clone, PartialEq)]
pub struct SeparationModel {
    /// Name of the model, carried into the processing log.
    pub name: String,
    /// Latitude of the first row.
    origin_lat: Angle,
    /// Longitude of the first column.
    origin_lon: Angle,
    /// Spacing between rows.
    step_lat: Angle,
    /// Spacing between columns.
    step_lon: Angle,
    rows: usize,
    columns: usize,
    values: Vec<f64>,
}

impl SeparationModel {
    /// Build a model from a row major grid of separations.
    ///
    /// Separations are the height of the target datum above the ellipsoid, so
    /// a chart datum below the ellipsoid is a negative number, which it very
    /// often is.
    pub fn new(
        name: impl Into<String>,
        origin: Geodetic,
        step_lat: Angle,
        step_lon: Angle,
        rows: usize,
        columns: usize,
        values: Vec<f64>,
    ) -> Result<Self> {
        if rows < 2 || columns < 2 {
            return Err(Error::Config(
                "a separation model needs at least two rows and two columns".into(),
            ));
        }
        if values.len() != rows * columns {
            return Err(Error::Config(format!(
                "separation model says {rows} by {columns} but carries {} values",
                values.len()
            )));
        }
        if step_lat.radians() <= 0.0 || step_lon.radians() <= 0.0 {
            return Err(Error::Config(
                "separation model steps have to be positive".into(),
            ));
        }
        Ok(SeparationModel {
            name: name.into(),
            origin_lat: origin.lat,
            origin_lon: origin.lon,
            step_lat,
            step_lon,
            rows,
            columns,
            values,
        })
    }

    /// A model that is the same everywhere, which is what a small survey with
    /// a single measured offset actually has.
    pub fn constant(name: impl Into<String>, separation: f64) -> Result<Self> {
        SeparationModel::new(
            name,
            Geodetic::from_degrees(-90.0, -180.0, 0.0),
            Angle::from_degrees(90.0),
            Angle::from_degrees(180.0),
            3,
            3,
            vec![separation; 9],
        )
    }

    /// Number of rows.
    pub fn rows(&self) -> usize {
        self.rows
    }

    /// Number of columns.
    pub fn columns(&self) -> usize {
        self.columns
    }

    /// Value in one cell, or `None` when the cell is a hole.
    pub fn cell(&self, row: usize, column: usize) -> Option<f64> {
        if row >= self.rows || column >= self.columns {
            return None;
        }
        let v = self.values[row * self.columns + column];
        if v <= NO_DATA + 1.0 || !v.is_finite() {
            None
        } else {
            Some(v)
        }
    }

    /// Separation at a position, bilinearly interpolated.
    ///
    /// Returns `None` outside the model and anywhere one of the four
    /// surrounding cells is a hole. Filling a hole from three neighbours gives
    /// a separation that is smooth, plausible and unsupported by anything.
    pub fn separation_at(&self, p: Geodetic) -> Option<f64> {
        let fr = (p.lat - self.origin_lat).radians() / self.step_lat.radians();
        // Longitude offsets are measured eastwards from the origin over a full
        // turn, not as a shortest difference. A model that spans the world has
        // columns three hundred degrees east of its origin and the signed wrap
        // puts them behind it.
        let fc = (p.lon - self.origin_lon).wrapped().radians() / self.step_lon.radians();
        if fr < 0.0 || fc < 0.0 {
            return None;
        }
        let r = fr.floor() as usize;
        let c = fc.floor() as usize;
        if r + 1 >= self.rows || c + 1 >= self.columns {
            return None;
        }
        let ur = fr - r as f64;
        let uc = fc - c as f64;

        let v00 = self.cell(r, c)?;
        let v01 = self.cell(r, c + 1)?;
        let v10 = self.cell(r + 1, c)?;
        let v11 = self.cell(r + 1, c + 1)?;

        Some((1.0 - ur) * ((1.0 - uc) * v00 + uc * v01) + ur * ((1.0 - uc) * v10 + uc * v11))
    }

    /// How much the model changes over its own extent, which is the number
    /// that says whether a constant separation would have done.
    pub fn relief(&self) -> f64 {
        let mut lo = f64::INFINITY;
        let mut hi = f64::NEG_INFINITY;
        for r in 0..self.rows {
            for c in 0..self.columns {
                if let Some(v) = self.cell(r, c) {
                    lo = lo.min(v);
                    hi = hi.max(v);
                }
            }
        }
        if lo.is_finite() && hi.is_finite() {
            hi - lo
        } else {
            0.0
        }
    }

    /// Fraction of the model that carries no value.
    pub fn hole_fraction(&self) -> f64 {
        let holes = self
            .values
            .iter()
            .filter(|v| **v <= NO_DATA + 1.0 || !v.is_finite())
            .count();
        holes as f64 / self.values.len() as f64
    }
}
