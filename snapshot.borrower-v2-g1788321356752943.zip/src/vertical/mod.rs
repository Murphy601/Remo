//! Getting a depth onto a datum.

pub mod draft;
pub mod reference;
pub mod separation;
pub mod tide;

pub use draft::{DraftModel, DraftPoint};
pub use reference::{VerticalInput, VerticalReference, VerticalSolution};
pub use separation::SeparationModel;
pub use tide::{TideGauge, TideModel, TideZone};
