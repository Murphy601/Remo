//! Choosing what a depth is measured from, and working out the offset.
//!
//! Everything in the reduction up to this point produces a depth below the
//! acoustic centre of the transducer. This is where that becomes a depth below
//! a datum somebody can put on a chart, and there are two ways to get there:
//! from a tide record, or from the ellipsoidal height of the vessel and a
//! separation model. They fail differently, so they are separate variants
//! rather than one path with a flag.

use crate::error::{Error, Result};
use crate::geodesy::Geodetic;
use crate::motion::series::Coverage;
use crate::time::Timestamp;

use super::draft::DraftModel;
use super::separation::SeparationModel;
use super::tide::TideModel;

/// What the depths are referred to.
#[derive(Debug, Clone)]
pub enum VerticalReference {
    /// Water level from a gauge, reduced through a zone.
    Tide {
        /// The gauges and zones.
        model: Box<TideModel>,
        /// Which zone this line is worked in.
        zone: String,
    },
    /// Ellipsoidal height of the vessel, less a separation model.
    Ellipsoid {
        /// Height of the datum above the ellipsoid.
        separation: Box<SeparationModel>,
    },
}

/// Everything the vertical solution needs about one instant.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct VerticalInput {
    /// Time of the ping.
    pub time: Timestamp,
    /// Position of the vessel, needed for the separation model.
    pub position: Geodetic,
    /// Ellipsoidal height of the transducer, when the positioning gives one.
    pub transducer_height: Option<f64>,
    /// Instantaneous heave, positive up.
    pub heave: f64,
    /// Speed through the water, for the settlement table.
    pub speed: f64,
}

/// Where the transducer was, vertically, and how confident we are about it.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct VerticalSolution {
    /// Height of the acoustic centre above the datum, in metres.
    ///
    /// Usually negative, because the transducer is usually under water and the
    /// datum is usually near the surface.
    pub transducer_above_datum: f64,
    /// Draft used, static plus settlement.
    pub draft: f64,
    /// How the water level was arrived at, when it came from a gauge.
    pub coverage: Option<Coverage>,
    /// True when the settlement table was extrapolated.
    pub outside_draft_table: bool,
}

impl VerticalSolution {
    /// Turn a depth below the transducer into a depth below the datum.
    pub fn to_datum(&self, depth_below_transducer: f64) -> f64 {
        depth_below_transducer - self.transducer_above_datum
    }
}

impl VerticalReference {
    /// Solve for the vertical position of the transducer.
    pub fn solve(
        &self,
        input: VerticalInput,
        draft_model: &DraftModel,
    ) -> Result<VerticalSolution> {
        let draft = draft_model.draft_at(input.speed);
        let outside_draft_table = draft_model.is_outside_table(input.speed);

        match self {
            VerticalReference::Tide { model, zone } => {
                let (level, coverage) = model.level_in_zone(zone, input.time)?;
                Ok(VerticalSolution {
                    transducer_above_datum: level - draft + input.heave,
                    draft,
                    coverage: Some(coverage),
                    outside_draft_table,
                })
            }
            VerticalReference::Ellipsoid { separation } => {
                let height = input.transducer_height.ok_or_else(|| {
                    Error::Config(
                        "ellipsoidal referencing needs a height from the positioning".into(),
                    )
                })?;
                let sep = separation.separation_at(input.position).ok_or_else(|| {
                    Error::Config(format!(
                        "separation model {} has no value at this position",
                        separation.name
                    ))
                })?;
                // The height already has the heave in it, because it comes
                // from the same solution that produced the position. Adding
                // the heave again here is the classic way to double it.
                Ok(VerticalSolution {
                    transducer_above_datum: height - sep,
                    draft,
                    coverage: None,
                    outside_draft_table,
                })
            }
        }
    }

    /// Short name for the log.
    pub fn describe(&self) -> String {
        match self {
            VerticalReference::Tide { zone, .. } => format!("tide, zone {zone}"),
            VerticalReference::Ellipsoid { separation } => {
                format!("ellipsoid, separation {}", separation.name)
            }
        }
    }

    /// True when this reference needs a height out of the positioning system.
    pub fn needs_height(&self) -> bool {
        matches!(self, VerticalReference::Ellipsoid { .. })
    }
}
