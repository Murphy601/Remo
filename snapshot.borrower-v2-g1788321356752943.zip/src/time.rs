//! Survey timestamps.
//!
//! Every observation in a survey carries a time, and everything downstream is
//! an interpolation between two of them, so the type has to be cheap to
//! compare and cheap to subtract. It is a `f64` count of SI seconds since the
//! Unix epoch, which gives roughly microsecond resolution for any date this
//! century, well inside the timing error of the sensors themselves.
//!
//! Leap seconds are ignored on purpose. Positioning systems hand out GPS or
//! UTC time and the offset between them is a constant over a survey; carrying
//! a leap table would only give the illusion of rigour.

use std::cmp::Ordering;
use std::fmt;
use std::ops::{Add, Sub};

/// Seconds in a day, ignoring leap seconds.
pub const SECONDS_PER_DAY: f64 = 86_400.0;

/// An instant, as SI seconds since 1970-01-01T00:00:00Z.
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub struct Timestamp(f64);

impl Timestamp {
    /// The Unix epoch itself.
    pub const EPOCH: Timestamp = Timestamp(0.0);

    /// Build from seconds since the epoch.
    #[inline]
    pub const fn from_unix_seconds(s: f64) -> Self {
        Timestamp(s)
    }

    /// Seconds since the epoch.
    #[inline]
    pub const fn unix_seconds(self) -> f64 {
        self.0
    }

    /// Build from a UTC calendar date and time.
    ///
    /// The date is not validated beyond what the day count algorithm needs, so
    /// a February 30th will silently roll over into March.
    pub fn from_utc(year: i32, month: u32, day: u32, hour: u32, min: u32, sec: f64) -> Self {
        let days = days_from_civil(year, month, day) as f64;
        Timestamp(days * SECONDS_PER_DAY + (hour as f64) * 3600.0 + (min as f64) * 60.0 + sec)
    }

    /// Split into UTC calendar parts.
    pub fn to_utc(self) -> CalendarTime {
        let days = (self.0 / SECONDS_PER_DAY).floor();
        let rem = self.0 - days * SECONDS_PER_DAY;
        let (year, month, day) = civil_from_days(days as i64);
        let hour = (rem / 3600.0).floor();
        let minute = ((rem - hour * 3600.0) / 60.0).floor();
        CalendarTime {
            year,
            month,
            day,
            hour: hour as u32,
            minute: minute as u32,
            second: rem - hour * 3600.0 - minute * 60.0,
        }
    }

    /// Day of year, one based, as survey logs label their files.
    pub fn day_of_year(self) -> u32 {
        let c = self.to_utc();
        let start = Timestamp::from_utc(c.year, 1, 1, 0, 0, 0.0);
        ((self.0 - start.0) / SECONDS_PER_DAY).floor() as u32 + 1
    }

    /// Seconds since midnight UTC, the form most sonar logs record.
    pub fn seconds_of_day(self) -> f64 {
        self.0 - (self.0 / SECONDS_PER_DAY).floor() * SECONDS_PER_DAY
    }

    /// Shift by a number of seconds.
    #[inline]
    pub fn offset(self, seconds: f64) -> Timestamp {
        Timestamp(self.0 + seconds)
    }

    /// True when the value is a usable time rather than a NaN placeholder.
    #[inline]
    pub fn is_valid(self) -> bool {
        self.0.is_finite()
    }

    /// Total ordering, safe to hand to `sort_by`.
    #[inline]
    pub fn cmp_total(self, other: Timestamp) -> Ordering {
        self.0.total_cmp(&other.0)
    }
}

impl Eq for Timestamp {}

impl PartialOrd for Timestamp {
    fn partial_cmp(&self, other: &Timestamp) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

impl Ord for Timestamp {
    fn cmp(&self, other: &Timestamp) -> Ordering {
        self.0.total_cmp(&other.0)
    }
}

impl Sub for Timestamp {
    type Output = f64;
    fn sub(self, rhs: Timestamp) -> f64 {
        self.0 - rhs.0
    }
}

impl Add<f64> for Timestamp {
    type Output = Timestamp;
    fn add(self, rhs: f64) -> Timestamp {
        Timestamp(self.0 + rhs)
    }
}

impl fmt::Display for Timestamp {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let c = self.to_utc();
        write!(
            f,
            "{:04}-{:02}-{:02}T{:02}:{:02}:{:06.3}Z",
            c.year, c.month, c.day, c.hour, c.minute, c.second
        )
    }
}

/// A timestamp broken into UTC calendar fields.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct CalendarTime {
    /// Proleptic Gregorian year.
    pub year: i32,
    /// Month, 1 to 12.
    pub month: u32,
    /// Day of month, 1 based.
    pub day: u32,
    /// Hour, 0 to 23.
    pub hour: u32,
    /// Minute, 0 to 59.
    pub minute: u32,
    /// Second, including the fraction.
    pub second: f64,
}

/// Days from the Unix epoch to a proleptic Gregorian date.
///
/// This is Howard Hinnant's civil calendar algorithm, shifted so the era
/// starts on 0000-03-01. It is exact for any year that fits in an `i32`.
fn days_from_civil(y: i32, m: u32, d: u32) -> i64 {
    let y = if m <= 2 { y - 1 } else { y } as i64;
    let era = if y >= 0 { y } else { y - 399 } / 400;
    let yoe = y - era * 400;
    let mp = ((m as i64) + 9) % 12;
    let doy = (153 * mp + 2) / 5 + (d as i64) - 1;
    let doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    era * 146_097 + doe - 719_468
}

/// Inverse of [`days_from_civil`].
fn civil_from_days(z: i64) -> (i32, u32, u32) {
    let z = z + 719_468;
    let era = if z >= 0 { z } else { z - 146_096 } / 146_097;
    let doe = z - era * 146_097;
    let yoe = (doe - doe / 1460 + doe / 36_524 - doe / 146_096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = if mp < 10 { mp + 3 } else { mp - 9 };
    let y = if m <= 2 { y + 1 } else { y };
    (y as i32, m as u32, d as u32)
}

/// A closed interval of time.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct TimeSpan {
    /// First instant in the span.
    pub start: Timestamp,
    /// Last instant in the span.
    pub end: Timestamp,
}

impl TimeSpan {
    /// Build a span, ordering the ends if they arrive the wrong way round.
    pub fn new(a: Timestamp, b: Timestamp) -> Self {
        if a <= b {
            TimeSpan { start: a, end: b }
        } else {
            TimeSpan { start: b, end: a }
        }
    }

    /// Length in seconds.
    pub fn duration(&self) -> f64 {
        self.end - self.start
    }

    /// True when `t` lies inside the span, ends included.
    pub fn contains(&self, t: Timestamp) -> bool {
        t >= self.start && t <= self.end
    }

    /// The overlap with another span, if they touch at all.
    pub fn intersect(&self, other: &TimeSpan) -> Option<TimeSpan> {
        let start = self.start.max(other.start);
        let end = self.end.min(other.end);
        if start <= end {
            Some(TimeSpan { start, end })
        } else {
            None
        }
    }

    /// Grow the span so it also covers `t`.
    pub fn extend(&mut self, t: Timestamp) {
        if t < self.start {
            self.start = t;
        }
        if t > self.end {
            self.end = t;
        }
    }
}
