//! Typed access to a configuration document.
//!
//! Two things matter here beyond pulling values out. The first is that a
//! missing key and a key of the wrong kind produce different messages, both
//! naming the key, because the person reading the message is holding the file.
//! The second is that every key read is remembered, so that at the end the
//! caller can ask what was set and never looked at. A misspelled key that is
//! silently ignored is the worst failure a configuration file has: everything
//! runs, nothing complains, and the setting did nothing.

use std::cell::RefCell;

use crate::error::{Error, Result};
use crate::units::Angle;

use super::document::{Document, Value};

/// A document plus a record of what has been read out of it.
#[derive(Debug)]
pub struct Reader<'a> {
    document: &'a Document,
    seen: RefCell<Vec<String>>,
}

impl<'a> Reader<'a> {
    /// Wrap a document.
    pub fn new(document: &'a Document) -> Self {
        Reader {
            document,
            seen: RefCell::new(Vec::new()),
        }
    }

    fn mark(&self, key: &str) {
        let mut seen = self.seen.borrow_mut();
        if !seen.iter().any(|k| k == key) {
            seen.push(key.to_string());
        }
    }

    fn lookup(&self, key: &str) -> Option<&'a Value> {
        self.mark(key);
        self.document.get(key)
    }

    fn missing(key: &str) -> Error {
        Error::Config(format!("{key} is not set"))
    }

    fn wrong_kind(key: &str, wanted: &str, got: &Value) -> Error {
        Error::Config(format!("{key} should be {wanted} but it is {}", got.kind()))
    }

    /// A string that has to be there.
    pub fn string(&self, key: &str) -> Result<String> {
        let value = self.lookup(key).ok_or_else(|| Self::missing(key))?;
        value
            .as_str()
            .map(ToString::to_string)
            .ok_or_else(|| Self::wrong_kind(key, "a string", value))
    }

    /// A string with a default.
    pub fn string_or(&self, key: &str, fallback: &str) -> Result<String> {
        match self.lookup(key) {
            None => Ok(fallback.to_string()),
            Some(v) => v
                .as_str()
                .map(ToString::to_string)
                .ok_or_else(|| Self::wrong_kind(key, "a string", v)),
        }
    }

    /// A number that has to be there.
    pub fn number(&self, key: &str) -> Result<f64> {
        let value = self.lookup(key).ok_or_else(|| Self::missing(key))?;
        value
            .as_number()
            .ok_or_else(|| Self::wrong_kind(key, "a number", value))
    }

    /// A number with a default.
    pub fn number_or(&self, key: &str, fallback: f64) -> Result<f64> {
        match self.lookup(key) {
            None => Ok(fallback),
            Some(v) => v
                .as_number()
                .ok_or_else(|| Self::wrong_kind(key, "a number", v)),
        }
    }

    /// A number that has to be inside a range.
    ///
    /// The range check lives here rather than at the call site so the message
    /// can name the key, which a bare domain error cannot.
    pub fn number_in(&self, key: &str, low: f64, high: f64) -> Result<f64> {
        let v = self.number(key)?;
        if v < low || v > high {
            return Err(Error::Config(format!(
                "{key} is {v}, it has to be between {low} and {high}"
            )));
        }
        Ok(v)
    }

    /// An angle given in degrees, with a default in degrees.
    pub fn angle_or(&self, key: &str, fallback_degrees: f64) -> Result<Angle> {
        Ok(Angle::from_degrees(self.number_or(key, fallback_degrees)?))
    }

    /// A boolean with a default.
    pub fn bool_or(&self, key: &str, fallback: bool) -> Result<bool> {
        match self.lookup(key) {
            None => Ok(fallback),
            Some(v) => v
                .as_bool()
                .ok_or_else(|| Self::wrong_kind(key, "a boolean", v)),
        }
    }

    /// An array of numbers, empty when the key is absent.
    pub fn numbers(&self, key: &str) -> Result<Vec<f64>> {
        let Some(value) = self.lookup(key) else {
            return Ok(Vec::new());
        };
        let items = value
            .as_array()
            .ok_or_else(|| Self::wrong_kind(key, "an array", value))?;
        items
            .iter()
            .map(|v| {
                v.as_number().ok_or_else(|| {
                    Error::Config(format!("{key} holds {} among the numbers", v.kind()))
                })
            })
            .collect()
    }

    /// An array of strings, empty when the key is absent.
    pub fn strings(&self, key: &str) -> Result<Vec<String>> {
        let Some(value) = self.lookup(key) else {
            return Ok(Vec::new());
        };
        let items = value
            .as_array()
            .ok_or_else(|| Self::wrong_kind(key, "an array", value))?;
        items
            .iter()
            .map(|v| {
                v.as_str().map(ToString::to_string).ok_or_else(|| {
                    Error::Config(format!("{key} holds {} among the strings", v.kind()))
                })
            })
            .collect()
    }

    /// A value from a fixed set of names, mapped by the caller.
    pub fn choice<T>(
        &self,
        key: &str,
        fallback: T,
        parse: impl Fn(&str) -> Option<T>,
    ) -> Result<T> {
        match self.lookup(key) {
            None => Ok(fallback),
            Some(v) => {
                let name = v
                    .as_str()
                    .ok_or_else(|| Self::wrong_kind(key, "a string", v))?;
                parse(name).ok_or_else(|| Error::Config(format!("{key} does not accept {name}")))
            }
        }
    }

    /// True when a key is present, without reading it.
    pub fn has(&self, key: &str) -> bool {
        self.document.contains(key)
    }

    /// Keys in the document that nothing asked for.
    pub fn unread(&self) -> Vec<String> {
        let seen = self.seen.borrow();
        self.document
            .keys()
            .filter(|k| !seen.iter().any(|s| s == *k))
            .cloned()
            .collect()
    }
}
