//! Reading a survey configuration, and turning it into the objects the
//! pipeline runs on.

pub mod document;
pub mod reader;
pub mod survey;

pub use document::{Document, Value};
pub use reader::Reader;
pub use survey::{SurveyConfig, VerticalMode};
