//! The survey configuration: one file that says how a block is to be reduced.
//!
//! This is the file that gets archived with the deliverable. Everything that
//! changes a depth is in it, and nothing that changes a depth is anywhere
//! else, which is the only way to answer the question of how a particular
//! survey was processed two years after everyone involved has moved on.

use std::path::Path;

use crate::error::{Error, InFile, Result};
use crate::motion::attitude::LeverArm;
use crate::motion::vessel::{Latency, MountAngles, VesselGeometry};
use crate::svp::equations::SoundSpeedEquation;
use crate::svp::library::ProfileSelection;
use crate::tpu::s44::Order;
use crate::tpu::sensors::UncertaintyBudget;
use crate::vertical::draft::{DraftModel, DraftPoint};

use super::document::Document;
use super::reader::Reader;

/// How the depths are to be referred to a datum.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum VerticalMode {
    /// From a tide gauge, worked through a named zone.
    Tide {
        /// Name of the zone this block is worked in.
        zone: String,
    },
    /// From the ellipsoidal height of the vessel and a separation.
    Ellipsoid,
}

/// Everything that decides what a sounding comes out as.
#[derive(Debug, Clone, PartialEq)]
pub struct SurveyConfig {
    /// Name of the survey, carried into every report.
    pub name: String,
    /// Order the survey is worked to.
    pub order: Option<Order>,
    /// Projection zone.
    pub utm_zone: u8,
    /// True for the northern hemisphere.
    pub northern: bool,
    /// The vessel.
    pub vessel: VesselGeometry,
    /// Uncertainty budget.
    pub budget: UncertaintyBudget,
    /// Which sound speed equation the casts are reduced with.
    pub equation: SoundSpeedEquation,
    /// How a cast is chosen for a ping.
    pub profile_selection: ProfileSelection,
    /// Tolerance used when thinning casts, in metres per second.
    pub thin_tolerance: f64,
    /// How the depths reach a datum.
    pub vertical: VerticalMode,
    /// Static and dynamic draft.
    pub draft: DraftModel,
    /// Grid cell size in metres.
    pub cell_size: f64,
    /// Swath half angle limit in degrees, when the specification sets one.
    pub swath_limit: Option<f64>,
    /// Depth window the survey expects, in metres.
    pub depth_window: (f64, f64),
    /// Largest departure from the local median before a sounding is flagged.
    pub max_deviation: Option<f64>,
    /// Keys in the file that nothing read.
    pub unread_keys: Vec<String>,
}

impl SurveyConfig {
    /// Read a configuration from text.
    pub fn parse(text: &str) -> Result<SurveyConfig> {
        let document = Document::parse(text)?;
        SurveyConfig::from_document(&document)
    }

    /// Read a configuration from a file.
    pub fn read(path: impl AsRef<Path>) -> Result<SurveyConfig> {
        let path = path.as_ref();
        let text = std::fs::read_to_string(path).map_err(|e| Error::io(path, e))?;
        SurveyConfig::parse(&text).in_file(path)
    }

    /// Build a configuration from an already parsed document.
    pub fn from_document(document: &Document) -> Result<SurveyConfig> {
        let r = Reader::new(document);

        let name = r.string("survey.name")?;
        let order = if r.has("survey.order") {
            let text = r.string("survey.order")?;
            Some(
                Order::from_name(&text)
                    .ok_or_else(|| Error::Config(format!("survey.order does not accept {text}")))?,
            )
        } else {
            None
        };
        let utm_zone = r.number_in("survey.utm_zone", 1.0, 60.0)? as u8;
        let northern = r.bool_or("survey.northern", true)?;

        let vessel = read_vessel(&r)?;
        let budget = read_budget(&r)?;

        let equation = r.choice(
            "sound_speed.equation",
            SoundSpeedEquation::ChenMillero,
            SoundSpeedEquation::from_name,
        )?;
        let profile_selection = r.choice(
            "sound_speed.selection",
            ProfileSelection::NearestInTime,
            |name| match name {
                "nearest in time" | "nearest-in-time" => Some(ProfileSelection::NearestInTime),
                "previous in time" | "previous-in-time" => Some(ProfileSelection::PreviousInTime),
                "nearest in space" | "nearest-in-space" => Some(ProfileSelection::NearestInSpace),
                _ => None,
            },
        )?;
        let thin_tolerance = r.number_or("sound_speed.thin_tolerance", 0.1)?;

        let vertical = match r.string_or("vertical.mode", "tide")?.as_str() {
            "tide" => VerticalMode::Tide {
                zone: r.string_or("vertical.zone", "whole survey")?,
            },
            "ellipsoid" => VerticalMode::Ellipsoid,
            other => {
                return Err(Error::Config(format!(
                    "vertical.mode is {other}, it has to be tide or ellipsoid"
                )))
            }
        };
        let draft = read_draft(&r)?;

        let cell_size = r.number_in("grid.cell_size", 0.01, 10_000.0)?;
        let swath_limit = if r.has("cleaning.max_swath_angle") {
            Some(r.number_in("cleaning.max_swath_angle", 0.0, 89.0)?)
        } else {
            None
        };
        let depth_window = (
            r.number_or("cleaning.min_depth", f64::NEG_INFINITY)?,
            r.number_or("cleaning.max_depth", f64::INFINITY)?,
        );
        let max_deviation = if r.has("cleaning.max_deviation") {
            Some(r.number("cleaning.max_deviation")?)
        } else {
            None
        };

        Ok(SurveyConfig {
            name,
            order,
            utm_zone,
            northern,
            vessel,
            budget,
            equation,
            profile_selection,
            thin_tolerance,
            vertical,
            draft,
            cell_size,
            swath_limit,
            depth_window,
            max_deviation,
            unread_keys: r.unread(),
        })
    }
}

fn read_vessel(r: &Reader<'_>) -> Result<VesselGeometry> {
    let mut vessel = VesselGeometry::identity(r.string_or("vessel.name", "unnamed")?);
    vessel.antenna = LeverArm::new(
        r.number_or("vessel.antenna_forward", 0.0)?,
        r.number_or("vessel.antenna_starboard", 0.0)?,
        r.number_or("vessel.antenna_down", 0.0)?,
    );
    vessel.transducer = LeverArm::new(
        r.number_or("vessel.transducer_forward", 0.0)?,
        r.number_or("vessel.transducer_starboard", 0.0)?,
        r.number_or("vessel.transducer_down", 0.0)?,
    );
    vessel.waterline_to_transducer = r.number_or("vessel.draft", 0.0)?;
    vessel.mount = MountAngles {
        roll: r.angle_or("vessel.roll_offset", 0.0)?,
        pitch: r.angle_or("vessel.pitch_offset", 0.0)?,
        heading: r.angle_or("vessel.heading_offset", 0.0)?,
    };
    vessel.latency = Latency {
        position: r.number_or("vessel.position_latency", 0.0)?,
        attitude: r.number_or("vessel.attitude_latency", 0.0)?,
        heading: r.number_or("vessel.heading_latency", 0.0)?,
    };
    vessel.validate()?;
    Ok(vessel)
}

fn read_draft(r: &Reader<'_>) -> Result<DraftModel> {
    let static_draft = r.number_or("vessel.draft", 0.0)?;
    let speeds = r.numbers("vessel.settlement_speeds")?;
    let settlements = r.numbers("vessel.settlement_values")?;
    if speeds.is_empty() && settlements.is_empty() {
        return DraftModel::fixed(static_draft);
    }
    if speeds.len() != settlements.len() {
        return Err(Error::Config(format!(
            "vessel.settlement_speeds has {} entries and vessel.settlement_values has {}",
            speeds.len(),
            settlements.len()
        )));
    }
    let points = speeds
        .into_iter()
        .zip(settlements)
        .map(|(speed, settlement)| DraftPoint::new(speed, settlement))
        .collect();
    DraftModel::with_table(static_draft, points)
}

fn read_budget(r: &Reader<'_>) -> Result<UncertaintyBudget> {
    let d = UncertaintyBudget::shallow_water_launch();
    let budget = UncertaintyBudget {
        roll: r.angle_or("uncertainty.roll", d.roll.degrees())?,
        pitch: r.angle_or("uncertainty.pitch", d.pitch.degrees())?,
        heading: r.angle_or("uncertainty.heading", d.heading.degrees())?,
        heave_constant: r.number_or("uncertainty.heave_constant", d.heave_constant)?,
        heave_fraction: r.number_or("uncertainty.heave_fraction", d.heave_fraction)?,
        position_horizontal: r
            .number_or("uncertainty.position_horizontal", d.position_horizontal)?,
        position_vertical: r.number_or("uncertainty.position_vertical", d.position_vertical)?,
        timing: r.number_or("uncertainty.timing", d.timing)?,
        beam_angle: r.angle_or("uncertainty.beam_angle", d.beam_angle.degrees())?,
        range_fraction: r.number_or("uncertainty.range_fraction", d.range_fraction)?,
        surface_sound_speed: r
            .number_or("uncertainty.surface_sound_speed", d.surface_sound_speed)?,
        profile_sound_speed: r
            .number_or("uncertainty.profile_sound_speed", d.profile_sound_speed)?,
        tide: r.number_or("uncertainty.tide", d.tide)?,
        separation: r.number_or("uncertainty.separation", d.separation)?,
        draft: r.number_or("uncertainty.draft", d.draft)?,
        lever_arm: r.number_or("uncertainty.lever_arm", d.lever_arm)?,
    };
    if !budget.is_valid() {
        return Err(Error::Config(
            "the uncertainty budget holds a negative or missing value".into(),
        ));
    }
    Ok(budget)
}
