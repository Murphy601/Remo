//! A reader for the subset of TOML a survey configuration needs.
//!
//! The obvious move is to take a dependency for this. I tried, and the current
//! releases of that whole tree want a language edition newer than the compiler
//! this crate is pinned to, which is a bad reason to move the pin. What is
//! actually needed here is small and stable: tables, key equals value,
//! strings, numbers, booleans and flat arrays. No inline tables, no arrays of
//! tables, no dates, no multi line strings.
//!
//! Anything outside that subset is an error with a line number rather than a
//! best effort, because a configuration that is silently half understood is
//! how a survey gets reduced against the wrong sound speed profile.

use std::collections::BTreeMap;

use crate::error::{FormatError, Result};

/// One value out of a configuration file.
#[derive(Debug, Clone, PartialEq)]
pub enum Value {
    /// A quoted string.
    String(String),
    /// Any number, kept as a float. A survey configuration has no integer
    /// large enough to lose anything this way.
    Number(f64),
    /// True or false.
    Boolean(bool),
    /// A flat array, whose members may be of mixed kinds.
    Array(Vec<Value>),
}

impl Value {
    /// The value as a string, if it is one.
    pub fn as_str(&self) -> Option<&str> {
        match self {
            Value::String(s) => Some(s),
            _ => None,
        }
    }

    /// The value as a number, if it is one.
    pub fn as_number(&self) -> Option<f64> {
        match self {
            Value::Number(n) => Some(*n),
            _ => None,
        }
    }

    /// The value as a boolean, if it is one.
    pub fn as_bool(&self) -> Option<bool> {
        match self {
            Value::Boolean(b) => Some(*b),
            _ => None,
        }
    }

    /// The value as an array, if it is one.
    pub fn as_array(&self) -> Option<&[Value]> {
        match self {
            Value::Array(a) => Some(a),
            _ => None,
        }
    }

    /// Name of the kind, for error messages.
    pub fn kind(&self) -> &'static str {
        match self {
            Value::String(_) => "a string",
            Value::Number(_) => "a number",
            Value::Boolean(_) => "a boolean",
            Value::Array(_) => "an array",
        }
    }
}

/// A parsed configuration file.
///
/// Keys are stored fully qualified, so a key `depth` under a table `[grid]` is
/// held as `grid.depth`. Flattening at parse time keeps the lookups trivial
/// and the errors readable.
#[derive(Debug, Clone, Default, PartialEq)]
pub struct Document {
    entries: BTreeMap<String, Value>,
}

impl Document {
    /// Parse a configuration file.
    pub fn parse(text: &str) -> Result<Document> {
        let mut entries = BTreeMap::new();
        let mut table = String::new();

        for (n, raw) in text.lines().enumerate() {
            let line_no = n + 1;
            let line = strip_comment(raw).trim();
            if line.is_empty() {
                continue;
            }

            if let Some(rest) = line.strip_prefix('[') {
                let name = rest
                    .strip_suffix(']')
                    .ok_or_else(|| FormatError::at_line(line_no, "unclosed table header"))?
                    .trim();
                if name.is_empty() {
                    return Err(FormatError::at_line(line_no, "empty table name").into());
                }
                table = name.to_string();
                continue;
            }

            let (key, value) = line
                .split_once('=')
                .ok_or_else(|| FormatError::at_line(line_no, "expected a key and a value"))?;
            let key = key.trim();
            if key.is_empty() {
                return Err(FormatError::at_line(line_no, "empty key").into());
            }
            let full = if table.is_empty() {
                key.to_string()
            } else {
                format!("{table}.{key}")
            };
            if entries.contains_key(&full) {
                return Err(FormatError::at_line(line_no, format!("{full} is set twice")).into());
            }
            entries.insert(full, parse_value(value.trim(), line_no)?);
        }
        Ok(Document { entries })
    }

    /// Every key in the document, in order.
    pub fn keys(&self) -> impl Iterator<Item = &String> {
        self.entries.keys()
    }

    /// The value at a fully qualified key.
    pub fn get(&self, key: &str) -> Option<&Value> {
        self.entries.get(key)
    }

    /// True when the document has a key.
    pub fn contains(&self, key: &str) -> bool {
        self.entries.contains_key(key)
    }

    /// Keys that were set but never read, which is nearly always a typo.
    pub fn unused<'a>(&'a self, read: &'a [String]) -> Vec<&'a String> {
        self.entries.keys().filter(|k| !read.contains(k)).collect()
    }
}

/// Remove a trailing comment, respecting quotes.
fn strip_comment(line: &str) -> &str {
    let mut in_string = false;
    for (i, c) in line.char_indices() {
        match c {
            '"' => in_string = !in_string,
            '#' if !in_string => return &line[..i],
            _ => {}
        }
    }
    line
}

fn parse_value(text: &str, line_no: usize) -> Result<Value> {
    if text.is_empty() {
        return Err(FormatError::at_line(line_no, "missing value").into());
    }
    if let Some(rest) = text.strip_prefix('[') {
        let inner = rest
            .strip_suffix(']')
            .ok_or_else(|| FormatError::at_line(line_no, "unclosed array"))?;
        let mut items = Vec::new();
        for part in split_array(inner) {
            let part = part.trim();
            if part.is_empty() {
                continue;
            }
            items.push(parse_value(part, line_no)?);
        }
        return Ok(Value::Array(items));
    }
    if let Some(rest) = text.strip_prefix('"') {
        let inner = rest
            .strip_suffix('"')
            .ok_or_else(|| FormatError::at_line(line_no, "unclosed string"))?;
        return Ok(Value::String(unescape(inner)));
    }
    match text {
        "true" => return Ok(Value::Boolean(true)),
        "false" => return Ok(Value::Boolean(false)),
        _ => {}
    }
    text.replace('_', "")
        .parse::<f64>()
        .map(Value::Number)
        .map_err(|_| FormatError::at_line(line_no, format!("cannot read {text} as a value")).into())
}

/// Split an array body on commas that are not inside a string.
fn split_array(inner: &str) -> Vec<&str> {
    let mut parts = Vec::new();
    let mut start = 0;
    let mut in_string = false;
    for (i, c) in inner.char_indices() {
        match c {
            '"' => in_string = !in_string,
            ',' if !in_string => {
                parts.push(&inner[start..i]);
                start = i + 1;
            }
            _ => {}
        }
    }
    parts.push(&inner[start..]);
    parts
}

/// Undo the two escapes that turn up in a path on Windows.
fn unescape(text: &str) -> String {
    text.replace("\\\\", "\\").replace("\\\"", "\"")
}
