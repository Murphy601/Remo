//! Coverage, and the holes in it.
//!
//! A specification asks for full coverage, and full coverage is not the same
//! as most cells having a sounding. What matters is where the gaps are and how
//! big they are: a scatter of single empty cells is noise in the gridding, one
//! contiguous gap thirty metres across is a hole in the survey that somebody
//! has to go back and fill. So the gaps get found, grouped, and measured.

use crate::grid::estimator::DepthRaster;
use crate::grid::geometry::GridGeometry;

/// A contiguous run of empty cells.
#[derive(Debug, Clone, PartialEq)]
pub struct Holiday {
    /// How many cells are in it.
    pub cells: usize,
    /// Area in square metres.
    pub area: f64,
    /// Lowest column it touches.
    pub min_column: usize,
    /// Highest column it touches.
    pub max_column: usize,
    /// Lowest row it touches.
    pub min_row: usize,
    /// Highest row it touches.
    pub max_row: usize,
    /// True when the gap touches the edge of the grid.
    ///
    /// An edge gap is usually the grid being bigger than the block rather than
    /// a hole in the survey, so the report separates them.
    pub on_edge: bool,
}

impl Holiday {
    /// Longest side of the bounding box, in metres.
    pub fn extent(&self, cell_size: f64) -> f64 {
        let across = (self.max_column - self.min_column + 1) as f64;
        let down = (self.max_row - self.min_row + 1) as f64;
        across.max(down) * cell_size
    }
}

/// What the coverage analysis found.
#[derive(Debug, Clone, PartialEq)]
pub struct Coverage {
    /// Cells with at least one sounding.
    pub populated: usize,
    /// Cells in the grid.
    pub total: usize,
    /// Every gap, largest first.
    pub holidays: Vec<Holiday>,
}

impl Coverage {
    /// Fraction of the grid with data in it.
    pub fn fraction(&self) -> f64 {
        if self.total == 0 {
            0.0
        } else {
            self.populated as f64 / self.total as f64
        }
    }

    /// Gaps that do not touch the edge of the grid.
    pub fn interior_holidays(&self) -> impl Iterator<Item = &Holiday> {
        self.holidays.iter().filter(|h| !h.on_edge)
    }

    /// The largest interior gap, which is the one that gets argued about.
    pub fn worst_interior(&self, cell_size: f64) -> Option<f64> {
        self.interior_holidays()
            .map(|h| h.extent(cell_size))
            .fold(None, |acc: Option<f64>, e| {
                Some(acc.map_or(e, |a| a.max(e)))
            })
    }
}

/// Find the gaps in a raster.
///
/// Four way connectivity, not eight. Two empty cells touching at a corner are
/// not a hole a vessel can sail through, and treating them as one gap makes
/// the reported extent bigger than anything real.
pub fn analyse(raster: &DepthRaster, geometry: &GridGeometry) -> Coverage {
    let columns = raster.columns;
    let rows = raster.rows;
    let total = columns * rows;
    let populated = raster.depths.iter().filter(|d| d.is_some()).count();

    let mut seen = vec![false; total];
    let mut holidays = Vec::new();
    let mut stack: Vec<usize> = Vec::new();

    for start in 0..total {
        if seen[start] || raster.depths[start].is_some() {
            continue;
        }
        let mut holiday = Holiday {
            cells: 0,
            area: 0.0,
            min_column: columns,
            max_column: 0,
            min_row: rows,
            max_row: 0,
            on_edge: false,
        };
        stack.clear();
        stack.push(start);
        seen[start] = true;

        while let Some(offset) = stack.pop() {
            let column = offset % columns;
            let row = offset / columns;
            holiday.cells += 1;
            holiday.min_column = holiday.min_column.min(column);
            holiday.max_column = holiday.max_column.max(column);
            holiday.min_row = holiday.min_row.min(row);
            holiday.max_row = holiday.max_row.max(row);
            if column == 0 || row == 0 || column + 1 == columns || row + 1 == rows {
                holiday.on_edge = true;
            }

            let push = |c: usize, r: usize, stack: &mut Vec<usize>, seen: &mut Vec<bool>| {
                let o = r * columns + c;
                if !seen[o] && raster.depths[o].is_none() {
                    seen[o] = true;
                    stack.push(o);
                }
            };
            if column > 0 {
                push(column - 1, row, &mut stack, &mut seen);
            }
            if column + 1 < columns {
                push(column + 1, row, &mut stack, &mut seen);
            }
            if row > 0 {
                push(column, row - 1, &mut stack, &mut seen);
            }
            if row + 1 < rows {
                push(column, row + 1, &mut stack, &mut seen);
            }
        }

        holiday.area = holiday.cells as f64 * geometry.cell_size * geometry.cell_size;
        holidays.push(holiday);
    }

    holidays.sort_by(|a, b| b.cells.cmp(&a.cells));
    Coverage {
        populated,
        total,
        holidays,
    }
}
