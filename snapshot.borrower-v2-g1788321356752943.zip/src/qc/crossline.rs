//! Comparing one surface against another.
//!
//! A crossline run at right angles to the main scheme is the only independent
//! check a hydrographic survey has on itself. Everything else, the patch test,
//! the bar check, the calibration certificates, tests one part of the system.
//! A crossline tests all of it at once, which is why the comparison statistic
//! is the number that ends up in the report.

use crate::grid::estimator::DepthRaster;
use crate::tpu::s44::Order;

/// The difference between two surfaces, cell by cell.
#[derive(Debug, Clone, PartialEq)]
pub struct Comparison {
    /// Differences in metres, reference minus check, for cells both cover.
    pub differences: Vec<f64>,
    /// Depth of the reference surface in those same cells.
    pub depths: Vec<f64>,
    /// Cells the reference covers and the check does not, and the other way.
    pub unmatched: usize,
}

impl Comparison {
    /// How many cells both surfaces cover.
    pub fn matched(&self) -> usize {
        self.differences.len()
    }

    /// Mean difference, which is the systematic part.
    ///
    /// A crossline that is a decimetre shallow everywhere is a draft or a tide
    /// problem. A crossline that is scattered is a noise problem. The two need
    /// different fixes and this is the number that tells them apart.
    pub fn mean(&self) -> Option<f64> {
        if self.differences.is_empty() {
            return None;
        }
        Some(self.differences.iter().sum::<f64>() / self.differences.len() as f64)
    }

    /// Standard deviation of the differences.
    pub fn standard_deviation(&self) -> Option<f64> {
        let mean = self.mean()?;
        if self.differences.len() < 2 {
            return None;
        }
        let sum: f64 = self
            .differences
            .iter()
            .map(|d| (d - mean) * (d - mean))
            .sum();
        Some((sum / (self.differences.len() - 1) as f64).sqrt())
    }

    /// The difference that a given fraction of cells are inside.
    ///
    /// Ninety five percent is the one a specification asks for. It is taken by
    /// nearest rank on the absolute differences, not by fitting anything,
    /// because the distribution of crossline differences has tails that no
    /// normal assumption survives.
    pub fn percentile(&self, fraction: f64) -> Option<f64> {
        if self.differences.is_empty() {
            return None;
        }
        let mut absolute: Vec<f64> = self.differences.iter().map(|d| d.abs()).collect();
        absolute.sort_by(f64::total_cmp);
        let rank = ((fraction.clamp(0.0, 1.0) * absolute.len() as f64).ceil() as usize)
            .clamp(1, absolute.len());
        Some(absolute[rank - 1])
    }

    /// Largest absolute difference anywhere.
    pub fn largest(&self) -> Option<f64> {
        self.differences
            .iter()
            .map(|d| d.abs())
            .fold(None, |acc: Option<f64>, d| {
                Some(acc.map_or(d, |a| a.max(d)))
            })
    }

    /// Fraction of cells whose difference is inside the allowance for an
    /// order, judged at the depth of the reference surface.
    ///
    /// The comparison of two surfaces has the uncertainty of both in it, so
    /// the allowance is widened by the square root of two before anything is
    /// compared to it.
    pub fn fraction_within_order(&self, order: Order) -> Option<f64> {
        if self.differences.is_empty() {
            return None;
        }
        let inside = self
            .differences
            .iter()
            .zip(self.depths.iter())
            .filter(|(d, depth)| d.abs() <= order.max_tvu(**depth) * std::f64::consts::SQRT_2)
            .count();
        Some(inside as f64 / self.differences.len() as f64)
    }
}

/// Compare two rasters of the same shape.
///
/// Cells one covers and the other does not are counted and otherwise ignored;
/// there is nothing to say about them and letting them into the statistics as
/// zeros would flatter the result.
pub fn compare(reference: &DepthRaster, check: &DepthRaster) -> Option<Comparison> {
    if reference.columns != check.columns || reference.rows != check.rows {
        return None;
    }
    let mut differences = Vec::new();
    let mut depths = Vec::new();
    let mut unmatched = 0;

    for (a, b) in reference.depths.iter().zip(check.depths.iter()) {
        match (a, b) {
            (Some(x), Some(y)) => {
                differences.push(x - y);
                depths.push(*x);
            }
            (Some(_), None) | (None, Some(_)) => unmatched += 1,
            (None, None) => {}
        }
    }
    Some(Comparison {
        differences,
        depths,
        unmatched,
    })
}

/// The difference expressed as a raster, for plotting where the disagreement
/// is rather than how big it is.
pub fn difference_raster(reference: &DepthRaster, check: &DepthRaster) -> Option<DepthRaster> {
    if reference.columns != check.columns || reference.rows != check.rows {
        return None;
    }
    Some(DepthRaster {
        columns: reference.columns,
        rows: reference.rows,
        depths: reference
            .depths
            .iter()
            .zip(check.depths.iter())
            .map(|(a, b)| match (a, b) {
                (Some(x), Some(y)) => Some(x - y),
                _ => None,
            })
            .collect(),
        estimator: reference.estimator,
    })
}
