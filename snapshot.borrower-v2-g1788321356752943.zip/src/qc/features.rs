//! Finding the things standing off the seabed.
//!
//! A survey to any order above the loosest has to detect features, and the
//! deliverable for a feature is not a surface: it is a position and a least
//! depth, with a count of how many soundings support it. One sounding on a
//! wreck is a fish. Six soundings in a cluster on the same wreck are a wreck.
//!
//! Everything here works on the surface rather than on the soundings, because
//! the surface has already dealt with the question of which soundings agree
//! with each other and it is a hundred times smaller.

use crate::grid::estimator::DepthRaster;
use crate::grid::geometry::{CellIndex, GridGeometry};
use crate::grid::surface::Surface;
use crate::tpu::s44::Order;

/// Something standing above the seabed around it.
#[derive(Debug, Clone, PartialEq)]
pub struct Feature {
    /// Cell holding the least depth.
    pub index: CellIndex,
    /// Least depth on the feature.
    pub least_depth: f64,
    /// Depth of the seabed around it.
    pub surrounding_depth: f64,
    /// How far it stands off the seabed.
    pub relief: f64,
    /// Cells that belong to the feature.
    pub cells: usize,
    /// Soundings behind the least depth cell.
    pub soundings: u32,
}

impl Feature {
    /// True when the relief is enough for an order to require detection.
    pub fn meets(&self, order: Order) -> bool {
        match order.feature_size(self.surrounding_depth) {
            Some(size) => self.relief >= size,
            None => false,
        }
    }

    /// Extent in metres across, from the cell count, assuming it is roughly
    /// round. A rough number for a rough purpose: deciding whether it is worth
    /// going back to run a detailed block over it.
    pub fn extent(&self, cell_size: f64) -> f64 {
        (self.cells as f64 / std::f64::consts::PI).sqrt() * 2.0 * cell_size
    }
}

/// How the search is set up.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct FeatureSearch {
    /// How far a cell has to stand above its surroundings, in metres.
    pub min_relief: f64,
    /// How many cells out the ring is that makes up the background seabed.
    pub background_radius: i64,
    /// Fewest soundings a cell needs before it can be a feature.
    ///
    /// This is the fish filter, and it is the single most useful number in
    /// here. Two is too few on any modern sonar.
    pub min_soundings: u32,
}

impl Default for FeatureSearch {
    fn default() -> Self {
        FeatureSearch {
            min_relief: 0.5,
            background_radius: 5,
            min_soundings: 4,
        }
    }
}

/// Median depth of the ring of cells at a given radius.
fn ring_median(
    raster: &DepthRaster,
    geometry: &GridGeometry,
    index: CellIndex,
    radius: i64,
) -> Option<f64> {
    let mut values = Vec::with_capacity((8 * radius) as usize);
    for dr in -radius..=radius {
        for dc in -radius..=radius {
            if dc.abs() != radius && dr.abs() != radius {
                continue;
            }
            let c = index.column + dc;
            let r = index.row + dr;
            if c < 0 || r < 0 || c as usize >= geometry.columns || r as usize >= geometry.rows {
                continue;
            }
            if let Some(v) = raster.at(c as usize, r as usize) {
                values.push(v);
            }
        }
    }
    // A clipped ring is worse than no ring. Near the edge of a grid only the
    // inward half of it exists, so on any sloping seabed the median comes from
    // the deep side and every edge cell reads as standing proud. Three
    // quarters of the ring has to be present, which means a feature within the
    // background radius of the edge is not detected and the grid wants a
    // margin around the block.
    if values.len() * 4 < (8 * radius.max(1)) as usize * 3 {
        return None;
    }
    values.sort_by(f64::total_cmp);
    Some(values[values.len() / 2])
}

/// Group touching candidates and report the shallowest cell of each group.
fn group(
    surface: &Surface,
    raster: &DepthRaster,
    candidate: &[bool],
    background: &[f64],
    geometry: &GridGeometry,
) -> Vec<Feature> {
    let columns = geometry.columns;
    let mut seen = vec![false; candidate.len()];
    let mut features = Vec::new();
    let mut stack = Vec::new();

    for start in 0..candidate.len() {
        if seen[start] || !candidate[start] {
            continue;
        }
        stack.clear();
        stack.push(start);
        seen[start] = true;

        let mut cells = 0usize;
        let mut best = start;
        let mut best_depth = f64::INFINITY;

        while let Some(offset) = stack.pop() {
            cells += 1;
            let column = offset % columns;
            let row = offset / columns;
            if let Some(depth) = raster.at(column, row) {
                if depth < best_depth {
                    best_depth = depth;
                    best = offset;
                }
            }
            for (dc, dr) in [(-1i64, 0i64), (1, 0), (0, -1), (0, 1)] {
                let c = column as i64 + dc;
                let r = row as i64 + dr;
                if c < 0 || r < 0 || c as usize >= columns || r as usize >= geometry.rows {
                    continue;
                }
                let o = r as usize * columns + c as usize;
                if !seen[o] && candidate[o] {
                    seen[o] = true;
                    stack.push(o);
                }
            }
        }

        let index = CellIndex::new((best % columns) as i64, (best / columns) as i64);
        let surrounding = background[best];
        features.push(Feature {
            index,
            least_depth: best_depth,
            surrounding_depth: surrounding,
            relief: surrounding - best_depth,
            cells,
            soundings: surface.cell(index).map(|c| c.count()).unwrap_or(0),
        });
    }

    features.sort_by(|a, b| b.relief.total_cmp(&a.relief));
    features
}

/// Find the features in a surface.
///
/// Candidates are cells standing above the median of the ring around them.
/// Neighbouring candidates are grouped, and the group reports the shallowest
/// cell in it.
pub fn find_features(
    surface: &Surface,
    raster: &DepthRaster,
    search: &FeatureSearch,
) -> Vec<Feature> {
    let geometry = surface.geometry();
    let columns = geometry.columns;
    let rows = geometry.rows;

    let mut candidate = vec![false; columns * rows];
    let mut background = vec![0.0f64; columns * rows];

    for row in 0..rows {
        for column in 0..columns {
            let Some(depth) = raster.at(column, row) else {
                continue;
            };
            let index = CellIndex::new(column as i64, row as i64);
            let Some(cell) = surface.cell(index) else {
                continue;
            };
            if cell.count() < search.min_soundings {
                continue;
            }
            let Some(around) = ring_median(raster, geometry, index, search.background_radius)
            else {
                continue;
            };
            if around - depth >= search.min_relief {
                candidate[row * columns + column] = true;
                background[row * columns + column] = around;
            }
        }
    }

    group(surface, raster, &candidate, &background, geometry)
}
