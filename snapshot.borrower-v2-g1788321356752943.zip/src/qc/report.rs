//! The survey report.
//!
//! Plain text, because it gets pasted into an email as often as it gets filed,
//! and because a report nobody can read in a terminal on a boat is a report
//! nobody reads. Everything in it is a number the crate actually measured;
//! there is no prose here that is not derived from the data.

use std::fmt::Write as _;

use crate::config::survey::SurveyConfig;
use crate::grid::estimator::Estimator;
use crate::pipeline::reduce_line::LineResult;
use crate::pipeline::survey::SurveySummary;
use crate::qc::features::Feature;
use crate::tpu::propagate::{propagate, SoundingGeometry};
use crate::tpu::s44::Order;
use crate::units::Angle;

/// Everything a report is written from.
///
/// A struct rather than six arguments, because it went from four to six in a
/// month and the next thing anybody adds will be the seventh.
#[derive(Debug, Clone, Copy)]
pub struct ReportInputs<'a> {
    /// Totals over the run.
    pub summary: &'a SurveySummary,
    /// Per line results.
    pub results: &'a [LineResult],
    /// The configuration it was run with.
    pub config: &'a SurveyConfig,
    /// Estimator the surface was rendered with.
    pub estimator: Estimator,
    /// Cell size of that surface.
    pub cell_size: f64,
    /// Features found, when the search was run.
    pub features: &'a [Feature],
}

/// Build the report for a run.
pub fn survey_report(inputs: &ReportInputs<'_>) -> String {
    let ReportInputs {
        summary,
        results,
        config,
        estimator,
        cell_size,
        features,
    } = *inputs;
    let mut out = String::new();
    let _ = writeln!(out, "survey: {}", summary.name);
    let _ = writeln!(out, "vessel: {}", config.vessel.name);
    let _ = writeln!(
        out,
        "sound speed equation: {}, cast selection: {:?}",
        config.equation.name(),
        config.profile_selection
    );
    let _ = writeln!(out, "vertical reference: {:?}", config.vertical);
    let _ = writeln!(out);

    let _ = writeln!(out, "lines reduced: {}", summary.lines);
    let _ = writeln!(
        out,
        "soundings: {} produced, {} accepted, {:.1}%",
        summary.soundings,
        summary.accepted,
        100.0 * summary.acceptance_rate()
    );
    let _ = writeln!(
        out,
        "depth range: {:.2} to {:.2} m",
        summary.min_depth, summary.max_depth
    );
    let _ = writeln!(
        out,
        "largest vertical uncertainty: {:.3} m",
        summary.max_tvu
    );

    if let (Some(order), Some(fraction)) = (config.order, summary.order_compliance) {
        let _ = writeln!(
            out,
            "order {}: {:.2}% of accepted soundings inside the envelope",
            order.name(),
            100.0 * fraction
        );
        if fraction < 0.95 {
            let _ = writeln!(
                out,
                "  this does not meet the order, look at the uncertainty budget and the outer beams"
            );
        }
    }
    let _ = writeln!(out);

    let _ = writeln!(
        out,
        "surface: {} m cells, {} populated, {:.1}% coverage, estimator {}",
        cell_size,
        summary.populated_cells,
        100.0 * summary.coverage.fraction(),
        estimator.name()
    );
    if estimator.is_shoal_biased() {
        let _ = writeln!(
            out,
            "  the estimator is shoal biased, do not compute volumes from this surface"
        );
    }
    let interior = summary.coverage.interior_holidays().count();
    let _ = writeln!(out, "gaps: {interior} inside the block");
    if let Some(worst) = summary.coverage.worst_interior(cell_size) {
        let _ = writeln!(out, "  the largest is {worst:.1} m across");
    }
    let _ = writeln!(out);

    let _ = writeln!(out, "by line:");
    for result in results {
        let _ = writeln!(
            out,
            "  {:<24} {:>7} of {:>7} kept  {:>6.2} to {:>6.2} m  cast {}",
            result.name,
            result.stats.accepted,
            result.stats.count,
            result.stats.min_depth,
            result.stats.max_depth,
            result.profile_used
        );
        for warning in &result.warnings {
            let _ = writeln!(out, "      {warning:?}");
        }
    }

    if !features.is_empty() {
        let _ = writeln!(out);
        let _ = writeln!(out, "features, deepest last:");
        for feature in features.iter().take(30) {
            let _ = writeln!(
                out,
                "  least depth {:>7.2} m on a seabed of {:>7.2} m, relief {:>5.2} m, {} cells, {} soundings",
                feature.least_depth,
                feature.surrounding_depth,
                feature.relief,
                feature.cells,
                feature.soundings
            );
            if let Some(order) = config.order {
                if !feature.meets(order) {
                    let _ = writeln!(
                        out,
                        "      below the detection size for {}, reported anyway",
                        order.name()
                    );
                }
            }
        }
        if features.len() > 30 {
            let _ = writeln!(out, "  and {} more", features.len() - 30);
        }
    }

    if summary.accepted > 0 {
        let _ = writeln!(out);
        let _ = write!(out, "{}", budget_breakdown(summary, config));
    }

    let flagged: usize = results.iter().map(|r| r.tally.total()).sum();
    if flagged > 0 {
        let _ = writeln!(out);
        let _ = writeln!(out, "flagged by rule:");
        let window: usize = results.iter().map(|r| r.tally.outside_window).sum();
        let swath: usize = results.iter().map(|r| r.tally.outside_swath).sum();
        let uncertain: usize = results.iter().map(|r| r.tally.too_uncertain).sum();
        let outliers: usize = results.iter().map(|r| r.tally.outlier).sum();
        let _ = writeln!(out, "  outside the depth window: {window}");
        let _ = writeln!(out, "  outside the swath limit:  {swath}");
        let _ = writeln!(out, "  above the tvu limit:      {uncertain}");
        let _ = writeln!(out, "  outliers:                 {outliers}");
    }

    if !config.unread_keys.is_empty() {
        let _ = writeln!(out);
        let _ = writeln!(
            out,
            "the configuration sets {} keys nothing read: {}",
            config.unread_keys.len(),
            config.unread_keys.join(", ")
        );
    }
    out
}

/// The one line verdict, for a log or a subject line.
pub fn verdict(summary: &SurveySummary, order: Option<Order>) -> String {
    let compliance = match (order, summary.order_compliance) {
        (Some(o), Some(f)) => format!(", {:.1}% inside {}", 100.0 * f, o.name()),
        _ => String::new(),
    };
    format!(
        "{}: {} soundings, {:.1}% kept, {:.1}% coverage{compliance}",
        summary.name,
        summary.soundings,
        100.0 * summary.acceptance_rate(),
        100.0 * summary.coverage.fraction()
    )
}

/// Where the uncertainty comes from, at nadir and at the edge of the swath.
///
/// The two are worth printing together because they are different problems
/// with different answers. If nadir is dominated by the tide then a better
/// sonar buys nothing; if the edge is dominated by the sound speed then the
/// answer is more casts, not a narrower swath.
///
/// The depths used are the mean depth of the survey, so the numbers describe
/// the job that was actually run rather than a nominal one.
pub fn budget_breakdown(summary: &SurveySummary, config: &SurveyConfig) -> String {
    let depth = if summary.accepted == 0 {
        return String::new();
    } else {
        (summary.min_depth + summary.max_depth) / 2.0
    };
    let swath = config.swath_limit.unwrap_or(60.0);

    let at = |angle_degrees: f64| {
        let angle = Angle::from_degrees(angle_degrees);
        propagate(
            SoundingGeometry {
                depth,
                across: depth * angle.tan(),
                launch_angle: angle,
                surface_speed: 1500.0,
                mean_speed: 1500.0,
                heave: 0.3,
                vessel_speed: 3.0,
                ellipsoidal: config.vertical == crate::config::survey::VerticalMode::Ellipsoid,
            },
            &config.budget,
        )
    };

    let mut out = String::new();
    let _ = writeln!(
        out,
        "uncertainty budget at {depth:.1} m, one sigma, largest first:"
    );
    for (label, angle) in [("nadir", 0.0), ("swath edge", swath)] {
        let propagated = at(angle);
        let _ = writeln!(
            out,
            "  {label} ({angle:.0} degrees), tvu {:.3} m at ninety five percent",
            propagated.tvu
        );
        for line in propagated.vertical_breakdown() {
            let _ = writeln!(out, "    {line}");
        }
    }
    out
}
