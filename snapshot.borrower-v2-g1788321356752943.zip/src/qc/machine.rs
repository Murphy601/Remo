//! The survey summary in a form something else can read.
//!
//! The text report is for a person. This is for whatever the office runs to
//! collect the numbers off a season of jobs, and it is JSON because everything
//! reads JSON. Writing it out by hand is about eighty lines and avoids
//! bringing a serialisation framework into a crate that otherwise has no
//! dependencies at all.
//!
//! There is no reader here on purpose. Producing JSON is a small, closed
//! problem; consuming arbitrary JSON is not, and nothing in this crate needs
//! to.

use std::fmt::Write as _;

use crate::config::survey::SurveyConfig;
use crate::pipeline::reduce_line::LineResult;
use crate::pipeline::survey::SurveySummary;
use crate::qc::features::Feature;

/// Escape a string so it can go inside JSON quotes.
///
/// Line names come off file names, and a file name on Windows is full of
/// backslashes, so this is not theoretical.
fn escape(text: &str) -> String {
    let mut out = String::with_capacity(text.len() + 2);
    for c in text.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if (c as u32) < 0x20 => {
                let _ = write!(out, "\\u{:04x}", c as u32);
            }
            c => out.push(c),
        }
    }
    out
}

/// A number, or `null` where it is not finite.
///
/// A NaN written as a bare NaN is not JSON and every reader chokes on it,
/// which is a poor way to find out that a survey had no accepted soundings.
fn number(value: f64) -> String {
    if value.is_finite() {
        format!("{value:.6}")
    } else {
        "null".to_string()
    }
}

/// The summary of a run as a JSON object.
pub fn summary_json(
    summary: &SurveySummary,
    results: &[LineResult],
    config: &SurveyConfig,
    features: &[Feature],
) -> String {
    let mut out = String::with_capacity(1024);
    out.push_str("{\n");
    let _ = writeln!(out, "  \"survey\": \"{}\",", escape(&summary.name));
    let _ = writeln!(out, "  \"vessel\": \"{}\",", escape(&config.vessel.name));
    let _ = writeln!(
        out,
        "  \"order\": {},",
        match config.order {
            Some(o) => format!("\"{}\"", o.name()),
            None => "null".into(),
        }
    );
    let _ = writeln!(out, "  \"lines\": {},", summary.lines);
    let _ = writeln!(out, "  \"soundings\": {},", summary.soundings);
    let _ = writeln!(out, "  \"accepted\": {},", summary.accepted);
    let _ = writeln!(
        out,
        "  \"acceptance_rate\": {},",
        number(summary.acceptance_rate())
    );
    let _ = writeln!(out, "  \"min_depth\": {},", number(summary.min_depth));
    let _ = writeln!(out, "  \"max_depth\": {},", number(summary.max_depth));
    let _ = writeln!(out, "  \"max_tvu\": {},", number(summary.max_tvu));
    let _ = writeln!(
        out,
        "  \"order_compliance\": {},",
        match summary.order_compliance {
            Some(f) => number(f),
            None => "null".into(),
        }
    );
    let _ = writeln!(
        out,
        "  \"coverage\": {},",
        number(summary.coverage.fraction())
    );
    let _ = writeln!(out, "  \"populated_cells\": {},", summary.populated_cells);
    let _ = writeln!(out, "  \"cell_size\": {},", number(config.cell_size));

    out.push_str("  \"lines_detail\": [\n");
    for (i, result) in results.iter().enumerate() {
        let comma = if i + 1 == results.len() { "" } else { "," };
        let _ = writeln!(
            out,
            "    {{\"name\": \"{}\", \"soundings\": {}, \"accepted\": {}, \"min_depth\": {}, \"max_depth\": {}, \"profile\": \"{}\"}}{comma}",
            escape(&result.name),
            result.stats.count,
            result.stats.accepted,
            number(result.stats.min_depth),
            number(result.stats.max_depth),
            escape(&result.profile_used)
        );
    }
    out.push_str("  ],\n");

    out.push_str("  \"features\": [\n");
    for (i, feature) in features.iter().enumerate() {
        let comma = if i + 1 == features.len() { "" } else { "," };
        let _ = writeln!(
            out,
            "    {{\"least_depth\": {}, \"surrounding_depth\": {}, \"relief\": {}, \"cells\": {}, \"soundings\": {}}}{comma}",
            number(feature.least_depth),
            number(feature.surrounding_depth),
            number(feature.relief),
            feature.cells,
            feature.soundings
        );
    }
    out.push_str("  ]\n");
    out.push_str("}\n");
    out
}
