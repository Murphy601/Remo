//! Deciding whether a survey is any good, and saying so in a form somebody
//! can sign.

pub mod coverage;
pub mod crossline;
pub mod features;
pub mod machine;
pub mod report;
pub mod rules;

pub use coverage::{analyse, Coverage, Holiday};
pub use crossline::{compare, Comparison};
pub use features::{find_features, Feature, FeatureSearch};
pub use machine::summary_json;
pub use report::{survey_report, verdict, ReportInputs};
pub use rules::{clean_ping, CleaningRules, CleaningTally, DepthWindow};
