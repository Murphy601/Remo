//! Automatic cleaning rules.
//!
//! Nothing in here decides that a sounding is wrong. Every rule sets a flag,
//! the flag says which rule set it, and the sounding stays in the file. That
//! matters more than it sounds: a cleaning pass that deletes is a cleaning
//! pass that can never be undone or argued with, and the argument usually
//! happens two months later when the client asks why there is no data over
//! the one part of the berth they care about.

use crate::ping::beam::BeamFlags;
use crate::ping::sounding::Sounding;

/// A window of depths the survey expects to see.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct DepthWindow {
    /// Shallowest depth that is believable, in metres.
    pub min_depth: f64,
    /// Deepest depth that is believable, in metres.
    pub max_depth: f64,
}

impl DepthWindow {
    /// A window that accepts anything finite.
    pub const ANY: DepthWindow = DepthWindow {
        min_depth: f64::NEG_INFINITY,
        max_depth: f64::INFINITY,
    };

    /// Build a window, ordering the ends if they arrive the wrong way round.
    pub fn new(a: f64, b: f64) -> DepthWindow {
        DepthWindow {
            min_depth: a.min(b),
            max_depth: a.max(b),
        }
    }

    /// True when a depth is inside the window.
    pub fn contains(&self, depth: f64) -> bool {
        depth.is_finite() && depth >= self.min_depth && depth <= self.max_depth
    }
}

/// Everything the automatic cleaner is allowed to do.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct CleaningRules {
    /// Depths outside this window are flagged.
    pub window: DepthWindow,
    /// Beams beyond this angle from nadir are flagged, in degrees.
    pub max_swath_angle: Option<f64>,
    /// Soundings with a vertical uncertainty above this are flagged.
    pub max_tvu: Option<f64>,
    /// Soundings more than this many metres from the local median are flagged.
    pub max_deviation: Option<f64>,
    /// How many soundings either side make up the local median.
    pub median_window: usize,
}

impl Default for CleaningRules {
    fn default() -> Self {
        CleaningRules {
            window: DepthWindow::ANY,
            max_swath_angle: None,
            max_tvu: None,
            max_deviation: None,
            median_window: 7,
        }
    }
}

/// How many soundings each rule caught.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct CleaningTally {
    /// Outside the depth window.
    pub outside_window: usize,
    /// Beyond the swath angle limit.
    pub outside_swath: usize,
    /// Above the uncertainty limit.
    pub too_uncertain: usize,
    /// Too far from the neighbours.
    pub outlier: usize,
}

impl CleaningTally {
    /// Total soundings flagged by any rule.
    ///
    /// A sounding caught by two rules is counted by both, so this can exceed
    /// the number of soundings. That is deliberate; the interesting question
    /// is how much work each rule is doing.
    pub fn total(&self) -> usize {
        self.outside_window + self.outside_swath + self.too_uncertain + self.outlier
    }
}

/// Run the rules over a set of soundings from one ping.
///
/// The median rule needs its neighbours, which is why this takes a whole ping
/// worth rather than one sounding at a time. Across a ping the seabed is
/// smooth enough for a median of seven to be meaningful and short enough that
/// a real slope does not defeat it.
pub fn clean_ping(soundings: &mut [Sounding], rules: &CleaningRules) -> CleaningTally {
    let mut tally = CleaningTally::default();

    for s in soundings.iter_mut() {
        if !s.is_accepted() {
            continue;
        }
        if !rules.window.contains(s.depth) {
            s.flags.set(BeamFlags::OUTSIDE_DEPTH_WINDOW);
            tally.outside_window += 1;
        }
        if let Some(limit) = rules.max_swath_angle {
            let angle = s.swath_ratio().atan().to_degrees().abs();
            if angle > limit {
                s.flags.set(BeamFlags::OUTSIDE_SWATH);
                tally.outside_swath += 1;
            }
        }
        if let Some(limit) = rules.max_tvu {
            if s.tvu > limit {
                s.flags.set(BeamFlags::FAILS_ORDER);
                tally.too_uncertain += 1;
            }
        }
    }

    if let Some(limit) = rules.max_deviation {
        tally.outlier += flag_outliers(soundings, limit, rules.median_window);
    }
    tally
}

/// Flag soundings that sit too far from the median of their neighbours.
///
/// The median is taken over accepted soundings only and over a window that
/// slides with the beam, so a rejected run of beams does not drag the window
/// off the seabed.
pub fn flag_outliers(soundings: &mut [Sounding], max_deviation: f64, window: usize) -> usize {
    let half = (window / 2).max(1);
    let depths: Vec<Option<f64>> = soundings
        .iter()
        .map(|s| if s.is_accepted() { Some(s.depth) } else { None })
        .collect();

    let mut flagged = 0;
    for (i, sounding) in soundings.iter_mut().enumerate() {
        if !sounding.is_accepted() {
            continue;
        }
        let lo = i.saturating_sub(half);
        let hi = (i + half + 1).min(depths.len());
        let mut around: Vec<f64> = depths[lo..hi]
            .iter()
            .enumerate()
            .filter(|(j, _)| lo + j != i)
            .filter_map(|(_, d)| *d)
            .collect();
        if around.len() < 3 {
            continue;
        }
        around.sort_by(f64::total_cmp);
        let median = around[around.len() / 2];
        if (sounding.depth - median).abs() > max_deviation {
            sounding.flags.set(BeamFlags::LOW_QUALITY);
            flagged += 1;
        }
    }
    flagged
}
