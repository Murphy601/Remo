//! The Esri ASCII grid format, for handing a surface to anything with a map
//! on it.
//!
//! Six header lines and then the values, and the one thing to get right is
//! that the rows run from north to south while every internal raster here runs
//! from south to north. Writing it out the wrong way up produces a file that
//! opens, draws, and is a mirror image of the seabed.

use std::fs::File;
use std::io::{BufRead, BufReader, BufWriter, Write};
use std::path::Path;

use crate::error::{Error, FormatError, Result};
use crate::grid::estimator::DepthRaster;
use crate::grid::geometry::GridGeometry;

/// The value written where a cell has no data.
pub const NODATA: f64 = -9999.0;

/// Write a raster as an Esri ASCII grid.
pub fn write_ascii_grid(
    path: impl AsRef<Path>,
    raster: &DepthRaster,
    geometry: &GridGeometry,
    decimals: usize,
) -> Result<()> {
    let path = path.as_ref();
    if raster.columns != geometry.columns || raster.rows != geometry.rows {
        return Err(Error::Config(
            "raster and geometry disagree about the shape of the grid".into(),
        ));
    }
    let file = File::create(path).map_err(|e| Error::io(path, e))?;
    let mut out = BufWriter::new(file);

    writeln!(out, "ncols {}", geometry.columns).map_err(|e| Error::io(path, e))?;
    writeln!(out, "nrows {}", geometry.rows).map_err(|e| Error::io(path, e))?;
    writeln!(out, "xllcorner {:.6}", geometry.origin_east).map_err(|e| Error::io(path, e))?;
    writeln!(out, "yllcorner {:.6}", geometry.origin_north).map_err(|e| Error::io(path, e))?;
    writeln!(out, "cellsize {:.6}", geometry.cell_size).map_err(|e| Error::io(path, e))?;
    writeln!(out, "NODATA_value {NODATA}").map_err(|e| Error::io(path, e))?;

    // North to south, which is the opposite of how the raster is stored.
    for row in (0..geometry.rows).rev() {
        let mut line = String::with_capacity(geometry.columns * (decimals + 6));
        for column in 0..geometry.columns {
            if column > 0 {
                line.push(' ');
            }
            match raster.at(column, row) {
                Some(v) => line.push_str(&format!("{v:.decimals$}")),
                None => line.push_str(&format!("{NODATA:.decimals$}")),
            }
        }
        writeln!(out, "{line}").map_err(|e| Error::io(path, e))?;
    }
    out.flush().map_err(|e| Error::io(path, e))?;
    Ok(())
}

/// A grid read back from an Esri ASCII file.
#[derive(Debug, Clone, PartialEq)]
pub struct AsciiGrid {
    /// Geometry taken from the header.
    pub geometry: GridGeometry,
    /// Values in the internal order, south to north, with holes as `None`.
    pub values: Vec<Option<f64>>,
}

/// Read an Esri ASCII grid.
pub fn read_ascii_grid(path: impl AsRef<Path>) -> Result<AsciiGrid> {
    let path = path.as_ref();
    let file = File::open(path).map_err(|e| Error::io(path, e))?;
    let reader = BufReader::new(file);
    let mut lines = reader.lines().enumerate();

    let mut header = std::collections::HashMap::new();
    let mut first_data: Option<String> = None;

    for (n, line) in lines.by_ref() {
        let line = line.map_err(|e| Error::io(path, e))?;
        let mut fields = line.split_whitespace();
        let Some(key) = fields.next() else { continue };
        let lower = key.to_ascii_lowercase();
        if [
            "ncols",
            "nrows",
            "xllcorner",
            "yllcorner",
            "cellsize",
            "nodata_value",
        ]
        .contains(&lower.as_str())
        {
            let value: f64 = fields
                .next()
                .and_then(|f| f.parse().ok())
                .ok_or_else(|| FormatError::at_line(n + 1, format!("bad value for {key}")))?;
            header.insert(lower, value);
        } else {
            first_data = Some(line);
            break;
        }
    }

    let get = |name: &str| -> Result<f64> {
        header
            .get(name)
            .copied()
            .ok_or_else(|| Error::Format(FormatError::new(format!("header has no {name}"))))
    };
    let columns = get("ncols")? as usize;
    let rows = get("nrows")? as usize;
    let geometry = GridGeometry::new(
        get("xllcorner")?,
        get("yllcorner")?,
        get("cellsize")?,
        columns,
        rows,
    )?;
    let nodata = header.get("nodata_value").copied().unwrap_or(NODATA);

    let mut north_to_south: Vec<Option<f64>> = Vec::with_capacity(columns * rows);
    let mut push_line = |line: &str| -> Result<()> {
        for field in line.split_whitespace() {
            let v: f64 = field
                .parse()
                .map_err(|_| FormatError::new(format!("cannot read cell value {field}")))?;
            north_to_south.push(if (v - nodata).abs() < 1.0e-6 {
                None
            } else {
                Some(v)
            });
        }
        Ok(())
    };

    if let Some(line) = first_data {
        push_line(&line)?;
    }
    for (_, line) in lines {
        let line = line.map_err(|e| Error::io(path, e))?;
        push_line(&line)?;
    }

    if north_to_south.len() != columns * rows {
        return Err(Error::Format(
            FormatError::new(format!(
                "header says {columns} by {rows} but the file holds {} values",
                north_to_south.len()
            ))
            .in_file(path),
        ));
    }

    // Flip back into south to north order.
    let mut values = vec![None; columns * rows];
    for row in 0..rows {
        let source = (rows - 1 - row) * columns;
        values[row * columns..(row + 1) * columns]
            .copy_from_slice(&north_to_south[source..source + columns]);
    }

    Ok(AsciiGrid { geometry, values })
}
