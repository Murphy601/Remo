//! Reading a tide gauge record out of a text file.
//!
//! Gauge records arrive as text from a dozen different agencies and every one
//! of them has its own idea of a timestamp. Three forms cover everything I
//! have been handed: an ISO instant, a year and day of year, and a bare count
//! of seconds since the epoch. All three are accepted, decided per line, so a
//! file that changes format half way through still reads.

use std::fs::File;
use std::io::{BufRead, BufReader, BufWriter, Write};
use std::path::Path;

use crate::error::{Error, FormatError, Result};
use crate::geodesy::Geodetic;
use crate::time::Timestamp;
use crate::vertical::tide::TideGauge;

/// Longest gap a gauge record is interpolated across, in seconds.
///
/// An hour. The tide is smooth over that, and a gauge that has been down
/// longer than an hour is a fact the report should carry rather than something
/// to paper over.
pub const DEFAULT_MAX_GAP: f64 = 3600.0;

/// Parse one of the three timestamp forms.
pub fn parse_timestamp(text: &str) -> Option<Timestamp> {
    let text = text.trim();
    if text.is_empty() {
        return None;
    }

    // A bare number is seconds since the epoch.
    if let Ok(seconds) = text.parse::<f64>() {
        return Some(Timestamp::from_unix_seconds(seconds));
    }

    let (date, time) = text.split_once(['T', ' '])?;
    let time = time.trim_end_matches('Z');
    let mut clock = time.split(':');
    let hour: u32 = clock.next()?.parse().ok()?;
    let minute: u32 = clock.next().and_then(|m| m.parse().ok()).unwrap_or(0);
    let second: f64 = clock.next().and_then(|s| s.parse().ok()).unwrap_or(0.0);

    let parts: Vec<&str> = date.split('-').collect();
    match parts.len() {
        // Year, day of year.
        2 => {
            let year: i32 = parts[0].parse().ok()?;
            let day: u32 = parts[1].parse().ok()?;
            let start = Timestamp::from_utc(year, 1, 1, hour, minute, second);
            Some(start.offset((day.saturating_sub(1) as f64) * 86_400.0))
        }
        // Year, month, day.
        3 => {
            let year: i32 = parts[0].parse().ok()?;
            let month: u32 = parts[1].parse().ok()?;
            let day: u32 = parts[2].parse().ok()?;
            Some(Timestamp::from_utc(year, month, day, hour, minute, second))
        }
        _ => None,
    }
}

/// Read a gauge record.
///
/// The header, if there is one, is a comment line beginning with `gauge` and
/// carrying the name and the position. Without it the gauge takes the file
/// name and sits at the origin, which is fine as long as nothing asks for a
/// distance to it.
pub fn read_tide_file(path: impl AsRef<Path>) -> Result<TideGauge> {
    let path = path.as_ref();
    let file = File::open(path).map_err(|e| Error::io(path, e))?;
    let reader = BufReader::new(file);

    let mut name = path
        .file_stem()
        .and_then(|s| s.to_str())
        .unwrap_or("gauge")
        .to_string();
    let mut position = Geodetic::from_degrees(0.0, 0.0, 0.0);
    let mut observations = Vec::new();

    for (n, line) in reader.lines().enumerate() {
        let line = line.map_err(|e| Error::io(path, e))?;
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }
        if let Some(rest) = trimmed.strip_prefix('#') {
            let mut fields = rest.split_whitespace();
            if fields.next() == Some("gauge") {
                if let Some(n) = fields.next() {
                    name = n.to_string();
                }
                let lat = fields.next().and_then(|f| f.parse::<f64>().ok());
                let lon = fields.next().and_then(|f| f.parse::<f64>().ok());
                if let (Some(lat), Some(lon)) = (lat, lon) {
                    position = Geodetic::from_degrees(lat, lon, 0.0);
                }
            }
            continue;
        }

        let mut fields = trimmed.split_whitespace();
        let stamp = fields.next().unwrap_or_default();
        // An ISO instant with a space in it takes two fields, a bare count
        // takes one, so try the pair first and fall back.
        let rest: Vec<&str> = fields.collect();
        let (time, level) = match (parse_timestamp(stamp), rest.first()) {
            (Some(t), Some(v)) => (t, v.parse::<f64>().ok()),
            (None, Some(second)) => {
                let joined = format!("{stamp} {second}");
                (
                    parse_timestamp(&joined).ok_or_else(|| {
                        FormatError::at_line(n + 1, format!("cannot read a time from {trimmed}"))
                    })?,
                    rest.get(1).and_then(|v| v.parse::<f64>().ok()),
                )
            }
            _ => {
                return Err(
                    FormatError::at_line(n + 1, format!("cannot read {trimmed}"))
                        .in_file(path)
                        .into(),
                )
            }
        };
        let level = level.ok_or_else(|| {
            Error::Format(
                FormatError::at_line(n + 1, "expected a water level after the time").in_file(path),
            )
        })?;
        observations.push((time, level));
    }

    TideGauge::new(name, position, observations, DEFAULT_MAX_GAP)
}

/// Write a gauge record in the form this crate reads.
pub fn write_tide_file(path: impl AsRef<Path>, gauge: &TideGauge) -> Result<usize> {
    let path = path.as_ref();
    let file = File::create(path).map_err(|e| Error::io(path, e))?;
    let mut out = BufWriter::new(file);
    writeln!(
        out,
        "# gauge {} {:.6} {:.6}",
        gauge.name,
        gauge.position.lat.degrees(),
        gauge.position.lon.degrees()
    )
    .map_err(|e| Error::io(path, e))?;

    let mut written = 0;
    for entry in gauge.observations().entries() {
        writeln!(out, "{} {:.3}", entry.time, entry.value).map_err(|e| Error::io(path, e))?;
        written += 1;
    }
    out.flush().map_err(|e| Error::io(path, e))?;
    Ok(written)
}
