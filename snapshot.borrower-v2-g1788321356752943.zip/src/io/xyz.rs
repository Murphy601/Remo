//! Soundings as plain text, which is still what half the world wants.
//!
//! The format is easting, northing, depth and then whatever else was asked
//! for, one sounding per line, space separated. It is verbose and slow and
//! every client accepts it, so it is not going anywhere.

use std::fs::File;
use std::io::{BufRead, BufReader, BufWriter, Write};
use std::path::Path;

use crate::error::{Error, FormatError, Result};
use crate::geodesy::utm::TransverseMercator;
use crate::ping::sounding::Sounding;

/// Which columns to write after the position and depth.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct XyzColumns {
    /// Write the vertical and horizontal uncertainty.
    pub uncertainty: bool,
    /// Write the ping and beam number.
    pub identity: bool,
    /// Write the time as seconds since the epoch.
    pub time: bool,
}

impl XyzColumns {
    /// Position and depth only.
    pub const PLAIN: XyzColumns = XyzColumns {
        uncertainty: false,
        identity: false,
        time: false,
    };

    /// Everything, for a working file rather than a delivery.
    pub const FULL: XyzColumns = XyzColumns {
        uncertainty: true,
        identity: true,
        time: true,
    };

    /// The header line describing these columns.
    pub fn header(&self) -> String {
        let mut names = vec!["easting", "northing", "depth"];
        if self.uncertainty {
            names.push("tvu");
            names.push("thu");
        }
        if self.identity {
            names.push("ping");
            names.push("beam");
        }
        if self.time {
            names.push("time");
        }
        format!("# {}", names.join(" "))
    }
}

/// Write accepted soundings to a text file.
///
/// Rejected soundings are left out entirely. An XYZ file is a delivery, and a
/// delivery with rejected soundings in it and no way to tell which they are is
/// worse than no delivery at all.
pub fn write_xyz(
    path: impl AsRef<Path>,
    soundings: &[Sounding],
    projection: &TransverseMercator,
    columns: XyzColumns,
) -> Result<usize> {
    let path = path.as_ref();
    let file = File::create(path).map_err(|e| Error::io(path, e))?;
    let mut out = BufWriter::new(file);
    writeln!(out, "{}", columns.header()).map_err(|e| Error::io(path, e))?;

    let mut written = 0;
    for s in soundings.iter().filter(|s| s.is_accepted()) {
        let grid = projection.forward(s.position)?;
        write!(out, "{:.3} {:.3} {:.3}", grid.east, grid.north, s.depth)
            .map_err(|e| Error::io(path, e))?;
        if columns.uncertainty {
            write!(out, " {:.3} {:.3}", s.tvu, s.thu).map_err(|e| Error::io(path, e))?;
        }
        if columns.identity {
            write!(out, " {} {}", s.ping, s.beam).map_err(|e| Error::io(path, e))?;
        }
        if columns.time {
            write!(out, " {:.4}", s.time.unix_seconds()).map_err(|e| Error::io(path, e))?;
        }
        writeln!(out).map_err(|e| Error::io(path, e))?;
        written += 1;
    }
    out.flush().map_err(|e| Error::io(path, e))?;
    Ok(written)
}

/// One row of a text file, before it becomes anything.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct XyzRow {
    /// Easting.
    pub east: f64,
    /// Northing.
    pub north: f64,
    /// Depth.
    pub depth: f64,
}

/// Read the first three columns of a text file, ignoring anything else.
///
/// Comment lines start with a hash. Blank lines are skipped. A line with fewer
/// than three numbers on it is an error rather than a skip, because a file
/// that is half readable is usually the wrong file.
pub fn read_xyz(path: impl AsRef<Path>) -> Result<Vec<XyzRow>> {
    let path = path.as_ref();
    let file = File::open(path).map_err(|e| Error::io(path, e))?;
    let reader = BufReader::new(file);
    let mut rows = Vec::new();

    for (n, line) in reader.lines().enumerate() {
        let line = line.map_err(|e| Error::io(path, e))?;
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let mut fields = trimmed.split_whitespace();
        let mut next = |what: &str| -> Result<f64> {
            fields
                .next()
                .and_then(|f| f.parse::<f64>().ok())
                .ok_or_else(|| {
                    Error::Format(
                        FormatError::at_line(n + 1, format!("expected {what}")).in_file(path),
                    )
                })
        };
        let east = next("an easting")?;
        let north = next("a northing")?;
        let depth = next("a depth")?;
        rows.push(XyzRow { east, north, depth });
    }
    Ok(rows)
}
