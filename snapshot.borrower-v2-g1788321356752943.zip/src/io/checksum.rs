//! A checksum for the binary files.
//!
//! Survey data gets copied between a boat, a hard disk that lives in a bag,
//! and an office, and it gets copied by whoever is awake. A checksum on the
//! file is cheap and it has caught two truncated transfers for me.
//!
//! This is the ordinary reflected CRC-32 with the polynomial everything else
//! uses, so a file can be checked from the command line with any standard
//! tool.

/// Reflected form of the CRC-32 polynomial.
const POLYNOMIAL: u32 = 0xEDB8_8320;

/// Running CRC-32 state.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Crc32 {
    state: u32,
}

impl Crc32 {
    /// A fresh checksum.
    pub const fn new() -> Self {
        Crc32 { state: 0xFFFF_FFFF }
    }

    /// Fold a slice of bytes in.
    pub fn update(&mut self, bytes: &[u8]) {
        for byte in bytes {
            self.state ^= *byte as u32;
            for _ in 0..8 {
                let mask = (self.state & 1).wrapping_neg();
                self.state = (self.state >> 1) ^ (POLYNOMIAL & mask);
            }
        }
    }

    /// The checksum of everything folded in so far.
    pub fn finish(&self) -> u32 {
        !self.state
    }
}

impl Default for Crc32 {
    fn default() -> Self {
        Crc32::new()
    }
}

/// Checksum of one slice.
pub fn crc32(bytes: &[u8]) -> u32 {
    let mut c = Crc32::new();
    c.update(bytes);
    c.finish()
}
