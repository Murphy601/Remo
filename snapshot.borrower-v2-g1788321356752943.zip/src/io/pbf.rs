//! A compact binary file of raw pings.
//!
//! Every sonar writes its own format and none of them are pleasant. Rather
//! than pretend to read all of them, this crate reads one format of its own,
//! and converting a manufacturer file into it is a separate job that can be
//! done once per sonar. The format is deliberately dull: a fixed header, a
//! flat sequence of pings, a checksum at the end.
//!
//! Everything is little endian. Quantities that do not need the precision are
//! stored as `f32`, which halves the file for something like a beam angle
//! where the fourth decimal of a degree is already below what the sonar
//! resolves. Travel times and timestamps stay `f64` because they have no such
//! slack.

use std::fs::File;
use std::io::{BufWriter, Write};
use std::path::Path;

use crate::error::{Error, InFile, Result};
use crate::motion::attitude::Attitude;
use crate::ping::beam::{Beam, BeamFlags, Detection};
use crate::ping::record::{Navigation, Ping};
use crate::units::Angle;

use super::checksum::crc32;

/// Four bytes at the front of every file.
pub const MAGIC: [u8; 4] = *b"PLMB";
/// Format version this build writes.
pub const VERSION: u16 = 1;
/// Bytes in the file header, magic included.
pub const HEADER_LEN: usize = 16;

/// Encode a detection kind as one byte.
fn detection_code(d: Detection) -> u8 {
    match d {
        Detection::None => 0,
        Detection::Amplitude => 1,
        Detection::Phase => 2,
        Detection::Unknown => 3,
    }
}

/// Decode a detection kind, treating anything unrecognised as unknown rather
/// than as an error. A newer writer adding a detection type should not stop an
/// older reader from getting the depths out.
pub(crate) fn detection_from_code(code: u8) -> Detection {
    match code {
        0 => Detection::None,
        1 => Detection::Amplitude,
        2 => Detection::Phase,
        _ => Detection::Unknown,
    }
}

/// Append a ping to a byte buffer.
fn encode_ping(buffer: &mut Vec<u8>, ping: &Ping) {
    buffer.extend_from_slice(&ping.time.unix_seconds().to_le_bytes());
    buffer.extend_from_slice(&ping.sequence.to_le_bytes());
    buffer.extend_from_slice(&(ping.surface_sound_speed as f32).to_le_bytes());
    buffer.extend_from_slice(&(ping.beams.len() as u16).to_le_bytes());
    buffer.push(u8::from(ping.navigation.is_some()));
    buffer.push(0); // reserved, keeps the ping header a whole number of words

    if let Some(nav) = ping.navigation {
        buffer.extend_from_slice(&nav.position.lat.degrees().to_le_bytes());
        buffer.extend_from_slice(&nav.position.lon.degrees().to_le_bytes());
        buffer.extend_from_slice(&nav.position.height.to_le_bytes());
        buffer.extend_from_slice(&(nav.attitude.roll.degrees() as f32).to_le_bytes());
        buffer.extend_from_slice(&(nav.attitude.pitch.degrees() as f32).to_le_bytes());
        buffer.extend_from_slice(&(nav.attitude.heading.degrees() as f32).to_le_bytes());
        buffer.extend_from_slice(&(nav.heave as f32).to_le_bytes());
        buffer.extend_from_slice(&(nav.speed as f32).to_le_bytes());
        match nav.transducer_height {
            Some(h) => {
                buffer.push(1);
                buffer.extend_from_slice(&h.to_le_bytes());
            }
            None => {
                buffer.push(0);
                buffer.extend_from_slice(&0f64.to_le_bytes());
            }
        }
    }

    for beam in &ping.beams {
        buffer.extend_from_slice(&beam.number.to_le_bytes());
        buffer.extend_from_slice(&beam.two_way_time.to_le_bytes());
        buffer.extend_from_slice(&(beam.pointing_angle.degrees() as f32).to_le_bytes());
        buffer.extend_from_slice(&(beam.steering_angle.degrees() as f32).to_le_bytes());
        buffer.extend_from_slice(&beam.quality.to_le_bytes());
        buffer.push(detection_code(beam.detection));
        buffer.extend_from_slice(&beam.flags.bits().to_le_bytes());
    }
}

/// Write a set of pings to a file, returning the checksum written.
pub fn write_pings(path: impl AsRef<Path>, pings: &[Ping]) -> Result<u32> {
    let path = path.as_ref();
    let mut body = Vec::with_capacity(pings.len() * 256);
    for ping in pings {
        encode_ping(&mut body, ping);
    }

    let mut header = Vec::with_capacity(HEADER_LEN);
    header.extend_from_slice(&MAGIC);
    header.extend_from_slice(&VERSION.to_le_bytes());
    header.extend_from_slice(&0u16.to_le_bytes());
    header.extend_from_slice(&(pings.len() as u32).to_le_bytes());
    header.extend_from_slice(&(body.len() as u32).to_le_bytes());

    let checksum = crc32(&body);
    let file = File::create(path).map_err(|e| Error::io(path, e))?;
    let mut out = BufWriter::new(file);
    out.write_all(&header).map_err(|e| Error::io(path, e))?;
    out.write_all(&body).map_err(|e| Error::io(path, e))?;
    out.write_all(&checksum.to_le_bytes())
        .map_err(|e| Error::io(path, e))?;
    out.flush().map_err(|e| Error::io(path, e))?;
    Ok(checksum)
}

/// Rebuild a beam from its stored fields.
pub(crate) fn beam_from_parts(
    number: u16,
    two_way_time: f64,
    pointing: f32,
    steering: f32,
    quality: f32,
    detection: u8,
    flags: u16,
) -> Beam {
    Beam {
        number,
        two_way_time,
        pointing_angle: Angle::from_degrees(pointing as f64),
        steering_angle: Angle::from_degrees(steering as f64),
        quality,
        detection: detection_from_code(detection),
        flags: BeamFlags::from_bits(flags),
    }
}

/// Rebuild navigation from its stored fields.
#[allow(clippy::too_many_arguments)]
pub(crate) fn navigation_from_parts(
    lat: f64,
    lon: f64,
    height: f64,
    roll: f32,
    pitch: f32,
    heading: f32,
    heave: f32,
    speed: f32,
    transducer_height: Option<f64>,
) -> Navigation {
    Navigation {
        position: crate::geodesy::Geodetic::from_degrees(lat, lon, height),
        attitude: Attitude::from_degrees(roll as f64, pitch as f64, heading as f64),
        heave: heave as f64,
        speed: speed as f64,
        transducer_height,
    }
}

/// A bounds checked walk over the bytes of a file.
///
/// Every read goes through here, so a truncated file produces one clear error
/// naming the offset instead of a panic somewhere in the middle of a ping.
struct Cursor<'a> {
    bytes: &'a [u8],
    at: usize,
}

impl<'a> Cursor<'a> {
    fn new(bytes: &'a [u8]) -> Self {
        Cursor { bytes, at: 0 }
    }

    fn take(&mut self, n: usize) -> Result<&'a [u8]> {
        if self.at + n > self.bytes.len() {
            return Err(Error::Format(crate::error::FormatError::new(format!(
                "file ends at byte {} but a {n} byte field starts at {}",
                self.bytes.len(),
                self.at
            ))));
        }
        let out = &self.bytes[self.at..self.at + n];
        self.at += n;
        Ok(out)
    }

    fn u8(&mut self) -> Result<u8> {
        Ok(self.take(1)?[0])
    }

    fn u16(&mut self) -> Result<u16> {
        let b = self.take(2)?;
        Ok(u16::from_le_bytes([b[0], b[1]]))
    }

    fn u32(&mut self) -> Result<u32> {
        let b = self.take(4)?;
        Ok(u32::from_le_bytes([b[0], b[1], b[2], b[3]]))
    }

    fn u64(&mut self) -> Result<u64> {
        let b = self.take(8)?;
        Ok(u64::from_le_bytes([
            b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7],
        ]))
    }

    fn f32(&mut self) -> Result<f32> {
        Ok(f32::from_bits(self.u32()?))
    }

    fn f64(&mut self) -> Result<f64> {
        Ok(f64::from_bits(self.u64()?))
    }
}

/// What the header of a ping file says about itself.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct FileHeader {
    /// Format version the file was written with.
    pub version: u16,
    /// Number of pings the header claims.
    pub ping_count: u32,
    /// Length of the body in bytes.
    pub body_len: u32,
}

/// Read the header without reading the pings.
///
/// Useful for the command line, where listing what is in a directory should
/// not mean parsing a gigabyte of beams.
pub fn read_header(path: impl AsRef<Path>) -> Result<FileHeader> {
    let path = path.as_ref();
    let bytes = std::fs::read(path).map_err(|e| Error::io(path, e))?;
    parse_header(&bytes).in_file(path)
}

fn parse_header(bytes: &[u8]) -> Result<FileHeader> {
    let mut cursor = Cursor::new(bytes);
    let magic = cursor.take(4)?;
    if magic != MAGIC {
        return Err(Error::Format(crate::error::FormatError::new(
            "not a plumbline ping file, the magic does not match",
        )));
    }
    let version = cursor.u16()?;
    let _reserved = cursor.u16()?;
    let ping_count = cursor.u32()?;
    let body_len = cursor.u32()?;
    if version > VERSION {
        return Err(Error::Format(crate::error::FormatError::new(format!(
            "file is version {version}, this build reads up to {VERSION}"
        ))));
    }
    Ok(FileHeader {
        version,
        ping_count,
        body_len,
    })
}

/// Read every ping in a file.
///
/// The checksum is verified before anything is decoded. A file that fails it
/// is refused outright rather than half read, because the interesting failure
/// is a truncated copy and half of those decode perfectly up to the cut.
pub fn read_pings(path: impl AsRef<Path>) -> Result<Vec<Ping>> {
    let path = path.as_ref();
    let bytes = std::fs::read(path).map_err(|e| Error::io(path, e))?;
    decode_pings(&bytes).in_file(path)
}

/// Decode a whole file that is already in memory.
pub fn decode_pings(bytes: &[u8]) -> Result<Vec<Ping>> {
    let header = parse_header(bytes)?;
    let body_end = HEADER_LEN + header.body_len as usize;
    if bytes.len() < body_end + 4 {
        return Err(Error::Format(crate::error::FormatError::new(format!(
            "header promises {} bytes of pings and a checksum, file holds {}",
            header.body_len,
            bytes.len().saturating_sub(HEADER_LEN)
        ))));
    }
    let body = &bytes[HEADER_LEN..body_end];
    let stored = u32::from_le_bytes([
        bytes[body_end],
        bytes[body_end + 1],
        bytes[body_end + 2],
        bytes[body_end + 3],
    ]);
    let actual = crc32(body);
    if stored != actual {
        return Err(Error::Format(crate::error::FormatError::new(format!(
            "checksum is {actual:08x}, the file says {stored:08x}"
        ))));
    }

    let mut cursor = Cursor::new(body);
    let mut pings = Vec::with_capacity(header.ping_count as usize);
    for _ in 0..header.ping_count {
        pings.push(decode_ping(&mut cursor)?);
    }
    Ok(pings)
}

fn decode_ping(cursor: &mut Cursor<'_>) -> Result<Ping> {
    let time = crate::time::Timestamp::from_unix_seconds(cursor.f64()?);
    let sequence = cursor.u64()?;
    let surface_sound_speed = cursor.f32()? as f64;
    let beam_count = cursor.u16()?;
    let has_nav = cursor.u8()? != 0;
    let _reserved = cursor.u8()?;

    let navigation = if has_nav {
        let lat = cursor.f64()?;
        let lon = cursor.f64()?;
        let height = cursor.f64()?;
        let roll = cursor.f32()?;
        let pitch = cursor.f32()?;
        let heading = cursor.f32()?;
        let heave = cursor.f32()?;
        let speed = cursor.f32()?;
        let has_height = cursor.u8()? != 0;
        let transducer_height = cursor.f64()?;
        Some(navigation_from_parts(
            lat,
            lon,
            height,
            roll,
            pitch,
            heading,
            heave,
            speed,
            has_height.then_some(transducer_height),
        ))
    } else {
        None
    };

    let mut beams = Vec::with_capacity(beam_count as usize);
    for _ in 0..beam_count {
        let number = cursor.u16()?;
        let two_way_time = cursor.f64()?;
        let pointing = cursor.f32()?;
        let steering = cursor.f32()?;
        let quality = cursor.f32()?;
        let detection = cursor.u8()?;
        let flags = cursor.u16()?;
        beams.push(beam_from_parts(
            number,
            two_way_time,
            pointing,
            steering,
            quality,
            detection,
            flags,
        ));
    }

    let mut ping = Ping::new(time, sequence, surface_sound_speed, beams);
    ping.navigation = navigation;
    Ok(ping)
}
