//! Bending an acoustic ray through the water column.

pub mod layer;
pub mod table;
pub mod tracer;

pub use layer::{advance_by_time, cross_layer, Step};
pub use table::{Bend, RayTable};
pub use tracer::{RayEnd, Tracer};
