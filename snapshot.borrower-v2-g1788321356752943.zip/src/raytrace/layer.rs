//! One layer of the water column, crossed by one ray.
//!
//! Inside a layer the sound speed is linear in depth, so the ray is a circular
//! arc and every quantity has a closed form. Writing them out here, once, is
//! what keeps the tracer itself readable.
//!
//! Angles are measured from the vertical, so a nadir beam is at zero and a
//! grazing one approaches ninety degrees. The Snell parameter is
//! `sin(angle) / speed` and it is constant along the whole ray, which is the
//! only invariant the tracer relies on.

/// The result of taking a ray through part of a layer.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Step {
    /// Depth gained, positive down.
    pub depth: f64,
    /// Horizontal distance covered, positive away from the transducer.
    pub across: f64,
    /// One way travel time in seconds.
    pub time: f64,
    /// Sound speed at the end of the step.
    pub speed: f64,
}

impl Step {
    /// A step that goes nowhere, used as the identity when accumulating.
    pub const NONE: Step = Step {
        depth: 0.0,
        across: 0.0,
        time: 0.0,
        speed: 0.0,
    };

    /// Add another step onto this one.
    pub fn then(self, next: Step) -> Step {
        Step {
            depth: self.depth + next.depth,
            across: self.across + next.across,
            time: self.time + next.time,
            speed: next.speed,
        }
    }
}

/// Cosine of the ray angle at a sound speed, given the Snell parameter.
///
/// Returns `None` when the ray has turned, which is when the product of the
/// parameter and the speed has passed one and the angle has no real cosine.
#[inline]
pub fn cos_angle(p: f64, speed: f64) -> Option<f64> {
    let s = p * speed;
    let c2 = 1.0 - s * s;
    if c2 <= 0.0 {
        None
    } else {
        Some(c2.sqrt())
    }
}

/// Take a ray all the way across a layer of constant gradient.
///
/// `c0` and `c1` are the speeds at the top and bottom of the layer, `dz` its
/// thickness, and `p` the Snell parameter. Returns `None` if the ray turns
/// before reaching the bottom, in which case the caller has to fall back to
/// [`turning_depth`].
pub fn cross_layer(c0: f64, c1: f64, dz: f64, p: f64) -> Option<Step> {
    let cos0 = cos_angle(p, c0)?;
    let cos1 = cos_angle(p, c1)?;

    if dz.abs() < 1.0e-12 {
        return Some(Step {
            depth: 0.0,
            across: 0.0,
            time: 0.0,
            speed: c1,
        });
    }

    let g = (c1 - c0) / dz;
    if g.abs() < 1.0e-12 {
        // Isovelocity: a straight line, and the arc formulae divide by the
        // gradient, so this is not an optimisation but a necessity.
        let along = dz / cos0;
        return Some(Step {
            depth: dz,
            across: along * (p * c0),
            time: along / c0,
            speed: c1,
        });
    }

    // Radius of curvature is 1/(p*g); the horizontal run of the arc is the
    // difference of the cosines over that curvature.
    let across = if p.abs() < 1.0e-15 {
        0.0
    } else {
        (cos0 - cos1) / (p * g)
    };
    let time = (1.0 / g) * ((c1 * (1.0 + cos0)) / (c0 * (1.0 + cos1))).ln();

    Some(Step {
        depth: dz,
        across,
        time,
        speed: c1,
    })
}

/// Depth below the top of a layer at which a ray turns horizontal.
///
/// Only meaningful when the gradient is negative enough for the ray to turn
/// inside the layer. Returns `None` when the ray gets through.
pub fn turning_depth(c0: f64, c1: f64, dz: f64, p: f64) -> Option<f64> {
    if p.abs() < 1.0e-15 {
        return None;
    }
    let turning_speed = 1.0 / p;
    if turning_speed >= c0.max(c1) || turning_speed <= c0.min(c1) {
        return None;
    }
    let g = (c1 - c0) / dz;
    if g.abs() < 1.0e-12 {
        return None;
    }
    Some((turning_speed - c0) / g)
}

/// Advance a ray through part of a layer by a given travel time.
///
/// This is the last step of a trace, where the remaining travel time runs out
/// part way down a layer. Inverting the travel time expression for the speed
/// at the end of the step gives a closed form, so there is no iteration here.
pub fn advance_by_time(c0: f64, gradient: f64, p: f64, dt: f64) -> Option<Step> {
    let cos0 = cos_angle(p, c0)?;

    if gradient.abs() < 1.0e-12 {
        let along = dt * c0;
        return Some(Step {
            depth: along * cos0,
            across: along * (p * c0),
            time: dt,
            speed: c0,
        });
    }

    // From t = ln(c1 (1 + cos0) / (c0 (1 + cos1))) / g, with cos1 written in
    // terms of c1 through the Snell parameter, the speed at the end of the
    // step comes out as a quadratic with one physical root.
    let b = (gradient * dt).exp() * c0 / (1.0 + cos0);
    let c1 = 2.0 * b / (1.0 + b * b * p * p);
    let cos1 = cos_angle(p, c1)?;

    let dz = (c1 - c0) / gradient;
    let across = if p.abs() < 1.0e-15 {
        0.0
    } else {
        (cos0 - cos1) / (p * gradient)
    };

    Some(Step {
        depth: dz,
        across,
        time: dt,
        speed: c1,
    })
}
