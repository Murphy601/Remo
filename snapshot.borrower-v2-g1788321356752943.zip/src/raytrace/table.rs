//! A precomputed table of traced rays.
//!
//! Tracing every beam of every ping through every layer of a cast is the most
//! expensive thing the pipeline does, and it is almost all repeated work: a
//! ping has a few hundred beams whose launch angles barely move from ping to
//! ping, and the profile changes once an hour. A table over launch angle and
//! travel time, filled once per profile and interpolated afterwards, turns
//! that into two multiplications per beam.
//!
//! The interpolation is bilinear, which is not exact, so the table carries the
//! spacing it was built at and the caller can decide whether that is close
//! enough. At a quarter of a degree and five milliseconds the departure from a
//! full trace is under a centimetre in three hundred metres of water.

use crate::error::{Error, Result};
use crate::svp::profile::SoundSpeedProfile;
use crate::units::Angle;

use super::tracer::Tracer;

/// A depth and across track distance, the pair a trace produces.
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub struct Bend {
    /// Depth below the transducer in metres.
    pub depth: f64,
    /// Across track distance in metres, signed.
    pub across: f64,
}

/// A table of traced rays over launch angle and one way travel time.
#[derive(Debug, Clone)]
pub struct RayTable {
    angle_step: Angle,
    time_step: f64,
    angle_count: usize,
    time_count: usize,
    max_angle: Angle,
    transducer_depth: f64,
    entries: Vec<Bend>,
    turned: Vec<bool>,
}

impl RayTable {
    /// Build a table covering launch angles out to `max_angle` and travel
    /// times out to `max_time`.
    ///
    /// Only one side is tabulated. The profile does not know which way the
    /// vessel is leaning, so a ray at minus forty degrees is the mirror of one
    /// at plus forty and storing both would double the table for nothing.
    pub fn build(
        profile: &SoundSpeedProfile,
        transducer_depth: f64,
        max_angle: Angle,
        max_time: f64,
        angle_step: Angle,
        time_step: f64,
    ) -> Result<Self> {
        if angle_step.radians() <= 0.0 || time_step <= 0.0 {
            return Err(Error::Config(
                "ray table needs a positive angle and time step".into(),
            ));
        }
        if max_angle.degrees() <= 0.0 || max_angle.degrees() >= 90.0 {
            return Err(Error::domain(
                "table max angle",
                max_angle.degrees(),
                "between 0 and 90 degrees",
            ));
        }
        let angle_count = (max_angle.radians() / angle_step.radians()).ceil() as usize + 1;
        let time_count = (max_time / time_step).ceil() as usize + 1;

        let tracer = Tracer::new(profile, transducer_depth)?;
        let mut entries = Vec::with_capacity(angle_count * time_count);
        let mut turned = Vec::with_capacity(angle_count * time_count);

        for ia in 0..angle_count {
            let angle = angle_step * ia as f64;
            for it in 0..time_count {
                let t = time_step * it as f64;
                let end = tracer.trace(angle, t)?;
                entries.push(Bend {
                    depth: end.depth - transducer_depth,
                    across: end.across,
                });
                turned.push(end.turned);
            }
        }

        Ok(RayTable {
            transducer_depth,
            angle_step,
            time_step,
            angle_count,
            time_count,
            max_angle,
            entries,
            turned,
        })
    }

    /// Transducer depth the table was traced from.
    pub fn transducer_depth(&self) -> f64 {
        self.transducer_depth
    }

    /// Widest launch angle the table covers.
    pub fn max_angle(&self) -> Angle {
        self.max_angle
    }

    /// Longest travel time the table covers.
    pub fn max_time(&self) -> f64 {
        self.time_step * (self.time_count - 1) as f64
    }

    /// Number of traced rays held.
    pub fn len(&self) -> usize {
        self.entries.len()
    }

    /// True when the table holds nothing, which a built table never does.
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    #[inline]
    fn at(&self, ia: usize, it: usize) -> Bend {
        self.entries[ia * self.time_count + it]
    }

    #[inline]
    fn turned_at(&self, ia: usize, it: usize) -> bool {
        self.turned[ia * self.time_count + it]
    }

    /// Look a ray up, interpolating between the four surrounding entries.
    ///
    /// Returns `None` outside the table, and for any cell whose corners
    /// include a turned ray, because interpolating across a turn produces a
    /// depth that looks reasonable and is not.
    pub fn lookup(&self, launch: Angle, one_way_time: f64) -> Option<Bend> {
        let sign = if launch.radians() < 0.0 { -1.0 } else { 1.0 };
        let magnitude = launch.radians().abs();
        if magnitude > self.max_angle.radians() || one_way_time < 0.0 {
            return None;
        }
        if one_way_time > self.max_time() {
            return None;
        }

        let fa = magnitude / self.angle_step.radians();
        let ft = one_way_time / self.time_step;
        let ia = (fa.floor() as usize).min(self.angle_count - 2);
        let it = (ft.floor() as usize).min(self.time_count - 2);
        let ua = fa - ia as f64;
        let ut = ft - it as f64;

        if self.turned_at(ia, it)
            || self.turned_at(ia + 1, it)
            || self.turned_at(ia, it + 1)
            || self.turned_at(ia + 1, it + 1)
        {
            return None;
        }

        let c00 = self.at(ia, it);
        let c10 = self.at(ia + 1, it);
        let c01 = self.at(ia, it + 1);
        let c11 = self.at(ia + 1, it + 1);

        let depth = (1.0 - ua) * ((1.0 - ut) * c00.depth + ut * c01.depth)
            + ua * ((1.0 - ut) * c10.depth + ut * c11.depth);
        let across = (1.0 - ua) * ((1.0 - ut) * c00.across + ut * c01.across)
            + ua * ((1.0 - ut) * c10.across + ut * c11.across);

        Some(Bend {
            depth,
            across: across * sign,
        })
    }
}
