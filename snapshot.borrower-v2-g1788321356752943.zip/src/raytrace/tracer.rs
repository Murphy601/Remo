//! Walking a ray down through a profile until its travel time runs out.

use crate::error::{Error, Result};
use crate::svp::profile::SoundSpeedProfile;
use crate::units::Angle;

use super::layer::{advance_by_time, cos_angle, cross_layer, turning_depth, Step};

/// Where a ray ended up.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct RayEnd {
    /// Depth below the surface in metres, positive down.
    pub depth: f64,
    /// Horizontal distance from the launch point, signed the same way as the
    /// launch angle, so port is negative.
    pub across: f64,
    /// One way travel time actually used, in seconds.
    pub time: f64,
    /// Angle from the vertical at the end of the ray.
    pub angle: Angle,
    /// True when the ray turned horizontal before the time ran out.
    ///
    /// A turned ray has no usable depth. The trace stops at the turning point
    /// and the caller is expected to reject the beam.
    pub turned: bool,
    /// How many layer boundaries the ray crossed, for diagnostics.
    pub layers: usize,
}

/// A ray tracer bound to one profile and one transducer depth.
#[derive(Debug, Clone)]
pub struct Tracer<'a> {
    profile: &'a SoundSpeedProfile,
    transducer_depth: f64,
    launch_speed: f64,
}

impl<'a> Tracer<'a> {
    /// Bind a tracer to a profile.
    ///
    /// The transducer depth is where the ray starts, not the waterline. The
    /// sound speed there is taken from the profile rather than from the
    /// surface sound speed sensor; the two disagree, and reconciling them is
    /// the job of the caller, not of the tracer.
    pub fn new(profile: &'a SoundSpeedProfile, transducer_depth: f64) -> Result<Self> {
        if transducer_depth < 0.0 || !transducer_depth.is_finite() {
            return Err(Error::domain(
                "transducer depth",
                transducer_depth,
                "finite and at or below the waterline",
            ));
        }
        let launch_speed = profile.speed_at(transducer_depth);
        Ok(Tracer {
            profile,
            transducer_depth,
            launch_speed,
        })
    }

    /// Sound speed at the transducer, as the profile sees it.
    pub fn launch_speed(&self) -> f64 {
        self.launch_speed
    }

    /// Trace a ray for a one way travel time.
    ///
    /// The launch angle is from the vertical and carries the sign of the side
    /// of the vessel: negative to port, positive to starboard.
    pub fn trace(&self, launch_angle: Angle, one_way_time: f64) -> Result<RayEnd> {
        if !one_way_time.is_finite() || one_way_time < 0.0 {
            return Err(Error::domain(
                "one way travel time",
                one_way_time,
                "finite and positive",
            ));
        }
        let launch = launch_angle.wrapped_signed();
        if launch.degrees().abs() >= 90.0 {
            return Err(Error::domain(
                "launch angle",
                launch.degrees(),
                "less than 90 degrees from the vertical",
            ));
        }

        let p = launch.sin() / self.launch_speed;
        let mut state = Step {
            depth: self.transducer_depth,
            across: 0.0,
            time: 0.0,
            speed: self.launch_speed,
        };
        let mut layers = 0usize;

        let samples = self.profile.samples();
        let mut index = self.profile.layer_index(self.transducer_depth).unwrap_or(0);

        while state.time < one_way_time {
            // Past the bottom of the cast the profile is flat, so the rest of
            // the ray is a straight line and can be taken in one go.
            if index + 1 >= samples.len() {
                let remaining = one_way_time - state.time;
                let tail = advance_by_time(state.speed, 0.0, p, remaining)
                    .ok_or_else(|| Error::Config("ray turned below the cast".into()))?;
                state.depth += tail.depth;
                state.across += tail.across;
                state.time = one_way_time;
                break;
            }

            let top = state.depth;
            let bottom = samples[index + 1].depth;
            let dz = bottom - top;
            if dz <= 0.0 {
                index += 1;
                continue;
            }
            let c0 = state.speed;
            let gradient = self.profile.gradient(index);
            let c1 = c0 + gradient * dz;

            match cross_layer(c0, c1, dz, p) {
                Some(step) if state.time + step.time <= one_way_time => {
                    state.depth += step.depth;
                    state.across += step.across;
                    state.time += step.time;
                    state.speed = step.speed;
                    index += 1;
                    layers += 1;
                }
                Some(_) => {
                    let remaining = one_way_time - state.time;
                    let step = advance_by_time(c0, gradient, p, remaining)
                        .ok_or_else(|| Error::Config("ray turned inside the last layer".into()))?;
                    state.depth += step.depth;
                    state.across += step.across;
                    state.time = one_way_time;
                    state.speed = step.speed;
                    break;
                }
                None => {
                    // The ray turns somewhere inside this layer. It only
                    // matters if the travel time reaches that far: an outer
                    // beam in a strong gradient often runs out of time well
                    // above the turning point, and treating that as a turn
                    // throws away a perfectly good sounding.
                    let turn = turning_depth(c0, c1, dz, p).unwrap_or(0.0);
                    let to_turn = if turn > 0.0 {
                        cross_layer(c0, c0 + gradient * turn, turn, p)
                    } else {
                        None
                    };
                    let reaches_turn = to_turn
                        .map(|s| state.time + s.time <= one_way_time)
                        .unwrap_or(true);

                    if !reaches_turn {
                        let remaining = one_way_time - state.time;
                        let step =
                            advance_by_time(c0, gradient, p, remaining).ok_or_else(|| {
                                Error::Config("ray turned inside the last layer".into())
                            })?;
                        state.depth += step.depth;
                        state.across += step.across;
                        state.time = one_way_time;
                        state.speed = step.speed;
                        break;
                    }

                    if let Some(step) = to_turn {
                        state.depth += step.depth;
                        state.across += step.across;
                        state.time += step.time;
                        state.speed = step.speed;
                    }
                    return Ok(RayEnd {
                        depth: state.depth,
                        across: state.across,
                        time: state.time,
                        angle: Angle::from_degrees(90.0 * launch.radians().signum()),
                        turned: true,
                        layers,
                    });
                }
            }
        }

        let cos_end = cos_angle(p, state.speed).unwrap_or(0.0);
        let sin_end = (p * state.speed).clamp(-1.0, 1.0);
        Ok(RayEnd {
            depth: state.depth,
            across: state.across,
            time: state.time,
            angle: Angle::from_radians(sin_end.atan2(cos_end)),
            turned: false,
            layers,
        })
    }
}
