//! Working out the mounting angles and the latency from a patch test.

pub mod patch;
pub mod search;

pub use patch::{Parameter, PatchTest};
pub use search::{golden_section, sweep, Minimum};
