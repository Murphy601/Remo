//! The patch test: solving for the mounting angles and the timing offset.
//!
//! The method is the same for all four parameters and it is the one every
//! hydrographer learns: run two lines whose geometry makes the parameter
//! visible, reduce them both with a trial value, and see how well the two
//! surfaces agree. What differs between parameters is which pair of lines
//! makes them visible, which is a decision for whoever ran the trial and is
//! recorded here only as a note on each variant.

use crate::config::survey::SurveyConfig;
use crate::error::{Error, Result};
use crate::geodesy::Ellipsoid;
use crate::grid::estimator::{render, Estimator};
use crate::grid::surface::Surface;
use crate::motion::attitude::Attitude;
use crate::motion::series::{Entry, TimeSeries};
use crate::ping::line::Line;
use crate::pipeline::reduce_line::Pipeline;
use crate::pipeline::survey::build_surface;
use crate::qc::crossline::compare;
use crate::svp::library::ProfileLibrary;
use crate::units::Angle;
use crate::vertical::reference::VerticalReference;

use super::search::{golden_section, sweep, Minimum};

/// Which mounting parameter is being solved for.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Parameter {
    /// Roll offset. Two reciprocal lines over flat seabed, wide swath.
    Roll,
    /// Pitch offset. Two reciprocal lines over a slope or a feature.
    Pitch,
    /// Heading offset. Two parallel lines run the same way, offset sideways,
    /// with a feature in the outer swath of both.
    Heading,
    /// Positioning latency. The same line run twice at different speeds.
    Latency,
}

impl Parameter {
    /// Short name for the report.
    pub fn name(&self) -> &'static str {
        match self {
            Parameter::Roll => "roll offset",
            Parameter::Pitch => "pitch offset",
            Parameter::Heading => "heading offset",
            Parameter::Latency => "positioning latency",
        }
    }

    /// The unit the answer comes back in.
    pub fn unit(&self) -> &'static str {
        match self {
            Parameter::Latency => "s",
            _ => "deg",
        }
    }

    /// A sensible search range for a system that is roughly right already.
    pub fn default_range(&self) -> (f64, f64) {
        match self {
            Parameter::Roll => (-3.0, 3.0),
            Parameter::Pitch => (-5.0, 5.0),
            Parameter::Heading => (-5.0, 5.0),
            Parameter::Latency => (-1.0, 1.0),
        }
    }
}

/// Everything a patch test needs to reprocess a pair of lines.
#[derive(Debug, Clone, Copy)]
pub struct PatchTest<'a> {
    /// The configuration as it stands, before the trial value is applied.
    pub config: &'a SurveyConfig,
    /// Casts.
    pub profiles: &'a ProfileLibrary,
    /// Vertical reference.
    pub vertical: &'a VerticalReference,
    /// Ellipsoid.
    pub ellipsoid: Ellipsoid,
    /// Cell size the two surfaces are compared on.
    ///
    /// Coarser than the survey grid on purpose. The comparison wants the
    /// systematic disagreement between two swaths, and a cell holding only one
    /// sounding from each line measures noise instead.
    pub cell_size: f64,
}

impl PatchTest<'_> {
    /// The configuration with a trial value applied.
    fn trial_config(&self, parameter: Parameter, value: f64) -> SurveyConfig {
        let mut config = self.config.clone();
        match parameter {
            Parameter::Roll => config.vessel.mount.roll = Angle::from_degrees(value),
            Parameter::Pitch => config.vessel.mount.pitch = Angle::from_degrees(value),
            Parameter::Heading => config.vessel.mount.heading = Angle::from_degrees(value),
            Parameter::Latency => config.vessel.latency.position = value,
        }
        config.cell_size = self.cell_size;
        config
    }

    /// How badly two lines disagree with a trial value applied.
    ///
    /// The objective is the root mean square difference over the cells both
    /// lines cover. Cells only one line reaches say nothing about a mounting
    /// angle and are left out.
    pub fn disagreement(
        &self,
        parameter: Parameter,
        value: f64,
        first: &Line,
        second: &Line,
    ) -> Result<f64> {
        let config = self.trial_config(parameter, value);
        let (first, second) = match parameter {
            Parameter::Latency => (
                shift_navigation(first, value),
                shift_navigation(second, value),
            ),
            _ => (first.clone(), second.clone()),
        };

        let pipeline = Pipeline {
            config: &config,
            profiles: self.profiles,
            vertical: self.vertical,
            ellipsoid: self.ellipsoid,
        };
        let a = pipeline.reduce_line(&first)?;
        let b = pipeline.reduce_line(&second)?;

        // Both surfaces have to be on the same grid, so size one from the
        // pair and then fill each separately.
        let projection = pipeline.projection()?;
        let both = build_surface(&[a.clone(), b.clone()], &config, projection)?;
        let geometry = *both.geometry();

        let mut first_surface = Surface::new(geometry, projection);
        first_surface.add_all(&a.soundings)?;
        let mut second_surface = Surface::new(geometry, projection);
        second_surface.add_all(&b.soundings)?;

        let comparison = compare(
            &render(&first_surface, Estimator::Mean),
            &render(&second_surface, Estimator::Mean),
        )
        .ok_or_else(|| Error::Config("the two trial surfaces did not line up".into()))?;

        if comparison.matched() < 10 {
            return Err(Error::Config(format!(
                "only {} cells carry both lines, this pair does not overlap enough",
                comparison.matched()
            )));
        }
        let mean = comparison.mean().unwrap_or(0.0);
        let spread = comparison.standard_deviation().unwrap_or(0.0);
        Ok((mean * mean + spread * spread).sqrt())
    }

    /// Solve for one parameter over a range.
    pub fn solve(
        &self,
        parameter: Parameter,
        first: &Line,
        second: &Line,
        range: Option<(f64, f64)>,
    ) -> Result<Minimum> {
        let (low, high) = range.unwrap_or_else(|| parameter.default_range());
        let tolerance = match parameter {
            Parameter::Latency => 0.002,
            _ => 0.005,
        };
        golden_section(low, high, tolerance, |value| {
            self.disagreement(parameter, value, first, second)
        })
    }

    /// The objective across a range, for plotting.
    pub fn curve(
        &self,
        parameter: Parameter,
        first: &Line,
        second: &Line,
        steps: usize,
    ) -> Result<Vec<(f64, f64)>> {
        let (low, high) = parameter.default_range();
        sweep(low, high, steps, |value| {
            self.disagreement(parameter, value, first, second)
        })
    }
}

/// Move the navigation on a line forward or back in time.
///
/// The pings keep their own timestamps and are given the navigation that
/// belonged to a different instant, which is exactly what a positioning
/// latency does. Off the ends of the line the nearest fix is held, so the
/// first and last few pings of a shifted line carry slightly stale
/// navigation. That is the honest behaviour and it is why a patch test line
/// wants to be run longer than the feature it is looking at.
pub fn shift_navigation(line: &Line, seconds: f64) -> Line {
    let mut attitudes = Vec::with_capacity(line.len());
    let mut latitudes = Vec::with_capacity(line.len());
    let mut longitudes = Vec::with_capacity(line.len());
    for ping in line.pings() {
        if let Some(nav) = ping.navigation {
            attitudes.push(Entry {
                time: ping.time,
                value: nav.attitude,
            });
            latitudes.push(Entry {
                time: ping.time,
                value: nav.position.lat.degrees(),
            });
            longitudes.push(Entry {
                time: ping.time,
                value: nav.position.lon.degrees(),
            });
        }
    }
    let attitudes: TimeSeries<Attitude> = TimeSeries::new(attitudes, 0.0);
    let latitudes: TimeSeries<f64> = TimeSeries::new(latitudes, 0.0);
    let longitudes: TimeSeries<f64> = TimeSeries::new(longitudes, 0.0);

    let mut pings = line.pings().to_vec();
    for ping in pings.iter_mut() {
        let at = ping.time.offset(-seconds);
        if let Some(nav) = ping.navigation.as_mut() {
            if let Some(a) = attitudes.at(at) {
                nav.attitude = a;
            }
            if let (Some(lat), Some(lon)) = (latitudes.at(at), longitudes.at(at)) {
                nav.position =
                    crate::geodesy::Geodetic::from_degrees(lat, lon, nav.position.height);
            }
        }
    }
    Line::new(line.name.clone(), pings)
}
