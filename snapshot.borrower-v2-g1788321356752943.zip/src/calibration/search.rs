//! One dimensional minimisation, for the calibration solvers.
//!
//! Every patch test parameter is found the same way: pick a value, reprocess
//! the two lines, measure how badly they disagree, repeat. The objective is
//! smooth and has one minimum over any range worth searching, and each
//! evaluation costs a reduction of two lines, so the method that matters is
//! the one that needs the fewest evaluations. Golden section needs about
//! fifteen for a thousandth of a degree over a range of two degrees, and
//! unlike a derivative method it cannot run away.

use crate::error::Result;

/// The golden ratio less one, which is the fraction golden section steps by.
const GOLDEN: f64 = 0.618_033_988_749_895;

/// What a search found.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Minimum {
    /// The value that minimises the objective.
    pub at: f64,
    /// The objective there.
    pub value: f64,
    /// How many times the objective was evaluated.
    pub evaluations: usize,
    /// True when the answer sits on an end of the search range.
    ///
    /// That almost always means the range was too narrow, and reporting a
    /// number pinned to the edge of a search as if it were a measurement is
    /// how a patch test produces a confident wrong answer.
    pub on_boundary: bool,
}

/// Find the minimum of a function over a range.
pub fn golden_section(
    low: f64,
    high: f64,
    tolerance: f64,
    mut objective: impl FnMut(f64) -> Result<f64>,
) -> Result<Minimum> {
    let (mut a, mut b) = if low <= high {
        (low, high)
    } else {
        (high, low)
    };
    let span = b - a;

    let mut c = b - GOLDEN * (b - a);
    let mut d = a + GOLDEN * (b - a);
    let mut fc = objective(c)?;
    let mut fd = objective(d)?;
    let mut evaluations = 2;

    while (b - a).abs() > tolerance && evaluations < 200 {
        if fc < fd {
            b = d;
            d = c;
            fd = fc;
            c = b - GOLDEN * (b - a);
            fc = objective(c)?;
        } else {
            a = c;
            c = d;
            fc = fd;
            d = a + GOLDEN * (b - a);
            fd = objective(d)?;
        }
        evaluations += 1;
    }

    let at = (a + b) / 2.0;
    let value = objective(at)?;
    evaluations += 1;
    let edge = span * 0.02;
    Ok(Minimum {
        at,
        value,
        evaluations,
        on_boundary: (at - low.min(high)).abs() < edge || (at - low.max(high)).abs() < edge,
    })
}

/// Sample the objective evenly across a range.
///
/// Not a solver: this is what gets plotted when a patch test comes back with
/// an answer nobody believes, and a flat curve or two minima explains more
/// than the number ever will.
pub fn sweep(
    low: f64,
    high: f64,
    steps: usize,
    mut objective: impl FnMut(f64) -> Result<f64>,
) -> Result<Vec<(f64, f64)>> {
    let steps = steps.max(2);
    let mut out = Vec::with_capacity(steps);
    for i in 0..steps {
        let x = low + (high - low) * i as f64 / (steps - 1) as f64;
        out.push((x, objective(x)?));
    }
    Ok(out)
}
