//! What choosing the wrong cast actually costs.
//!
//! The argument about how often to take a cast is usually had in the abstract
//! and always ends the same way. This settles it with a number: take two
//! casts, trace the same beams through both, and report how far apart the
//! depths land. If two casts an hour apart disagree by two centimetres at the
//! edge of the swath then hourly casting is a waste of a day; if they disagree
//! by a decimetre then it is not.

use crate::error::Result;
use crate::raytrace::Tracer;
use crate::units::Angle;

use super::profile::SoundSpeedProfile;

/// How two casts differ for one beam.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct BeamDifference {
    /// Launch angle the comparison was made at.
    pub angle: Angle,
    /// Depth the first cast gives.
    pub depth: f64,
    /// Depth difference, second cast minus first.
    pub depth_difference: f64,
    /// Across track difference, second minus first.
    pub across_difference: f64,
}

impl BeamDifference {
    /// The difference as a fraction of the depth, which is the form a
    /// specification is written in.
    pub fn fraction_of_depth(&self) -> f64 {
        if self.depth.abs() < 1.0e-9 {
            0.0
        } else {
            self.depth_difference.abs() / self.depth.abs()
        }
    }
}

/// The whole comparison.
#[derive(Debug, Clone, PartialEq)]
pub struct CastComparison {
    /// One entry per angle tried, from port to starboard.
    pub beams: Vec<BeamDifference>,
    /// Nominal depth the comparison was made at.
    pub nominal_depth: f64,
}

impl CastComparison {
    /// Largest depth difference anywhere in the swath.
    pub fn worst_depth_difference(&self) -> f64 {
        self.beams
            .iter()
            .map(|b| b.depth_difference.abs())
            .fold(0.0, f64::max)
    }

    /// Depth difference at nadir, which is what a single beam echo sounder
    /// would have seen and is usually reassuringly small.
    pub fn at_nadir(&self) -> Option<f64> {
        self.beams
            .iter()
            .min_by(|a, b| a.angle.radians().abs().total_cmp(&b.angle.radians().abs()))
            .map(|b| b.depth_difference)
    }

    /// True when the difference stays inside an allowance everywhere.
    pub fn within(&self, allowance: f64) -> bool {
        self.worst_depth_difference() <= allowance
    }
}

/// Compare two casts by tracing the same beams through both.
///
/// The travel time for each angle is worked out from the first cast so that
/// both traces answer the same acoustic observation, which is the comparison
/// that matters: the sonar measures a time, not a depth.
pub fn compare_casts(
    first: &SoundSpeedProfile,
    second: &SoundSpeedProfile,
    nominal_depth: f64,
    transducer_depth: f64,
    max_angle: Angle,
    beams: usize,
) -> Result<CastComparison> {
    let beams = beams.max(3);
    let a = Tracer::new(first, transducer_depth)?;
    let b = Tracer::new(second, transducer_depth)?;

    let mut out = Vec::with_capacity(beams);
    for i in 0..beams {
        let fraction = i as f64 / (beams - 1) as f64;
        let angle =
            Angle::from_radians(-max_angle.radians() + 2.0 * max_angle.radians() * fraction);

        // A first guess at the travel time from a straight line at the mean
        // speed, then two corrections, which is enough to land within a
        // centimetre of the nominal depth for any real cast.
        let mean = first.harmonic_mean_speed(nominal_depth);
        let mut time = (nominal_depth - transducer_depth) / (mean * angle.cos());
        for _ in 0..3 {
            let trial = a.trace(angle, time)?;
            if trial.turned || trial.depth <= transducer_depth {
                break;
            }
            time *= (nominal_depth - transducer_depth) / (trial.depth - transducer_depth);
        }

        let first_ray = a.trace(angle, time)?;
        let second_ray = b.trace(angle, time)?;
        if first_ray.turned || second_ray.turned {
            continue;
        }
        out.push(BeamDifference {
            angle,
            depth: first_ray.depth,
            depth_difference: second_ray.depth - first_ray.depth,
            across_difference: second_ray.across - first_ray.across,
        });
    }

    Ok(CastComparison {
        beams: out,
        nominal_depth,
    })
}
