//! The sound speed profile itself.
//!
//! A cast is a list of depth and sound speed pairs, shallowest first. Between
//! two samples the speed is taken to vary linearly with depth, which is the
//! assumption the ray tracer is built on: a constant gradient layer bends a
//! ray into a circular arc with a closed form, and anything fancier buys
//! nothing against the sampling error of the probe.

use crate::error::{Error, Result};

/// One measurement in a cast.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Sample {
    /// Depth below the surface in metres, positive down.
    pub depth: f64,
    /// Sound speed in metres per second.
    pub speed: f64,
}

impl Sample {
    /// Build a sample.
    pub const fn new(depth: f64, speed: f64) -> Self {
        Sample { depth, speed }
    }
}

/// Widest sound speed anyone will see in the ocean, used as a sanity bound.
pub const MAX_PLAUSIBLE_SPEED: f64 = 1650.0;
/// Slowest sound speed anyone will see in the ocean.
pub const MIN_PLAUSIBLE_SPEED: f64 = 1350.0;

/// A sound speed cast, sorted by depth with no repeated depths.
#[derive(Debug, Clone, PartialEq)]
pub struct SoundSpeedProfile {
    samples: Vec<Sample>,
}

impl SoundSpeedProfile {
    /// Build a profile from samples in any order.
    ///
    /// Samples are sorted by depth, samples at a repeated depth are collapsed
    /// to the first one seen, and anything outside the plausible speed band is
    /// rejected outright rather than quietly clamped: a bad cast is a data
    /// problem and hiding it produces depths that look fine and are not.
    pub fn new(mut samples: Vec<Sample>) -> Result<Self> {
        if samples.len() < 2 {
            return Err(Error::Config(
                "a sound speed profile needs at least two samples".into(),
            ));
        }
        for s in &samples {
            if !s.depth.is_finite() || s.depth < 0.0 {
                return Err(Error::domain(
                    "profile depth",
                    s.depth,
                    "finite and positive",
                ));
            }
            if !(MIN_PLAUSIBLE_SPEED..=MAX_PLAUSIBLE_SPEED).contains(&s.speed) {
                return Err(Error::domain(
                    "sound speed",
                    s.speed,
                    "between 1350 and 1650 m/s",
                ));
            }
        }
        samples.sort_by(|a, b| a.depth.total_cmp(&b.depth));
        samples.dedup_by(|a, b| (a.depth - b.depth).abs() < 1.0e-6);
        if samples.len() < 2 {
            return Err(Error::Config(
                "the profile collapsed to a single depth once duplicates were removed".into(),
            ));
        }
        Ok(SoundSpeedProfile { samples })
    }

    /// The samples, shallowest first.
    pub fn samples(&self) -> &[Sample] {
        &self.samples
    }

    /// Number of samples in the cast.
    pub fn len(&self) -> usize {
        self.samples.len()
    }

    /// Always false; a profile cannot be built with fewer than two samples.
    pub fn is_empty(&self) -> bool {
        false
    }

    /// Depth of the shallowest sample.
    pub fn shallowest(&self) -> f64 {
        self.samples[0].depth
    }

    /// Depth of the deepest sample.
    pub fn deepest(&self) -> f64 {
        self.samples[self.samples.len() - 1].depth
    }

    /// Sound speed at the surface, the value the transducer needs for beam
    /// steering.
    pub fn surface_speed(&self) -> f64 {
        self.samples[0].speed
    }

    /// Index of the layer containing a depth, or `None` above or below the
    /// cast.
    ///
    /// A depth exactly on a sample boundary belongs to the layer below it, so
    /// that walking down a profile visits every layer exactly once.
    pub fn layer_index(&self, depth: f64) -> Option<usize> {
        if depth < self.shallowest() || depth > self.deepest() {
            return None;
        }
        let idx = self
            .samples
            .partition_point(|s| s.depth <= depth)
            .saturating_sub(1);
        Some(idx.min(self.samples.len() - 2))
    }

    /// Sound speed at a depth, linearly interpolated inside the cast.
    ///
    /// Above the shallowest sample and below the deepest one the profile is
    /// held constant. Extrapolating a gradient past the end of a cast produces
    /// speeds that leave the physical range within a few hundred metres.
    pub fn speed_at(&self, depth: f64) -> f64 {
        if depth <= self.shallowest() {
            return self.samples[0].speed;
        }
        if depth >= self.deepest() {
            return self.samples[self.samples.len() - 1].speed;
        }
        let i = self.layer_index(depth).unwrap_or(0);
        let a = self.samples[i];
        let b = self.samples[i + 1];
        let t = (depth - a.depth) / (b.depth - a.depth);
        a.speed + t * (b.speed - a.speed)
    }

    /// Sound speed gradient of a layer in reciprocal seconds.
    pub fn gradient(&self, layer: usize) -> f64 {
        let a = self.samples[layer];
        let b = self.samples[layer + 1];
        let dz = b.depth - a.depth;
        if dz.abs() < 1.0e-9 {
            0.0
        } else {
            (b.speed - a.speed) / dz
        }
    }

    /// Harmonic mean sound speed between the surface and a depth.
    ///
    /// ```
    /// use plumbline::svp::profile::{Sample, SoundSpeedProfile};
    ///
    /// let profile = SoundSpeedProfile::new(vec![
    ///     Sample::new(0.0, 1470.0),
    ///     Sample::new(100.0, 1450.0),
    /// ])?;
    ///
    /// // Between the two, and below the arithmetic mean, which is what the
    /// // harmonic mean always does.
    /// let mean = profile.harmonic_mean_speed(100.0);
    /// assert!(mean > 1450.0 && mean < 1460.0);
    /// # Ok::<(), plumbline::Error>(())
    /// ```
    ///
    /// This is the number to compare against a single speed correction, and it
    /// is the one that reproduces the vertical travel time, which a plain
    /// arithmetic mean does not.
    pub fn harmonic_mean_speed(&self, depth: f64) -> f64 {
        if depth <= 0.0 {
            return self.surface_speed();
        }
        let mut travel_time = 0.0;
        let mut z = 0.0;
        while z < depth {
            let step = (depth - z).min(1.0);
            let mid = self.speed_at(z + step / 2.0);
            travel_time += step / mid;
            z += step;
        }
        if travel_time <= 0.0 {
            self.surface_speed()
        } else {
            depth / travel_time
        }
    }
}
