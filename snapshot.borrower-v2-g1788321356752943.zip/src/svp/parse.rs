//! Readers for the sound speed formats that come off acquisition software.

use std::fs;
use std::path::Path;

use crate::error::{Error, FormatError, InFile, Result};
use crate::geodesy::Geodetic;
use crate::time::Timestamp;
use crate::units::Angle;

use super::profile::{Sample, SoundSpeedProfile};

/// A section of the file while it is still being read.
struct Section {
    label: String,
    time: Option<Timestamp>,
    position: Option<Geodetic>,
    samples: Vec<Sample>,
}

/// A profile as it came out of a file, with the header fields that identify it.
#[derive(Debug, Clone, PartialEq)]
pub struct ProfileRecord {
    /// Section name from the header.
    pub label: String,
    /// Time the cast was taken, when the header carried one.
    pub time: Option<Timestamp>,
    /// Position of the cast, when the header carried one.
    pub position: Option<Geodetic>,
    /// The profile itself.
    pub profile: SoundSpeedProfile,
}

/// Read a version 2 SVP file, the format Caris writes.
///
/// The file holds one or more sections. Each section starts with a line that
/// names it and carries a day of year timestamp and a position in degrees,
/// minutes and seconds, and is followed by depth and speed pairs until the
/// next section or the end of the file.
pub fn parse_svp(text: &str) -> Result<Vec<ProfileRecord>> {
    let mut records = Vec::new();
    let mut current: Option<Section> = None;

    for (n, raw) in text.lines().enumerate() {
        let line = raw.trim();
        let line_no = n + 1;

        if line.is_empty() || line.starts_with("//") {
            continue;
        }
        if line.starts_with('[') {
            // Version banner. Anything other than version 2 has a different
            // section layout and would be silently misread.
            if !line.contains("SVP_VERSION_2") {
                return Err(FormatError::at_line(
                    line_no,
                    format!("unsupported svp banner {line}"),
                )
                .into());
            }
            continue;
        }
        if line.starts_with("Section") {
            if let Some(done) = current.take() {
                records.push(finish_section(done, line_no)?);
            }
            let (time, position) = parse_section_header(line, line_no);
            current = Some(Section {
                label: line.to_string(),
                time,
                position,
                samples: Vec::new(),
            });
            continue;
        }

        // The line after the banner is the path the file was written from,
        // which carries nothing we do not already have.
        let Some(section) = current.as_mut() else {
            continue;
        };
        let samples = &mut section.samples;
        let mut fields = line.split_whitespace();
        let depth = fields
            .next()
            .and_then(|f| f.parse::<f64>().ok())
            .ok_or_else(|| FormatError::at_line(line_no, "expected a depth"))?;
        let speed = fields
            .next()
            .and_then(|f| f.parse::<f64>().ok())
            .ok_or_else(|| FormatError::at_line(line_no, "expected a sound speed"))?;
        samples.push(Sample::new(depth, speed));
    }

    if let Some(done) = current.take() {
        let end = text.lines().count();
        records.push(finish_section(done, end)?);
    }
    if records.is_empty() {
        return Err(FormatError::new("no profile sections in file").into());
    }
    Ok(records)
}

fn finish_section(section: Section, line_no: usize) -> Result<ProfileRecord> {
    let Section {
        label,
        time,
        position,
        samples,
    } = section;
    if samples.len() < 2 {
        return Err(FormatError::at_line(
            line_no,
            format!("section {label} ended with fewer than two samples"),
        )
        .into());
    }
    Ok(ProfileRecord {
        label,
        time,
        position,
        profile: SoundSpeedProfile::new(samples)?,
    })
}

/// Pull the timestamp and position out of a section header.
///
/// Both are optional in the wild. A header with a broken position is treated
/// as a header without one rather than as an error, because the profile is
/// still usable and refusing the file would lose the whole cast.
fn parse_section_header(line: &str, line_no: usize) -> (Option<Timestamp>, Option<Geodetic>) {
    let fields: Vec<&str> = line.split_whitespace().collect();
    if fields.len() < 3 {
        return (None, None);
    }
    let time = parse_yearday(fields[1], fields[2], line_no).ok();
    let position = if fields.len() >= 5 {
        match (parse_dms(fields[3]), parse_dms(fields[4])) {
            (Some(lat), Some(lon)) => Some(Geodetic {
                lat,
                lon,
                height: 0.0,
            }),
            _ => None,
        }
    } else {
        None
    };
    (time, position)
}

/// Parse a year and day of year date with an hour, minute and second time.
fn parse_yearday(date: &str, time: &str, line_no: usize) -> Result<Timestamp> {
    let bad = |what: &str| -> Error {
        FormatError::at_line(line_no, format!("cannot read {what} from {date} {time}")).into()
    };
    let (year, day) = date.split_once('-').ok_or_else(|| bad("date"))?;
    let year: i32 = year.parse().map_err(|_| bad("year"))?;
    let day: u32 = day.parse().map_err(|_| bad("day of year"))?;
    let mut parts = time.split(':');
    let hour: u32 = parts
        .next()
        .and_then(|p| p.parse().ok())
        .ok_or_else(|| bad("hour"))?;
    let minute: u32 = parts
        .next()
        .and_then(|p| p.parse().ok())
        .ok_or_else(|| bad("minute"))?;
    let second: f64 = parts.next().and_then(|p| p.parse().ok()).unwrap_or(0.0);
    let start = Timestamp::from_utc(year, 1, 1, hour, minute, second);
    Ok(start.offset((day.saturating_sub(1) as f64) * 86_400.0))
}

/// Parse a degrees, minutes and seconds angle with an optional leading sign.
fn parse_dms(field: &str) -> Option<Angle> {
    let (sign, body) = match field.strip_prefix('-') {
        Some(rest) => (-1.0, rest),
        None => (1.0, field.strip_prefix('+').unwrap_or(field)),
    };
    let mut parts = body.split(':');
    let d: f64 = parts.next()?.parse().ok()?;
    let m: f64 = parts.next().and_then(|p| p.parse().ok()).unwrap_or(0.0);
    let s: f64 = parts.next().and_then(|p| p.parse().ok()).unwrap_or(0.0);
    if !(d.is_finite() && m.is_finite() && s.is_finite()) {
        return None;
    }
    Some(Angle::from_degrees(sign * (d + m / 60.0 + s / 3600.0)))
}

/// Read profiles from a file on disk.
pub fn read_svp_file(path: impl AsRef<Path>) -> Result<Vec<ProfileRecord>> {
    let path = path.as_ref();
    let text = fs::read_to_string(path).map_err(|e| Error::io(path, e))?;
    parse_svp(&text).in_file(path)
}

/// The label a cast gets when a file gives it none.
pub fn default_label(index: usize) -> String {
    format!("cast {}", index + 1)
}
