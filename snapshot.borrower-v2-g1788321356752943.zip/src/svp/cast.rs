//! Conductivity, temperature and depth casts, and how they become profiles.

use crate::error::{Error, Result};
use crate::geodesy::Geodetic;
use crate::time::Timestamp;
use crate::units::Angle;

use super::equations::SoundSpeedEquation;
use super::profile::{Sample, SoundSpeedProfile};

/// One bottle of a cast.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct CtdSample {
    /// Depth below the surface in metres, positive down.
    pub depth: f64,
    /// In situ temperature in degrees Celsius.
    pub temperature: f64,
    /// Practical salinity.
    pub salinity: f64,
}

impl CtdSample {
    /// Build a sample.
    pub const fn new(depth: f64, temperature: f64, salinity: f64) -> Self {
        CtdSample {
            depth,
            temperature,
            salinity,
        }
    }
}

/// A cast, with enough metadata to decide whether it applies to a ping.
#[derive(Debug, Clone, PartialEq)]
pub struct CtdCast {
    /// Where the probe went in.
    pub position: Geodetic,
    /// When it went in.
    pub time: Timestamp,
    /// An identifier from the acquisition system, for tracing a profile back.
    pub label: String,
    /// The measurements, in whatever order the file had them.
    pub samples: Vec<CtdSample>,
}

impl CtdCast {
    /// Build a cast.
    pub fn new(
        position: Geodetic,
        time: Timestamp,
        label: impl Into<String>,
        samples: Vec<CtdSample>,
    ) -> Self {
        CtdCast {
            position,
            time,
            label: label.into(),
            samples,
        }
    }

    /// Deepest sample in the cast, or zero if it is empty.
    pub fn max_depth(&self) -> f64 {
        self.samples
            .iter()
            .map(|s| s.depth)
            .fold(0.0, |acc, d| if d > acc { d } else { acc })
    }

    /// Turn the cast into a sound speed profile with a chosen equation.
    ///
    /// The latitude of the cast is used for the gravity term in the pressure
    /// conversion. It is taken from the cast position rather than passed in,
    /// because a cast reduced against the wrong latitude is exactly the kind of
    /// error that survives review.
    pub fn to_profile(&self, equation: SoundSpeedEquation) -> Result<SoundSpeedProfile> {
        if self.samples.is_empty() {
            return Err(Error::Config(format!("cast {} has no samples", self.label)));
        }
        let latitude = self.position.lat;
        let samples = self
            .samples
            .iter()
            .map(|s| {
                let speed = equation.speed(s.salinity, s.temperature, s.depth, latitude);
                Sample::new(s.depth, speed)
            })
            .collect();
        SoundSpeedProfile::new(samples)
    }

    /// Check the cast for the mistakes that come out of acquisition systems.
    ///
    /// This is separate from [`CtdCast::to_profile`] on purpose: a cast that
    /// fails one of these is still usable if somebody looks at it and decides
    /// so, and the caller is the one who can make that decision.
    pub fn validate(&self) -> Vec<CastWarning> {
        let mut out = Vec::new();
        if self.samples.len() < 4 {
            out.push(CastWarning::TooFewSamples(self.samples.len()));
        }
        for (i, s) in self.samples.iter().enumerate() {
            if !(-2.5..=40.0).contains(&s.temperature) {
                out.push(CastWarning::TemperatureOutOfRange {
                    index: i,
                    value: s.temperature,
                });
            }
            if !(0.0..=42.0).contains(&s.salinity) {
                out.push(CastWarning::SalinityOutOfRange {
                    index: i,
                    value: s.salinity,
                });
            }
        }
        let mut sorted = self.samples.clone();
        sorted.sort_by(|a, b| a.depth.total_cmp(&b.depth));
        for w in sorted.windows(2) {
            let gap = w[1].depth - w[0].depth;
            if gap > 50.0 {
                out.push(CastWarning::LargeGap {
                    from: w[0].depth,
                    to: w[1].depth,
                });
            }
        }
        out
    }
}

/// Something suspicious about a cast, short of it being unusable.
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum CastWarning {
    /// Fewer samples than it takes to describe a thermocline.
    TooFewSamples(usize),
    /// A temperature no ocean has.
    TemperatureOutOfRange {
        /// Index into the samples as they were given.
        index: usize,
        /// The offending temperature.
        value: f64,
    },
    /// A salinity no ocean has.
    SalinityOutOfRange {
        /// Index into the samples as they were given.
        index: usize,
        /// The offending salinity.
        value: f64,
    },
    /// A stretch of water column with no samples in it.
    LargeGap {
        /// Shallow end of the gap.
        from: f64,
        /// Deep end of the gap.
        to: f64,
    },
}

/// Latitude used when a cast has no position at all, the equator, where the
/// gravity term is furthest from the poles and the error is at least honest.
pub const FALLBACK_LATITUDE: Angle = Angle::ZERO;
