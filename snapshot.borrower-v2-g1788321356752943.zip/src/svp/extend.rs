//! Extending a cast past the depth the probe reached.
//!
//! A sound speed cast almost never reaches the seabed. The tracer needs a
//! speed at every depth a ray visits, so the profile has to be carried down
//! somehow, and how it is carried down is a decision with a real effect on the
//! outer beams. Holding the last speed is the conservative choice; below a
//! thousand metres the adiabatic gradient is closer to the truth and the
//! difference is worth a decimetre in six thousand metres of water.

use crate::error::{Error, Result};

use super::profile::{Sample, SoundSpeedProfile};

/// The adiabatic sound speed gradient in deep water, per metre.
///
/// Below the sound channel axis the profile is very nearly linear at this
/// slope, because pressure is the only term still changing.
pub const ADIABATIC_GRADIENT: f64 = 0.017;

/// How to carry a cast below its deepest sample.
#[derive(Debug, Clone, PartialEq)]
pub enum Extension {
    /// Hold the deepest measured speed.
    Constant,
    /// Continue at a fixed gradient in metres per second per metre.
    Gradient(f64),
    /// Continue at the gradient of the deepest layer of the cast itself.
    ///
    /// Only sensible when the cast reached deep enough to be past the sound
    /// channel, so it refuses to run on a cast shallower than a limit.
    LastLayerGradient {
        /// Shallowest cast this is allowed on, in metres.
        min_cast_depth: f64,
    },
    /// Blend into a deeper reference cast, usually a climatology.
    Reference(Box<SoundSpeedProfile>),
}

impl Default for Extension {
    fn default() -> Self {
        Extension::Gradient(ADIABATIC_GRADIENT)
    }
}

/// Carry a profile down to `target_depth` using a strategy.
///
/// A profile that already reaches the target is returned unchanged. The
/// extension adds one sample at the target for the simple strategies, and
/// every reference sample below the cast for the blended one, so the layer
/// structure stays as coarse as it can be.
pub fn extend_to(
    profile: &SoundSpeedProfile,
    target_depth: f64,
    how: &Extension,
) -> Result<SoundSpeedProfile> {
    let bottom = profile.deepest();
    if target_depth <= bottom {
        return Ok(profile.clone());
    }
    let bottom_speed = profile.speed_at(bottom);
    let mut samples = profile.samples().to_vec();

    match how {
        Extension::Constant => {
            samples.push(Sample::new(target_depth, bottom_speed));
        }
        Extension::Gradient(g) => {
            samples.push(Sample::new(
                target_depth,
                bottom_speed + g * (target_depth - bottom),
            ));
        }
        Extension::LastLayerGradient { min_cast_depth } => {
            if bottom < *min_cast_depth {
                return Err(Error::Config(format!(
                    "cast reaches {bottom:.0} m, too shallow to extrapolate its own gradient below {min_cast_depth:.0} m"
                )));
            }
            let g = profile.gradient(profile.len() - 2);
            samples.push(Sample::new(
                target_depth,
                bottom_speed + g * (target_depth - bottom),
            ));
        }
        Extension::Reference(reference) => {
            if reference.deepest() < target_depth {
                return Err(Error::Config(format!(
                    "reference profile reaches {:.0} m, short of the {target_depth:.0} m needed",
                    reference.deepest()
                )));
            }
            // Shift the reference so it meets the cast at the join, otherwise
            // the profile takes a step at the bottom of the cast and the ray
            // tracer sees a refraction that is not there.
            let offset = bottom_speed - reference.speed_at(bottom);
            for s in reference.samples() {
                if s.depth > bottom && s.depth <= target_depth {
                    samples.push(Sample::new(s.depth, s.speed + offset));
                }
            }
            if samples.last().map(|s| s.depth) != Some(target_depth) {
                samples.push(Sample::new(
                    target_depth,
                    reference.speed_at(target_depth) + offset,
                ));
            }
        }
    }

    SoundSpeedProfile::new(samples)
}

/// Extend a cast up to the surface if it starts below it.
///
/// The top of a cast is often a metre or two down because the probe was still
/// settling. The first metre of the water column is where the transducer is,
/// so it cannot be left undefined; the shallowest measured speed is held.
pub fn extend_to_surface(profile: &SoundSpeedProfile) -> Result<SoundSpeedProfile> {
    if profile.shallowest() <= 0.0 {
        return Ok(profile.clone());
    }
    let mut samples = vec![Sample::new(0.0, profile.surface_speed())];
    samples.extend_from_slice(profile.samples());
    SoundSpeedProfile::new(samples)
}
