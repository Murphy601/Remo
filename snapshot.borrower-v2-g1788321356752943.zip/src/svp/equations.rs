//! Empirical sound speed equations.
//!
//! A conductivity, temperature and depth cast has to be turned into sound
//! speed before it is any use, and which equation you use is a decision the
//! survey specification usually makes for you. Two are implemented here and
//! the caller has to pick one; there is no default, because silently changing
//! equation between casts is worth a decimetre at depth.

use crate::units::Angle;

/// Chen and Millero, the UNESCO equation of 1977.
///
/// Salinity in practical salinity units, temperature in degrees Celsius on
/// the 1968 scale, pressure in bars gauge, that is zero at the surface. Valid
/// over 0 to 40 PSU, 0 to 40 degrees and 0 to 1000 bars, which covers every
/// ocean cast that exists.
pub fn chen_millero(salinity: f64, temperature: f64, pressure_bar: f64) -> f64 {
    let t = temperature;
    let s = salinity;
    let p = pressure_bar;

    let t2 = t * t;
    let t3 = t2 * t;
    let t4 = t3 * t;
    let t5 = t4 * t;
    let p2 = p * p;
    let p3 = p2 * p;

    // Pure water term.
    let cw = (1402.388 + 5.038_30 * t - 5.810_90e-2 * t2 + 3.3432e-4 * t3 - 1.477_97e-6 * t4
        + 3.1419e-9 * t5)
        + (0.153_563 + 6.8999e-4 * t - 8.1829e-6 * t2 + 1.3632e-7 * t3 - 6.1260e-10 * t4) * p
        + (3.1260e-5 - 1.7111e-6 * t + 2.5986e-8 * t2 - 2.5353e-10 * t3 + 1.0415e-12 * t4) * p2
        + (-9.7729e-9 + 3.8513e-10 * t - 2.3654e-12 * t2) * p3;

    // Linear salinity term.
    let a = (1.389 - 1.262e-2 * t + 7.166e-5 * t2 + 2.008e-6 * t3 - 3.21e-8 * t4)
        + (9.4742e-5 - 1.2580e-5 * t - 6.4885e-8 * t2 + 1.0507e-8 * t3 - 2.0122e-10 * t4) * p
        + (-3.9064e-7 + 9.1041e-9 * t - 1.6002e-10 * t2 + 7.988e-12 * t3) * p2
        + (1.100e-10 + 6.649e-12 * t - 3.389e-13 * t2) * p3;

    // Three halves power term.
    let b = -1.922e-2 - 4.42e-5 * t + (7.3637e-5 + 1.7945e-7 * t) * p;

    // Quadratic salinity term.
    let d = 1.727e-3 - 7.9836e-6 * p;

    cw + a * s + b * s * s.sqrt() + d * s * s
}

/// Mackenzie, 1981.
///
/// Takes depth directly instead of pressure, which makes it convenient for a
/// quick check but no substitute for the UNESCO equation on a real cast. Valid
/// to 8000 m, 0 to 30 degrees, 30 to 40 PSU.
pub fn mackenzie(salinity: f64, temperature: f64, depth: f64) -> f64 {
    let t = temperature;
    let ds = salinity - 35.0;
    let z = depth;
    1448.96 + 4.591 * t - 5.304e-2 * t * t
        + 2.374e-4 * t * t * t
        + 1.340 * ds
        + 1.630e-2 * z
        + 1.675e-7 * z * z
        - 1.025e-2 * t * ds
        - 7.139e-13 * t * z * z * z
}

/// Gravity at the sea surface for a latitude, in metres per second squared.
pub fn surface_gravity(latitude: Angle) -> f64 {
    let s = latitude.sin();
    9.780_318 * (1.0 + 5.2788e-3 * s * s + 2.36e-5 * s * s * s * s)
}

/// Convert a depth to a gauge pressure, after Leroy and Parthiot, 1998.
///
/// The result is in bars, which is what [`chen_millero`] wants. The latitude
/// matters because gravity does. It is not a rounding term: gravity changes
/// by half a percent between the equator and the pole, and at 6000 m that is
/// thirty metres of apparent depth.
pub fn depth_to_pressure(depth: f64, latitude: Angle) -> f64 {
    let z = depth;
    let sin2 = latitude.sin() * latitude.sin();
    let g = 9.780_318 * (1.0 + 5.2788e-3 * sin2 + 2.36e-5 * sin2 * sin2) + 1.092e-6 * z;
    let h45 = 1.008_18e-2 * z + 2.465e-8 * z * z - 1.25e-13 * z * z * z + 2.8e-19 * z * z * z * z;
    let k = (g - 2.0e-5 * z) / (9.806_12 - 2.0e-5 * z);
    // Leroy works in megapascals, and one megapascal is ten bars.
    h45 * k * 10.0
}

/// Convert a gauge pressure in bars back to a depth, by inverting
/// [`depth_to_pressure`] with a few Newton steps.
pub fn pressure_to_depth(pressure_bar: f64, latitude: Angle) -> f64 {
    // The relation is very nearly linear at about one bar per ten metres, so
    // start there and refine. Four iterations is plenty for micrometres.
    let mut z = pressure_bar * 9.9;
    for _ in 0..8 {
        let f = depth_to_pressure(z, latitude) - pressure_bar;
        let step = 0.1;
        let dfdz = (depth_to_pressure(z + step, latitude) - depth_to_pressure(z - step, latitude))
            / (2.0 * step);
        if dfdz.abs() < 1.0e-12 {
            break;
        }
        let dz = f / dfdz;
        z -= dz;
        if dz.abs() < 1.0e-9 {
            break;
        }
    }
    z
}

/// Del Grosso, 1974, in the coefficient set tabulated by Wong and Zhu.
///
/// Pressure is in kilograms force per square centimetre, which is the unit the
/// original paper used and which nobody else uses for anything. Use
/// [`bar_to_kgf_per_cm2`] on the way in. This equation is the one most
/// hydrographic offices settled on for deep water because it sits closer to
/// the measurements below 1000 bar than the UNESCO one does.
pub fn del_grosso(salinity: f64, temperature: f64, pressure_kgf: f64) -> f64 {
    let t = temperature;
    let s = salinity;
    let p = pressure_kgf;

    let dct = 0.501_228_5e1 * t - 0.551_184e-1 * t * t + 0.221_649e-3 * t * t * t;
    let dcs = 0.132_953_0e1 * s + 0.128_859_8e-3 * s * s;
    let dcp = 0.156_059_2 * p + 0.244_999_3e-4 * p * p - 0.883_395_9e-8 * p * p * p;

    let dcstp =
        0.635_350_9e-2 * t * p - 0.438_361_5e-6 * t * t * t * p - 0.159_389_5e-5 * t * p * p
            + 0.265_617_4e-7 * t * t * p * p
            + 0.522_248_3e-9 * t * p * p * p
            - 0.127_593_6e-1 * s * t
            + 0.968_844_1e-4 * s * t * t
            - 0.340_682_4e-3 * s * t * p
            + 0.485_761_4e-5 * s * s * t * p
            - 0.161_674_5e-8 * s * s * p * p;

    1402.392 + dct + dcs + dcp + dcstp
}

/// One bar in kilograms force per square centimetre.
pub const KGF_PER_CM2_PER_BAR: f64 = 1.019_716_212_977_9;

/// Convert bars to the pressure unit [`del_grosso`] expects.
pub fn bar_to_kgf_per_cm2(bar: f64) -> f64 {
    bar * KGF_PER_CM2_PER_BAR
}

/// Which empirical equation to use when reducing a cast.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SoundSpeedEquation {
    /// UNESCO, Chen and Millero 1977.
    ChenMillero,
    /// Del Grosso 1974.
    DelGrosso,
    /// Mackenzie 1981.
    Mackenzie,
}

impl SoundSpeedEquation {
    /// Sound speed for a sample of a cast.
    ///
    /// All three equations are reached through the same arguments so the
    /// choice can live in a configuration file. Depth is converted to pressure
    /// internally for the two that want it.
    pub fn speed(&self, salinity: f64, temperature: f64, depth: f64, latitude: Angle) -> f64 {
        match self {
            SoundSpeedEquation::ChenMillero => {
                chen_millero(salinity, temperature, depth_to_pressure(depth, latitude))
            }
            SoundSpeedEquation::DelGrosso => del_grosso(
                salinity,
                temperature,
                bar_to_kgf_per_cm2(depth_to_pressure(depth, latitude)),
            ),
            SoundSpeedEquation::Mackenzie => mackenzie(salinity, temperature, depth),
        }
    }

    /// Short name as it appears in a configuration file.
    pub fn name(&self) -> &'static str {
        match self {
            SoundSpeedEquation::ChenMillero => "chen-millero",
            SoundSpeedEquation::DelGrosso => "del-grosso",
            SoundSpeedEquation::Mackenzie => "mackenzie",
        }
    }

    /// Parse the name back, case insensitively.
    pub fn from_name(name: &str) -> Option<Self> {
        match name.trim().to_ascii_lowercase().as_str() {
            "chen-millero" | "chen_millero" | "unesco" => Some(SoundSpeedEquation::ChenMillero),
            "del-grosso" | "del_grosso" | "delgrosso" => Some(SoundSpeedEquation::DelGrosso),
            "mackenzie" => Some(SoundSpeedEquation::Mackenzie),
            _ => None,
        }
    }
}
