//! Thinning a cast down to the points that matter.
//!
//! A modern probe hands back a sample every few centimetres, which is tens of
//! thousands of layers. The ray tracer walks every layer of every profile for
//! every beam, so the cost of carrying them is real, and almost all of them
//! say nothing the neighbouring two do not. This is the Douglas and Peucker
//! line simplification run on the depth against speed curve, which keeps the
//! points where the curve actually bends and guarantees a bound on how far the
//! thinned profile can be from the original.

use crate::error::Result;

use super::profile::{Sample, SoundSpeedProfile};

/// Default tolerance for thinning, in metres per second.
///
/// A tenth of a metre per second is an order below what a probe resolves and
/// two orders below the difference between casts an hour apart.
pub const DEFAULT_TOLERANCE: f64 = 0.1;

/// Thin a profile so that no original sample is further than `tolerance` from
/// the retained curve, measured in sound speed.
///
/// The first and last samples are always kept, so the depth range of the cast
/// does not move.
pub fn thin(profile: &SoundSpeedProfile, tolerance: f64) -> Result<SoundSpeedProfile> {
    let samples = profile.samples();
    if samples.len() <= 2 || tolerance <= 0.0 {
        return Ok(profile.clone());
    }
    let mut keep = vec![false; samples.len()];
    keep[0] = true;
    keep[samples.len() - 1] = true;
    simplify(samples, 0, samples.len() - 1, tolerance, &mut keep);

    let kept: Vec<Sample> = samples
        .iter()
        .zip(keep.iter())
        .filter_map(|(s, k)| if *k { Some(*s) } else { None })
        .collect();
    SoundSpeedProfile::new(kept)
}

/// Recursive half of the simplification.
///
/// Written with an explicit stack rather than by recursing, because a cast
/// with fifty thousand samples that happen to be nearly collinear recurses
/// once per sample and blows the stack.
fn simplify(samples: &[Sample], first: usize, last: usize, tolerance: f64, keep: &mut [bool]) {
    let mut stack = vec![(first, last)];
    while let Some((a, b)) = stack.pop() {
        if b <= a + 1 {
            continue;
        }
        let start = samples[a];
        let end = samples[b];
        let span = end.depth - start.depth;

        let mut worst = 0.0;
        let mut worst_at = a;
        for (i, s) in samples.iter().enumerate().take(b).skip(a + 1) {
            let interpolated = if span.abs() < 1.0e-12 {
                start.speed
            } else {
                start.speed + (s.depth - start.depth) / span * (end.speed - start.speed)
            };
            let error = (s.speed - interpolated).abs();
            if error > worst {
                worst = error;
                worst_at = i;
            }
        }

        if worst > tolerance {
            keep[worst_at] = true;
            stack.push((a, worst_at));
            stack.push((worst_at, b));
        }
    }
}

/// Thin a profile down to at most `max_samples` points.
///
/// Doubles the tolerance until the profile is small enough. The result is the
/// first thinning that fits, so it is never far above the target and never
/// below it by much.
pub fn thin_to_count(profile: &SoundSpeedProfile, max_samples: usize) -> Result<SoundSpeedProfile> {
    if profile.len() <= max_samples.max(2) {
        return Ok(profile.clone());
    }
    let mut tolerance = DEFAULT_TOLERANCE;
    let mut out = thin(profile, tolerance)?;
    // Twenty doublings takes a tenth of a metre per second past a hundred
    // thousand, well past the point where any cast is two samples.
    for _ in 0..20 {
        if out.len() <= max_samples.max(2) {
            break;
        }
        tolerance *= 2.0;
        out = thin(profile, tolerance)?;
    }
    Ok(out)
}

/// Largest sound speed difference between two profiles over a depth range.
///
/// Used to check a thinning, and to decide whether two casts are different
/// enough to be worth switching between.
pub fn max_speed_difference(a: &SoundSpeedProfile, b: &SoundSpeedProfile, to_depth: f64) -> f64 {
    let mut depths: Vec<f64> = a.samples().iter().map(|s| s.depth).collect();
    depths.extend(b.samples().iter().map(|s| s.depth));
    depths.retain(|d| *d <= to_depth);
    depths.push(to_depth);
    depths
        .iter()
        .map(|d| (a.speed_at(*d) - b.speed_at(*d)).abs())
        .fold(0.0, f64::max)
}
