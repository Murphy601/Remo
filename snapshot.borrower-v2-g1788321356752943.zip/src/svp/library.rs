//! Holding several casts and choosing between them.
//!
//! A survey of any length has more than one cast, and picking the wrong one is
//! one of the few processing mistakes that leaves a signature you can see in
//! the crosslines: the outer beams of one line curl up against the next. The
//! rule used has to be recorded with the result, which is why the selection is
//! a value here and not a closure.

use crate::error::{Error, Result};
use crate::geodesy::{Ellipsoid, Geodetic};
use crate::time::Timestamp;

use super::profile::SoundSpeedProfile;

/// A cast in the library, with what it takes to choose it.
#[derive(Debug, Clone, PartialEq)]
pub struct LibraryEntry {
    /// Name of the cast, carried through to the processing log.
    pub label: String,
    /// When the cast was taken.
    pub time: Timestamp,
    /// Where the cast was taken, when it is known.
    pub position: Option<Geodetic>,
    /// The profile.
    pub profile: SoundSpeedProfile,
}

/// How to choose a cast for a ping.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ProfileSelection {
    /// The cast closest in time, in either direction.
    NearestInTime,
    /// The most recent cast taken at or before the ping.
    ///
    /// This is the honest choice for a line being processed as it is acquired,
    /// because the later cast did not exist yet.
    PreviousInTime,
    /// The cast closest in position, falling back to time when a cast has no
    /// position at all.
    NearestInSpace,
}

/// A set of casts with a selection rule.
#[derive(Debug, Clone)]
pub struct ProfileLibrary {
    entries: Vec<LibraryEntry>,
    selection: ProfileSelection,
    ellipsoid: Ellipsoid,
}

impl ProfileLibrary {
    /// Build a library. The entries are sorted by time.
    pub fn new(mut entries: Vec<LibraryEntry>, selection: ProfileSelection) -> Result<Self> {
        if entries.is_empty() {
            return Err(Error::Config("no sound speed profiles supplied".into()));
        }
        entries.sort_by(|a, b| a.time.cmp(&b.time));
        Ok(ProfileLibrary {
            entries,
            selection,
            ellipsoid: Ellipsoid::WGS84,
        })
    }

    /// The casts, oldest first.
    pub fn entries(&self) -> &[LibraryEntry] {
        &self.entries
    }

    /// The rule this library selects by.
    pub fn selection(&self) -> ProfileSelection {
        self.selection
    }

    /// Choose a cast for a ping at a time and place.
    ///
    /// Never fails: a library cannot be empty, so there is always something to
    /// return. Whether it is a sensible thing to return is what
    /// [`ProfileLibrary::selection_gap`] is for.
    pub fn select(&self, time: Timestamp, position: Option<Geodetic>) -> &LibraryEntry {
        match (self.selection, position) {
            (ProfileSelection::NearestInSpace, Some(p)) => self.nearest_in_space(p, time),
            (ProfileSelection::PreviousInTime, _) => self.previous_in_time(time),
            _ => self.nearest_in_time(time),
        }
    }

    fn nearest_in_time(&self, time: Timestamp) -> &LibraryEntry {
        self.entries
            .iter()
            .min_by(|a, b| (a.time - time).abs().total_cmp(&(b.time - time).abs()))
            .expect("library is never empty")
    }

    fn previous_in_time(&self, time: Timestamp) -> &LibraryEntry {
        // Before the first cast there is nothing earlier to use, so the first
        // one stands in. Saying so in the log is better than refusing to
        // process the run in to the line.
        self.entries
            .iter()
            .rev()
            .find(|e| e.time <= time)
            .unwrap_or(&self.entries[0])
    }

    fn nearest_in_space(&self, position: Geodetic, time: Timestamp) -> &LibraryEntry {
        let mut best: Option<(&LibraryEntry, f64)> = None;
        for e in &self.entries {
            let Some(p) = e.position else { continue };
            let d = self.approximate_distance(position, p);
            if best.map(|(_, bd)| d < bd).unwrap_or(true) {
                best = Some((e, d));
            }
        }
        match best {
            Some((e, _)) => e,
            None => self.nearest_in_time(time),
        }
    }

    /// Plane distance between two positions, good enough to rank casts.
    ///
    /// Casts are tens of kilometres apart at most and only their order
    /// matters, so this stays out of the geodesic solver.
    fn approximate_distance(&self, a: Geodetic, b: Geodetic) -> f64 {
        let mid = crate::units::Angle::from_radians((a.lat.radians() + b.lat.radians()) / 2.0);
        let dn =
            (b.lat.degrees() - a.lat.degrees()) * self.ellipsoid.metres_per_degree_latitude(mid);
        let de = a.lon.delta_to(b.lon).degrees() * self.ellipsoid.metres_per_degree_longitude(mid);
        (dn * dn + de * de).sqrt()
    }

    /// How far the chosen cast is from the ping, in seconds and in metres.
    ///
    /// The quality report quotes both. A cast six hours and forty kilometres
    /// away is still the nearest one and still worth flagging.
    pub fn selection_gap(&self, time: Timestamp, position: Option<Geodetic>) -> (f64, Option<f64>) {
        let entry = self.select(time, position);
        let dt = (time - entry.time).abs();
        let dx = match (position, entry.position) {
            (Some(a), Some(b)) => Some(self.approximate_distance(a, b)),
            _ => None,
        };
        (dt, dx)
    }
}
