//! Sound velocity profiles: reading them, describing them, and the empirical
//! equations that turn a conductivity, temperature and depth cast into one.

pub mod cast;
pub mod compare;
pub mod equations;
pub mod extend;
pub mod library;
pub mod parse;
pub mod profile;
pub mod thin;

pub use cast::{CtdCast, CtdSample};
pub use compare::{compare_casts, CastComparison};
pub use equations::SoundSpeedEquation;
pub use extend::{extend_to, extend_to_surface, Extension};
pub use library::{LibraryEntry, ProfileLibrary, ProfileSelection};
pub use parse::{parse_svp, read_svp_file, ProfileRecord};
pub use profile::{Sample, SoundSpeedProfile};
pub use thin::{thin, thin_to_count};
