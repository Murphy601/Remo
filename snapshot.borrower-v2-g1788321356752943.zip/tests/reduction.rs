//! End to end reduction of a ping, in water simple enough to check by hand.

use approx::assert_relative_eq;
use plumbline::geodesy::{Ellipsoid, Geodetic};
use plumbline::motion::attitude::{Attitude, LeverArm};
use plumbline::motion::vessel::VesselGeometry;
use plumbline::ping::beam::{Beam, BeamFlags, Detection};
use plumbline::ping::record::{Navigation, Ping};
use plumbline::ping::reduce::{beam_direction, refract_at_face, Reducer};
use plumbline::svp::profile::{Sample, SoundSpeedProfile};
use plumbline::time::Timestamp;
use plumbline::tpu::sensors::UncertaintyBudget;
use plumbline::units::Angle;
use plumbline::vertical::draft::DraftModel;
use plumbline::vertical::reference::VerticalReference;
use plumbline::vertical::tide::{TideGauge, TideModel};

const SPEED: f64 = 1500.0;
const DRAFT: f64 = 2.0;

fn profile() -> SoundSpeedProfile {
    SoundSpeedProfile::new(vec![Sample::new(0.0, SPEED), Sample::new(3000.0, SPEED)]).unwrap()
}

fn flat_tide(level: f64) -> VerticalReference {
    let gauge = TideGauge::new(
        "flat",
        Geodetic::from_degrees(69.0, 33.0, 0.0),
        vec![
            (Timestamp::from_unix_seconds(0.0), level),
            (Timestamp::from_unix_seconds(100_000.0), level),
        ],
        200_000.0,
    )
    .unwrap();
    VerticalReference::Tide {
        model: Box::new(TideModel::single_gauge(gauge).unwrap()),
        zone: "whole survey".into(),
    }
}

fn vessel() -> VesselGeometry {
    let mut v = VesselGeometry::identity("launch");
    v.waterline_to_transducer = DRAFT;
    v
}

fn ping_with(angles: &[f64], two_way_time: f64, attitude: Attitude) -> Ping {
    let beams: Vec<Beam> = angles
        .iter()
        .enumerate()
        .map(|(i, a)| {
            let mut b = Beam::new(i as u16, two_way_time, Angle::from_degrees(*a));
            b.detection = Detection::Amplitude;
            b
        })
        .collect();
    let mut ping = Ping::new(Timestamp::from_unix_seconds(50_000.0), 17, SPEED, beams);
    ping.navigation = Some(Navigation {
        position: Geodetic::from_degrees(69.0, 33.0, 0.0),
        attitude,
        heave: 0.0,
        speed: 3.0,
        transducer_height: None,
    });
    ping
}

/// A budget of all zeros, so the geometry assertions in this file are not
/// entangled with the uncertainty model.
const QUIET: UncertaintyBudget = UncertaintyBudget::ZERO;

fn reducer<'a>(
    v: &'a VesselGeometry,
    p: &'a SoundSpeedProfile,
    vert: &'a VerticalReference,
    d: &'a DraftModel,
) -> Reducer<'a> {
    Reducer {
        vessel: v,
        profile: p,
        vertical: vert,
        draft: d,
        ellipsoid: Ellipsoid::WGS84,
        budget: &QUIET,
        order: None,
        table: None,
    }
}

#[test]
fn a_nadir_beam_in_flat_water_gives_the_obvious_depth() {
    let v = vessel();
    let p = profile();
    let vert = flat_tide(0.0);
    let d = DraftModel::fixed(DRAFT).unwrap();
    let r = reducer(&v, &p, &vert, &d);

    let ping = ping_with(&[0.0], 0.08, Attitude::LEVEL);
    let out = r.reduce(&ping).unwrap();
    assert_eq!(out.len(), 1);
    let s = out[0];
    assert!(s.is_accepted());
    // Half the two way time, at 1500 m/s, plus the draft.
    assert_relative_eq!(s.depth, SPEED * 0.04 + DRAFT, epsilon = 1.0e-6);
    assert_relative_eq!(s.across, 0.0, epsilon = 1.0e-6);
    assert_relative_eq!(s.along, 0.0, epsilon = 1.0e-6);
    assert_eq!(s.ping, 17);
    assert_eq!(s.beam, 0);
}

#[test]
fn a_forty_five_degree_beam_is_as_far_out_as_it_is_deep() {
    let v = vessel();
    let p = profile();
    let vert = flat_tide(0.0);
    let d = DraftModel::fixed(DRAFT).unwrap();
    let r = reducer(&v, &p, &vert, &d);

    let out = r
        .reduce(&ping_with(&[45.0, -45.0], 0.1, Attitude::LEVEL))
        .unwrap();
    let stbd = out[0];
    let port = out[1];
    let below_transducer = SPEED * 0.05 / 2.0_f64.sqrt();
    assert_relative_eq!(stbd.depth, below_transducer + DRAFT, epsilon = 1.0e-6);
    assert_relative_eq!(stbd.across, below_transducer, epsilon = 1.0e-3);
    assert_relative_eq!(port.across, -below_transducer, epsilon = 1.0e-3);
    assert_relative_eq!(stbd.depth, port.depth, epsilon = 1.0e-9);
}

#[test]
fn the_tide_lifts_every_depth_by_the_same_amount() {
    let v = vessel();
    let p = profile();
    let d = DraftModel::fixed(DRAFT).unwrap();
    let low = flat_tide(0.0);
    let high = flat_tide(1.4);
    let ping = ping_with(&[0.0, 30.0], 0.06, Attitude::LEVEL);

    let a = reducer(&v, &p, &low, &d).reduce(&ping).unwrap();
    let b = reducer(&v, &p, &high, &d).reduce(&ping).unwrap();
    for (x, y) in a.iter().zip(b.iter()) {
        assert_relative_eq!(x.depth - y.depth, 1.4, epsilon = 1.0e-9);
        assert_relative_eq!(x.across, y.across, epsilon = 1.0e-9);
    }
}

#[test]
fn rolling_the_vessel_swings_the_swath() {
    let v = vessel();
    let p = profile();
    let vert = flat_tide(0.0);
    let d = DraftModel::fixed(DRAFT).unwrap();
    let r = reducer(&v, &p, &vert, &d);

    let level = r.reduce(&ping_with(&[0.0], 0.1, Attitude::LEVEL)).unwrap()[0];
    let rolled = r
        .reduce(&ping_with(
            &[0.0],
            0.1,
            Attitude::from_degrees(10.0, 0.0, 0.0),
        ))
        .unwrap()[0];
    // Starboard down rotates the whole body frame that way, and the down
    // axis with it, so the nadir beam swings to port and not to starboard.
    // This is the sign everybody gets backwards at least once.
    assert!(rolled.across < 0.0, "across {}", rolled.across);
    let slant = SPEED * 0.05;
    assert_relative_eq!(
        rolled.across,
        -slant * 10.0_f64.to_radians().sin(),
        epsilon = 1.0e-3
    );
    assert_relative_eq!(
        rolled.depth,
        slant * 10.0_f64.to_radians().cos() + DRAFT,
        epsilon = 1.0e-6
    );
    assert!(rolled.depth < level.depth);
}

#[test]
fn heading_rotates_the_across_track_axis_and_not_the_depth() {
    let v = vessel();
    let p = profile();
    let vert = flat_tide(0.0);
    let d = DraftModel::fixed(DRAFT).unwrap();
    let r = reducer(&v, &p, &vert, &d);

    let north = r
        .reduce(&ping_with(&[40.0], 0.09, Attitude::LEVEL))
        .unwrap()[0];
    let east = r
        .reduce(&ping_with(
            &[40.0],
            0.09,
            Attitude::from_degrees(0.0, 0.0, 90.0),
        ))
        .unwrap()[0];
    assert_relative_eq!(north.depth, east.depth, epsilon = 1.0e-9);
    assert_relative_eq!(north.across, east.across, epsilon = 1.0e-6);
    // The one steaming east puts its starboard soundings to the south.
    assert!(east.position.lat.degrees() < north.position.lat.degrees());
    assert!(north.position.lon.degrees() > east.position.lon.degrees());
}

#[test]
fn beams_without_a_detection_come_back_flagged_not_missing() {
    let v = vessel();
    let p = profile();
    let vert = flat_tide(0.0);
    let d = DraftModel::fixed(DRAFT).unwrap();
    let r = reducer(&v, &p, &vert, &d);

    let mut ping = ping_with(&[0.0, 20.0, -20.0], 0.07, Attitude::LEVEL);
    ping.beams[1].detection = Detection::None;
    ping.limit_swath(Angle::from_degrees(10.0));

    let out = r.reduce(&ping).unwrap();
    assert_eq!(out.len(), 3);
    assert!(out[0].is_accepted());
    assert!(!out[1].is_accepted());
    assert!(out[2].flags.has(BeamFlags::OUTSIDE_SWATH));
    assert_eq!(out[2].depth, 0.0);
}

#[test]
fn a_ping_with_no_navigation_reduces_to_nothing_usable() {
    let v = vessel();
    let p = profile();
    let vert = flat_tide(0.0);
    let d = DraftModel::fixed(DRAFT).unwrap();
    let mut ping = ping_with(&[0.0, 10.0], 0.05, Attitude::LEVEL);
    ping.navigation = None;
    let out = reducer(&v, &p, &vert, &d).reduce(&ping).unwrap();
    assert_eq!(out.len(), 2);
    assert!(out.iter().all(|s| s.flags.has(BeamFlags::NO_NAVIGATION)));
}

#[test]
fn the_face_refraction_bends_towards_the_slower_water() {
    let pointing = Angle::from_degrees(60.0);
    // Profile slower than the sensor: the ray leaves at a smaller angle.
    let bent = refract_at_face(pointing, 1500.0, 1480.0).unwrap();
    assert!(bent.degrees() < 60.0);
    assert_relative_eq!(
        bent.sin() / 1480.0,
        pointing.sin() / 1500.0,
        epsilon = 1.0e-15
    );
    // Equal speeds change nothing.
    assert_relative_eq!(
        refract_at_face(pointing, 1500.0, 1500.0).unwrap().degrees(),
        60.0,
        epsilon = 1.0e-12
    );
    // A wide beam into much faster water has nowhere to go.
    assert!(refract_at_face(Angle::from_degrees(80.0), 1450.0, 1600.0).is_none());
}

#[test]
fn beam_direction_puts_a_level_nadir_beam_straight_down() {
    let v = vessel();
    let nav = Navigation::stationary(Geodetic::from_degrees(69.0, 33.0, 0.0));
    let d = beam_direction(&Beam::new(0, 0.1, Angle::ZERO), &nav, &v);
    assert_relative_eq!(d.from_vertical.degrees(), 0.0, epsilon = 1.0e-12);

    let stbd = beam_direction(&Beam::new(1, 0.1, Angle::from_degrees(30.0)), &nav, &v);
    assert_relative_eq!(stbd.from_vertical.degrees(), 30.0, epsilon = 1.0e-12);
    assert_relative_eq!(stbd.azimuth.degrees(), 90.0, epsilon = 1.0e-12);

    let port = beam_direction(&Beam::new(2, 0.1, Angle::from_degrees(-30.0)), &nav, &v);
    assert_relative_eq!(port.from_vertical.degrees(), 30.0, epsilon = 1.0e-12);
    assert_relative_eq!(port.azimuth.degrees(), 270.0, epsilon = 1.0e-12);
}

#[test]
fn a_transducer_offset_moves_the_whole_swath() {
    let mut v = vessel();
    v.transducer = LeverArm::new(4.0, 0.0, 0.0);
    let p = profile();
    let vert = flat_tide(0.0);
    let d = DraftModel::fixed(DRAFT).unwrap();
    let out = reducer(&v, &p, &vert, &d)
        .reduce(&ping_with(&[0.0], 0.06, Attitude::LEVEL))
        .unwrap();
    // Four metres forward of the reference point, on a northbound heading.
    assert_relative_eq!(out[0].along, 4.0, epsilon = 1.0e-3);
    assert_relative_eq!(out[0].across, 0.0, epsilon = 1.0e-6);
}
