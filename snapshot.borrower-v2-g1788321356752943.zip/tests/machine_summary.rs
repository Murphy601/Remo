//! The machine readable summary: is it well formed, and does it say the same
//! thing as the text report.

mod common;

use common::TempDir;
use plumbline::config::survey::SurveyConfig;
use plumbline::geodesy::utm::{Projected, TransverseMercator};
use plumbline::geodesy::Ellipsoid;
use plumbline::grid::estimator::{render, Estimator};
use plumbline::grid::geometry::GridGeometry;
use plumbline::grid::surface::Surface;
use plumbline::pipeline::survey::{summarise, SurveySummary};
use plumbline::qc::machine::summary_json;

const CONFIG: &str = r#"
[survey]
name = "berth 4, north end"
utm_zone = 36

[vessel]
name = "launch \"tri\""

[grid]
cell_size = 0.5
"#;

/// A structural check on a JSON document: balanced braces and brackets,
/// balanced quotes with escapes honoured, and no trailing comma before a
/// closing bracket. Enough to catch every way a hand written writer breaks.
fn well_formed(text: &str) -> Result<(), String> {
    let mut stack = Vec::new();
    let mut in_string = false;
    let mut escaped = false;
    let mut previous_meaningful = ' ';

    for (i, c) in text.char_indices() {
        if in_string {
            if escaped {
                escaped = false;
            } else if c == '\\' {
                escaped = true;
            } else if c == '"' {
                in_string = false;
            }
            continue;
        }
        match c {
            '"' => in_string = true,
            '{' | '[' => stack.push(c),
            '}' | ']' => {
                if previous_meaningful == ',' {
                    return Err(format!("trailing comma before {c} at byte {i}"));
                }
                match (stack.pop(), c) {
                    (Some('{'), '}') | (Some('['), ']') => {}
                    (open, _) => return Err(format!("{open:?} closed by {c} at byte {i}")),
                }
            }
            _ => {}
        }
        if !c.is_whitespace() {
            previous_meaningful = c;
        }
    }
    if in_string {
        return Err("the document ends inside a string".into());
    }
    if !stack.is_empty() {
        return Err(format!("{} brackets left open", stack.len()));
    }
    Ok(())
}

fn summary_for(config: &SurveyConfig) -> (SurveySummary, Surface) {
    let geometry = GridGeometry::new(500_000.0, 7_650_000.0, config.cell_size, 8, 8).unwrap();
    let projection = TransverseMercator::utm(36, true, Ellipsoid::WGS84).unwrap();
    let mut surface = Surface::new(geometry, projection);
    surface.add_at(Projected::new(500_001.0, 7_650_001.0), 12.5, 0.2);
    let summary = summarise(&[], &surface, config, Estimator::Shoalest);
    let _ = render(&surface, Estimator::Shoalest);
    (summary, surface)
}

#[test]
fn the_checker_itself_rejects_what_it_should() {
    assert!(well_formed("{}").is_ok());
    assert!(well_formed("{\"a\": [1, 2]}").is_ok());
    assert!(well_formed("{\"a\": \"}\"}").is_ok());
    assert!(well_formed("{").is_err());
    assert!(well_formed("{]").is_err());
    assert!(well_formed("[1, 2,]").is_err());
    assert!(well_formed("{\"a\": \"unclosed}").is_err());
}

#[test]
fn the_summary_is_well_formed_json() {
    let config = SurveyConfig::parse(CONFIG).unwrap();
    let (summary, _) = summary_for(&config);
    let json = summary_json(&summary, &[], &config, &[]);
    well_formed(&json).expect("the summary should be well formed");
    assert!(json.contains("\"lines\": 0"));
    assert!(json.contains("\"features\": ["));
    assert!(json.contains("\"order\": null"));
}

#[test]
fn quotes_in_a_name_are_escaped() {
    let config = SurveyConfig::parse(CONFIG).unwrap();
    let (summary, _) = summary_for(&config);
    let json = summary_json(&summary, &[], &config, &[]);
    well_formed(&json).expect("a quoted vessel name should not break it");
    assert!(json.contains("launch"));
    assert!(json.contains("\\\"tri\\\""), "{json}");
}

#[test]
fn a_name_full_of_backslashes_survives() {
    let text = CONFIG.replace("berth 4, north end", "C:\\surveys\\berth 4");
    let config = SurveyConfig::parse(&text).unwrap();
    let (summary, _) = summary_for(&config);
    let json = summary_json(&summary, &[], &config, &[]);
    well_formed(&json).expect("a windows path should not break it");
    assert!(json.contains("surveys"));
}

#[test]
fn an_empty_survey_writes_nulls_rather_than_nans() {
    let config = SurveyConfig::parse(CONFIG).unwrap();
    let geometry = GridGeometry::new(0.0, 0.0, 1.0, 4, 4).unwrap();
    let projection = TransverseMercator::utm(36, true, Ellipsoid::WGS84).unwrap();
    let empty = Surface::new(geometry, projection);
    let summary = summarise(&[], &empty, &config, Estimator::Shoalest);
    let json = summary_json(&summary, &[], &config, &[]);
    well_formed(&json).expect("an empty survey should still be json");
    assert!(!json.contains("NaN"), "{json}");
    assert!(!json.contains("inf"), "{json}");
}

#[test]
fn the_reduce_command_writes_it() {
    let dir = TempDir::new("json");
    let config = dir.join("survey.toml");
    let svp = dir.join("casts.svp");
    let tide = dir.join("gauge.tide");
    std::fs::write(
        &config,
        "[survey]\nname = \"json demo\"\norder = \"order 1\"\nutm_zone = 36\n\n[vessel]\ndraft = 1.8\n\n[grid]\ncell_size = 1.0\n",
    )
    .unwrap();
    std::fs::write(
        &svp,
        "[SVP_VERSION_2]\nx.svp\nSection 2025-146 07:30:00 69:00:00 033:00:00\n0.0 1500.0\n150.0 1500.0\n",
    )
    .unwrap();
    std::fs::write(
        &tide,
        "# gauge demo 69.0 33.0\n2025-05-26T00:00:00Z 0.000\n2025-05-27T00:00:00Z 0.000\n",
    )
    .unwrap();

    let exe = env!("CARGO_BIN_EXE_plumbline");
    let pbf = dir.join("line.pbf");
    let xyz = dir.join("line.xyz");
    let txt = dir.join("report.txt");
    let json = dir.join("summary.json");
    assert!(std::process::Command::new(exe)
        .args(["simulate", &pbf.to_string_lossy(), "--pings", "30"])
        .status()
        .unwrap()
        .success());

    let output = std::process::Command::new(exe)
        .args([
            "reduce",
            &pbf.to_string_lossy(),
            "--config",
            &config.to_string_lossy(),
            "--svp",
            &svp.to_string_lossy(),
            "--tide",
            &tide.to_string_lossy(),
            "--out",
            &xyz.to_string_lossy(),
            "--report",
            &txt.to_string_lossy(),
            "--json",
            &json.to_string_lossy(),
        ])
        .output()
        .unwrap();
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );

    let text = std::fs::read_to_string(&json).unwrap();
    well_formed(&text).expect("the tool should write well formed json");
    assert!(text.contains("\"survey\": \"json demo\""));
    assert!(text.contains("\"order\": \"order 1\""));
    assert!(text.contains("\"lines\": 1"));

    // And it agrees with the text report about the acceptance rate.
    let report = std::fs::read_to_string(&txt).unwrap();
    assert!(report.contains("100.0%"));
    assert!(text.contains("\"acceptance_rate\": 1.000000"));
}
