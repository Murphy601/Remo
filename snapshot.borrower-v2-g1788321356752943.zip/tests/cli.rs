//! The command line tool, run as a process, and the argument parser under it.

mod common;

use std::process::Command;

use common::TempDir;
use plumbline::cli::args::{Args, Spec};

const EXE: &str = env!("CARGO_BIN_EXE_plumbline");

const CONFIG: &str = r#"
[survey]
name = "cli demo"
order = "order 1"
utm_zone = 36

[vessel]
name = "demo launch"
draft = 1.8

[grid]
cell_size = 1.0

[cleaning]
min_depth = 2.0
max_depth = 80.0
"#;

const SVP: &str = "\
[SVP_VERSION_2]
/demo/demo.svp
Section 2025-146 07:30:00 69:00:00 033:00:00
0.000000 1500.000000
150.000000 1500.000000
";

const TIDE: &str = "\
# gauge demo 69.0 33.0
2025-05-26T00:00:00Z 0.000
2025-05-27T00:00:00Z 0.000
";

struct Run {
    status: i32,
    stdout: String,
    stderr: String,
}

fn run(arguments: &[&str]) -> Run {
    let output = Command::new(EXE)
        .args(arguments)
        .output()
        .expect("could not run the tool");
    Run {
        status: output.status.code().unwrap_or(-1),
        stdout: String::from_utf8_lossy(&output.stdout).to_string(),
        stderr: String::from_utf8_lossy(&output.stderr).to_string(),
    }
}

fn survey_files(dir: &TempDir) -> (String, String, String) {
    let config = dir.join("survey.toml");
    let svp = dir.join("casts.svp");
    let tide = dir.join("gauge.tide");
    std::fs::write(&config, CONFIG).unwrap();
    std::fs::write(&svp, SVP).unwrap();
    std::fs::write(&tide, TIDE).unwrap();
    (
        config.to_string_lossy().to_string(),
        svp.to_string_lossy().to_string(),
        tide.to_string_lossy().to_string(),
    )
}

#[test]
fn with_no_arguments_it_prints_the_usage() {
    let r = run(&[]);
    assert_eq!(r.status, 0);
    assert!(r.stdout.contains("usage: plumbline"));
    assert!(r.stdout.contains("simulate"));
}

#[test]
fn an_unknown_command_is_an_error_with_the_usage() {
    let r = run(&["dredge"]);
    assert_eq!(r.status, 2);
    assert!(r.stderr.contains("no command called dredge"));
}

#[test]
fn help_for_one_command_describes_that_command() {
    let r = run(&["reduce", "--help"]);
    assert_eq!(r.status, 0);
    assert!(r.stdout.contains("plumbline reduce"));
    assert!(r.stdout.contains("--svp"));
}

#[test]
fn the_whole_chain_runs_and_gives_back_the_seabed_it_was_given() {
    let dir = TempDir::new("cli");
    let (config, svp, tide) = survey_files(&dir);
    let pbf = dir.join("line.pbf").to_string_lossy().to_string();
    let xyz = dir.join("line.xyz").to_string_lossy().to_string();
    let asc = dir.join("surface.asc").to_string_lossy().to_string();

    let sim = run(&[
        "simulate", &pbf, "--pings", "40", "--depth", "25", "--beams", "41",
    ]);
    assert_eq!(sim.status, 0, "{}", sim.stderr);
    assert!(sim.stdout.contains("40 pings"));

    let info = run(&["info", &pbf, "--full"]);
    assert_eq!(info.status, 0, "{}", info.stderr);
    assert!(info.stdout.contains("40 pings"));
    assert!(info.stdout.contains("1640 beams"));

    let reduce = run(&[
        "reduce", &pbf, "--config", &config, "--svp", &svp, "--tide", &tide, "--out", &xyz,
    ]);
    assert_eq!(reduce.status, 0, "{}", reduce.stderr);
    // Twenty five metres below the transducer plus one point eight of draft.
    assert!(
        reduce.stdout.contains("26.8 to 26.8 m"),
        "{}",
        reduce.stdout
    );
    assert!(reduce.stdout.contains("1640 soundings kept"));

    let grid = run(&["grid", &xyz, "--cell", "1.0", "--out", &asc]);
    assert_eq!(grid.status, 0, "{}", grid.stderr);
    assert!(grid.stdout.contains("by shoalest"));
    assert!(grid.stdout.contains("26.80 to 26.80"));

    let compared = run(&["compare", &asc, &asc, "--order", "order 1"]);
    assert_eq!(compared.status, 0, "{}", compared.stderr);
    assert!(compared.stdout.contains("mean difference +0.000 m"));
    assert!(compared.stdout.contains("100.0% of cells"));
}

#[test]
fn a_sloping_seabed_comes_back_sloping() {
    let dir = TempDir::new("cli");
    let (config, svp, tide) = survey_files(&dir);
    let pbf = dir.join("slope.pbf").to_string_lossy().to_string();
    let xyz = dir.join("slope.xyz").to_string_lossy().to_string();

    let sim = run(&[
        "simulate", &pbf, "--pings", "20", "--depth", "30", "--slope", "10",
    ]);
    assert_eq!(sim.status, 0, "{}", sim.stderr);

    let reduce = run(&[
        "reduce", &pbf, "--config", &config, "--svp", &svp, "--tide", &tide, "--out", &xyz,
    ]);
    assert_eq!(reduce.status, 0, "{}", reduce.stderr);
    let text = std::fs::read_to_string(&xyz).unwrap();
    let depths: Vec<f64> = text
        .lines()
        .filter(|l| !l.starts_with('#'))
        .filter_map(|l| l.split_whitespace().nth(2))
        .filter_map(|d| d.parse().ok())
        .collect();
    let shallow = depths.iter().cloned().fold(f64::INFINITY, f64::min);
    let deep = depths.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
    // Ten degrees across a swath sixty degrees either side of nadir.
    assert!(deep - shallow > 15.0, "{shallow} to {deep}");
}

#[test]
fn a_missing_file_fails_with_a_message_naming_it() {
    let dir = TempDir::new("cli");
    let (config, svp, tide) = survey_files(&dir);
    let missing = dir.join("nothing.pbf").to_string_lossy().to_string();
    let r = run(&[
        "reduce", &missing, "--config", &config, "--svp", &svp, "--tide", &tide,
    ]);
    assert_eq!(r.status, 1);
    assert!(r.stderr.contains("nothing.pbf"), "{}", r.stderr);
}

#[test]
fn a_mistyped_option_is_refused() {
    let dir = TempDir::new("cli");
    let pbf = dir.join("x.pbf").to_string_lossy().to_string();
    let r = run(&["simulate", &pbf, "--dpeth", "20"]);
    assert_eq!(r.status, 1);
    assert!(r.stderr.contains("unknown option --dpeth"), "{}", r.stderr);
}

#[test]
fn the_parser_takes_both_forms_of_an_option() {
    let a = Args::parse(["reduce", "--config=x.toml", "--svp", "y.svp", "file.pbf"]).unwrap();
    assert_eq!(a.command.as_deref(), Some("reduce"));
    assert_eq!(a.positional, vec!["file.pbf".to_string()]);
    assert_eq!(a.value("config").unwrap(), "x.toml");
    assert_eq!(a.value("svp").unwrap(), "y.svp");
    assert!(a.value("tide").is_err());
    assert_eq!(a.value_or("tide", "none"), "none");
}

#[test]
fn a_lone_option_name_is_a_flag() {
    let a = Args::parse(["grid", "--south", "--cell", "2.0", "in.xyz"]).unwrap();
    assert!(a.flag("south"));
    assert!(!a.flag("north"));
    assert_eq!(a.number("cell").unwrap(), 2.0);
    assert_eq!(a.number_or("missing", 7.0).unwrap(), 7.0);
    assert!(a.has("cell"));
}

#[test]
fn the_spec_catches_what_a_command_does_not_take() {
    let spec = Spec::new()
        .option("cell")
        .flag("south")
        .positional(1, Some(2));
    assert!(Args::parse(["grid", "--cell", "1", "a"])
        .unwrap()
        .check(&spec)
        .is_ok());
    assert!(Args::parse(["grid", "--cel", "1", "a"])
        .unwrap()
        .check(&spec)
        .is_err());
    assert!(Args::parse(["grid", "--south=yes", "a"])
        .unwrap()
        .check(&spec)
        .is_err());
    assert!(Args::parse(["grid"]).unwrap().check(&spec).is_err());
    assert!(Args::parse(["grid", "--cell", "1", "a", "b", "c"])
        .unwrap()
        .check(&spec)
        .is_err());
}

#[test]
fn a_number_that_is_not_a_number_says_so() {
    let a = Args::parse(["grid", "--cell", "wide"]).unwrap();
    let err = a.number("cell").unwrap_err();
    assert!(format!("{err}").contains("--cell"));
    assert!(Args::parse(["grid", "--"]).is_err());
}

#[test]
fn the_reduce_command_can_write_a_report() {
    let dir = TempDir::new("cli");
    let (config, svp, tide) = survey_files(&dir);
    let pbf = dir.join("line.pbf").to_string_lossy().to_string();
    let xyz = dir.join("line.xyz").to_string_lossy().to_string();
    let txt = dir.join("report.txt").to_string_lossy().to_string();

    assert_eq!(
        run(&["simulate", &pbf, "--pings", "30", "--depth", "20"]).status,
        0
    );
    let r = run(&[
        "reduce", &pbf, "--config", &config, "--svp", &svp, "--tide", &tide, "--out", &xyz,
        "--report", &txt,
    ]);
    assert_eq!(r.status, 0, "{}", r.stderr);
    assert!(r.stdout.contains("100.0% kept"));

    let report = std::fs::read_to_string(&txt).unwrap();
    assert!(report.contains("survey: cli demo"));
    assert!(report.contains("lines reduced: 1"));
    assert!(report.contains("21.80 to 21.80 m"));
    assert!(report.contains("shoal biased"));
    assert!(report.contains("by line:"));
}

#[test]
fn an_unknown_estimator_is_refused_by_name() {
    let dir = TempDir::new("cli");
    let (config, svp, tide) = survey_files(&dir);
    let pbf = dir.join("line.pbf").to_string_lossy().to_string();
    let xyz = dir.join("line.xyz").to_string_lossy().to_string();
    let txt = dir.join("report.txt").to_string_lossy().to_string();
    assert_eq!(run(&["simulate", &pbf, "--pings", "10"]).status, 0);
    let r = run(&[
        "reduce",
        &pbf,
        "--config",
        &config,
        "--svp",
        &svp,
        "--tide",
        &tide,
        "--out",
        &xyz,
        "--report",
        &txt,
        "--estimator",
        "guess",
    ]);
    assert_eq!(r.status, 1);
    assert!(
        r.stderr.contains("no estimator called guess"),
        "{}",
        r.stderr
    );
}

#[test]
fn the_plan_command_lays_lines_over_a_rectangle() {
    let dir = TempDir::new("cli");
    let out = dir.join("lines.txt").to_string_lossy().to_string();
    let r = run(&[
        "plan",
        "--rect",
        "500000,7650000,500600,7651000",
        "--depth",
        "20",
        "--out",
        &out,
    ]);
    assert_eq!(r.status, 0, "{}", r.stderr);
    assert!(r.stdout.contains("hectares"));
    assert!(r.stdout.contains("on line"));

    let text = std::fs::read_to_string(&out).unwrap();
    let lines: Vec<&str> = text.lines().filter(|l| !l.starts_with('#')).collect();
    assert!(!lines.is_empty());
    assert_eq!(lines[0].split_whitespace().count(), 5);
}

#[test]
fn planning_needs_either_a_spacing_or_a_depth() {
    let r = run(&["plan", "--rect", "0,0,1000,1000"]);
    assert_eq!(r.status, 1);
    assert!(r.stderr.contains("--spacing"), "{}", r.stderr);
}

#[test]
fn the_report_lists_features_when_asked() {
    let dir = TempDir::new("cli");
    let (config, svp, tide) = survey_files(&dir);
    let pbf = dir.join("features.pbf").to_string_lossy().to_string();
    let xyz = dir.join("features.xyz").to_string_lossy().to_string();
    let txt = dir.join("features.txt").to_string_lossy().to_string();

    // A sloping seabed has no features on it, so the section stays out.
    assert_eq!(
        run(&["simulate", &pbf, "--pings", "60", "--depth", "25"]).status,
        0
    );
    let r = run(&[
        "reduce",
        &pbf,
        "--config",
        &config,
        "--svp",
        &svp,
        "--tide",
        &tide,
        "--out",
        &xyz,
        "--report",
        &txt,
        "--features",
    ]);
    assert_eq!(r.status, 0, "{}", r.stderr);
    let report = std::fs::read_to_string(&txt).unwrap();
    assert!(report.contains("survey: cli demo"));
    // Flat seabed, nothing standing off it.
    assert!(!report.contains("features, deepest last"), "{report}");
}
