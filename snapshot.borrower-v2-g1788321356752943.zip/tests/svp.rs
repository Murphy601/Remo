//! Sound speed equations, profile behaviour, and the file reader.

use approx::assert_relative_eq;
use plumbline::geodesy::Geodetic;
use plumbline::svp::cast::{CastWarning, CtdCast, CtdSample};
use plumbline::svp::equations::{
    bar_to_kgf_per_cm2, chen_millero, del_grosso, depth_to_pressure, mackenzie, pressure_to_depth,
    SoundSpeedEquation,
};
use plumbline::svp::parse::parse_svp;
use plumbline::svp::profile::{Sample, SoundSpeedProfile};
use plumbline::time::Timestamp;
use plumbline::units::Angle;

fn arctic_cast() -> SoundSpeedProfile {
    SoundSpeedProfile::new(vec![
        Sample::new(0.0, 1462.0),
        Sample::new(10.0, 1461.0),
        Sample::new(30.0, 1455.0),
        Sample::new(80.0, 1452.0),
        Sample::new(200.0, 1458.0),
        Sample::new(400.0, 1466.0),
    ])
    .unwrap()
}

#[test]
fn chen_millero_reproduces_the_published_table() {
    // Fresh water at the surface is the leading constant on its own.
    assert_relative_eq!(chen_millero(0.0, 0.0, 0.0), 1402.388, epsilon = 1.0e-9);
    // Two entries from the UNESCO table, which is quoted to two decimals.
    assert_relative_eq!(chen_millero(35.0, 0.0, 0.0), 1449.14, epsilon = 5.0e-3);
    assert_relative_eq!(chen_millero(35.0, 10.0, 0.0), 1489.83, epsilon = 5.0e-3);
}

#[test]
fn the_sensitivities_are_the_textbook_ones() {
    // About 4.6 m/s per degree near freezing, 1.3 m/s per practical salinity
    // unit, and 1.6 m/s for every hundred metres of depth.
    let base = chen_millero(35.0, 0.0, 0.0);
    assert_relative_eq!(chen_millero(35.0, 1.0, 0.0) - base, 4.6, epsilon = 0.1);
    assert_relative_eq!(chen_millero(36.0, 0.0, 0.0) - base, 1.34, epsilon = 0.05);
    let deeper = chen_millero(35.0, 0.0, depth_to_pressure(100.0, Angle::ZERO));
    assert_relative_eq!(deeper - base, 1.6, epsilon = 0.1);
}

#[test]
fn del_grosso_at_the_origin_is_the_salinity_terms_alone() {
    // With temperature and pressure at zero everything but the constant and
    // the two salinity terms drops out, which is a sum you can do by hand.
    let expected = 1402.392 + 1.329_530 * 35.0 + 0.128_859_8e-3 * 35.0 * 35.0;
    assert_relative_eq!(del_grosso(35.0, 0.0, 0.0), expected, epsilon = 1.0e-9);
}

#[test]
fn mackenzie_at_the_origin_is_the_leading_constant() {
    assert_relative_eq!(mackenzie(35.0, 0.0, 0.0), 1448.96, epsilon = 1.0e-9);
}

#[test]
fn the_three_equations_agree_to_a_few_decimetres() {
    let lat = Angle::from_degrees(69.0);
    for depth in [0.0, 100.0, 500.0, 2000.0] {
        let p = depth_to_pressure(depth, lat);
        let cm = chen_millero(34.8, 2.0, p);
        let dg = del_grosso(34.8, 2.0, bar_to_kgf_per_cm2(p));
        let mk = mackenzie(34.8, 2.0, depth);
        assert!((cm - dg).abs() < 0.5, "at {depth} m: {cm} against {dg}");
        assert!((cm - mk).abs() < 1.5, "at {depth} m: {cm} against {mk}");
    }
}

#[test]
fn pressure_is_about_a_bar_for_every_ten_metres() {
    let lat = Angle::from_degrees(60.0);
    let p = depth_to_pressure(1000.0, lat);
    assert!((100.0..103.0).contains(&p), "got {p} bar at 1000 m");
    assert_relative_eq!(pressure_to_depth(p, lat), 1000.0, epsilon = 1.0e-6);
}

#[test]
fn gravity_makes_pressure_depend_on_latitude() {
    let equator = depth_to_pressure(6000.0, Angle::ZERO);
    let pole = depth_to_pressure(6000.0, Angle::from_degrees(90.0));
    assert!(pole > equator);
    // Half a percent of gravity is thirty metres of apparent depth down
    // there, which is why the latitude is an argument and not a constant.
    let as_depth = pressure_to_depth(pole, Angle::ZERO) - 6000.0;
    assert!((25.0..40.0).contains(&as_depth), "got {as_depth} m");
}

#[test]
fn a_profile_needs_two_distinct_depths() {
    assert!(SoundSpeedProfile::new(vec![Sample::new(0.0, 1500.0)]).is_err());
    assert!(
        SoundSpeedProfile::new(vec![Sample::new(4.0, 1500.0), Sample::new(4.0, 1501.0)]).is_err()
    );
}

#[test]
fn implausible_speeds_are_refused_not_clamped() {
    let bad = SoundSpeedProfile::new(vec![Sample::new(0.0, 1500.0), Sample::new(10.0, 149.0)]);
    assert!(bad.is_err());
}

#[test]
fn samples_are_sorted_on_the_way_in() {
    let p = SoundSpeedProfile::new(vec![
        Sample::new(30.0, 1455.0),
        Sample::new(0.0, 1462.0),
        Sample::new(10.0, 1461.0),
    ])
    .unwrap();
    let depths: Vec<f64> = p.samples().iter().map(|s| s.depth).collect();
    assert_eq!(depths, vec![0.0, 10.0, 30.0]);
}

#[test]
fn speed_is_held_constant_outside_the_cast() {
    let p = arctic_cast();
    assert_relative_eq!(p.speed_at(-5.0), 1462.0, epsilon = 1.0e-9);
    assert_relative_eq!(p.speed_at(0.0), 1462.0, epsilon = 1.0e-9);
    assert_relative_eq!(p.speed_at(9999.0), 1466.0, epsilon = 1.0e-9);
}

#[test]
fn speed_interpolates_linearly_inside_a_layer() {
    let p = arctic_cast();
    assert_relative_eq!(p.speed_at(5.0), 1461.5, epsilon = 1.0e-9);
    assert_relative_eq!(p.speed_at(20.0), 1458.0, epsilon = 1.0e-9);
}

#[test]
fn a_depth_on_a_boundary_belongs_to_the_layer_below() {
    let p = arctic_cast();
    assert_eq!(p.layer_index(0.0), Some(0));
    assert_eq!(p.layer_index(10.0), Some(1));
    assert_eq!(p.layer_index(30.0), Some(2));
    // The deepest sample has no layer below it, so it stays in the last one.
    assert_eq!(p.layer_index(400.0), Some(4));
    assert_eq!(p.layer_index(400.1), None);
    assert_eq!(p.layer_index(-0.1), None);
}

#[test]
fn gradients_have_the_sign_of_the_speed_change() {
    let p = arctic_cast();
    assert_relative_eq!(p.gradient(0), -0.1, epsilon = 1.0e-9);
    assert_relative_eq!(p.gradient(1), -0.3, epsilon = 1.0e-9);
    assert!(p.gradient(3) > 0.0);
}

#[test]
fn the_harmonic_mean_sits_inside_the_range_of_the_cast() {
    let p = arctic_cast();
    let mean = p.harmonic_mean_speed(200.0);
    assert!((1452.0..1462.0).contains(&mean), "got {mean}");
    // A profile with one speed everywhere has that speed as its mean.
    let flat =
        SoundSpeedProfile::new(vec![Sample::new(0.0, 1480.0), Sample::new(500.0, 1480.0)]).unwrap();
    assert_relative_eq!(flat.harmonic_mean_speed(300.0), 1480.0, epsilon = 1.0e-9);
}

#[test]
fn a_cast_becomes_a_profile_that_deepens_with_pressure() {
    let cast = CtdCast::new(
        Geodetic::from_degrees(69.7, 33.1, 0.0),
        Timestamp::from_utc(2025, 2, 3, 8, 15, 0.0),
        "station 4",
        vec![
            CtdSample::new(0.0, 3.4, 34.2),
            CtdSample::new(50.0, 3.4, 34.2),
            CtdSample::new(200.0, 3.4, 34.2),
        ],
    );
    let p = cast.to_profile(SoundSpeedEquation::ChenMillero).unwrap();
    // Same water, deeper: only the pressure term moves, and it moves up.
    assert!(p.speed_at(200.0) > p.speed_at(0.0));
    assert_relative_eq!(p.speed_at(200.0) - p.speed_at(0.0), 3.3, epsilon = 0.3);
}

#[test]
fn cast_validation_reports_what_is_wrong_without_refusing_the_cast() {
    let cast = CtdCast::new(
        Geodetic::from_degrees(69.7, 33.1, 0.0),
        Timestamp::EPOCH,
        "suspect",
        vec![
            CtdSample::new(0.0, 3.4, 34.2),
            CtdSample::new(5.0, 99.0, 34.2),
            CtdSample::new(400.0, 3.0, 34.4),
        ],
    );
    let warnings = cast.validate();
    assert!(warnings
        .iter()
        .any(|w| matches!(w, CastWarning::TemperatureOutOfRange { index: 1, .. })));
    assert!(warnings
        .iter()
        .any(|w| matches!(w, CastWarning::LargeGap { .. })));
    assert!(warnings
        .iter()
        .any(|w| matches!(w, CastWarning::TooFewSamples(3))));
    // And it still reduces, because that is the surveyor to decide.
    assert!(cast.to_profile(SoundSpeedEquation::Mackenzie).is_ok());
}

#[test]
fn a_two_section_svp_file_reads_back() {
    let text = "[SVP_VERSION_2]\n\
                /survey/2025/casts.svp\n\
                Section 2025-034 08:15:00 69:42:44 033:04:59\n\
                0.000000 1462.100000\n\
                10.000000 1461.000000\n\
                80.000000 1452.400000\n\
                Section 2025-034 14:02:00 69:50:01 -033:10:00\n\
                0.000000 1463.000000\n\
                25.000000 1459.700000\n";
    let records = parse_svp(text).unwrap();
    assert_eq!(records.len(), 2);
    assert_eq!(records[0].profile.len(), 3);
    assert_relative_eq!(records[0].profile.surface_speed(), 1462.1, epsilon = 1.0e-9);

    let pos = records[0].position.unwrap();
    assert_relative_eq!(
        pos.lat.degrees(),
        69.0 + 42.0 / 60.0 + 44.0 / 3600.0,
        epsilon = 1.0e-12
    );
    assert_relative_eq!(
        pos.lon.degrees(),
        33.0 + 4.0 / 60.0 + 59.0 / 3600.0,
        epsilon = 1.0e-12
    );
    assert!(records[1].position.unwrap().lon.degrees() < 0.0);

    let t = records[0].time.unwrap().to_utc();
    assert_eq!((t.year, t.month, t.day, t.hour), (2025, 2, 3, 8));
}

#[test]
fn a_bad_banner_is_refused() {
    let text = "[SVP_VERSION_1]\n0.0 1500.0\n10.0 1500.0\n";
    assert!(parse_svp(text).is_err());
}

#[test]
fn a_section_with_one_sample_is_refused() {
    let text = "[SVP_VERSION_2]\nfile.svp\nSection 2025-001 00:00:00\n0.0 1500.0\n";
    assert!(parse_svp(text).is_err());
}
