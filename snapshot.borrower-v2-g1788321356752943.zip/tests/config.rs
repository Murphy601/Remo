//! The configuration reader, and what it refuses.

mod common;

use approx::assert_relative_eq;
use common::TempDir;
use plumbline::config::document::{Document, Value};
use plumbline::config::reader::Reader;
use plumbline::config::survey::{SurveyConfig, VerticalMode};
use plumbline::svp::equations::SoundSpeedEquation;
use plumbline::svp::library::ProfileSelection;
use plumbline::tpu::s44::Order;

const MINIMAL: &str = r#"
[survey]
name = "kola inlet 2025"
utm_zone = 36

[grid]
cell_size = 0.5
"#;

const FULL: &str = r#"
# Berth survey, april
[survey]
name = "berth 4"
order = "special"
utm_zone = 36
northern = true

[vessel]
name = "launch tri"
antenna_forward = 1.2
antenna_starboard = -0.35
antenna_down = -3.10
transducer_forward = -0.85
transducer_starboard = 0.0
transducer_down = 0.55
draft = 1.85
roll_offset = -0.42
pitch_offset = 1.03
heading_offset = 0.15
settlement_speeds = [2.0, 4.0, 6.0]
settlement_values = [0.01, 0.05, 0.14]

[sound_speed]
equation = "del-grosso"
selection = "previous in time"
thin_tolerance = 0.05

[vertical]
mode = "tide"
zone = "b2"

[grid]
cell_size = 0.25

[cleaning]
min_depth = 1.0
max_depth = 40.0
max_swath_angle = 60.0
max_deviation = 0.75

[uncertainty]
roll = 0.01
tide = 0.03
profile_sound_speed = 1.5
"#;

#[test]
fn a_minimal_config_takes_the_defaults() {
    let c = SurveyConfig::parse(MINIMAL).unwrap();
    assert_eq!(c.name, "kola inlet 2025");
    assert_eq!(c.utm_zone, 36);
    assert!(c.northern);
    assert_eq!(c.order, None);
    assert_eq!(c.equation, SoundSpeedEquation::ChenMillero);
    assert_eq!(c.profile_selection, ProfileSelection::NearestInTime);
    assert_eq!(
        c.vertical,
        VerticalMode::Tide {
            zone: "whole survey".into()
        }
    );
    assert_relative_eq!(c.cell_size, 0.5, epsilon = 1.0e-12);
    assert!(c.swath_limit.is_none());
    assert!(c.unread_keys.is_empty());
}

#[test]
fn a_full_config_comes_through_intact() {
    let c = SurveyConfig::parse(FULL).unwrap();
    assert_eq!(c.order, Some(Order::Special));
    assert_eq!(c.equation, SoundSpeedEquation::DelGrosso);
    assert_eq!(c.profile_selection, ProfileSelection::PreviousInTime);
    assert_eq!(c.vertical, VerticalMode::Tide { zone: "b2".into() });

    assert_relative_eq!(c.vessel.antenna.forward, 1.2, epsilon = 1.0e-12);
    assert_relative_eq!(c.vessel.antenna.down, -3.10, epsilon = 1.0e-12);
    assert_relative_eq!(c.vessel.transducer.forward, -0.85, epsilon = 1.0e-12);
    assert_relative_eq!(c.vessel.waterline_to_transducer, 1.85, epsilon = 1.0e-12);
    assert_relative_eq!(c.vessel.mount.roll.degrees(), -0.42, epsilon = 1.0e-12);

    assert_eq!(c.draft.table().len(), 3);
    assert_relative_eq!(c.draft.draft_at(4.0), 1.90, epsilon = 1.0e-12);

    assert_relative_eq!(c.budget.roll.degrees(), 0.01, epsilon = 1.0e-12);
    assert_relative_eq!(c.budget.tide, 0.03, epsilon = 1.0e-12);
    assert_relative_eq!(c.budget.profile_sound_speed, 1.5, epsilon = 1.0e-12);
    // Anything the file did not mention keeps its default.
    assert_relative_eq!(c.budget.position_horizontal, 0.30, epsilon = 1.0e-12);

    assert_eq!(c.swath_limit, Some(60.0));
    assert_relative_eq!(c.depth_window.0, 1.0, epsilon = 1.0e-12);
    assert_relative_eq!(c.max_deviation.unwrap(), 0.75, epsilon = 1.0e-12);
    assert!(c.unread_keys.is_empty(), "unread: {:?}", c.unread_keys);
}

#[test]
fn a_misspelled_key_is_reported_rather_than_ignored() {
    let text = format!("{MINIMAL}\n[cleaning]\nmax_swath_angel = 55.0\n");
    let c = SurveyConfig::parse(&text).unwrap();
    assert_eq!(c.unread_keys, vec!["cleaning.max_swath_angel".to_string()]);
    assert!(c.swath_limit.is_none());
}

#[test]
fn the_things_that_have_to_be_there_are_checked() {
    assert!(SurveyConfig::parse("[grid]\ncell_size = 1.0\n").is_err());
    assert!(SurveyConfig::parse("[survey]\nname = \"x\"\nutm_zone = 36\n").is_err());
    assert!(SurveyConfig::parse(
        "[survey]\nname = \"x\"\nutm_zone = 99\n\n[grid]\ncell_size = 1.0\n"
    )
    .is_err());
}

#[test]
fn a_value_of_the_wrong_kind_says_which_key() {
    let text = "[survey]\nname = 4\nutm_zone = 36\n\n[grid]\ncell_size = 1.0\n";
    let err = SurveyConfig::parse(text).unwrap_err();
    let message = format!("{err}");
    assert!(message.contains("survey.name"), "got {message}");
    assert!(message.contains("string"), "got {message}");
}

#[test]
fn a_settlement_table_with_mismatched_columns_is_refused() {
    let text = format!(
        "{MINIMAL}\n[vessel]\ndraft = 1.5\nsettlement_speeds = [1.0, 2.0]\nsettlement_values = [0.1]\n"
    );
    let err = SurveyConfig::parse(&text).unwrap_err();
    assert!(format!("{err}").contains("settlement"));
}

#[test]
fn an_unknown_vertical_mode_is_refused() {
    let text = format!("{MINIMAL}\n[vertical]\nmode = \"guesswork\"\n");
    assert!(SurveyConfig::parse(&text).is_err());
    let good = format!("{MINIMAL}\n[vertical]\nmode = \"ellipsoid\"\n");
    assert_eq!(
        SurveyConfig::parse(&good).unwrap().vertical,
        VerticalMode::Ellipsoid
    );
}

#[test]
fn a_config_reads_off_disk() {
    let dir = TempDir::new("config");
    let path = dir.join("survey.toml");
    std::fs::write(&path, FULL).unwrap();
    let c = SurveyConfig::read(&path).unwrap();
    assert_eq!(c.name, "berth 4");
    assert!(SurveyConfig::read(dir.join("nothing.toml")).is_err());
}

#[test]
fn the_document_parser_handles_the_subset_it_promises() {
    let d = Document::parse(
        "top = 1\n\n[a]\nname = \"x y\"  # trailing comment\nflag = false\nlist = [1, 2, 3]\nnames = [\"p\", \"q\"]\n",
    )
    .unwrap();
    assert_eq!(d.get("top"), Some(&Value::Number(1.0)));
    assert_eq!(d.get("a.name").unwrap().as_str(), Some("x y"));
    assert_eq!(d.get("a.flag").unwrap().as_bool(), Some(false));
    assert_eq!(d.get("a.list").unwrap().as_array().unwrap().len(), 3);
    assert_eq!(d.get("a.names").unwrap().as_array().unwrap().len(), 2);
    assert!(d.get("a.missing").is_none());
    assert!(d.contains("a.flag"));
}

#[test]
fn a_hash_inside_a_string_is_not_a_comment() {
    let d = Document::parse("[a]\npath = \"C:\\survey\\line #4.pbf\"\n").unwrap();
    assert_eq!(
        d.get("a.path").unwrap().as_str(),
        Some(r"C:\survey\line #4.pbf")
    );
}

#[test]
fn the_document_parser_refuses_what_it_cannot_read() {
    assert!(Document::parse("[unclosed\n").is_err());
    assert!(Document::parse("[]\n").is_err());
    assert!(Document::parse("no equals sign\n").is_err());
    assert!(Document::parse("= 4\n").is_err());
    assert!(Document::parse("k = \n").is_err());
    assert!(Document::parse("k = \"unclosed\n").is_err());
    assert!(Document::parse("k = [1, 2\n").is_err());
    assert!(Document::parse("k = not_a_value\n").is_err());
    // The same key twice is a mistake, not a last one wins.
    assert!(Document::parse("[a]\nk = 1\nk = 2\n").is_err());
}

#[test]
fn the_reader_reports_range_failures_with_the_key_in_them() {
    let d = Document::parse("[a]\nangle = 400.0\n").unwrap();
    let r = Reader::new(&d);
    let err = r.number_in("a.angle", 0.0, 90.0).unwrap_err();
    assert!(format!("{err}").contains("a.angle"));
    assert!(r.number_in("a.angle", 0.0, 500.0).is_ok());
    assert!(r.unread().is_empty());
}
