//! Cleaning rules, crossline statistics and coverage.

use approx::assert_relative_eq;
use plumbline::geodesy::Geodetic;
use plumbline::grid::estimator::{DepthRaster, Estimator};
use plumbline::grid::geometry::GridGeometry;
use plumbline::ping::beam::{BeamFlags, Detection};
use plumbline::ping::sounding::{Sounding, SoundingStats};
use plumbline::qc::coverage::analyse;
use plumbline::qc::crossline::{compare, difference_raster};
use plumbline::qc::rules::{clean_ping, CleaningRules, DepthWindow};
use plumbline::time::Timestamp;
use plumbline::tpu::s44::Order;

fn sounding(depth: f64, across: f64, tvu: f64) -> Sounding {
    Sounding {
        time: Timestamp::EPOCH,
        ping: 1,
        beam: 0,
        position: Geodetic::from_degrees(69.0, 33.0, 0.0),
        depth,
        across,
        along: 0.0,
        tvu,
        thu: 1.0,
        detection: Detection::Amplitude,
        flags: BeamFlags::NONE,
    }
}

fn raster(columns: usize, rows: usize, values: Vec<Option<f64>>) -> DepthRaster {
    DepthRaster {
        columns,
        rows,
        depths: values,
        estimator: Estimator::WeightedMean,
    }
}

#[test]
fn the_depth_window_flags_what_falls_outside_it() {
    let mut soundings = vec![
        sounding(5.0, 0.0, 0.1),
        sounding(35.0, 0.0, 0.1),
        sounding(120.0, 0.0, 0.1),
    ];
    let rules = CleaningRules {
        window: DepthWindow::new(10.0, 60.0),
        ..CleaningRules::default()
    };
    let tally = clean_ping(&mut soundings, &rules);
    assert_eq!(tally.outside_window, 2);
    assert!(soundings[0].flags.has(BeamFlags::OUTSIDE_DEPTH_WINDOW));
    assert!(soundings[1].is_accepted());
    assert!(soundings[2].flags.has(BeamFlags::OUTSIDE_DEPTH_WINDOW));
    assert!(DepthWindow::ANY.contains(-1000.0));
    assert!(!DepthWindow::ANY.contains(f64::NAN));
}

#[test]
fn the_window_orders_its_ends() {
    let w = DepthWindow::new(60.0, 10.0);
    assert_relative_eq!(w.min_depth, 10.0, epsilon = 1.0e-12);
    assert_relative_eq!(w.max_depth, 60.0, epsilon = 1.0e-12);
}

#[test]
fn the_swath_limit_works_off_the_ratio_and_not_the_distance() {
    // Twenty metres out in twenty metres of water is forty five degrees.
    let mut soundings = vec![sounding(20.0, 20.0, 0.1), sounding(20.0, 5.0, 0.1)];
    let rules = CleaningRules {
        max_swath_angle: Some(30.0),
        ..CleaningRules::default()
    };
    let tally = clean_ping(&mut soundings, &rules);
    assert_eq!(tally.outside_swath, 1);
    assert!(soundings[0].flags.has(BeamFlags::OUTSIDE_SWATH));
    assert!(soundings[1].is_accepted());
}

#[test]
fn the_uncertainty_limit_catches_the_worst_soundings() {
    let mut soundings = vec![sounding(30.0, 0.0, 0.2), sounding(30.0, 0.0, 1.5)];
    let rules = CleaningRules {
        max_tvu: Some(0.5),
        ..CleaningRules::default()
    };
    let tally = clean_ping(&mut soundings, &rules);
    assert_eq!(tally.too_uncertain, 1);
    assert!(soundings[1].flags.has(BeamFlags::FAILS_ORDER));
    assert_eq!(tally.total(), 1);
}

#[test]
fn an_outlier_in_a_flat_swath_gets_caught() {
    let mut soundings: Vec<Sounding> = (0..21)
        .map(|i| sounding(30.0 + (i % 3) as f64 * 0.02, i as f64 - 10.0, 0.2))
        .collect();
    soundings[10].depth = 24.0;
    let rules = CleaningRules {
        max_deviation: Some(1.0),
        median_window: 7,
        ..CleaningRules::default()
    };
    let tally = clean_ping(&mut soundings, &rules);
    assert_eq!(tally.outlier, 1);
    assert!(soundings[10].flags.has(BeamFlags::LOW_QUALITY));
    assert!(soundings[9].is_accepted());
    assert!(soundings[11].is_accepted());
}

#[test]
fn a_steady_slope_is_not_an_outlier() {
    let mut soundings: Vec<Sounding> = (0..21)
        .map(|i| sounding(20.0 + i as f64 * 0.4, i as f64 - 10.0, 0.2))
        .collect();
    let rules = CleaningRules {
        max_deviation: Some(1.0),
        median_window: 7,
        ..CleaningRules::default()
    };
    let tally = clean_ping(&mut soundings, &rules);
    assert_eq!(tally.outlier, 0);
}

#[test]
fn cleaning_never_touches_a_sounding_that_is_already_out() {
    let mut soundings = vec![sounding(500.0, 0.0, 9.9)];
    soundings[0].flags.set(BeamFlags::MANUAL);
    let rules = CleaningRules {
        window: DepthWindow::new(0.0, 50.0),
        max_tvu: Some(0.5),
        ..CleaningRules::default()
    };
    let tally = clean_ping(&mut soundings, &rules);
    assert_eq!(tally.total(), 0);
    assert_eq!(soundings[0].flags.names(), vec!["manual"]);
}

#[test]
fn sounding_stats_ignore_the_rejected_ones() {
    let mut soundings = vec![sounding(10.0, 0.0, 0.1), sounding(1000.0, 0.0, 0.1)];
    soundings[1].flags.set(BeamFlags::LOW_QUALITY);
    let stats = SoundingStats::of(&soundings);
    assert_eq!(stats.count, 2);
    assert_eq!(stats.accepted, 1);
    assert_relative_eq!(stats.mean_depth, 10.0, epsilon = 1.0e-12);
    assert_relative_eq!(stats.max_depth, 10.0, epsilon = 1.0e-12);
    assert_relative_eq!(stats.acceptance_rate(), 0.5, epsilon = 1.0e-12);
    let empty = SoundingStats::of(&[]);
    assert_relative_eq!(empty.acceptance_rate(), 0.0, epsilon = 1.0e-12);
}

#[test]
fn a_crossline_that_is_shallow_everywhere_shows_up_as_a_mean() {
    let reference = raster(3, 2, (0..6).map(|i| Some(20.0 + i as f64)).collect());
    let check = raster(3, 2, (0..6).map(|i| Some(20.15 + i as f64)).collect());
    let c = compare(&reference, &check).unwrap();
    assert_eq!(c.matched(), 6);
    assert_relative_eq!(c.mean().unwrap(), -0.15, epsilon = 1.0e-12);
    assert_relative_eq!(c.standard_deviation().unwrap(), 0.0, epsilon = 1.0e-12);
    assert_relative_eq!(c.largest().unwrap(), 0.15, epsilon = 1.0e-12);
}

#[test]
fn a_noisy_crossline_shows_up_as_a_spread() {
    let reference = raster(4, 1, vec![Some(30.0); 4]);
    let check = raster(4, 1, vec![Some(29.6), Some(30.4), Some(29.7), Some(30.3)]);
    let c = compare(&reference, &check).unwrap();
    assert_relative_eq!(c.mean().unwrap(), 0.0, epsilon = 1.0e-12);
    assert!(c.standard_deviation().unwrap() > 0.3);
    // Nearest rank, so the ninety fifth percentile of four values is the
    // largest one.
    assert_relative_eq!(c.percentile(0.95).unwrap(), 0.4, epsilon = 1.0e-12);
    assert_relative_eq!(c.percentile(0.5).unwrap(), 0.3, epsilon = 1.0e-12);
}

#[test]
fn cells_only_one_surface_covers_are_counted_and_left_out() {
    let reference = raster(3, 1, vec![Some(10.0), Some(11.0), None]);
    let check = raster(3, 1, vec![Some(10.0), None, Some(12.0)]);
    let c = compare(&reference, &check).unwrap();
    assert_eq!(c.matched(), 1);
    assert_eq!(c.unmatched, 2);
    assert_relative_eq!(c.mean().unwrap(), 0.0, epsilon = 1.0e-12);
}

#[test]
fn compliance_against_an_order_widens_for_two_surfaces() {
    // Order 1 allows half a metre at these depths, and two surfaces compared
    // against each other get root two of that.
    let reference = raster(2, 1, vec![Some(20.0), Some(20.0)]);
    let check = raster(2, 1, vec![Some(20.6), Some(20.2)]);
    let c = compare(&reference, &check).unwrap();
    let fraction = c.fraction_within_order(Order::One).unwrap();
    assert_relative_eq!(fraction, 1.0, epsilon = 1.0e-12);

    let worse = raster(2, 1, vec![Some(22.0), Some(20.2)]);
    let d = compare(&reference, &worse).unwrap();
    assert_relative_eq!(
        d.fraction_within_order(Order::One).unwrap(),
        0.5,
        epsilon = 1.0e-12
    );
}

#[test]
fn surfaces_of_different_shapes_do_not_compare() {
    let a = raster(3, 1, vec![Some(1.0); 3]);
    let b = raster(2, 1, vec![Some(1.0); 2]);
    assert!(compare(&a, &b).is_none());
    assert!(difference_raster(&a, &b).is_none());
}

#[test]
fn the_difference_raster_keeps_the_holes() {
    let a = raster(2, 1, vec![Some(10.0), Some(11.0)]);
    let b = raster(2, 1, vec![Some(10.5), None]);
    let d = difference_raster(&a, &b).unwrap();
    assert_relative_eq!(d.at(0, 0).unwrap(), -0.5, epsilon = 1.0e-12);
    assert!(d.at(1, 0).is_none());
}

#[test]
fn coverage_finds_an_interior_hole_and_measures_it() {
    let geometry = GridGeometry::new(0.0, 0.0, 2.0, 5, 5).unwrap();
    let mut values = vec![Some(30.0); 25];
    // Punch a two by two hole in the middle.
    for (column, row) in [(2usize, 2usize), (3, 2), (2, 3), (3, 3)] {
        values[row * 5 + column] = None;
    }
    let r = raster(5, 5, values);
    let coverage = analyse(&r, &geometry);
    assert_eq!(coverage.total, 25);
    assert_eq!(coverage.populated, 21);
    assert_relative_eq!(coverage.fraction(), 21.0 / 25.0, epsilon = 1.0e-12);
    assert_eq!(coverage.holidays.len(), 1);

    let hole = &coverage.holidays[0];
    assert_eq!(hole.cells, 4);
    assert_relative_eq!(hole.area, 16.0, epsilon = 1.0e-12);
    assert!(!hole.on_edge);
    assert_relative_eq!(hole.extent(2.0), 4.0, epsilon = 1.0e-12);
    assert_relative_eq!(
        coverage.worst_interior(2.0).unwrap(),
        4.0,
        epsilon = 1.0e-12
    );
}

#[test]
fn a_gap_touching_the_edge_is_separated_from_the_interior_ones() {
    let geometry = GridGeometry::new(0.0, 0.0, 1.0, 4, 4).unwrap();
    let mut values = vec![Some(10.0); 16];
    values[0] = None; // corner, on the edge
    values[5] = None; // interior
    let coverage = analyse(&raster(4, 4, values), &geometry);
    assert_eq!(coverage.holidays.len(), 2);
    assert_eq!(coverage.interior_holidays().count(), 1);
    assert_relative_eq!(
        coverage.worst_interior(1.0).unwrap(),
        1.0,
        epsilon = 1.0e-12
    );
}

#[test]
fn cells_touching_only_at_a_corner_are_two_holes() {
    let geometry = GridGeometry::new(0.0, 0.0, 1.0, 5, 5).unwrap();
    let mut values = vec![Some(10.0); 25];
    values[5 + 1] = None;
    values[2 * 5 + 2] = None;
    let coverage = analyse(&raster(5, 5, values), &geometry);
    assert_eq!(coverage.holidays.len(), 2);
    assert!(coverage.holidays.iter().all(|h| h.cells == 1));
}

#[test]
fn a_completely_empty_grid_is_one_hole() {
    let geometry = GridGeometry::new(0.0, 0.0, 1.0, 3, 3).unwrap();
    let coverage = analyse(&raster(3, 3, vec![None; 9]), &geometry);
    assert_relative_eq!(coverage.fraction(), 0.0, epsilon = 1.0e-12);
    assert_eq!(coverage.holidays.len(), 1);
    assert!(coverage.holidays[0].on_edge);
    assert!(coverage.worst_interior(1.0).is_none());
}
