//! A whole synthetic survey, from pings to a gridded surface.

use approx::assert_relative_eq;
use plumbline::config::survey::SurveyConfig;
use plumbline::geodesy::{Ellipsoid, Geodetic};
use plumbline::grid::estimator::{render, Estimator};
use plumbline::motion::attitude::Attitude;
use plumbline::ping::beam::{Beam, Detection};
use plumbline::ping::line::Line;
use plumbline::ping::record::{Navigation, Ping};
use plumbline::pipeline::parallel::{reduce_lines, Progress, Threads};
use plumbline::pipeline::reduce_line::Pipeline;
use plumbline::pipeline::survey::{accepted_soundings, build_surface, summarise};
use plumbline::svp::library::{LibraryEntry, ProfileLibrary, ProfileSelection};
use plumbline::svp::profile::{Sample, SoundSpeedProfile};
use plumbline::time::Timestamp;
use plumbline::units::Angle;
use plumbline::vertical::reference::VerticalReference;
use plumbline::vertical::tide::{TideGauge, TideModel};

const SPEED: f64 = 1500.0;
const DRAFT: f64 = 2.0;
const SEABED_BELOW_TRANSDUCER: f64 = 28.0;
const START: f64 = 1_745_000_000.0;

const CONFIG: &str = r#"
[survey]
name = "synthetic block"
order = "order 1"
utm_zone = 36

[vessel]
name = "test launch"
draft = 2.0

[grid]
cell_size = 1.0

[cleaning]
min_depth = 5.0
max_depth = 60.0
"#;

fn profile() -> SoundSpeedProfile {
    SoundSpeedProfile::new(vec![Sample::new(0.0, SPEED), Sample::new(200.0, SPEED)]).unwrap()
}

fn library() -> ProfileLibrary {
    ProfileLibrary::new(
        vec![LibraryEntry {
            label: "cast 1".into(),
            time: Timestamp::from_unix_seconds(START),
            position: Some(Geodetic::from_degrees(69.0, 33.0, 0.0)),
            profile: profile(),
        }],
        ProfileSelection::NearestInTime,
    )
    .unwrap()
}

fn flat_tide() -> VerticalReference {
    let gauge = TideGauge::new(
        "flat",
        Geodetic::from_degrees(69.0, 33.0, 0.0),
        vec![
            (Timestamp::from_unix_seconds(START - 10_000.0), 0.0),
            (Timestamp::from_unix_seconds(START + 10_000.0), 0.0),
        ],
        30_000.0,
    )
    .unwrap();
    VerticalReference::Tide {
        model: Box::new(TideModel::single_gauge(gauge).unwrap()),
        zone: "whole survey".into(),
    }
}

/// A line steaming north over a flat seabed, pinging at five hertz.
fn synthetic_line(name: &str, start_lat: f64, lon: f64, pings: usize) -> Line {
    let angles: Vec<f64> = (0..61).map(|i| -60.0 + 2.0 * i as f64).collect();
    let records = (0..pings)
        .map(|p| {
            let t = START + p as f64 * 0.2;
            // Three metres per second north.
            let lat = start_lat + (p as f64 * 0.6) / 111_320.0;
            let beams: Vec<Beam> = angles
                .iter()
                .enumerate()
                .map(|(i, a)| {
                    let angle = Angle::from_degrees(*a);
                    let slant = SEABED_BELOW_TRANSDUCER / angle.cos();
                    let mut b = Beam::new(i as u16, 2.0 * slant / SPEED, angle);
                    b.detection = Detection::Amplitude;
                    b.quality = 0.9;
                    b
                })
                .collect();
            let mut ping = Ping::new(Timestamp::from_unix_seconds(t), p as u64, SPEED, beams);
            ping.navigation = Some(Navigation {
                position: Geodetic::from_degrees(lat, lon, 0.0),
                attitude: Attitude::LEVEL,
                heave: 0.0,
                speed: 3.0,
                transducer_height: None,
            });
            ping
        })
        .collect();
    Line::new(name, records)
}

fn pipeline<'a>(
    config: &'a SurveyConfig,
    profiles: &'a ProfileLibrary,
    vertical: &'a VerticalReference,
) -> Pipeline<'a> {
    Pipeline {
        config,
        profiles,
        vertical,
        ellipsoid: Ellipsoid::WGS84,
    }
}

#[test]
fn a_flat_seabed_comes_back_flat() {
    let config = SurveyConfig::parse(CONFIG).unwrap();
    let profiles = library();
    let vertical = flat_tide();
    let p = pipeline(&config, &profiles, &vertical);

    let line = synthetic_line("line 1", 69.0, 33.0, 40);
    let result = p.reduce_line(&line).unwrap();

    assert_eq!(result.name, "line 1");
    assert_eq!(result.profile_used, "cast 1");
    assert_eq!(result.soundings.len(), 40 * 61);
    assert_eq!(result.stats.accepted, 40 * 61);
    let expected = SEABED_BELOW_TRANSDUCER + DRAFT;
    assert_relative_eq!(result.stats.min_depth, expected, epsilon = 1.0e-6);
    assert_relative_eq!(result.stats.max_depth, expected, epsilon = 1.0e-6);
    assert!(
        result.warnings.is_empty(),
        "warnings: {:?}",
        result.warnings
    );
}

#[test]
fn the_swath_is_as_wide_as_the_geometry_says() {
    let config = SurveyConfig::parse(CONFIG).unwrap();
    let profiles = library();
    let vertical = flat_tide();
    let result = pipeline(&config, &profiles, &vertical)
        .reduce_line(&synthetic_line("line 1", 69.0, 33.0, 5))
        .unwrap();

    let widest = result
        .soundings
        .iter()
        .map(|s| s.across.abs())
        .fold(0.0f64, f64::max);
    // Sixty degrees either side of nadir in twenty eight metres of water.
    assert_relative_eq!(
        widest,
        SEABED_BELOW_TRANSDUCER * 60.0_f64.to_radians().tan(),
        epsilon = 0.05
    );
}

#[test]
fn the_uncertainty_grows_towards_the_edge_of_the_swath() {
    let config = SurveyConfig::parse(CONFIG).unwrap();
    let profiles = library();
    let vertical = flat_tide();
    let result = pipeline(&config, &profiles, &vertical)
        .reduce_line(&synthetic_line("line 1", 69.0, 33.0, 2))
        .unwrap();

    let nadir = result
        .soundings
        .iter()
        .min_by(|a, b| a.across.abs().total_cmp(&b.across.abs()))
        .unwrap();
    let edge = result
        .soundings
        .iter()
        .max_by(|a, b| a.across.abs().total_cmp(&b.across.abs()))
        .unwrap();
    assert!(
        edge.tvu > nadir.tvu * 1.5,
        "{} against {}",
        edge.tvu,
        nadir.tvu
    );
    assert!(nadir.tvu > 0.0);
    assert!(edge.thu > nadir.thu);
}

#[test]
fn several_lines_grid_into_one_surface() {
    let config = SurveyConfig::parse(CONFIG).unwrap();
    let profiles = library();
    let vertical = flat_tide();
    let p = pipeline(&config, &profiles, &vertical);

    let lines: Vec<Line> = (0..3)
        .map(|i| {
            synthetic_line(
                &format!("line {}", i + 1),
                69.0,
                33.0 + i as f64 * 0.0006,
                30,
            )
        })
        .collect();

    let progress = Progress::new();
    let results = reduce_lines(&p, &lines, Threads::Fixed(2), &progress).unwrap();
    assert_eq!(results.len(), 3);
    assert_eq!(progress.lines_done(), 3);
    assert_eq!(progress.soundings(), 3 * 30 * 61);
    // Order is the input order whichever thread finished first.
    assert_eq!(results[0].name, "line 1");
    assert_eq!(results[2].name, "line 3");

    let projection = p.projection().unwrap();
    let surface = build_surface(&results, &config, projection).unwrap();
    assert_eq!(surface.outside_count(), 0);
    assert!(surface.populated_cells() > 100);

    let (lo, hi) = surface.depth_range().unwrap();
    let expected = SEABED_BELOW_TRANSDUCER + DRAFT;
    assert_relative_eq!(lo, expected, epsilon = 1.0e-4);
    assert_relative_eq!(hi, expected, epsilon = 1.0e-4);

    let summary = summarise(&results, &surface, &config, Estimator::Shoalest);
    assert_eq!(summary.lines, 3);
    assert_eq!(summary.soundings, 3 * 30 * 61);
    assert_relative_eq!(summary.acceptance_rate(), 1.0, epsilon = 1.0e-12);
    assert_relative_eq!(summary.order_compliance.unwrap(), 1.0, epsilon = 1.0e-12);
    assert!(summary.coverage.fraction() > 0.5);

    let raster = render(&surface, Estimator::Shoalest);
    assert_eq!(raster.populated(), surface.populated_cells());
    assert_eq!(accepted_soundings(&results).len(), 3 * 30 * 61);
}

#[test]
fn one_thread_and_many_threads_agree() {
    let config = SurveyConfig::parse(CONFIG).unwrap();
    let profiles = library();
    let vertical = flat_tide();
    let p = pipeline(&config, &profiles, &vertical);
    let lines: Vec<Line> = (0..4)
        .map(|i| synthetic_line(&format!("line {i}"), 69.0 + i as f64 * 0.001, 33.0, 10))
        .collect();

    let serial = reduce_lines(&p, &lines, Threads::One, &Progress::new()).unwrap();
    let parallel = reduce_lines(&p, &lines, Threads::Available, &Progress::new()).unwrap();
    assert_eq!(serial.len(), parallel.len());
    for (a, b) in serial.iter().zip(parallel.iter()) {
        assert_eq!(a.name, b.name);
        assert_eq!(a.soundings.len(), b.soundings.len());
        for (x, y) in a.soundings.iter().zip(b.soundings.iter()) {
            assert_relative_eq!(x.depth, y.depth, epsilon = 1.0e-12);
            assert_relative_eq!(x.tvu, y.tvu, epsilon = 1.0e-12);
        }
    }
    assert_eq!(Threads::Fixed(8).count(2), 2);
    assert_eq!(Threads::One.count(100), 1);
}

#[test]
fn a_depth_window_that_excludes_the_seabed_rejects_everything() {
    let text = CONFIG.replace("max_depth = 60.0", "max_depth = 10.0");
    let config = SurveyConfig::parse(&text).unwrap();
    let profiles = library();
    let vertical = flat_tide();
    let result = pipeline(&config, &profiles, &vertical)
        .reduce_line(&synthetic_line("line 1", 69.0, 33.0, 5))
        .unwrap();
    assert_eq!(result.stats.accepted, 0);
    assert_eq!(result.tally.outside_window, 5 * 61);
    assert!(result
        .warnings
        .iter()
        .any(|w| matches!(w, plumbline::pipeline::LineWarning::EmptyPings { .. })));
}

#[test]
fn the_ray_table_gives_the_same_answer_as_the_full_trace() {
    // The table only comes into play above five thousand beams in a line, so
    // this pair straddles that threshold on purpose: one line short enough to
    // trace every beam, one long enough to use the table, over the same
    // seabed.
    let config = SurveyConfig::parse(CONFIG).unwrap();
    let profiles = library();
    let vertical = flat_tide();
    let p = pipeline(&config, &profiles, &vertical);

    let short = p
        .reduce_line(&synthetic_line("short", 69.0, 33.0, 20))
        .unwrap();
    let long = p
        .reduce_line(&synthetic_line("long", 69.0, 33.0, 400))
        .unwrap();

    // The same beam of the same ping, one traced and one interpolated.
    for ping in 0..20 {
        for beam in 0..61 {
            let a = short.soundings[ping * 61 + beam];
            let b = long.soundings[ping * 61 + beam];
            assert_relative_eq!(a.depth, b.depth, epsilon = 0.01);
            assert_relative_eq!(a.across, b.across, epsilon = 0.01);
        }
    }
}
