//! File formats, in both directions.

mod common;

use approx::assert_relative_eq;
use plumbline::geodesy::utm::TransverseMercator;
use plumbline::geodesy::{Ellipsoid, Geodetic};
use plumbline::grid::estimator::{DepthRaster, Estimator};
use plumbline::grid::geometry::GridGeometry;
use plumbline::io::ascii_grid::{read_ascii_grid, write_ascii_grid, NODATA};
use plumbline::io::checksum::crc32;
use plumbline::io::pbf::{decode_pings, read_header, read_pings, write_pings, MAGIC};
use plumbline::io::xyz::{read_xyz, write_xyz, XyzColumns};
use plumbline::motion::attitude::Attitude;
use plumbline::ping::beam::{Beam, BeamFlags, Detection};
use plumbline::ping::record::{Navigation, Ping};
use plumbline::ping::sounding::Sounding;
use plumbline::time::Timestamp;
use plumbline::units::Angle;

use common::TempDir;

fn projection() -> TransverseMercator {
    TransverseMercator::utm(36, true, Ellipsoid::WGS84).unwrap()
}

fn sounding(depth: f64, flagged: bool) -> Sounding {
    Sounding {
        time: Timestamp::from_unix_seconds(1_740_000_000.0),
        ping: 42,
        beam: 7,
        position: Geodetic::from_degrees(69.05, 33.02, 0.0),
        depth,
        across: 12.0,
        along: 0.5,
        tvu: 0.21,
        thu: 0.85,
        detection: Detection::Phase,
        flags: if flagged {
            BeamFlags::LOW_QUALITY
        } else {
            BeamFlags::NONE
        },
    }
}

#[test]
fn the_checksum_matches_the_standard_vector() {
    assert_eq!(crc32(b"123456789"), 0xCBF4_3926);
    assert_eq!(crc32(b""), 0);
    assert_ne!(crc32(b"a"), crc32(b"b"));
}

#[test]
fn xyz_writes_only_the_accepted_soundings() {
    let dir = TempDir::new("io");
    let path = dir.join("block.xyz");
    let soundings = [
        sounding(21.0, false),
        sounding(9.0, true),
        sounding(22.5, false),
    ];
    let written = write_xyz(&path, &soundings, &projection(), XyzColumns::PLAIN).unwrap();
    assert_eq!(written, 2);

    let rows = read_xyz(&path).unwrap();
    assert_eq!(rows.len(), 2);
    assert_relative_eq!(rows[0].depth, 21.0, epsilon = 1.0e-9);
    assert_relative_eq!(rows[1].depth, 22.5, epsilon = 1.0e-9);
    // And the position survived the projection round trip to the millimetre.
    let back = projection()
        .inverse(plumbline::geodesy::utm::Projected::new(
            rows[0].east,
            rows[0].north,
        ))
        .unwrap();
    assert_relative_eq!(back.lat.degrees(), 69.05, epsilon = 1.0e-7);
}

#[test]
fn the_full_column_set_carries_the_identity_and_the_uncertainty() {
    let dir = TempDir::new("io");
    let path = dir.join("working.xyz");
    write_xyz(
        &path,
        &[sounding(30.0, false)],
        &projection(),
        XyzColumns::FULL,
    )
    .unwrap();
    let text = std::fs::read_to_string(&path).unwrap();
    assert!(text.starts_with("# easting northing depth tvu thu ping beam time"));
    let data = text.lines().nth(1).unwrap();
    assert_eq!(data.split_whitespace().count(), 8);
    assert!(data.contains(" 42 7 "));
}

#[test]
fn a_short_xyz_line_is_an_error_and_not_a_skip() {
    let dir = TempDir::new("io");
    let path = dir.join("broken.xyz");
    std::fs::write(&path, "# header\n1.0 2.0 3.0\n4.0 5.0\n").unwrap();
    assert!(read_xyz(&path).is_err());
}

#[test]
fn an_ascii_grid_round_trips_the_right_way_up() {
    let dir = TempDir::new("io");
    let path = dir.join("surface.asc");
    let geometry = GridGeometry::new(500_000.0, 7_650_000.0, 5.0, 3, 2).unwrap();
    // Bottom row is 10 and 11 and a hole, top row is 20, 21, 22.
    let raster = DepthRaster {
        columns: 3,
        rows: 2,
        depths: vec![
            Some(10.0),
            Some(11.0),
            None,
            Some(20.0),
            Some(21.0),
            Some(22.0),
        ],
        estimator: Estimator::Shoalest,
    };
    write_ascii_grid(&path, &raster, &geometry, 2).unwrap();

    let text = std::fs::read_to_string(&path).unwrap();
    let lines: Vec<&str> = text.lines().collect();
    assert_eq!(lines[0], "ncols 3");
    assert_eq!(lines[1], "nrows 2");
    // First data line is the northern row.
    assert_eq!(lines[6], "20.00 21.00 22.00");
    assert!(lines[7].contains(&format!("{NODATA:.2}")));

    let back = read_ascii_grid(&path).unwrap();
    assert_eq!(back.geometry, geometry);
    assert_eq!(back.values, raster.depths);
}

#[test]
fn a_grid_that_disagrees_with_its_geometry_is_refused() {
    let dir = TempDir::new("io");
    let path = dir.join("wrong.asc");
    let geometry = GridGeometry::new(0.0, 0.0, 1.0, 4, 4).unwrap();
    let raster = DepthRaster {
        columns: 2,
        rows: 2,
        depths: vec![Some(1.0); 4],
        estimator: Estimator::Mean,
    };
    assert!(write_ascii_grid(&path, &raster, &geometry, 2).is_err());
}

fn ping_fixture(sequence: u64, with_nav: bool) -> Ping {
    let beams: Vec<Beam> = (0..4)
        .map(|i| {
            let mut b = Beam::new(
                i,
                0.05 + i as f64 * 0.001,
                Angle::from_degrees(-30.0 + 20.0 * i as f64),
            );
            b.quality = 0.5 + 0.1 * i as f32;
            b.detection = if i % 2 == 0 {
                Detection::Amplitude
            } else {
                Detection::Phase
            };
            b.steering_angle = Angle::from_degrees(0.25);
            b
        })
        .collect();
    let mut ping = Ping::new(
        Timestamp::from_unix_seconds(1_740_000_123.5),
        sequence,
        1478.5,
        beams,
    );
    if with_nav {
        ping.navigation = Some(Navigation {
            position: Geodetic::from_degrees(69.712_45, 33.083_11, 41.7),
            attitude: Attitude::from_degrees(-1.25, 0.5, 187.75),
            heave: -0.12,
            speed: 3.6,
            transducer_height: Some(-28.4),
        });
    }
    ping
}

#[test]
fn pings_survive_a_round_trip_through_the_binary_format() {
    let dir = TempDir::new("pbf");
    let path = dir.join("line01.pbf");
    let pings = vec![ping_fixture(1, true), ping_fixture(2, false)];
    write_pings(&path, &pings).unwrap();

    let header = read_header(&path).unwrap();
    assert_eq!(header.version, 1);
    assert_eq!(header.ping_count, 2);

    let back = read_pings(&path).unwrap();
    assert_eq!(back.len(), 2);
    assert_eq!(back[0].sequence, 1);
    assert_eq!(back[0].beams.len(), 4);
    assert_relative_eq!(back[0].surface_sound_speed, 1478.5, epsilon = 1.0e-3);
    assert_relative_eq!(
        back[0].time.unix_seconds(),
        1_740_000_123.5,
        epsilon = 1.0e-9
    );

    let nav = back[0].navigation.unwrap();
    assert_relative_eq!(nav.position.lat.degrees(), 69.712_45, epsilon = 1.0e-12);
    assert_relative_eq!(nav.attitude.roll.degrees(), -1.25, epsilon = 1.0e-5);
    assert_relative_eq!(nav.attitude.heading.degrees(), 187.75, epsilon = 1.0e-4);
    assert_relative_eq!(nav.transducer_height.unwrap(), -28.4, epsilon = 1.0e-12);
    assert!(back[1].navigation.is_none());

    // Beams keep their angles to better than a thousandth of a degree, which
    // is what the f32 storage is worth and well under the beam width.
    for (a, b) in pings[0].beams.iter().zip(back[0].beams.iter()) {
        assert_eq!(a.number, b.number);
        assert_relative_eq!(a.two_way_time, b.two_way_time, epsilon = 1.0e-15);
        assert_relative_eq!(
            a.pointing_angle.degrees(),
            b.pointing_angle.degrees(),
            epsilon = 1.0e-4
        );
        assert_eq!(a.detection, b.detection);
        assert_relative_eq!(a.quality, b.quality, epsilon = 1.0e-7);
    }
}

#[test]
fn beam_flags_survive_the_round_trip() {
    let dir = TempDir::new("pbf");
    let path = dir.join("flagged.pbf");
    let mut ping = ping_fixture(9, true);
    ping.beams[2]
        .flags
        .set(BeamFlags::LOW_QUALITY.with(BeamFlags::MANUAL));
    write_pings(&path, &[ping]).unwrap();
    let back = read_pings(&path).unwrap();
    let flags = back[0].beams[2].flags;
    assert!(flags.has(BeamFlags::LOW_QUALITY));
    assert!(flags.has(BeamFlags::MANUAL));
    assert_eq!(flags.names(), vec!["low quality", "manual"]);
    assert!(back[0].beams[0].flags.is_clear());
}

#[test]
fn a_truncated_file_is_refused_rather_than_half_read() {
    let dir = TempDir::new("pbf");
    let path = dir.join("cut.pbf");
    write_pings(&path, &[ping_fixture(1, true), ping_fixture(2, true)]).unwrap();

    let whole = std::fs::read(&path).unwrap();
    for cut in [8, 40, whole.len() - 10, whole.len() - 1] {
        assert!(
            decode_pings(&whole[..cut]).is_err(),
            "a file cut at {cut} bytes should not decode"
        );
    }
    assert!(decode_pings(&whole).is_ok());
}

#[test]
fn a_corrupted_byte_fails_the_checksum() {
    let dir = TempDir::new("pbf");
    let path = dir.join("bitrot.pbf");
    write_pings(&path, &[ping_fixture(3, true)]).unwrap();
    let mut bytes = std::fs::read(&path).unwrap();
    let middle = bytes.len() / 2;
    bytes[middle] ^= 0x01;
    let err = decode_pings(&bytes).unwrap_err();
    assert!(format!("{err}").contains("checksum"), "got {err}");
}

#[test]
fn something_that_is_not_a_ping_file_says_so() {
    let mut bytes = b"NOPE".to_vec();
    bytes.extend_from_slice(&[0u8; 32]);
    let err = decode_pings(&bytes).unwrap_err();
    assert!(format!("{err}").contains("magic"), "got {err}");
    assert_eq!(&MAGIC, b"PLMB");
}

#[test]
fn a_file_from_the_future_is_refused() {
    let dir = TempDir::new("pbf");
    let path = dir.join("future.pbf");
    write_pings(&path, &[ping_fixture(1, true)]).unwrap();
    let mut bytes = std::fs::read(&path).unwrap();
    bytes[4] = 99;
    let err = decode_pings(&bytes).unwrap_err();
    assert!(format!("{err}").contains("version"), "got {err}");
}
