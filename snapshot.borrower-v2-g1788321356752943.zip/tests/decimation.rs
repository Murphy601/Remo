//! Thinning soundings for a delivery.

mod common;

use approx::assert_relative_eq;
use common::TempDir;
use plumbline::geodesy::utm::TransverseMercator;
use plumbline::geodesy::{Ellipsoid, Geodetic};
use plumbline::ping::beam::{BeamFlags, Detection};
use plumbline::ping::decimate::{decimate, every_nth, DecimationReport, Keep};
use plumbline::ping::sounding::Sounding;
use plumbline::time::Timestamp;

fn projection() -> TransverseMercator {
    TransverseMercator::utm(36, true, Ellipsoid::WGS84).unwrap()
}

fn sounding(index: u64, position: Geodetic, depth: f64, tvu: f64) -> Sounding {
    Sounding {
        time: Timestamp::from_unix_seconds(1_750_000_000.0 + index as f64 * 0.2),
        ping: index,
        beam: (index % 61) as u16,
        position,
        depth,
        across: 0.0,
        along: 0.0,
        tvu,
        thu: 1.0,
        detection: Detection::Amplitude,
        flags: BeamFlags::NONE,
    }
}

/// A patch of soundings on a half metre lattice, deepening east.
fn patch() -> Vec<Sounding> {
    let origin = projection()
        .inverse(plumbline::geodesy::utm::Projected::new(
            500_000.0,
            7_650_000.0,
        ))
        .unwrap();
    let mut out = Vec::new();
    let mut index = 0;
    for i in 0..20 {
        for j in 0..20 {
            let east = 500_000.0 + i as f64 * 0.5;
            let north = 7_650_000.0 + j as f64 * 0.5;
            let position = projection()
                .inverse(plumbline::geodesy::utm::Projected::new(east, north))
                .unwrap();
            let _ = origin;
            out.push(sounding(index, position, 20.0 + i as f64 * 0.1, 0.2));
            index += 1;
        }
    }
    out
}

#[test]
fn decimating_to_a_spacing_keeps_one_per_square() {
    let soundings = patch();
    let thinned = decimate(&soundings, &projection(), 2.0, Keep::Shoalest).unwrap();
    // Ten metres of lattice at two metre bins is five bins each way.
    assert_eq!(thinned.len(), 25);
    assert!(thinned.len() < soundings.len());
}

#[test]
fn the_shallowest_sounding_always_survives() {
    let mut soundings = patch();
    // A rock, in the middle of a bin with plenty of company.
    soundings[123].depth = 11.5;
    let thinned = decimate(&soundings, &projection(), 5.0, Keep::Shoalest).unwrap();
    let report = DecimationReport::of(&soundings, &thinned, 5.0);
    assert!(report.kept_the_shoalest());
    assert_relative_eq!(report.shoalest_out, 11.5, epsilon = 1.0e-9);
    assert!(report.fraction() < 0.1);
    assert!(thinned.iter().any(|s| (s.depth - 11.5).abs() < 1.0e-9));
}

#[test]
fn keeping_the_deepest_does_the_opposite() {
    let mut soundings = patch();
    soundings[123].depth = 55.0;
    let thinned = decimate(&soundings, &projection(), 5.0, Keep::Deepest).unwrap();
    assert!(thinned.iter().any(|s| (s.depth - 55.0).abs() < 1.0e-9));
    // And the same bin under the shoalest rule keeps something else.
    let shoal = decimate(&soundings, &projection(), 5.0, Keep::Shoalest).unwrap();
    assert!(!shoal.iter().any(|s| (s.depth - 55.0).abs() < 1.0e-9));
}

#[test]
fn keeping_the_most_certain_looks_at_the_uncertainty() {
    let mut soundings = patch();
    soundings[7].tvu = 0.01;
    soundings[7].depth = 44.0;
    let thinned = decimate(&soundings, &projection(), 20.0, Keep::MostCertain).unwrap();
    assert_eq!(thinned.len(), 1);
    assert_relative_eq!(thinned[0].depth, 44.0, epsilon = 1.0e-9);
    assert_eq!(Keep::MostCertain.name(), "most certain");
}

#[test]
fn rejected_soundings_never_reach_the_output() {
    let mut soundings = patch();
    for s in soundings.iter_mut() {
        s.flags.set(BeamFlags::LOW_QUALITY);
    }
    soundings[50].flags = BeamFlags::NONE;
    let thinned = decimate(&soundings, &projection(), 1.0, Keep::Shoalest).unwrap();
    assert_eq!(thinned.len(), 1);
    assert_eq!(thinned[0].ping, 50);
}

#[test]
fn the_output_is_in_a_stable_order() {
    let soundings = patch();
    let once = decimate(&soundings, &projection(), 3.0, Keep::Shoalest).unwrap();
    let twice = decimate(&soundings, &projection(), 3.0, Keep::Shoalest).unwrap();
    let times: Vec<f64> = once.iter().map(|s| s.time.unix_seconds()).collect();
    let again: Vec<f64> = twice.iter().map(|s| s.time.unix_seconds()).collect();
    assert_eq!(times, again);
    assert!(times.windows(2).all(|w| w[0] <= w[1]));
}

#[test]
fn a_silly_spacing_is_refused() {
    let soundings = patch();
    assert!(decimate(&soundings, &projection(), 0.0, Keep::Shoalest).is_err());
    assert!(decimate(&soundings, &projection(), -1.0, Keep::Shoalest).is_err());
    assert!(decimate(&soundings, &projection(), f64::NAN, Keep::Shoalest).is_err());
}

#[test]
fn every_nth_is_blunt_and_says_so() {
    let soundings = patch();
    assert_eq!(every_nth(&soundings, 4).len(), soundings.len().div_ceil(4));
    assert_eq!(every_nth(&soundings, 1).len(), soundings.len());
    assert_eq!(every_nth(&soundings, 0).len(), soundings.len());
}

#[test]
fn the_reduce_command_can_decimate() {
    let dir = TempDir::new("decimate");
    let config = dir.join("survey.toml");
    let svp = dir.join("casts.svp");
    let tide = dir.join("gauge.tide");
    std::fs::write(
        &config,
        "[survey]\nname = \"thin\"\nutm_zone = 36\n\n[vessel]\ndraft = 1.8\n\n[grid]\ncell_size = 1.0\n",
    )
    .unwrap();
    std::fs::write(
        &svp,
        "[SVP_VERSION_2]\nx.svp\nSection 2025-146 07:30:00 69:00:00 033:00:00\n0.0 1500.0\n150.0 1500.0\n",
    )
    .unwrap();
    std::fs::write(
        &tide,
        "# gauge demo 69.0 33.0\n2025-05-26T00:00:00Z 0.000\n2025-05-27T00:00:00Z 0.000\n",
    )
    .unwrap();

    let exe = env!("CARGO_BIN_EXE_plumbline");
    let pbf = dir.join("line.pbf");
    let xyz = dir.join("line.xyz");
    assert!(std::process::Command::new(exe)
        .args(["simulate", &pbf.to_string_lossy(), "--pings", "40"])
        .status()
        .unwrap()
        .success());

    let output = std::process::Command::new(exe)
        .args([
            "reduce",
            &pbf.to_string_lossy(),
            "--config",
            &config.to_string_lossy(),
            "--svp",
            &svp.to_string_lossy(),
            "--tide",
            &tide.to_string_lossy(),
            "--out",
            &xyz.to_string_lossy(),
            "--decimate",
            "2.0",
        ])
        .output()
        .unwrap();
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    let text = String::from_utf8_lossy(&output.stdout);
    assert!(
        text.contains("decimated to 2.0 m keeping the shoalest"),
        "{text}"
    );

    let written = std::fs::read_to_string(&xyz).unwrap();
    let rows = written.lines().filter(|l| !l.starts_with('#')).count();
    assert!(rows > 0 && rows < 40 * 61);
}
