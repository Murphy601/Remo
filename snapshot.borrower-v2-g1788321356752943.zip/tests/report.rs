//! The report, which is the only part of this most people ever read.

use plumbline::config::survey::SurveyConfig;
use plumbline::geodesy::utm::{Projected, TransverseMercator};
use plumbline::geodesy::Ellipsoid;
use plumbline::grid::estimator::Estimator;
use plumbline::grid::geometry::GridGeometry;
use plumbline::grid::surface::Surface;
use plumbline::pipeline::survey::{summarise, SurveySummary};
use plumbline::qc::report::{budget_breakdown, survey_report, verdict, ReportInputs};
use plumbline::tpu::s44::Order;

const CONFIG: &str = r#"
[survey]
name = "test block"
order = "order 1"
utm_zone = 36

[vessel]
name = "test launch"
draft = 1.8

[grid]
cell_size = 1.0

[cleaning]
max_swath_angle = 55.0
"#;

/// A surface with a patch of soundings in the middle of it, so the coverage
/// is neither nothing nor everything.
fn surface_with_data(config: &SurveyConfig) -> Surface {
    let geometry = GridGeometry::new(500_000.0, 7_650_000.0, config.cell_size, 20, 20).unwrap();
    let projection = TransverseMercator::utm(36, true, Ellipsoid::WGS84).unwrap();
    let mut surface = Surface::new(geometry, projection);
    for i in 4..16 {
        for j in 4..16 {
            for k in 0..4 {
                surface.add_at(
                    Projected::new(500_000.5 + i as f64, 7_650_000.5 + j as f64),
                    25.0 + k as f64 * 0.01,
                    0.15,
                );
            }
        }
    }
    surface
}

/// A summary of a surface with no line results behind it.
///
/// summarise counts the soundings off the line results, so the totals have to
/// be filled in here to describe the surface that was actually built.
fn summary(config: &SurveyConfig) -> SurveySummary {
    let surface = surface_with_data(config);
    let mut s = summarise(&[], &surface, config, Estimator::Shoalest);
    let (lo, hi) = surface.depth_range().unwrap();
    s.soundings = 4 * 12 * 12;
    s.accepted = s.soundings;
    s.min_depth = lo;
    s.max_depth = hi;
    s.max_tvu = 0.3;
    s
}

fn report_for(config: &SurveyConfig, estimator: Estimator) -> String {
    let s = summary(config);
    survey_report(&ReportInputs {
        summary: &s,
        results: &[],
        config,
        estimator,
        cell_size: config.cell_size,
        features: &[],
    })
}

#[test]
fn the_report_names_the_survey_and_the_vessel() {
    let config = SurveyConfig::parse(CONFIG).unwrap();
    let text = report_for(&config, Estimator::Shoalest);
    assert!(text.contains("survey: test block"));
    assert!(text.contains("vessel: test launch"));
    assert!(text.contains("sound speed equation: chen-millero"));
    assert!(text.contains("vertical reference"));
}

#[test]
fn a_shoal_biased_surface_says_so() {
    let config = SurveyConfig::parse(CONFIG).unwrap();
    let shoal = report_for(&config, Estimator::Shoalest);
    assert!(shoal.contains("do not compute volumes"));

    let weighted = report_for(&config, Estimator::WeightedMean);
    assert!(!weighted.contains("do not compute volumes"));
}

#[test]
fn coverage_and_gaps_are_reported() {
    let config = SurveyConfig::parse(CONFIG).unwrap();
    let text = report_for(&config, Estimator::Shoalest);
    assert!(text.contains("coverage"));
    assert!(text.contains("gaps:"));
    // The patch is in the middle, so the empty border is one edge gap and
    // there is nothing inside the block.
    assert!(text.contains("gaps: 0 inside the block"), "{text}");
}

#[test]
fn a_survey_that_misses_its_order_is_told_so() {
    let config = SurveyConfig::parse(CONFIG).unwrap();
    let mut s = summary(&config);
    s.order_compliance = Some(0.80);
    let text = survey_report(&ReportInputs {
        summary: &s,
        results: &[],
        config: &config,
        estimator: Estimator::Shoalest,
        cell_size: config.cell_size,
        features: &[],
    });
    assert!(text.contains("80.00% of accepted soundings"));
    assert!(text.contains("does not meet the order"));

    s.order_compliance = Some(0.999);
    let good = survey_report(&ReportInputs {
        summary: &s,
        results: &[],
        config: &config,
        estimator: Estimator::Shoalest,
        cell_size: config.cell_size,
        features: &[],
    });
    assert!(!good.contains("does not meet the order"));
}

#[test]
fn unread_configuration_keys_reach_the_report() {
    let text = format!("{CONFIG}\n[cleaning]\nmax_swath_angel = 40.0\n");
    let config = SurveyConfig::parse(&text).unwrap();
    let report = report_for(&config, Estimator::Shoalest);
    assert!(report.contains("nothing read"));
    assert!(report.contains("max_swath_angel"));
}

#[test]
fn the_budget_breakdown_shows_the_swap_across_the_swath() {
    let config = SurveyConfig::parse(CONFIG).unwrap();
    let text = budget_breakdown(&summary(&config), &config);
    assert!(text.contains("uncertainty budget at"));
    assert!(text.contains("nadir (0 degrees)"));
    assert!(text.contains("swath edge (55 degrees)"));

    // Nadir is dominated by something that does not scale with the angle,
    // the swath edge by the refraction.
    let (nadir, edge) = text.split_once("swath edge").unwrap();
    let first_of = |section: &str| {
        section
            .lines()
            .find(|l| l.starts_with("    ") && l.contains(" m "))
            .unwrap_or_default()
            .to_string()
    };
    let worst_at_nadir = first_of(nadir);
    let worst_at_edge = first_of(edge);
    assert!(
        worst_at_nadir.contains("heave") || worst_at_nadir.contains("tide"),
        "{worst_at_nadir}"
    );
    assert!(worst_at_edge.contains("sound speed"), "{worst_at_edge}");
}

#[test]
fn an_empty_survey_has_no_budget_to_break_down() {
    let config = SurveyConfig::parse(CONFIG).unwrap();
    let geometry = GridGeometry::new(0.0, 0.0, 1.0, 4, 4).unwrap();
    let projection = TransverseMercator::utm(36, true, Ellipsoid::WGS84).unwrap();
    let empty = Surface::new(geometry, projection);
    let s = summarise(&[], &empty, &config, Estimator::Shoalest);
    assert!(budget_breakdown(&s, &config).is_empty());
}

#[test]
fn the_verdict_is_one_line_and_carries_the_order() {
    let config = SurveyConfig::parse(CONFIG).unwrap();
    let mut s = summary(&config);
    s.order_compliance = Some(0.97);
    let line = verdict(&s, Some(Order::One));
    assert_eq!(line.lines().count(), 1);
    assert!(line.contains("test block"));
    assert!(line.contains("97.0% inside order 1"));

    let without = verdict(&s, None);
    assert!(!without.contains("inside"));
}
