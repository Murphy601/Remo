//! Slope, shading and resampling over rasters built by hand.

use approx::assert_relative_eq;
use plumbline::grid::estimator::{DepthRaster, Estimator};
use plumbline::grid::geometry::GridGeometry;
use plumbline::grid::resample::{coarsen_shoalest, resample, Method};
use plumbline::grid::slope::{gradients, hillshade, slope_raster, standard_hillshade};
use plumbline::units::Angle;

fn raster(columns: usize, rows: usize, f: impl Fn(usize, usize) -> Option<f64>) -> DepthRaster {
    let mut depths = Vec::with_capacity(columns * rows);
    for row in 0..rows {
        for column in 0..columns {
            depths.push(f(column, row));
        }
    }
    DepthRaster {
        columns,
        rows,
        depths,
        estimator: Estimator::Mean,
    }
}

#[test]
fn a_flat_surface_has_no_slope() {
    let flat = raster(5, 5, |_, _| Some(20.0));
    let slopes = slope_raster(&flat, 1.0);
    assert_relative_eq!(slopes.at(2, 2).unwrap(), 0.0, epsilon = 1.0e-12);
    // The border has no gradient at all, only the inside does.
    assert!(slopes.at(0, 0).is_none());
    assert!(slopes.at(4, 4).is_none());
}

#[test]
fn a_plane_has_the_slope_it_was_built_with() {
    // Deepening one metre for every two metres east, which is about twenty six
    // and a half degrees.
    let ramp = raster(7, 7, |c, _| Some(10.0 + c as f64 * 0.5));
    let gradient = gradients(&ramp, 1.0)[3 * 7 + 3].unwrap();
    assert_relative_eq!(gradient.d_east, 0.5, epsilon = 1.0e-12);
    assert_relative_eq!(gradient.d_north, 0.0, epsilon = 1.0e-12);
    assert_relative_eq!(
        gradient.slope.degrees(),
        0.5_f64.atan().to_degrees(),
        epsilon = 1.0e-9
    );
    // Depth increases east, so the seabed falls away east.
    assert_relative_eq!(gradient.aspect.degrees(), 90.0, epsilon = 1.0e-9);
}

#[test]
fn the_cell_size_scales_the_slope() {
    let ramp = raster(5, 5, |c, _| Some(c as f64));
    let fine = gradients(&ramp, 1.0)[2 * 5 + 2].unwrap();
    let coarse = gradients(&ramp, 4.0)[2 * 5 + 2].unwrap();
    assert_relative_eq!(coarse.d_east, fine.d_east / 4.0, epsilon = 1.0e-12);
}

#[test]
fn a_hole_stops_the_gradient_of_every_cell_that_touches_it() {
    let holed = raster(
        5,
        5,
        |c, r| {
            if c == 2 && r == 2 {
                None
            } else {
                Some(10.0)
            }
        },
    );
    let g = gradients(&holed, 1.0);
    assert!(g[2 * 5 + 2].is_none());
    assert!(g[5 + 1].is_none());
    assert!(g[3 * 5 + 3].is_none());
}

#[test]
fn shading_lights_a_slope_from_the_side_it_is_lit_from() {
    // A bank that shoals towards the north west, which the standard light
    // should show as bright.
    let bank = raster(7, 7, |c, r| Some(30.0 + c as f64 * 0.5 - r as f64 * 0.5));
    let lit = standard_hillshade(&bank, 1.0);
    let value = lit.at(3, 3).unwrap();
    assert!((0.0..=1.0).contains(&value));
    assert!(value > 0.8, "north west facing bank came out at {value}");

    // Lit from the opposite side, the same bank is in shadow.
    let against = hillshade(
        &bank,
        1.0,
        Angle::from_degrees(135.0),
        Angle::from_degrees(30.0),
    );
    assert!(against.at(3, 3).unwrap() < value);
}

#[test]
fn flat_ground_shades_to_the_sine_of_the_sun_altitude() {
    let flat = raster(5, 5, |_, _| Some(12.0));
    let lit = hillshade(
        &flat,
        1.0,
        Angle::from_degrees(315.0),
        Angle::from_degrees(45.0),
    );
    assert_relative_eq!(
        lit.at(2, 2).unwrap(),
        45.0_f64.to_radians().sin(),
        epsilon = 1.0e-12
    );
}

#[test]
fn resampling_onto_the_same_grid_changes_nothing() {
    let geometry = GridGeometry::new(1000.0, 2000.0, 2.0, 4, 3).unwrap();
    let source = raster(4, 3, |c, r| Some(10.0 + c as f64 + 10.0 * r as f64));
    for method in [Method::Nearest, Method::Bilinear] {
        let same = resample(&source, &geometry, &geometry, method).unwrap();
        assert_eq!(same.depths, source.depths, "{}", method.name());
    }
}

#[test]
fn nearest_keeps_the_values_that_were_there() {
    let from = GridGeometry::new(0.0, 0.0, 4.0, 4, 4).unwrap();
    let to = GridGeometry::new(0.0, 0.0, 1.0, 16, 16).unwrap();
    let source = raster(4, 4, |c, r| Some((c + 4 * r) as f64));
    let fine = resample(&source, &from, &to, Method::Nearest).unwrap();
    let values: Vec<f64> = fine.depths.iter().flatten().copied().collect();
    for v in &values {
        assert!(source.depths.contains(&Some(*v)), "{v} was invented");
    }
    assert!(!Method::Nearest.invents_values());
    assert!(Method::Bilinear.invents_values());
}

#[test]
fn bilinear_interpolates_between_the_cells() {
    let from = GridGeometry::new(0.0, 0.0, 10.0, 3, 3).unwrap();
    let to = GridGeometry::new(0.0, 0.0, 5.0, 6, 6).unwrap();
    let source = raster(3, 3, |c, _| Some(c as f64 * 10.0));
    let fine = resample(&source, &from, &to, Method::Bilinear).unwrap();
    // Cell centres of the fine grid sit at quarter and three quarter points
    // between the source cell centres, so the values do too.
    assert_relative_eq!(fine.at(2, 2).unwrap(), 7.5, epsilon = 1.0e-9);
    assert_relative_eq!(fine.at(1, 2).unwrap(), 2.5, epsilon = 1.0e-9);
}

#[test]
fn a_raster_that_does_not_match_its_geometry_is_refused() {
    let from = GridGeometry::new(0.0, 0.0, 1.0, 5, 5).unwrap();
    let to = GridGeometry::new(0.0, 0.0, 1.0, 5, 5).unwrap();
    let wrong = raster(3, 3, |_, _| Some(1.0));
    assert!(resample(&wrong, &from, &to, Method::Nearest).is_err());
}

#[test]
fn coarsening_takes_the_shoalest_of_each_block() {
    let source = raster(4, 4, |c, r| Some(20.0 + (c + 4 * r) as f64));
    let coarse = coarsen_shoalest(&source, 2).unwrap();
    assert_eq!(coarse.columns, 2);
    assert_eq!(coarse.rows, 2);
    // The first block holds 20, 21, 24 and 25.
    assert_relative_eq!(coarse.at(0, 0).unwrap(), 20.0, epsilon = 1.0e-12);
    assert_relative_eq!(coarse.at(1, 0).unwrap(), 22.0, epsilon = 1.0e-12);
    assert_relative_eq!(coarse.at(1, 1).unwrap(), 30.0, epsilon = 1.0e-12);
    assert!(coarsen_shoalest(&source, 1).is_err());
}

#[test]
fn coarsening_an_odd_sized_raster_keeps_the_last_partial_block() {
    let source = raster(5, 5, |_, _| Some(7.0));
    let coarse = coarsen_shoalest(&source, 2).unwrap();
    assert_eq!(coarse.columns, 3);
    assert_eq!(coarse.rows, 3);
    assert_eq!(coarse.populated(), 9);
}

#[test]
fn coarsening_never_loses_the_shallowest_cell() {
    let mut source = raster(8, 8, |_, _| Some(30.0));
    // One rock, in the middle of a block.
    let index = 5 * 8 + 3;
    source.depths[index] = Some(11.0);
    let coarse = coarsen_shoalest(&source, 4).unwrap();
    let (lo, _) = coarse.range().unwrap();
    assert_relative_eq!(lo, 11.0, epsilon = 1.0e-12);
}
