//! The patch test solvers, checked by injecting a bias and asking for it back.

use approx::assert_relative_eq;
use plumbline::calibration::patch::{shift_navigation, Parameter, PatchTest};
use plumbline::calibration::search::{golden_section, sweep};
use plumbline::config::survey::SurveyConfig;
use plumbline::geodesy::{Ellipsoid, Geodetic};
use plumbline::motion::attitude::Attitude;
use plumbline::ping::beam::{Beam, Detection};
use plumbline::ping::line::Line;
use plumbline::ping::record::{Navigation, Ping};
use plumbline::svp::library::{LibraryEntry, ProfileLibrary, ProfileSelection};
use plumbline::svp::profile::{Sample, SoundSpeedProfile};
use plumbline::time::Timestamp;
use plumbline::units::Angle;
use plumbline::vertical::reference::VerticalReference;
use plumbline::vertical::tide::{TideGauge, TideModel};

const SPEED: f64 = 1500.0;
const DEPTH: f64 = 25.0;
const START: f64 = 1_749_000_000.0;

const CONFIG: &str = r#"
[survey]
name = "patch test"
utm_zone = 36

[vessel]
name = "trials launch"
draft = 1.5

[grid]
cell_size = 5.0

[cleaning]
min_depth = 2.0
max_depth = 60.0
"#;

fn library() -> ProfileLibrary {
    ProfileLibrary::new(
        vec![LibraryEntry {
            label: "cast".into(),
            time: Timestamp::from_unix_seconds(START),
            position: Some(Geodetic::from_degrees(69.0, 33.0, 0.0)),
            profile: SoundSpeedProfile::new(vec![
                Sample::new(0.0, SPEED),
                Sample::new(200.0, SPEED),
            ])
            .unwrap(),
        }],
        ProfileSelection::NearestInTime,
    )
    .unwrap()
}

fn flat_tide() -> VerticalReference {
    let gauge = TideGauge::new(
        "flat",
        Geodetic::from_degrees(69.0, 33.0, 0.0),
        vec![
            (Timestamp::from_unix_seconds(START - 10_000.0), 0.0),
            (Timestamp::from_unix_seconds(START + 10_000.0), 0.0),
        ],
        30_000.0,
    )
    .unwrap();
    VerticalReference::Tide {
        model: Box::new(TideModel::single_gauge(gauge).unwrap()),
        zone: "whole survey".into(),
    }
}

/// A line over a flat seabed whose transducer is mounted `bias` degrees out.
///
/// The travel times belong to the true beam directions; the angles written
/// into the file are what a sonar that does not know about the bias would
/// report. Reducing with a roll offset equal to the bias has to undo it.
fn biased_line(name: &str, heading: f64, start_lat: f64, pings: usize, bias: f64) -> Line {
    let (sin_hd, cos_hd) = Angle::from_degrees(heading).sin_cos();
    let records = (0..pings)
        .map(|p| {
            let along = p as f64 * 0.6;
            let lat = start_lat + along * cos_hd / 111_320.0;
            let lon = 33.0 + along * sin_hd / (111_320.0 * 69.0_f64.to_radians().cos());
            let beams: Vec<Beam> = (0..41)
                .map(|i| {
                    let truth = Angle::from_degrees(-50.0 + 2.5 * i as f64);
                    let slant = DEPTH / truth.cos();
                    let reported = Angle::from_degrees(truth.degrees() + bias);
                    let mut b = Beam::new(i as u16, 2.0 * slant / SPEED, reported);
                    b.detection = Detection::Amplitude;
                    b.quality = 0.9;
                    b
                })
                .collect();
            let mut ping = Ping::new(
                Timestamp::from_unix_seconds(START + p as f64 * 0.2),
                p as u64,
                SPEED,
                beams,
            );
            ping.navigation = Some(Navigation {
                position: Geodetic::from_degrees(lat, lon, 0.0),
                attitude: Attitude::from_degrees(0.0, 0.0, heading),
                heave: 0.0,
                speed: 3.0,
                transducer_height: None,
            });
            ping
        })
        .collect();
    Line::new(name, records)
}

#[test]
fn golden_section_finds_the_bottom_of_a_parabola() {
    let m = golden_section(-4.0, 4.0, 1.0e-6, |x| Ok((x - 1.25) * (x - 1.25) + 3.0)).unwrap();
    assert_relative_eq!(m.at, 1.25, epsilon = 1.0e-5);
    assert_relative_eq!(m.value, 3.0, epsilon = 1.0e-9);
    assert!(m.evaluations < 60);
    assert!(!m.on_boundary);
}

#[test]
fn a_minimum_at_the_edge_of_the_range_says_so() {
    let m = golden_section(0.0, 2.0, 1.0e-4, |x| Ok((x + 5.0) * (x + 5.0))).unwrap();
    assert!(m.on_boundary, "landed at {}", m.at);
}

#[test]
fn a_sweep_returns_the_points_it_was_asked_for() {
    let points = sweep(-1.0, 1.0, 5, |x| Ok(x * x)).unwrap();
    assert_eq!(points.len(), 5);
    assert_relative_eq!(points[0].0, -1.0, epsilon = 1.0e-12);
    assert_relative_eq!(points[2].1, 0.0, epsilon = 1.0e-12);
    assert_relative_eq!(points[4].0, 1.0, epsilon = 1.0e-12);
}

fn patch_test<'a>(
    config: &'a SurveyConfig,
    profiles: &'a ProfileLibrary,
    vertical: &'a VerticalReference,
) -> PatchTest<'a> {
    PatchTest {
        config,
        profiles,
        vertical,
        ellipsoid: Ellipsoid::WGS84,
        cell_size: 5.0,
    }
}

#[test]
fn the_roll_solver_gets_back_the_bias_that_was_put_in() {
    let config = SurveyConfig::parse(CONFIG).unwrap();
    let profiles = library();
    let vertical = flat_tide();
    let test = patch_test(&config, &profiles, &vertical);

    let bias = 0.8;
    let north = biased_line("north", 0.0, 69.0, 60, bias);
    let south = biased_line("south", 180.0, 69.0 + 36.0 / 111_320.0, 60, bias);

    let solved = test.solve(Parameter::Roll, &north, &south, None).unwrap();
    assert_relative_eq!(solved.at, bias, epsilon = 0.05);
    assert!(!solved.on_boundary);
    assert!(solved.value < 0.05, "residual {}", solved.value);
}

#[test]
fn a_system_with_no_bias_solves_to_zero() {
    let config = SurveyConfig::parse(CONFIG).unwrap();
    let profiles = library();
    let vertical = flat_tide();
    let test = patch_test(&config, &profiles, &vertical);

    let north = biased_line("north", 0.0, 69.0, 60, 0.0);
    let south = biased_line("south", 180.0, 69.0 + 36.0 / 111_320.0, 60, 0.0);
    let solved = test
        .solve(Parameter::Roll, &north, &south, Some((-2.0, 2.0)))
        .unwrap();
    assert_relative_eq!(solved.at, 0.0, epsilon = 0.05);
}

#[test]
fn the_disagreement_curve_has_its_minimum_where_the_solver_puts_it() {
    let config = SurveyConfig::parse(CONFIG).unwrap();
    let profiles = library();
    let vertical = flat_tide();
    let test = patch_test(&config, &profiles, &vertical);

    let bias = -1.2;
    let north = biased_line("north", 0.0, 69.0, 40, bias);
    let south = biased_line("south", 180.0, 69.0 + 24.0 / 111_320.0, 40, bias);

    let curve = test.curve(Parameter::Roll, &north, &south, 13).unwrap();
    assert_eq!(curve.len(), 13);
    let best = curve
        .iter()
        .min_by(|a, b| a.1.total_cmp(&b.1))
        .expect("a curve with points in it");
    assert!((best.0 - bias).abs() < 0.6, "curve bottoms at {}", best.0);
    // And the ends of the range are much worse than the bottom.
    assert!(curve[0].1 > best.1 * 3.0);
    assert!(curve[12].1 > best.1 * 3.0);
}

#[test]
fn a_pair_of_lines_that_do_not_overlap_is_refused() {
    let config = SurveyConfig::parse(CONFIG).unwrap();
    let profiles = library();
    let vertical = flat_tide();
    let test = patch_test(&config, &profiles, &vertical);

    let here = biased_line("here", 0.0, 69.0, 20, 0.0);
    let far = biased_line("far", 0.0, 69.2, 20, 0.0);
    assert!(test
        .disagreement(Parameter::Roll, 0.0, &here, &far)
        .is_err());
}

#[test]
fn shifting_the_navigation_moves_the_fixes_and_not_the_ping_times() {
    let line = biased_line("line", 0.0, 69.0, 20, 0.0);
    let shifted = shift_navigation(&line, 0.4);
    assert_eq!(shifted.len(), line.len());
    for (a, b) in line.pings().iter().zip(shifted.pings().iter()) {
        assert_eq!(a.time, b.time);
    }
    // Two pings in, the navigation is now the fix from two pings earlier.
    let original = line.pings()[10].navigation.unwrap().position;
    let moved = shifted.pings()[10].navigation.unwrap().position;
    let earlier = line.pings()[8].navigation.unwrap().position;
    assert!(moved.lat.degrees() < original.lat.degrees());
    assert_relative_eq!(
        moved.lat.degrees(),
        earlier.lat.degrees(),
        epsilon = 1.0e-12
    );
}

#[test]
fn the_parameters_describe_themselves() {
    for p in [
        Parameter::Roll,
        Parameter::Pitch,
        Parameter::Heading,
        Parameter::Latency,
    ] {
        assert!(!p.name().is_empty());
        let (low, high) = p.default_range();
        assert!(low < 0.0 && high > 0.0);
    }
    assert_eq!(Parameter::Latency.unit(), "s");
    assert_eq!(Parameter::Roll.unit(), "deg");
}
