//! Grid geometry, cell statistics, estimators and hypotheses.

use approx::assert_relative_eq;
use plumbline::geodesy::utm::{Projected, TransverseMercator};
use plumbline::geodesy::{Ellipsoid, Geodetic};
use plumbline::grid::cell::Cell;
use plumbline::grid::contested::ContestedSurface;
use plumbline::grid::estimator::{render, render_uncertainty, Estimator};
use plumbline::grid::geometry::{CellIndex, GridGeometry};
use plumbline::grid::hypothesis::{Disambiguation, Hypothesis, HypothesisSet};
use plumbline::grid::surface::Surface;
use plumbline::ping::beam::{BeamFlags, Detection};
use plumbline::ping::sounding::Sounding;
use plumbline::time::Timestamp;

fn projection() -> TransverseMercator {
    TransverseMercator::utm(36, true, Ellipsoid::WGS84).unwrap()
}

fn sounding_at(lat: f64, lon: f64, depth: f64, tvu: f64) -> Sounding {
    Sounding {
        time: Timestamp::EPOCH,
        ping: 0,
        beam: 0,
        position: Geodetic::from_degrees(lat, lon, 0.0),
        depth,
        across: 0.0,
        along: 0.0,
        tvu,
        thu: 1.0,
        detection: Detection::Amplitude,
        flags: BeamFlags::NONE,
    }
}

#[test]
fn a_covering_grid_snaps_its_origin_to_the_cell_size() {
    let g = GridGeometry::covering(1003.0, 2007.0, 1050.0, 2060.0, 10.0).unwrap();
    assert_relative_eq!(g.origin_east, 1000.0, epsilon = 1.0e-12);
    assert_relative_eq!(g.origin_north, 2000.0, epsilon = 1.0e-12);
    assert_eq!(g.columns, 5);
    assert_eq!(g.rows, 6);
    assert!(g.max_east() >= 1050.0);
    assert!(g.max_north() >= 2060.0);
}

#[test]
fn two_grids_at_the_same_resolution_line_up() {
    let a = GridGeometry::covering(1003.0, 2007.0, 1200.0, 2200.0, 5.0).unwrap();
    let b = GridGeometry::covering(1101.0, 2103.0, 1400.0, 2400.0, 5.0).unwrap();
    let offset = (a.origin_east - b.origin_east) / 5.0;
    assert_relative_eq!(offset, offset.round(), epsilon = 1.0e-12);
}

#[test]
fn a_position_on_a_boundary_belongs_up_and_to_the_right() {
    let g = GridGeometry::new(0.0, 0.0, 10.0, 4, 4).unwrap();
    assert_eq!(g.index_of(Projected::new(0.0, 0.0)), CellIndex::new(0, 0));
    assert_eq!(
        g.index_of(Projected::new(9.999, 9.999)),
        CellIndex::new(0, 0)
    );
    assert_eq!(g.index_of(Projected::new(10.0, 10.0)), CellIndex::new(1, 1));
    assert_eq!(g.index_of(Projected::new(-0.1, 5.0)), CellIndex::new(-1, 0));
}

#[test]
fn cell_centres_and_offsets_round_trip() {
    let g = GridGeometry::new(500.0, 1000.0, 4.0, 7, 3).unwrap();
    for offset in 0..g.cell_count() {
        let index = g.index_at_offset(offset).unwrap();
        assert_eq!(g.offset_of(index), Some(offset));
        assert_eq!(g.index_of(g.centre_of(index)), index);
    }
    assert!(g.index_at_offset(g.cell_count()).is_none());
    assert!(!g.contains(CellIndex::new(7, 0)));
    assert!(!g.contains(CellIndex::new(0, 3)));
}

#[test]
fn a_bad_grid_is_refused() {
    assert!(GridGeometry::new(0.0, 0.0, 0.0, 4, 4).is_err());
    assert!(GridGeometry::new(0.0, 0.0, -1.0, 4, 4).is_err());
    assert!(GridGeometry::new(0.0, 0.0, 1.0, 0, 4).is_err());
    assert!(GridGeometry::covering(10.0, 0.0, 0.0, 10.0, 1.0).is_err());
}

#[test]
fn a_cell_keeps_the_statistics_it_promises() {
    let mut c = Cell::EMPTY;
    assert!(c.is_empty());
    assert_eq!(c.mean(), None);
    for d in [10.0, 12.0, 11.0, 13.0] {
        c.add(d, 0.2);
    }
    assert_eq!(c.count(), 4);
    assert_relative_eq!(c.mean().unwrap(), 11.5, epsilon = 1.0e-12);
    assert_relative_eq!(c.shoalest().unwrap(), 10.0, epsilon = 1.0e-12);
    assert_relative_eq!(c.deepest().unwrap(), 13.0, epsilon = 1.0e-12);
    assert_relative_eq!(c.range().unwrap(), 3.0, epsilon = 1.0e-12);
    // Sample standard deviation of 10, 11, 12, 13.
    assert_relative_eq!(
        c.standard_deviation().unwrap(),
        (5.0f64 / 3.0).sqrt(),
        epsilon = 1.0e-12
    );
}

#[test]
fn the_weighted_mean_leans_on_the_better_soundings() {
    let mut c = Cell::EMPTY;
    c.add(10.0, 0.1);
    c.add(20.0, 1.0);
    // The precise one carries a hundred times the weight.
    assert_relative_eq!(c.mean().unwrap(), 15.0, epsilon = 1.0e-12);
    assert_relative_eq!(c.weighted_mean().unwrap(), 10.099_009_9, epsilon = 1.0e-6);
    assert!(c.weighted_uncertainty().unwrap() < 0.1);
    assert_relative_eq!(c.best_uncertainty().unwrap(), 0.1, epsilon = 1.0e-12);
}

#[test]
fn merging_cells_matches_adding_everything_to_one() {
    let values = [4.0, 9.0, 1.0, 7.0, 3.0, 8.0];
    let mut whole = Cell::EMPTY;
    for v in values {
        whole.add(v, 0.3);
    }
    let mut left = Cell::EMPTY;
    for v in &values[..2] {
        left.add(*v, 0.3);
    }
    let mut right = Cell::EMPTY;
    for v in &values[2..] {
        right.add(*v, 0.3);
    }
    left.merge(&right);

    assert_eq!(left.count(), whole.count());
    assert_relative_eq!(
        left.mean().unwrap(),
        whole.mean().unwrap(),
        epsilon = 1.0e-12
    );
    assert_relative_eq!(
        left.standard_deviation().unwrap(),
        whole.standard_deviation().unwrap(),
        epsilon = 1.0e-12
    );
    assert_relative_eq!(left.shoalest().unwrap(), 1.0, epsilon = 1.0e-12);

    // Merging an empty cell changes nothing either way round.
    let before = left;
    left.merge(&Cell::EMPTY);
    assert_eq!(left, before);
}

#[test]
fn soundings_land_in_the_surface_and_the_strays_get_counted() {
    let geometry = GridGeometry::new(500_000.0, 7_650_000.0, 5.0, 20, 20).unwrap();
    let mut surface = Surface::new(geometry, projection());
    let centre = surface.position_of(CellIndex::new(10, 10)).unwrap();

    for d in [22.1, 22.4, 21.8] {
        let mut s = sounding_at(0.0, 0.0, d, 0.2);
        s.position = centre;
        surface.add(&s).unwrap();
    }
    let cell = surface.cell(CellIndex::new(10, 10)).unwrap();
    assert_eq!(cell.count(), 3);
    assert_relative_eq!(cell.shoalest().unwrap(), 21.8, epsilon = 1.0e-9);
    assert_eq!(surface.populated_cells(), 1);

    // A sounding a long way off the block is counted, not silently dropped.
    let stray = sounding_at(60.0, 33.0, 30.0, 0.2);
    assert!(!surface.add(&stray).unwrap());
    assert_eq!(surface.outside_count(), 1);

    // And a rejected sounding never gets near a cell.
    let mut flagged = sounding_at(0.0, 0.0, 5.0, 0.2);
    flagged.position = centre;
    flagged.flags.set(BeamFlags::LOW_QUALITY);
    assert!(!surface.add(&flagged).unwrap());
    assert_eq!(surface.cell(CellIndex::new(10, 10)).unwrap().count(), 3);
}

#[test]
fn the_estimators_disagree_in_the_way_they_should() {
    let mut c = Cell::EMPTY;
    c.add(18.0, 0.5);
    c.add(20.0, 0.1);
    c.add(21.0, 0.1);
    assert_relative_eq!(
        Estimator::Shoalest.depth(&c).unwrap(),
        18.0,
        epsilon = 1.0e-12
    );
    assert_relative_eq!(
        Estimator::Deepest.depth(&c).unwrap(),
        21.0,
        epsilon = 1.0e-12
    );
    // The mean is dragged by the poor sounding, the weighted mean much less.
    let mean = Estimator::Mean.depth(&c).unwrap();
    let weighted = Estimator::WeightedMean.depth(&c).unwrap();
    assert!(weighted > mean);
    assert!(Estimator::Shoalest.is_shoal_biased());
    assert!(!Estimator::WeightedMean.is_shoal_biased());

    let confident = Estimator::ShoalestOfConfident { min_soundings: 4 };
    assert!(confident.depth(&c).is_none());
    assert!(Estimator::ShoalestOfConfident { min_soundings: 3 }
        .depth(&c)
        .is_some());
}

#[test]
fn estimator_names_round_trip() {
    for e in [
        Estimator::Shoalest,
        Estimator::Deepest,
        Estimator::Mean,
        Estimator::WeightedMean,
    ] {
        assert_eq!(Estimator::from_name(e.name()), Some(e));
    }
    assert_eq!(Estimator::from_name("nothing"), None);
}

#[test]
fn rendering_leaves_holes_where_there_are_no_soundings() {
    let geometry = GridGeometry::new(500_000.0, 7_650_000.0, 5.0, 4, 4).unwrap();
    let mut surface = Surface::new(geometry, projection());
    surface.add_at(Projected::new(500_002.0, 7_650_002.0), 15.0, 0.2);
    surface.add_at(Projected::new(500_003.0, 7_650_001.0), 15.4, 0.2);

    let raster = render(&surface, Estimator::Shoalest);
    assert_eq!(raster.columns, 4);
    assert_eq!(raster.populated(), 1);
    assert_relative_eq!(raster.at(0, 0).unwrap(), 15.0, epsilon = 1.0e-12);
    assert!(raster.at(3, 3).is_none());
    assert!(raster.at(9, 9).is_none());
    let (lo, hi) = raster.range().unwrap();
    assert_relative_eq!(lo, hi, epsilon = 1.0e-12);

    let sigma = render_uncertainty(&surface, Estimator::WeightedMean);
    assert!(sigma.at(0, 0).unwrap() < 0.2);
}

#[test]
fn surfaces_merge_only_when_the_geometry_matches() {
    let geometry = GridGeometry::new(0.0, 0.0, 10.0, 3, 3).unwrap();
    let mut a = Surface::new(geometry, projection());
    let mut b = Surface::new(geometry, projection());
    a.add_at(Projected::new(5.0, 5.0), 10.0, 0.2);
    b.add_at(Projected::new(5.0, 5.0), 12.0, 0.2);
    a.merge(&b).unwrap();
    assert_eq!(a.cell(CellIndex::new(0, 0)).unwrap().count(), 2);
    assert_relative_eq!(
        a.cell(CellIndex::new(0, 0)).unwrap().mean().unwrap(),
        11.0,
        epsilon = 1.0e-12
    );

    let other = Surface::new(
        GridGeometry::new(0.0, 0.0, 5.0, 3, 3).unwrap(),
        projection(),
    );
    assert!(a.merge(&other).is_err());
}

#[test]
fn a_hypothesis_absorbs_agreeing_soundings_and_splits_on_the_rest() {
    let mut set = HypothesisSet::new();
    for d in [20.0, 20.05, 19.95, 20.02] {
        set.add(d, 0.1, 2.5);
    }
    assert_eq!(set.len(), 1);
    assert_relative_eq!(set.hypotheses()[0].depth, 20.0, epsilon = 0.05);
    // A wreck five metres off the bottom is a different answer, not noise.
    set.add(15.0, 0.1, 2.5);
    set.add(15.02, 0.1, 2.5);
    assert_eq!(set.len(), 2);
    assert_eq!(set.total_soundings(), 6);
    assert!(set.contention() > 0.0);
}

#[test]
fn an_updated_hypothesis_tightens_up() {
    let mut h = Hypothesis::seed(30.0, 0.4);
    let before = h.sigma();
    h.update(30.2, 0.4);
    assert!(h.sigma() < before);
    assert_relative_eq!(h.depth, 30.1, epsilon = 1.0e-9);
    assert_eq!(h.count, 2);
    // Distance is measured against both uncertainties together.
    assert!(h.distance_to(30.1, 0.4) < 1.0);
    assert!(h.distance_to(40.0, 0.01) > 10.0);
}

#[test]
fn the_disambiguation_rules_pick_different_answers() {
    let mut set = HypothesisSet::new();
    for _ in 0..10 {
        set.add(40.0, 0.3, 2.0);
    }
    set.add(31.0, 0.3, 2.0);
    set.add(31.05, 0.3, 2.0);

    assert_eq!(set.len(), 2);
    assert_relative_eq!(
        set.resolve(Disambiguation::MostSounded, None)
            .unwrap()
            .depth,
        40.0,
        epsilon = 0.1
    );
    assert_relative_eq!(
        set.resolve(Disambiguation::Shoalest, None).unwrap().depth,
        31.0,
        epsilon = 0.1
    );
    assert_relative_eq!(
        set.resolve(Disambiguation::LeastUncertain, None)
            .unwrap()
            .depth,
        40.0,
        epsilon = 0.1
    );
    assert_relative_eq!(
        set.resolve(Disambiguation::NearestToGuide, Some(31.5))
            .unwrap()
            .depth,
        31.0,
        epsilon = 0.1
    );
    // With no guide the rule falls back to something that needs none.
    assert!(set.resolve(Disambiguation::NearestToGuide, None).is_some());
    assert!(HypothesisSet::new()
        .resolve(Disambiguation::Shoalest, None)
        .is_none());
}

/// Put a depth into a contested surface at a projected point.
fn contested_add(surface: &mut ContestedSurface, at: Projected, depth: f64) {
    let position = projection().inverse(at).unwrap();
    let mut s = sounding_at(0.0, 0.0, depth, 0.2);
    s.position = position;
    surface.add(&s).unwrap();
}

#[test]
fn a_contested_surface_resolves_with_help_from_the_neighbours() {
    let geometry = GridGeometry::new(500_000.0, 7_650_000.0, 10.0, 3, 3).unwrap();
    let mut surface = ContestedSurface::new(geometry, projection(), 2.5);

    // Everything around the middle cell is flat seabed at forty metres.
    for column in 0..3 {
        for row in 0..3 {
            if column == 1 && row == 1 {
                continue;
            }
            let p = geometry.centre_of(CellIndex::new(column, row));
            for _ in 0..4 {
                contested_add(&mut surface, p, 40.0);
            }
        }
    }
    // The middle cell is split evenly between the seabed and something above.
    let middle = geometry.centre_of(CellIndex::new(1, 1));
    for _ in 0..3 {
        contested_add(&mut surface, middle, 40.0);
        contested_add(&mut surface, middle, 34.0);
    }

    assert_eq!(surface.contested_cells(), 1);
    let guided = surface.resolve(Disambiguation::NearestToGuide);
    assert_relative_eq!(guided.at(1, 1).unwrap(), 40.0, epsilon = 0.2);
    let shoalest = surface.resolve(Disambiguation::Shoalest);
    assert_relative_eq!(shoalest.at(1, 1).unwrap(), 34.0, epsilon = 0.2);

    let contention = surface.contention_raster();
    assert_relative_eq!(contention.at(1, 1).unwrap(), 1.0, epsilon = 1.0e-9);
    assert_relative_eq!(contention.at(0, 0).unwrap(), 0.0, epsilon = 1.0e-9);
    assert_eq!(surface.outside_count(), 0);
    assert!(surface.cell(CellIndex::new(1, 1)).unwrap().len() == 2);
}
