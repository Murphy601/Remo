//! Dense and sparse storage have to be indistinguishable apart from cost.

use approx::assert_relative_eq;
use plumbline::geodesy::utm::{Projected, TransverseMercator};
use plumbline::geodesy::Ellipsoid;
use plumbline::grid::cell::Cell;
use plumbline::grid::estimator::{render, Estimator};
use plumbline::grid::geometry::{CellIndex, GridGeometry};
use plumbline::grid::store::{CellStore, DENSE_CELL_LIMIT};
use plumbline::grid::surface::Surface;

fn projection() -> TransverseMercator {
    TransverseMercator::utm(36, true, Ellipsoid::WGS84).unwrap()
}

fn geometry() -> GridGeometry {
    GridGeometry::new(500_000.0, 7_650_000.0, 1.0, 12, 9).unwrap()
}

/// The same soundings put into a surface, whichever store it has.
fn fill(store: CellStore) -> Surface {
    let mut surface = Surface::with_store(geometry(), projection(), store);
    for i in 0..12 {
        for j in 0..9 {
            if (i + j) % 3 == 0 {
                continue; // leave holes, so the two stores differ where it counts
            }
            for k in 0..3 {
                surface.add_at(
                    Projected::new(500_000.5 + i as f64, 7_650_000.5 + j as f64),
                    20.0 + i as f64 * 0.1 + k as f64 * 0.01,
                    0.2,
                );
            }
        }
    }
    surface
}

#[test]
fn the_two_stores_hold_the_same_thing() {
    let dense = fill(CellStore::dense(geometry().cell_count()));
    let sparse = fill(CellStore::sparse(geometry().cell_count()));

    assert!(!dense.store().is_sparse());
    assert!(sparse.store().is_sparse());
    assert_eq!(dense.populated_cells(), sparse.populated_cells());
    assert_relative_eq!(dense.coverage(), sparse.coverage(), epsilon = 1.0e-12);

    for row in 0..9 {
        for column in 0..12 {
            let index = CellIndex::new(column, row);
            assert_eq!(dense.cell(index), sparse.cell(index), "at {index:?}");
        }
    }

    let a = render(&dense, Estimator::Shoalest);
    let b = render(&sparse, Estimator::Shoalest);
    assert_eq!(a.depths, b.depths);
}

#[test]
fn a_sparse_store_only_pays_for_what_it_holds() {
    let dense = fill(CellStore::dense(geometry().cell_count()));
    let sparse = fill(CellStore::sparse(geometry().cell_count()));
    // Two thirds of the grid has data, so the sparse store is not smaller
    // here, which is the honest result and the reason the choice is by size.
    assert!(sparse.store().footprint() > 0);
    assert!(dense.store().footprint() > 0);

    let mostly_empty = CellStore::sparse(1_000_000);
    assert_eq!(mostly_empty.footprint(), 0);
    assert_eq!(mostly_empty.len(), 1_000_000);
    assert_eq!(mostly_empty.populated(), 0);
}

#[test]
fn an_empty_offset_reads_back_as_an_empty_cell() {
    let store = CellStore::sparse(10);
    assert!(store.get(4).is_empty());
    assert!(store.get(999).is_empty());
    assert_eq!(store.get(4), Cell::EMPTY);

    let dense = CellStore::dense(10);
    assert_eq!(dense.get(999), Cell::EMPTY);
}

#[test]
fn writing_past_the_end_is_ignored_by_both() {
    let mut dense = CellStore::dense(4);
    let mut sparse = CellStore::sparse(4);
    dense.add(99, 10.0, 0.2);
    sparse.add(99, 10.0, 0.2);
    assert_eq!(dense.populated(), 0);
    assert_eq!(sparse.populated(), 0);
    assert_eq!(sparse.get(99), Cell::EMPTY);
}

#[test]
fn merging_works_between_the_two_kinds() {
    let mut dense = CellStore::dense(6);
    dense.add(2, 10.0, 0.2);
    let mut sparse = CellStore::sparse(6);
    sparse.add(2, 12.0, 0.2);
    sparse.add(5, 30.0, 0.2);

    dense.merge(&sparse);
    assert_eq!(dense.get(2).count(), 2);
    assert_relative_eq!(dense.get(2).mean().unwrap(), 11.0, epsilon = 1.0e-12);
    assert_eq!(dense.get(5).count(), 1);
    assert_eq!(dense.populated(), 2);

    let mut back = CellStore::sparse(6);
    back.add(0, 1.0, 0.1);
    back.merge(&dense);
    assert_eq!(back.populated(), 3);
}

#[test]
fn iterating_a_sparse_store_still_visits_every_square() {
    let mut store = CellStore::sparse(7);
    store.add(3, 15.0, 0.2);
    let cells: Vec<Cell> = store.iter().collect();
    assert_eq!(cells.len(), 7);
    assert_eq!(cells.iter().filter(|c| !c.is_empty()).count(), 1);
    assert!(!cells[3].is_empty());
}

#[test]
fn the_size_threshold_picks_the_right_store() {
    assert!(!CellStore::for_size(1_000).is_sparse());
    assert!(!CellStore::for_size(DENSE_CELL_LIMIT / 100).is_sparse());
    assert!(CellStore::for_size(DENSE_CELL_LIMIT).is_sparse());
    // And a grid that large does not try to allocate itself.
    let huge = CellStore::for_size(DENSE_CELL_LIMIT);
    assert_eq!(huge.footprint(), 0);
    assert!(!huge.is_empty());
}
