//! What the errors say, which is most of what a user of this ever sees.

mod common;

use common::TempDir;
use plumbline::error::{Error, FormatError, InFile};
use plumbline::io::pbf::read_pings;
use plumbline::svp::parse::read_svp_file;
use plumbline::units::Angle;
use plumbline::{geodesy, Result};

#[test]
fn an_io_error_names_the_file() {
    let dir = TempDir::new("errors");
    let missing = dir.join("no-such-line.pbf");
    let err = read_pings(&missing).unwrap_err();
    let text = format!("{err}");
    assert!(text.contains("no-such-line.pbf"), "{text}");
    assert!(text.starts_with("io error on"), "{text}");
}

#[test]
fn a_format_error_names_the_file_and_the_line() {
    let dir = TempDir::new("errors");
    let path = dir.join("bad.svp");
    std::fs::write(&path, "[SVP_VERSION_9]\n0.0 1500.0\n").unwrap();
    let err = read_svp_file(&path).unwrap_err();
    let text = format!("{err}");
    assert!(text.contains("bad.svp"), "{text}");
    assert!(text.contains(":1:"), "{text}");
    assert!(text.contains("banner"), "{text}");
}

#[test]
fn a_domain_error_says_what_was_expected() {
    let err = geodesy::utm::TransverseMercator::utm(99, true, Default::default()).unwrap_err();
    let text = format!("{err}");
    assert!(text.contains("utm zone"), "{text}");
    assert!(text.contains("99"), "{text}");
    assert!(text.contains("1 to 60"), "{text}");
}

#[test]
fn a_config_error_names_the_key() {
    let err =
        plumbline::config::survey::SurveyConfig::parse("[grid]\ncell_size = 1.0\n").unwrap_err();
    let text = format!("{err}");
    assert!(text.contains("survey.name"), "{text}");
}

#[test]
fn attaching_a_file_leaves_other_kinds_alone() {
    let format: Result<()> = Err(FormatError::at_line(4, "no good").into());
    let annotated = format.in_file("somewhere.svp").unwrap_err();
    assert!(format!("{annotated}").contains("somewhere.svp"));

    let domain: Result<()> = Err(Error::domain("depth", -1.0, "positive"));
    let untouched = domain.in_file("somewhere.svp").unwrap_err();
    assert!(!format!("{untouched}").contains("somewhere.svp"));
    assert!(format!("{untouched}").contains("depth"));
}

#[test]
fn a_format_error_reads_the_same_with_or_without_a_line() {
    let bare = FormatError::new("nothing here");
    assert_eq!(format!("{bare}"), "nothing here");

    let with_line = FormatError::at_line(7, "nothing here");
    assert_eq!(format!("{with_line}"), "line 7: nothing here");

    let with_file = FormatError::new("nothing here").in_file("a.svp");
    assert_eq!(format!("{with_file}"), "a.svp: nothing here");

    let both = FormatError::at_line(7, "nothing here").in_file("a.svp");
    assert_eq!(format!("{both}"), "a.svp:7: nothing here");
}

#[test]
fn the_error_type_carries_its_source() {
    use std::error::Error as _;
    let dir = TempDir::new("errors");
    let err = read_pings(dir.join("gone.pbf")).unwrap_err();
    assert!(err.source().is_some(), "an io error should keep the os one");
}

#[test]
fn a_bad_angle_into_the_tracer_says_which_quantity() {
    use plumbline::raytrace::Tracer;
    use plumbline::svp::profile::{Sample, SoundSpeedProfile};

    let profile =
        SoundSpeedProfile::new(vec![Sample::new(0.0, 1500.0), Sample::new(100.0, 1500.0)]).unwrap();
    let tracer = Tracer::new(&profile, 0.0).unwrap();
    let err = tracer.trace(Angle::from_degrees(95.0), 0.1).unwrap_err();
    let text = format!("{err}");
    assert!(text.contains("launch angle"), "{text}");
    assert!(text.contains("90 degrees"), "{text}");
}
