//! Feature detection over surfaces built by hand.

use approx::assert_relative_eq;
use plumbline::geodesy::utm::{Projected, TransverseMercator};
use plumbline::geodesy::Ellipsoid;
use plumbline::grid::estimator::{render, Estimator};
use plumbline::grid::geometry::GridGeometry;
use plumbline::grid::surface::Surface;
use plumbline::qc::features::{find_features, FeatureSearch};
use plumbline::tpu::s44::Order;

const CELL: f64 = 1.0;
const SEABED: f64 = 30.0;

/// A flat seabed with soundings in every cell, and whatever is put on top.
fn seabed(columns: usize, rows: usize, soundings_per_cell: u32) -> Surface {
    let geometry = GridGeometry::new(0.0, 0.0, CELL, columns, rows).unwrap();
    let projection = TransverseMercator::utm(36, true, Ellipsoid::WGS84).unwrap();
    let mut surface = Surface::new(geometry, projection);
    for row in 0..rows {
        for column in 0..columns {
            for _ in 0..soundings_per_cell {
                surface.add_at(
                    Projected::new(column as f64 + 0.5, row as f64 + 0.5),
                    SEABED,
                    0.2,
                );
            }
        }
    }
    surface
}

fn raise(surface: &mut Surface, column: usize, row: usize, depth: f64, count: u32) {
    for _ in 0..count {
        surface.add_at(
            Projected::new(column as f64 + 0.5, row as f64 + 0.5),
            depth,
            0.2,
        );
    }
}

#[test]
fn a_flat_seabed_has_no_features() {
    let surface = seabed(25, 25, 5);
    let raster = render(&surface, Estimator::Shoalest);
    let found = find_features(&surface, &raster, &FeatureSearch::default());
    assert!(found.is_empty(), "found {found:?}");
}

#[test]
fn a_wreck_standing_off_the_bottom_is_found() {
    let mut surface = seabed(25, 25, 5);
    // A three by three block standing four metres proud, in the middle.
    for column in 11..=13 {
        for row in 11..=13 {
            raise(&mut surface, column, row, SEABED - 4.0, 6);
        }
    }
    let raster = render(&surface, Estimator::Shoalest);
    let found = find_features(&surface, &raster, &FeatureSearch::default());

    assert_eq!(found.len(), 1);
    let wreck = &found[0];
    assert_relative_eq!(wreck.least_depth, SEABED - 4.0, epsilon = 1.0e-9);
    assert_relative_eq!(wreck.surrounding_depth, SEABED, epsilon = 1.0e-9);
    assert_relative_eq!(wreck.relief, 4.0, epsilon = 1.0e-9);
    assert_eq!(wreck.cells, 9);
    assert!(wreck.soundings >= 6);
    assert!(wreck.extent(CELL) > 2.0);
}

#[test]
fn a_single_shallow_sounding_is_a_fish_and_not_a_feature() {
    let mut surface = seabed(25, 25, 5);
    // One shallow return in a cell that is otherwise seabed.
    raise(&mut surface, 12, 12, SEABED - 6.0, 1);
    let raster = render(&surface, Estimator::Shoalest);

    // The default search wants four soundings in the cell before it counts,
    // and this cell has five seabed ones and the fish, so it does count. What
    // stops it is asking for more.
    let strict = FeatureSearch {
        min_soundings: 12,
        ..FeatureSearch::default()
    };
    assert!(find_features(&surface, &raster, &strict).is_empty());

    // A cell with only the fish in it never qualifies.
    let mut sparse = seabed(25, 25, 0);
    for row in 0..25 {
        for column in 0..25 {
            if column != 12 || row != 12 {
                raise(&mut sparse, column, row, SEABED, 5);
            }
        }
    }
    raise(&mut sparse, 12, 12, SEABED - 6.0, 1);
    let sparse_raster = render(&sparse, Estimator::Shoalest);
    assert!(find_features(&sparse, &sparse_raster, &FeatureSearch::default()).is_empty());
}

#[test]
fn two_wrecks_come_back_as_two_features_sorted_by_relief() {
    let mut surface = seabed(35, 35, 5);
    raise(&mut surface, 10, 10, SEABED - 2.0, 6);
    raise(&mut surface, 10, 11, SEABED - 2.0, 6);
    raise(&mut surface, 25, 25, SEABED - 7.0, 6);

    let raster = render(&surface, Estimator::Shoalest);
    let found = find_features(&surface, &raster, &FeatureSearch::default());
    assert_eq!(found.len(), 2);
    assert!(found[0].relief > found[1].relief);
    assert_relative_eq!(found[0].relief, 7.0, epsilon = 1.0e-9);
    assert_eq!(found[0].cells, 1);
    assert_eq!(found[1].cells, 2);
}

#[test]
fn a_relief_threshold_decides_what_counts() {
    let mut surface = seabed(25, 25, 5);
    raise(&mut surface, 12, 12, SEABED - 0.8, 6);
    let raster = render(&surface, Estimator::Shoalest);

    let loose = FeatureSearch {
        min_relief: 0.5,
        ..FeatureSearch::default()
    };
    let tight = FeatureSearch {
        min_relief: 1.5,
        ..FeatureSearch::default()
    };
    assert_eq!(find_features(&surface, &raster, &loose).len(), 1);
    assert!(find_features(&surface, &raster, &tight).is_empty());
}

#[test]
fn a_feature_knows_which_orders_would_have_required_it() {
    let mut surface = seabed(25, 25, 5);
    // One and a half metres of relief in thirty metres of water.
    raise(&mut surface, 12, 12, SEABED - 1.5, 6);
    let raster = render(&surface, Estimator::Shoalest);
    let found = find_features(&surface, &raster, &FeatureSearch::default());
    let f = &found[0];

    // Exclusive wants half a metre, special wants a metre, order 1 wants two
    // metres at this depth and order 2 requires nothing.
    assert!(f.meets(Order::Exclusive));
    assert!(f.meets(Order::Special));
    assert!(!f.meets(Order::One));
    assert!(!f.meets(Order::Two));
}

#[test]
fn a_slope_is_not_a_feature() {
    let geometry = GridGeometry::new(0.0, 0.0, CELL, 30, 30).unwrap();
    let projection = TransverseMercator::utm(36, true, Ellipsoid::WGS84).unwrap();
    let mut surface = Surface::new(geometry, projection);
    for row in 0..30 {
        for column in 0..30 {
            for _ in 0..5 {
                surface.add_at(
                    Projected::new(column as f64 + 0.5, row as f64 + 0.5),
                    20.0 + column as f64 * 0.3,
                    0.2,
                );
            }
        }
    }
    let raster = render(&surface, Estimator::Shoalest);
    let found = find_features(&surface, &raster, &FeatureSearch::default());
    assert!(found.is_empty(), "a plane produced {found:?}");
}
