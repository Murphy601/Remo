//! Smoothing and despiking, checked for the things a filter can get wrong.

use approx::assert_relative_eq;
use plumbline::motion::filter::{despike, largest_step, rate_of_change, smooth, smooth_series};
use plumbline::motion::series::{Entry, TimeSeries};
use plumbline::time::Timestamp;

fn t(s: f64) -> Timestamp {
    Timestamp::from_unix_seconds(s)
}

fn series(values: &[f64], interval: f64) -> TimeSeries<f64> {
    TimeSeries::new(
        values
            .iter()
            .enumerate()
            .map(|(i, v)| Entry {
                time: t(i as f64 * interval),
                value: *v,
            })
            .collect(),
        10.0,
    )
}

#[test]
fn smoothing_a_constant_changes_nothing() {
    let flat = vec![3.5; 40];
    let out = smooth(&flat, 9);
    for v in out {
        assert_relative_eq!(v, 3.5, epsilon = 1.0e-12);
    }
}

#[test]
fn smoothing_a_ramp_leaves_the_ramp_where_it_was() {
    // A straight line through a symmetric filter comes back as itself, apart
    // from the ends. This is the property that says the filter has no phase.
    let ramp: Vec<f64> = (0..60).map(|i| i as f64 * 0.25).collect();
    let out = smooth(&ramp, 11);
    for i in 12..48 {
        assert_relative_eq!(out[i], ramp[i], epsilon = 1.0e-9);
    }
}

#[test]
fn a_sine_comes_back_in_phase() {
    // The amplitude is allowed to drop, that is what a low pass does. What is
    // not allowed is for the peak to move.
    let wave: Vec<f64> = (0..200)
        .map(|i| (i as f64 / 200.0 * std::f64::consts::TAU * 3.0).sin())
        .collect();
    let out = smooth(&wave, 7);

    let peak_in = wave
        .iter()
        .enumerate()
        .skip(10)
        .take(50)
        .max_by(|a, b| a.1.total_cmp(b.1))
        .unwrap()
        .0;
    let peak_out = out
        .iter()
        .enumerate()
        .skip(10)
        .take(50)
        .max_by(|a, b| a.1.total_cmp(b.1))
        .unwrap()
        .0;
    assert!(
        peak_in.abs_diff(peak_out) <= 1,
        "peak moved from {peak_in} to {peak_out}"
    );
    assert!(out[peak_out].abs() < wave[peak_in].abs());
}

#[test]
fn a_short_series_or_a_window_of_one_is_left_alone() {
    let short = vec![1.0, 5.0];
    assert_eq!(smooth(&short, 9), short);
    let values = vec![1.0, 2.0, 9.0, 2.0];
    assert_eq!(smooth(&values, 1), values);
}

#[test]
fn a_spike_is_replaced_and_counted() {
    let mut values: Vec<f64> = (0..40).map(|i| 10.0 + (i % 3) as f64 * 0.01).collect();
    values[20] = 40.0;
    let (cleaned, replaced) = despike(&values, 7, 1.0);
    assert_eq!(replaced, 1);
    assert!(cleaned[20] < 11.0, "spike survived as {}", cleaned[20]);
    // Nothing else moved.
    for i in [5, 15, 25, 35] {
        assert_relative_eq!(cleaned[i], values[i], epsilon = 1.0e-12);
    }
}

#[test]
fn a_big_spike_does_not_hide_itself() {
    // Against a mean, a spike this size drags the window far enough that the
    // spike is inside the tolerance. Against the median it does not.
    let mut values = vec![2.0; 30];
    values[15] = 5000.0;
    let (cleaned, replaced) = despike(&values, 5, 10.0);
    assert_eq!(replaced, 1);
    assert_relative_eq!(cleaned[15], 2.0, epsilon = 1.0e-12);
}

#[test]
fn a_real_step_is_not_a_spike() {
    // A tide that steps and stays stepped is data, not noise.
    let mut values = vec![1.0; 20];
    values.extend(std::iter::repeat(6.0).take(20));
    let (cleaned, replaced) = despike(&values, 7, 2.0);
    assert_eq!(replaced, 0);
    assert_eq!(cleaned, values);
}

#[test]
fn smoothing_a_series_keeps_its_times_and_its_gap_rule() {
    let raw = series(&[1.0, 9.0, 1.0, 9.0, 1.0, 9.0, 1.0], 0.5);
    let smoothed = smooth_series(&raw, 5);
    assert_eq!(smoothed.len(), raw.len());
    assert_relative_eq!(smoothed.max_gap(), raw.max_gap(), epsilon = 1.0e-12);
    for (a, b) in raw.entries().iter().zip(smoothed.entries().iter()) {
        assert_eq!(a.time, b.time);
    }
    // The alternation is flattened towards the middle.
    let values: Vec<f64> = smoothed.entries().iter().map(|e| e.value).collect();
    assert!(largest_step(&values) < largest_step(&[1.0, 9.0]));
}

#[test]
fn the_rate_of_change_of_a_ramp_is_its_slope() {
    let ramp = series(&[0.0, 1.0, 2.0, 3.0, 4.0, 5.0], 1.0);
    let rate = rate_of_change(&ramp, t(2.5), 1.0).unwrap();
    assert_relative_eq!(rate, 1.0, epsilon = 1.0e-9);
    assert!(rate_of_change(&ramp, t(2.5), 0.0).is_none());
}

#[test]
fn the_largest_step_finds_the_worst_jump() {
    assert_relative_eq!(
        largest_step(&[1.0, 1.2, 1.1, 7.0, 7.1]),
        5.9,
        epsilon = 1.0e-9
    );
    assert_relative_eq!(largest_step(&[4.0]), 0.0, epsilon = 1.0e-12);
    assert_relative_eq!(largest_step(&[]), 0.0, epsilon = 1.0e-12);
}
