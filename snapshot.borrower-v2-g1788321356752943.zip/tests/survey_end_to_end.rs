//! One synthetic survey carried the whole way: pings, reduction, surface,
//! feature search, crossline comparison and the report.
//!
//! The seabed has a wreck on it whose least depth is known before anything is
//! processed, and the test is that the number comes back out of the other end.

use approx::assert_relative_eq;
use plumbline::config::survey::SurveyConfig;
use plumbline::geodesy::utm::TransverseMercator;
use plumbline::geodesy::{Ellipsoid, Geodetic};
use plumbline::grid::estimator::{render, Estimator};
use plumbline::grid::surface::Surface;
use plumbline::motion::attitude::Attitude;
use plumbline::ping::beam::{Beam, Detection};
use plumbline::ping::line::Line;
use plumbline::ping::record::{Navigation, Ping};
use plumbline::pipeline::parallel::{reduce_lines, Progress, Threads};
use plumbline::pipeline::reduce_line::Pipeline;
use plumbline::pipeline::survey::{build_surface, summarise};
use plumbline::qc::crossline::compare;
use plumbline::qc::features::{find_features, FeatureSearch};
use plumbline::qc::report::{survey_report, ReportInputs};
use plumbline::svp::library::{LibraryEntry, ProfileLibrary, ProfileSelection};
use plumbline::svp::profile::{Sample, SoundSpeedProfile};
use plumbline::time::Timestamp;
use plumbline::tpu::s44::Order;
use plumbline::units::Angle;
use plumbline::vertical::reference::VerticalReference;
use plumbline::vertical::tide::{TideGauge, TideModel};

const SPEED: f64 = 1500.0;
const DRAFT: f64 = 1.8;
const SEABED: f64 = 24.0;
const WRECK_TOP: f64 = 18.0;
const START: f64 = 1_752_000_000.0;
const ORIGIN_EAST: f64 = 500_000.0;
const ORIGIN_NORTH: f64 = 7_650_000.0;

const CONFIG: &str = r#"
[survey]
name = "wreck block"
order = "order 1"
utm_zone = 36

[vessel]
name = "survey launch"
draft = 1.8

[grid]
cell_size = 1.0

[cleaning]
min_depth = 2.0
max_depth = 60.0
"#;

/// Depth below the transducer at a projected position: flat seabed with a
/// wreck standing six metres proud over an eight metre square.
fn seabed_at(east: f64, north: f64) -> f64 {
    let de = east - (ORIGIN_EAST + 40.0);
    let dn = north - (ORIGIN_NORTH + 40.0);
    if de.abs() < 4.0 && dn.abs() < 4.0 {
        WRECK_TOP
    } else {
        SEABED
    }
}

fn projection() -> TransverseMercator {
    TransverseMercator::utm(36, true, Ellipsoid::WGS84).unwrap()
}

fn position(east: f64, north: f64) -> Geodetic {
    projection()
        .inverse(plumbline::geodesy::utm::Projected::new(east, north))
        .unwrap()
}

/// A line running north or south along an easting, sounding the seabed below.
///
/// The travel time for each beam is found by walking out along the beam until
/// it meets the seabed, which handles the wreck with no special casing.
fn survey_line(name: &str, east: f64, northbound: bool, pings: usize) -> Line {
    let heading = if northbound { 0.0 } else { 180.0 };
    let records = (0..pings)
        .map(|p| {
            let along = p as f64 * 0.6;
            let north = if northbound {
                ORIGIN_NORTH + along
            } else {
                ORIGIN_NORTH + 90.0 - along
            };
            let beams: Vec<Beam> = (0..81)
                .map(|i| {
                    let angle = Angle::from_degrees(-60.0 + 1.5 * i as f64);
                    let sideways = if northbound { 1.0 } else { -1.0 };
                    let mut depth = SEABED;
                    let mut r = 1.0;
                    while r < 200.0 {
                        let z = r * angle.cos();
                        let x = r * angle.sin() * sideways;
                        if z >= seabed_at(east + x, north) {
                            depth = seabed_at(east + x, north);
                            break;
                        }
                        r += 0.05;
                    }
                    let slant = depth / angle.cos();
                    let mut b = Beam::new(i as u16, 2.0 * slant / SPEED, angle);
                    b.detection = Detection::Amplitude;
                    b.quality = 0.9;
                    b
                })
                .collect();
            let mut ping = Ping::new(
                Timestamp::from_unix_seconds(START + p as f64 * 0.2),
                p as u64,
                SPEED,
                beams,
            );
            ping.navigation = Some(Navigation {
                position: position(east, north),
                attitude: Attitude::from_degrees(0.0, 0.0, heading),
                heave: 0.0,
                speed: 3.0,
                transducer_height: None,
            });
            ping
        })
        .collect();
    Line::new(name, records)
}

fn library() -> ProfileLibrary {
    ProfileLibrary::new(
        vec![LibraryEntry {
            label: "cast 1".into(),
            time: Timestamp::from_unix_seconds(START),
            position: Some(position(ORIGIN_EAST, ORIGIN_NORTH)),
            profile: SoundSpeedProfile::new(vec![
                Sample::new(0.0, SPEED),
                Sample::new(200.0, SPEED),
            ])
            .unwrap(),
        }],
        ProfileSelection::NearestInTime,
    )
    .unwrap()
}

fn flat_tide() -> VerticalReference {
    let gauge = TideGauge::new(
        "gauge",
        position(ORIGIN_EAST, ORIGIN_NORTH),
        vec![
            (Timestamp::from_unix_seconds(START - 10_000.0), 0.0),
            (Timestamp::from_unix_seconds(START + 10_000.0), 0.0),
        ],
        30_000.0,
    )
    .unwrap();
    VerticalReference::Tide {
        model: Box::new(TideModel::single_gauge(gauge).unwrap()),
        zone: "whole survey".into(),
    }
}

#[test]
fn a_wreck_survives_the_whole_pipeline() {
    let config = SurveyConfig::parse(CONFIG).unwrap();
    let profiles = library();
    let vertical = flat_tide();
    let pipeline = Pipeline {
        config: &config,
        profiles: &profiles,
        vertical: &vertical,
        ellipsoid: Ellipsoid::WGS84,
    };

    let lines = vec![
        survey_line("line 1", ORIGIN_EAST + 25.0, true, 150),
        survey_line("line 2", ORIGIN_EAST + 55.0, false, 150),
    ];
    let progress = Progress::new();
    let results = reduce_lines(&pipeline, &lines, Threads::Fixed(2), &progress).unwrap();
    assert_eq!(results.len(), 2);
    assert_eq!(progress.lines_done(), 2);

    let projection = pipeline.projection().unwrap();
    let surface = build_surface(&results, &config, projection).unwrap();
    let raster = render(&surface, Estimator::Shoalest);
    let summary = summarise(&results, &surface, &config, Estimator::Shoalest);

    // The flat seabed and the wreck, both referred to the datum.
    assert_relative_eq!(summary.max_depth, SEABED + DRAFT, epsilon = 0.05);
    assert_relative_eq!(summary.min_depth, WRECK_TOP + DRAFT, epsilon = 0.05);
    assert!(summary.acceptance_rate() > 0.99);
    assert!(summary.order_compliance.unwrap() > 0.99);

    // And the feature search finds it, with the right least depth.
    let features = find_features(&surface, &raster, &FeatureSearch::default());
    assert!(!features.is_empty(), "the wreck was not found");
    let wreck = &features[0];
    assert_relative_eq!(wreck.least_depth, WRECK_TOP + DRAFT, epsilon = 0.05);
    assert_relative_eq!(wreck.surrounding_depth, SEABED + DRAFT, epsilon = 0.1);
    assert_relative_eq!(wreck.relief, SEABED - WRECK_TOP, epsilon = 0.15);
    assert!(
        wreck.meets(Order::One),
        "six metres of relief meets order 1"
    );
    assert!(wreck.soundings >= FeatureSearch::default().min_soundings);

    // The two lines see the same seabed, which is what a crossline check is.
    let geometry = *surface.geometry();
    let mut first = Surface::new(geometry, projection);
    first.add_all(&results[0].soundings).unwrap();
    let mut second = Surface::new(geometry, projection);
    second.add_all(&results[1].soundings).unwrap();
    let comparison = compare(
        &render(&first, Estimator::Mean),
        &render(&second, Estimator::Mean),
    )
    .unwrap();
    assert!(comparison.matched() > 100, "the lines barely overlap");
    assert!(comparison.mean().unwrap().abs() < 0.05);
    // Not quite everything: the cells on the edge of the wreck are seen from
    // opposite sides by the two lines, so they genuinely disagree there, and a
    // real crossline over a real wreck does exactly the same thing.
    let within = comparison.fraction_within_order(Order::One).unwrap();
    assert!(within > 0.99, "only {within} of cells agree");

    // And the report says all of it.
    let report = survey_report(&ReportInputs {
        summary: &summary,
        results: &results,
        config: &config,
        estimator: Estimator::Shoalest,
        cell_size: config.cell_size,
        features: &features,
    });
    assert!(report.contains("survey: wreck block"));
    assert!(report.contains("lines reduced: 2"));
    assert!(report.contains("features, deepest last"));
    assert!(report.contains("line 1"));
    assert!(report.contains("line 2"));
    assert!(!report.contains("does not meet the order"));
}
