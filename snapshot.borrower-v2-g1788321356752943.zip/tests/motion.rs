//! Attitude conventions, lever arms and series interpolation.
//!
//! Most of this file exists to pin down signs. Every one of these assertions
//! corresponds to a way a survey can come out wrong while still looking like a
//! seabed.

use approx::assert_relative_eq;
use plumbline::motion::attitude::{Attitude, LeverArm};
use plumbline::motion::rotation::{Mat3, Vec3};
use plumbline::motion::series::{Coverage, Entry, Interpolate, TimeSeries};
use plumbline::motion::vessel::{Latency, MountAngles, VesselGeometry};
use plumbline::time::Timestamp;
use plumbline::units::Angle;

fn t(s: f64) -> Timestamp {
    Timestamp::from_unix_seconds(s)
}

#[test]
fn a_level_vessel_points_its_bow_north() {
    let ned = Attitude::LEVEL.rotate(Vec3::new(1.0, 0.0, 0.0));
    assert_relative_eq!(ned.x, 1.0, epsilon = 1.0e-12);
    assert_relative_eq!(ned.y, 0.0, epsilon = 1.0e-12);
    assert_relative_eq!(ned.z, 0.0, epsilon = 1.0e-12);
}

#[test]
fn heading_turns_the_bow_clockwise() {
    let east = Attitude::from_degrees(0.0, 0.0, 90.0).rotate(Vec3::new(1.0, 0.0, 0.0));
    assert_relative_eq!(east.x, 0.0, epsilon = 1.0e-12);
    assert_relative_eq!(east.y, 1.0, epsilon = 1.0e-12);
}

#[test]
fn positive_roll_puts_the_starboard_side_down() {
    let stbd = Attitude::from_degrees(90.0, 0.0, 0.0).rotate(Vec3::new(0.0, 1.0, 0.0));
    // Third axis is down, so a positive third component is downwards.
    assert_relative_eq!(stbd.z, 1.0, epsilon = 1.0e-12);
}

#[test]
fn positive_pitch_lifts_the_bow() {
    let bow = Attitude::from_degrees(0.0, 90.0, 0.0).rotate(Vec3::new(1.0, 0.0, 0.0));
    assert_relative_eq!(bow.z, -1.0, epsilon = 1.0e-12);
}

#[test]
fn the_local_level_form_flips_only_the_vertical() {
    let enu = Attitude::LEVEL.rotate_to_enu(Vec3::new(3.0, 4.0, 5.0));
    assert_relative_eq!(enu.north, 3.0, epsilon = 1.0e-12);
    assert_relative_eq!(enu.east, 4.0, epsilon = 1.0e-12);
    assert_relative_eq!(enu.up, -5.0, epsilon = 1.0e-12);
}

#[test]
fn a_rotation_keeps_lengths_and_has_unit_determinant() {
    let a = Attitude::from_degrees(-4.2, 1.9, 213.0);
    let m = a.body_to_ned();
    assert_relative_eq!(m.determinant(), 1.0, epsilon = 1.0e-12);
    let v = Vec3::new(1.5, -2.5, 7.25);
    assert_relative_eq!(m.apply(v).norm(), v.norm(), epsilon = 1.0e-12);
    // And the transpose really is the inverse.
    let back = a.ned_to_body().apply(m.apply(v));
    assert_relative_eq!(back.x, v.x, epsilon = 1.0e-12);
    assert_relative_eq!(back.y, v.y, epsilon = 1.0e-12);
    assert_relative_eq!(back.z, v.z, epsilon = 1.0e-12);
}

#[test]
fn rotations_compose_right_to_left() {
    let composed =
        Mat3::rot_z(Angle::from_degrees(90.0)).times(&Mat3::rot_x(Angle::from_degrees(90.0)));
    // Rotate about x first, taking the second axis to the third, then about
    // the third axis, which leaves it alone.
    let v = composed.apply(Vec3::new(0.0, 1.0, 0.0));
    assert_relative_eq!(v.z, 1.0, epsilon = 1.0e-12);
}

#[test]
fn heading_interpolation_goes_the_short_way_round() {
    let a = Attitude::from_degrees(0.0, 0.0, 350.0);
    let b = Attitude::from_degrees(0.0, 0.0, 10.0);
    let mid = Attitude::interpolate(a, b, 0.5);
    assert_relative_eq!(mid.heading.degrees(), 0.0, epsilon = 1.0e-9);
    let quarter = Attitude::interpolate(a, b, 0.25);
    assert_relative_eq!(quarter.heading.degrees(), 355.0, epsilon = 1.0e-9);
}

#[test]
fn a_lever_arm_swings_with_the_roll() {
    // Two metres to starboard, five degrees of starboard down roll.
    let arm = LeverArm::new(0.0, 2.0, 0.0);
    let level = arm.to_enu(&Attitude::LEVEL);
    assert_relative_eq!(level.up, 0.0, epsilon = 1.0e-12);
    let rolled = arm.to_enu(&Attitude::from_degrees(5.0, 0.0, 0.0));
    assert_relative_eq!(
        rolled.up,
        -2.0 * 5.0_f64.to_radians().sin(),
        epsilon = 1.0e-12
    );
    assert!(rolled.up < -0.17, "moved by {} m", rolled.up);
}

#[test]
fn lever_arms_subtract() {
    let antenna = LeverArm::new(1.0, 0.5, -8.0);
    let transducer = LeverArm::new(-3.0, 0.0, 2.0);
    let d = antenna.to(&transducer);
    assert_relative_eq!(d.forward, -4.0, epsilon = 1.0e-12);
    assert_relative_eq!(d.starboard, -0.5, epsilon = 1.0e-12);
    assert_relative_eq!(d.down, 10.0, epsilon = 1.0e-12);
}

#[test]
fn vessel_geometry_refuses_the_obvious_mistakes() {
    let mut v = VesselGeometry::identity("test boat");
    v.waterline_to_transducer = 1.8;
    assert!(v.validate().is_ok());

    let mut radians_by_mistake = v.clone();
    radians_by_mistake.mount = MountAngles::from_degrees(45.0, 0.0, 0.0);
    assert!(radians_by_mistake.validate().is_err());

    let mut millimetres = v.clone();
    millimetres.transducer = LeverArm::new(3000.0, 0.0, 1500.0);
    assert!(millimetres.validate().is_err());

    let mut inverted = v.clone();
    inverted.waterline_to_transducer = -1.8;
    assert!(inverted.validate().is_err());
    assert_eq!(v.latency, Latency::default());
}

#[test]
fn a_series_interpolates_between_its_samples() {
    let s = TimeSeries::new(
        vec![
            Entry {
                time: t(100.0),
                value: 10.0,
            },
            Entry {
                time: t(102.0),
                value: 14.0,
            },
        ],
        5.0,
    );
    let (v, c) = s.value_at(t(101.0)).unwrap();
    assert_relative_eq!(v, 12.0, epsilon = 1.0e-12);
    assert_eq!(c, Coverage::Interpolated);
    assert_relative_eq!(s.at(t(101.5)).unwrap(), 13.0, epsilon = 1.0e-12);

    // The same series with a gap limit below the sample interval holds the
    // earlier value instead of interpolating, and says it did.
    let tight = TimeSeries::new(s.entries().to_vec(), 1.0);
    assert_eq!(tight.value_at(t(101.0)).unwrap(), (10.0, Coverage::InGap));
}

#[test]
fn a_series_holds_rather_than_extrapolating_off_the_ends() {
    let s = TimeSeries::new(
        vec![
            Entry {
                time: t(0.0),
                value: 1.0,
            },
            Entry {
                time: t(1.0),
                value: 2.0,
            },
        ],
        5.0,
    );
    assert_eq!(s.value_at(t(-10.0)).unwrap(), (1.0, Coverage::Extrapolated));
    assert_eq!(s.value_at(t(10.0)).unwrap(), (2.0, Coverage::Extrapolated));
    assert_eq!(s.value_at(t(0.5)).unwrap(), (1.5, Coverage::Interpolated));
}

#[test]
fn a_series_reports_its_holes() {
    let s = TimeSeries::new(
        (0..10)
            .filter(|i| !(4..7).contains(i))
            .map(|i| Entry {
                time: t(i as f64),
                value: i as f64,
            })
            .collect(),
        0.5,
    );
    let gaps = s.gaps(1.5);
    assert_eq!(gaps.len(), 1);
    assert_relative_eq!(gaps[0].duration(), 4.0, epsilon = 1.0e-12);
    // And inside that hole it declines to interpolate.
    assert_eq!(s.value_at(t(5.0)).unwrap().1, Coverage::InGap);
    assert_relative_eq!(s.mean_interval(), 9.0 / 6.0, epsilon = 1.0e-12);
}

#[test]
fn attitudes_go_through_the_series_with_the_wrap_intact() {
    let s = TimeSeries::new(
        vec![
            Entry {
                time: t(0.0),
                value: Attitude::from_degrees(-2.0, 1.0, 359.0),
            },
            Entry {
                time: t(1.0),
                value: Attitude::from_degrees(2.0, -1.0, 3.0),
            },
        ],
        2.0,
    );
    let a = s.at(t(0.5)).unwrap();
    assert_relative_eq!(a.roll.degrees(), 0.0, epsilon = 1.0e-9);
    assert_relative_eq!(a.heading.degrees(), 1.0, epsilon = 1.0e-9);
    assert_relative_eq!(
        Attitude::interpolate(
            Attitude::from_degrees(0.0, 0.0, 359.0),
            Attitude::from_degrees(0.0, 0.0, 3.0),
            0.5
        )
        .heading
        .degrees(),
        1.0,
        epsilon = 1.0e-9
    );
    assert_relative_eq!(f64::interpolate(1.0, 3.0, 0.25), 1.5, epsilon = 1.0e-12);
}
