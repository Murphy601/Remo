//! Ray tracing, checked against closed forms and against a slow integrator.

use approx::assert_relative_eq;
use plumbline::raytrace::layer::{advance_by_time, cos_angle, cross_layer, turning_depth};
use plumbline::raytrace::Tracer;
use plumbline::svp::profile::{Sample, SoundSpeedProfile};
use plumbline::units::Angle;

fn isovelocity(speed: f64) -> SoundSpeedProfile {
    SoundSpeedProfile::new(vec![Sample::new(0.0, speed), Sample::new(4000.0, speed)]).unwrap()
}

fn linear(surface: f64, gradient: f64, bottom_depth: f64) -> SoundSpeedProfile {
    SoundSpeedProfile::new(vec![
        Sample::new(0.0, surface),
        Sample::new(bottom_depth, surface + gradient * bottom_depth),
    ])
    .unwrap()
}

/// Step a ray forward in tiny increments, with no closed form anywhere.
///
/// Slow and obviously correct, which is exactly what a closed form needs to be
/// checked against.
fn integrate(
    profile: &SoundSpeedProfile,
    launch: Angle,
    total_time: f64,
    steps: usize,
) -> (f64, f64) {
    let c0 = profile.speed_at(0.0);
    let p = launch.sin() / c0;
    let dt = total_time / steps as f64;
    let mut z = 0.0;
    let mut x = 0.0;
    for _ in 0..steps {
        let c = profile.speed_at(z);
        let sin = (p * c).clamp(-1.0, 1.0);
        let cos = (1.0 - sin * sin).max(0.0).sqrt();
        z += c * cos * dt;
        x += c * sin * dt;
    }
    (z, x)
}

#[test]
fn in_isovelocity_water_the_ray_is_a_straight_line() {
    let profile = isovelocity(1500.0);
    let tracer = Tracer::new(&profile, 0.0).unwrap();
    for angle_deg in [0.0, 15.0, 45.0, -60.0, 70.0] {
        let angle = Angle::from_degrees(angle_deg);
        let end = tracer.trace(angle, 0.4).unwrap();
        assert!(!end.turned);
        assert_relative_eq!(end.depth, 1500.0 * 0.4 * angle.cos(), epsilon = 1.0e-9);
        assert_relative_eq!(end.across, 1500.0 * 0.4 * angle.sin(), epsilon = 1.0e-9);
        assert_relative_eq!(end.angle.degrees(), angle_deg, epsilon = 1.0e-9);
    }
}

#[test]
fn a_nadir_beam_goes_straight_down_whatever_the_profile() {
    let profile = linear(1450.0, 0.05, 3000.0);
    let tracer = Tracer::new(&profile, 0.0).unwrap();
    let end = tracer.trace(Angle::ZERO, 0.5).unwrap();
    assert_relative_eq!(end.across, 0.0, epsilon = 1.0e-12);
    // Depth is the integral of the speed, which for a linear profile grows
    // exponentially with time at rate g.
    let expected = 1450.0 * ((0.05 * 0.5f64).exp() - 1.0) / 0.05;
    assert_relative_eq!(end.depth, expected, epsilon = 1.0e-6);
}

#[test]
fn the_closed_form_matches_a_fine_integration() {
    let profile = linear(1450.0, 0.04, 2000.0);
    let tracer = Tracer::new(&profile, 0.0).unwrap();
    for angle_deg in [10.0, 35.0, 55.0, -45.0] {
        let angle = Angle::from_degrees(angle_deg);
        let end = tracer.trace(angle, 0.6).unwrap();
        let (z, x) = integrate(&profile, angle, 0.6, 400_000);
        assert_relative_eq!(end.depth, z, epsilon = 0.01);
        assert_relative_eq!(end.across, x, epsilon = 0.01);
    }
}

#[test]
fn a_layered_cast_matches_a_fine_integration_too() {
    let profile = SoundSpeedProfile::new(vec![
        Sample::new(0.0, 1462.0),
        Sample::new(20.0, 1461.0),
        Sample::new(60.0, 1452.0),
        Sample::new(150.0, 1456.0),
        Sample::new(400.0, 1470.0),
        Sample::new(900.0, 1478.0),
    ])
    .unwrap();
    let tracer = Tracer::new(&profile, 5.0).unwrap();
    for angle_deg in [5.0, 25.0, 50.0, -65.0] {
        let angle = Angle::from_degrees(angle_deg);
        let end = tracer.trace(angle, 0.35).unwrap();
        assert!(!end.turned, "beam at {angle_deg} turned");
        // The integrator starts at the surface, so run the comparison from a
        // tracer that does too.
        let surface_tracer = Tracer::new(&profile, 0.0).unwrap();
        let surface_end = surface_tracer.trace(angle, 0.35).unwrap();
        let (z, x) = integrate(&profile, angle, 0.35, 400_000);
        assert_relative_eq!(surface_end.depth, z, epsilon = 0.02);
        assert_relative_eq!(surface_end.across, x, epsilon = 0.02);
    }
}

#[test]
fn port_and_starboard_are_mirror_images() {
    let profile = linear(1470.0, -0.02, 1000.0);
    let tracer = Tracer::new(&profile, 3.0).unwrap();
    let stbd = tracer.trace(Angle::from_degrees(50.0), 0.3).unwrap();
    let port = tracer.trace(Angle::from_degrees(-50.0), 0.3).unwrap();
    assert_relative_eq!(stbd.depth, port.depth, epsilon = 1.0e-12);
    assert_relative_eq!(stbd.across, -port.across, epsilon = 1.0e-12);
}

#[test]
fn a_strong_positive_gradient_turns_the_outer_beams() {
    // A ray bends towards the slower water, so it is a rising sound speed
    // that turns a wide beam back up, not a falling one.
    let profile = linear(1450.0, 0.5, 300.0);
    let tracer = Tracer::new(&profile, 0.0).unwrap();
    let end = tracer.trace(Angle::from_degrees(75.0), 1.0).unwrap();
    assert!(end.turned, "expected the beam to turn");
    assert!(end.time < 1.0, "a turned ray stops early");
    // Half a second of travel time does not reach the turning point, so that
    // beam is still good and has to come back unflagged.
    let short = tracer.trace(Angle::from_degrees(75.0), 0.4).unwrap();
    assert!(!short.turned, "beam turned before it ran out of time");
    assert_relative_eq!(short.time, 0.4, epsilon = 1.0e-12);
    // A beam near nadir in the same water gets through.
    assert!(!tracer.trace(Angle::from_degrees(5.0), 0.3).unwrap().turned);
}

#[test]
fn travel_time_is_conserved_across_a_layer_boundary() {
    // Crossing one layer in one call has to match crossing it in two.
    let p = Angle::from_degrees(40.0).sin() / 1500.0;
    let whole = cross_layer(1500.0, 1520.0, 100.0, p).unwrap();
    let first = cross_layer(1500.0, 1510.0, 50.0, p).unwrap();
    let second = cross_layer(1510.0, 1520.0, 50.0, p).unwrap();
    assert_relative_eq!(whole.time, first.time + second.time, epsilon = 1.0e-12);
    assert_relative_eq!(whole.across, first.across + second.across, epsilon = 1.0e-9);
    assert_relative_eq!(whole.depth, first.depth + second.depth, epsilon = 1.0e-12);
}

#[test]
fn the_partial_step_inverts_the_full_one() {
    let p = Angle::from_degrees(30.0).sin() / 1480.0;
    let full = cross_layer(1480.0, 1500.0, 200.0, p).unwrap();
    let partial = advance_by_time(1480.0, 0.1, p, full.time).unwrap();
    assert_relative_eq!(partial.depth, full.depth, epsilon = 1.0e-9);
    assert_relative_eq!(partial.across, full.across, epsilon = 1.0e-9);
    assert_relative_eq!(partial.speed, full.speed, epsilon = 1.0e-9);
}

#[test]
fn the_turning_depth_is_where_the_angle_reaches_the_horizontal() {
    let p = Angle::from_degrees(70.0).sin() / 1500.0;
    // Speed rising to 1/p somewhere inside the layer.
    let c_turn = 1.0 / p;
    let depth = turning_depth(1500.0, c_turn + 5.0, 100.0, p).unwrap();
    assert!(depth > 0.0 && depth < 100.0);
    let speed_there = 1500.0 + (c_turn + 5.0 - 1500.0) / 100.0 * depth;
    assert_relative_eq!(speed_there, c_turn, epsilon = 1.0e-9);
    assert!(cos_angle(p, speed_there + 1.0).is_none());
    // A layer the ray gets through has no turning depth.
    assert!(turning_depth(1500.0, 1505.0, 100.0, p).is_none());
}

#[test]
fn a_negative_travel_time_is_refused() {
    let profile = isovelocity(1500.0);
    let tracer = Tracer::new(&profile, 0.0).unwrap();
    assert!(tracer.trace(Angle::ZERO, -1.0).is_err());
    assert!(tracer.trace(Angle::from_degrees(90.0), 1.0).is_err());
    assert!(Tracer::new(&profile, -2.0).is_err());
}
