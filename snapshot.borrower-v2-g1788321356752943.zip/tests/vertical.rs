//! Tides, draft, separation models and what they add up to.

use approx::assert_relative_eq;
use plumbline::geodesy::Geodetic;
use plumbline::motion::series::Coverage;
use plumbline::time::Timestamp;
use plumbline::units::Angle;
use plumbline::vertical::draft::{DraftModel, DraftPoint};
use plumbline::vertical::reference::{VerticalInput, VerticalReference};
use plumbline::vertical::separation::{SeparationModel, NO_DATA};
use plumbline::vertical::tide::{TideGauge, TideModel, TideZone};

fn t(s: f64) -> Timestamp {
    Timestamp::from_unix_seconds(s)
}

fn gauge() -> TideGauge {
    // A crude semidiurnal record, six minutes apart, two metre range.
    let obs: Vec<(Timestamp, f64)> = (0..=240)
        .map(|i| {
            let sec = i as f64 * 360.0;
            let phase = sec / 44_700.0 * std::f64::consts::TAU;
            (t(sec), 1.5 + 1.0 * phase.sin())
        })
        .collect();
    TideGauge::new(
        "kola inlet",
        Geodetic::from_degrees(69.2, 33.4, 0.0),
        obs,
        900.0,
    )
    .unwrap()
}

#[test]
fn a_gauge_reports_its_range() {
    let g = gauge();
    assert!((1.9..2.1).contains(&g.range()), "range {}", g.range());
    let (level, coverage) = g.level_at(t(0.0)).unwrap();
    assert_relative_eq!(level, 1.5, epsilon = 1.0e-9);
    assert_eq!(coverage, Coverage::Extrapolated);
}

#[test]
fn a_gauge_needs_two_observations() {
    let one = TideGauge::new(
        "short",
        Geodetic::from_degrees(0.0, 0.0, 0.0),
        vec![(t(0.0), 1.0)],
        60.0,
    );
    assert!(one.is_err());
}

#[test]
fn a_transparent_zone_reproduces_its_gauge() {
    let model = TideModel::single_gauge(gauge()).unwrap();
    let (zoned, _) = model.level_in_zone("whole survey", t(3600.0)).unwrap();
    let (raw, _) = model.gauges()[0].level_at(t(3600.0)).unwrap();
    assert_relative_eq!(zoned, raw, epsilon = 1.0e-12);
}

#[test]
fn a_zone_shifts_and_scales_the_gauge() {
    let zone = TideZone {
        name: "b2".into(),
        gauge: "kola inlet".into(),
        time_offset: 1800.0,
        range_factor: 0.8,
        datum_offset: -0.2,
    };
    let model = TideModel::new(vec![gauge()], vec![zone]).unwrap();
    let (zoned, _) = model.level_in_zone("b2", t(7200.0)).unwrap();
    let (gauge_earlier, _) = model.gauges()[0].level_at(t(5400.0)).unwrap();
    assert_relative_eq!(zoned, gauge_earlier * 0.8 - 0.2, epsilon = 1.0e-12);
}

#[test]
fn a_zone_naming_a_missing_gauge_is_refused() {
    let zone = TideZone::transparent("a1", "somewhere else");
    assert!(TideModel::new(vec![gauge()], vec![zone]).is_err());
    let model = TideModel::single_gauge(gauge()).unwrap();
    assert!(model.level_in_zone("no such zone", t(0.0)).is_err());
}

#[test]
fn settlement_interpolates_and_then_holds() {
    let d = DraftModel::with_table(
        1.85,
        vec![
            DraftPoint::new(2.0, 0.01),
            DraftPoint::new(4.0, 0.05),
            DraftPoint::new(6.0, 0.14),
        ],
    )
    .unwrap();
    assert_relative_eq!(d.settlement_at(3.0), 0.03, epsilon = 1.0e-12);
    assert_relative_eq!(d.settlement_at(5.0), 0.095, epsilon = 1.0e-12);
    // Held at both ends, not extrapolated.
    assert_relative_eq!(d.settlement_at(0.0), 0.01, epsilon = 1.0e-12);
    assert_relative_eq!(d.settlement_at(12.0), 0.14, epsilon = 1.0e-12);
    assert!(d.is_outside_table(12.0));
    assert!(!d.is_outside_table(5.0));
    assert_relative_eq!(d.draft_at(4.0), 1.90, epsilon = 1.0e-12);
    assert_relative_eq!(d.max_settlement(), 0.14, epsilon = 1.0e-12);
}

#[test]
fn a_fixed_draft_has_no_settlement_at_any_speed() {
    let d = DraftModel::fixed(2.4).unwrap();
    assert_relative_eq!(d.settlement_at(9.0), 0.0, epsilon = 1.0e-12);
    assert_relative_eq!(d.draft_at(9.0), 2.4, epsilon = 1.0e-12);
    assert!(d.is_outside_table(0.0));
    assert!(DraftModel::fixed(-1.0).is_err());
    assert!(DraftModel::with_table(2.0, vec![DraftPoint::new(1.0, 0.0)]).is_err());
}

#[test]
fn a_separation_model_interpolates_between_its_cells() {
    let m = SeparationModel::new(
        "test sep",
        Geodetic::from_degrees(69.0, 33.0, 0.0),
        Angle::from_degrees(0.5),
        Angle::from_degrees(1.0),
        3,
        3,
        vec![
            -30.0, -31.0, -32.0, -30.5, -31.5, -32.5, -31.0, -32.0, -33.0,
        ],
    )
    .unwrap();
    assert_relative_eq!(
        m.separation_at(Geodetic::from_degrees(69.0, 33.0, 0.0))
            .unwrap(),
        -30.0,
        epsilon = 1.0e-12
    );
    assert_relative_eq!(
        m.separation_at(Geodetic::from_degrees(69.25, 33.5, 0.0))
            .unwrap(),
        -30.75,
        epsilon = 1.0e-12
    );
    assert!(m
        .separation_at(Geodetic::from_degrees(68.0, 33.0, 0.0))
        .is_none());
    assert!(m
        .separation_at(Geodetic::from_degrees(69.0, 40.0, 0.0))
        .is_none());
    assert_relative_eq!(m.relief(), 3.0, epsilon = 1.0e-12);
}

#[test]
fn a_hole_in_the_separation_model_stays_a_hole() {
    let m = SeparationModel::new(
        "holed",
        Geodetic::from_degrees(0.0, 0.0, 0.0),
        Angle::from_degrees(1.0),
        Angle::from_degrees(1.0),
        2,
        2,
        vec![-30.0, NO_DATA, -30.5, -31.0],
    )
    .unwrap();
    assert!(m
        .separation_at(Geodetic::from_degrees(0.5, 0.5, 0.0))
        .is_none());
    assert_relative_eq!(m.hole_fraction(), 0.25, epsilon = 1.0e-12);
    assert_eq!(m.cell(0, 1), None);
    assert_eq!(m.cell(9, 9), None);
}

#[test]
fn a_constant_separation_covers_the_whole_world() {
    let m = SeparationModel::constant("flat", -27.4).unwrap();
    for (lat, lon) in [(0.0, 0.0), (69.0, 33.0), (-45.0, -170.0)] {
        assert_relative_eq!(
            m.separation_at(Geodetic::from_degrees(lat, lon, 0.0))
                .unwrap(),
            -27.4,
            epsilon = 1.0e-12
        );
    }
    assert_relative_eq!(m.relief(), 0.0, epsilon = 1.0e-12);
}

#[test]
fn the_tide_route_puts_the_transducer_under_the_water() {
    let model = TideModel::single_gauge(gauge()).unwrap();
    let reference = VerticalReference::Tide {
        model: Box::new(model),
        zone: "whole survey".into(),
    };
    let draft = DraftModel::fixed(1.8).unwrap();
    let input = VerticalInput {
        time: t(0.0),
        position: Geodetic::from_degrees(69.2, 33.4, 0.0),
        transducer_height: None,
        heave: 0.2,
        speed: 3.0,
    };
    let s = reference.solve(input, &draft).unwrap();
    // Water 1.5 above datum, transducer 1.8 down, heaved 0.2 up.
    assert_relative_eq!(s.transducer_above_datum, -0.1, epsilon = 1.0e-9);
    assert_relative_eq!(s.to_datum(30.0), 30.1, epsilon = 1.0e-9);
    assert_relative_eq!(s.draft, 1.8, epsilon = 1.0e-12);
    assert!(reference.describe().contains("whole survey"));
    assert!(!reference.needs_height());
}

#[test]
fn the_ellipsoid_route_needs_a_height_and_a_separation() {
    let reference = VerticalReference::Ellipsoid {
        separation: Box::new(SeparationModel::constant("flat", -30.0).unwrap()),
    };
    let draft = DraftModel::fixed(1.8).unwrap();
    let base = VerticalInput {
        time: t(0.0),
        position: Geodetic::from_degrees(69.2, 33.4, 0.0),
        transducer_height: Some(-31.2),
        heave: 0.2,
        speed: 3.0,
    };
    let s = reference.solve(base, &draft).unwrap();
    assert_relative_eq!(s.transducer_above_datum, -1.2, epsilon = 1.0e-12);
    assert!(s.coverage.is_none());
    assert!(reference.needs_height());

    let mut no_height = base;
    no_height.transducer_height = None;
    assert!(reference.solve(no_height, &draft).is_err());
}
