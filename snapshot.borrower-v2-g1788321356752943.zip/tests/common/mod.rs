//! Small helpers shared between the integration tests.

use std::fs;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU32, Ordering};

static COUNTER: AtomicU32 = AtomicU32::new(0);

/// A directory under the system temporary directory that deletes itself.
///
/// There are crates for this. There is also about thirty lines of it, and this
/// crate has spent the whole of its life so far not taking a dependency for
/// thirty lines, so here it is.
pub struct TempDir {
    path: PathBuf,
}

impl TempDir {
    /// Create a directory, tagged with a name so a leftover one is traceable.
    pub fn new(tag: &str) -> TempDir {
        let n = COUNTER.fetch_add(1, Ordering::Relaxed);
        let mut path = std::env::temp_dir();
        path.push(format!("plumbline-{tag}-{}-{n}", std::process::id()));
        fs::create_dir_all(&path).expect("could not create a temporary directory");
        TempDir { path }
    }

    /// The directory itself.
    #[allow(dead_code)] // not every test binary that includes this needs it
    pub fn path(&self) -> &Path {
        &self.path
    }

    /// A path inside the directory.
    pub fn join(&self, name: &str) -> PathBuf {
        self.path.join(name)
    }
}

impl Drop for TempDir {
    fn drop(&mut self) {
        // A test that has already failed should not fail again on the way out.
        let _ = fs::remove_dir_all(&self.path);
    }
}
