//! Blocks, spacing and run lines.

use approx::assert_relative_eq;
use plumbline::geodesy::utm::Projected;
use plumbline::planning::block::Block;
use plumbline::planning::lines::{plan_crosslines, plan_lines, spacing_for};
use plumbline::units::Angle;

fn square() -> Block {
    Block::rectangle("square", 0.0, 0.0, 1000.0, 1000.0).unwrap()
}

#[test]
fn a_rectangle_knows_its_area_and_perimeter() {
    let b = square();
    assert_relative_eq!(b.area(), 1_000_000.0, epsilon = 1.0e-6);
    assert_relative_eq!(b.perimeter(), 4000.0, epsilon = 1.0e-6);
    let (min, max) = b.bounds();
    assert_relative_eq!(min.east, 0.0, epsilon = 1.0e-12);
    assert_relative_eq!(max.north, 1000.0, epsilon = 1.0e-12);
}

#[test]
fn winding_does_not_change_the_area() {
    let clockwise = Block::new(
        "clockwise",
        vec![
            Projected::new(0.0, 0.0),
            Projected::new(0.0, 100.0),
            Projected::new(100.0, 100.0),
            Projected::new(100.0, 0.0),
        ],
    )
    .unwrap();
    assert_relative_eq!(clockwise.area(), 10_000.0, epsilon = 1.0e-9);
}

#[test]
fn a_repeated_closing_corner_is_dropped() {
    let b = Block::new(
        "closed",
        vec![
            Projected::new(0.0, 0.0),
            Projected::new(10.0, 0.0),
            Projected::new(10.0, 10.0),
            Projected::new(0.0, 0.0),
        ],
    )
    .unwrap();
    assert_eq!(b.corners().len(), 3);
    assert!(Block::new(
        "thin",
        vec![Projected::new(0.0, 0.0), Projected::new(1.0, 1.0)]
    )
    .is_err());
}

#[test]
fn a_point_inside_is_inside_and_one_outside_is_not() {
    let b = square();
    assert!(b.contains(Projected::new(500.0, 500.0)));
    assert!(b.contains(Projected::new(1.0, 999.0)));
    assert!(!b.contains(Projected::new(-1.0, 500.0)));
    assert!(!b.contains(Projected::new(1001.0, 500.0)));
    assert!(!b.contains(Projected::new(500.0, 1001.0)));
}

#[test]
fn a_concave_block_is_handled_by_the_ray_test() {
    // An L shape, with the notch in the top right.
    let l = Block::new(
        "ell",
        vec![
            Projected::new(0.0, 0.0),
            Projected::new(100.0, 0.0),
            Projected::new(100.0, 40.0),
            Projected::new(40.0, 40.0),
            Projected::new(40.0, 100.0),
            Projected::new(0.0, 100.0),
        ],
    )
    .unwrap();
    assert!(l.contains(Projected::new(20.0, 80.0)));
    assert!(l.contains(Projected::new(80.0, 20.0)));
    assert!(!l.contains(Projected::new(80.0, 80.0)));
    assert_relative_eq!(l.area(), 100.0 * 40.0 + 40.0 * 60.0, epsilon = 1.0e-9);
}

#[test]
fn a_line_across_a_square_crosses_it_twice() {
    let b = square();
    let hits = b.crossings(Projected::new(500.0, -500.0), (0.0, 1.0));
    assert_eq!(hits.len(), 2);
    assert_relative_eq!(hits[0], 500.0, epsilon = 1.0e-9);
    assert_relative_eq!(hits[1], 1500.0, epsilon = 1.0e-9);
}

#[test]
fn spacing_is_the_swath_less_the_overlap() {
    // Sixty degrees either side in thirty metres is about a hundred and four
    // metres of swath, and a twenty percent overlap takes a fifth off it.
    let full = spacing_for(30.0, Angle::from_degrees(60.0), 0.0).unwrap();
    assert_relative_eq!(
        full,
        2.0 * 30.0 * 60.0_f64.to_radians().tan(),
        epsilon = 1.0e-9
    );
    let overlapped = spacing_for(30.0, Angle::from_degrees(60.0), 0.2).unwrap();
    assert_relative_eq!(overlapped, full * 0.8, epsilon = 1.0e-9);
    // Shallower water means narrower swath means closer lines.
    assert!(spacing_for(10.0, Angle::from_degrees(60.0), 0.2).unwrap() < overlapped);
}

#[test]
fn silly_spacing_arguments_are_refused() {
    assert!(spacing_for(0.0, Angle::from_degrees(60.0), 0.2).is_err());
    assert!(spacing_for(30.0, Angle::from_degrees(95.0), 0.2).is_err());
    assert!(spacing_for(30.0, Angle::from_degrees(60.0), 1.5).is_err());
}

#[test]
fn lines_cover_the_block_at_the_spacing_asked_for() {
    let plan = plan_lines(&square(), Angle::ZERO, 100.0).unwrap();
    assert_eq!(plan.lines.len(), 10);
    assert_relative_eq!(plan.spacing, 100.0, epsilon = 1.0e-12);
    for line in &plan.lines {
        assert_relative_eq!(line.length(), 1000.0, epsilon = 1.0e-6);
        assert_relative_eq!(line.heading().degrees(), 0.0, epsilon = 1.0e-9);
    }
    assert_relative_eq!(plan.line_length(), 10_000.0, epsilon = 1.0e-6);
}

#[test]
fn lines_can_run_on_any_heading() {
    let plan = plan_lines(&square(), Angle::from_degrees(90.0), 200.0).unwrap();
    assert!(!plan.lines.is_empty());
    for line in &plan.lines {
        assert_relative_eq!(line.heading().degrees(), 90.0, epsilon = 1.0e-6);
        assert_relative_eq!(line.length(), 1000.0, epsilon = 1.0e-6);
    }
}

#[test]
fn running_alternate_lines_the_other_way_halves_the_turning() {
    let mut plan = plan_lines(&square(), Angle::ZERO, 100.0).unwrap();
    let straight_through = plan.turn_length();
    plan.alternate_directions();
    assert!(plan.turn_length() < straight_through);
    // Every turn is now just the line spacing.
    assert_relative_eq!(plan.turn_length(), 9.0 * 100.0, epsilon = 1.0e-6);
    assert!(plan.hours_at(3.0) > 0.0);
    assert!(plan.hours_at(0.0).is_infinite());
}

#[test]
fn crosslines_run_across_the_main_scheme() {
    let main = plan_lines(&square(), Angle::ZERO, 50.0).unwrap();
    let cross = plan_crosslines(&square(), &main).unwrap();
    assert!(cross.lines.len() >= 2);
    assert_relative_eq!(cross.heading.degrees(), 90.0, epsilon = 1.0e-6);
    for line in &cross.lines {
        assert_relative_eq!(line.length(), 1000.0, epsilon = 1.0e-6);
    }
}

#[test]
fn a_spacing_bigger_than_the_block_still_gives_one_line() {
    let plan = plan_lines(&square(), Angle::ZERO, 5000.0).unwrap();
    assert_eq!(plan.lines.len(), 1);
    assert!(plan_lines(&square(), Angle::ZERO, -5.0).is_err());
}
