//! The uncertainty budget, its propagation, and the order envelopes.

use approx::assert_relative_eq;
use plumbline::geodesy::Geodetic;
use plumbline::ping::beam::{BeamFlags, Detection};
use plumbline::ping::sounding::Sounding;
use plumbline::time::Timestamp;
use plumbline::tpu::propagate::{propagate, SoundingGeometry};
use plumbline::tpu::s44::{best_order, check, Order};
use plumbline::tpu::sensors::{UncertaintyBudget, ONE_DIMENSIONAL_95, TWO_DIMENSIONAL_95};
use plumbline::units::Angle;

fn geometry(depth: f64, angle_deg: f64) -> SoundingGeometry {
    let angle = Angle::from_degrees(angle_deg);
    SoundingGeometry {
        depth,
        across: depth * angle.tan(),
        launch_angle: angle,
        surface_speed: 1500.0,
        mean_speed: 1490.0,
        heave: 0.3,
        vessel_speed: 3.5,
        ellipsoidal: false,
    }
}

fn sounding(depth: f64, tvu: f64, thu: f64) -> Sounding {
    Sounding {
        time: Timestamp::EPOCH,
        ping: 1,
        beam: 0,
        position: Geodetic::from_degrees(69.0, 33.0, 0.0),
        depth,
        across: 0.0,
        along: 0.0,
        tvu,
        thu,
        detection: Detection::Amplitude,
        flags: BeamFlags::NONE,
    }
}

#[test]
fn an_empty_budget_produces_no_uncertainty() {
    let p = propagate(geometry(40.0, 50.0), &UncertaintyBudget::ZERO);
    assert_relative_eq!(p.tvu, 0.0, epsilon = 1.0e-15);
    assert_relative_eq!(p.thu, 0.0, epsilon = 1.0e-15);
    assert!(!p.vertical.is_empty());
}

#[test]
fn a_single_term_comes_through_scaled_by_the_confidence_factor() {
    let mut budget = UncertaintyBudget::ZERO;
    budget.tide = 0.05;
    let p = propagate(geometry(30.0, 0.0), &budget);
    assert_relative_eq!(p.tvu, 0.05 * ONE_DIMENSIONAL_95, epsilon = 1.0e-12);

    let mut horizontal = UncertaintyBudget::ZERO;
    horizontal.position_horizontal = 0.4;
    let q = propagate(geometry(30.0, 0.0), &horizontal);
    assert_relative_eq!(q.thu, 0.4 * TWO_DIMENSIONAL_95, epsilon = 1.0e-12);
}

#[test]
fn roll_costs_nothing_at_nadir_and_everything_at_the_edge() {
    let mut budget = UncertaintyBudget::ZERO;
    budget.roll = Angle::from_degrees(0.05);

    let nadir = propagate(geometry(50.0, 0.0), &budget);
    assert_relative_eq!(nadir.tvu, 0.0, epsilon = 1.0e-12);

    let outer = propagate(geometry(50.0, 60.0), &budget);
    // Slant range is depth over cos, and the vertical term is that times
    // sin(theta) times the angular sigma.
    let range = 50.0 / 60.0_f64.to_radians().cos();
    let expected = range * 60.0_f64.to_radians().sin() * 0.05_f64.to_radians();
    assert_relative_eq!(outer.tvu, expected * ONE_DIMENSIONAL_95, epsilon = 1.0e-9);
    assert!(outer.tvu > 0.05);
}

#[test]
fn the_angular_terms_swap_between_vertical_and_horizontal() {
    let mut budget = UncertaintyBudget::ZERO;
    budget.beam_angle = Angle::from_degrees(0.1);
    let nadir = propagate(geometry(60.0, 0.0), &budget);
    // At nadir an angular error is entirely horizontal.
    assert_relative_eq!(nadir.tvu, 0.0, epsilon = 1.0e-12);
    assert!(nadir.thu > 0.1);

    let steep = propagate(geometry(60.0, 70.0), &budget);
    assert!(steep.tvu > steep.thu);
}

#[test]
fn sound_speed_uncertainty_grows_with_depth() {
    let mut budget = UncertaintyBudget::ZERO;
    budget.profile_sound_speed = 2.0;
    let shallow = propagate(geometry(20.0, 30.0), &budget);
    let deep = propagate(geometry(200.0, 30.0), &budget);
    assert!(deep.tvu > 9.0 * shallow.tvu);
    // Depth over the cosine squared of the beam angle, times the fractional
    // speed error, times the confidence factor.
    let secant2 = 1.0 / 30.0_f64.to_radians().cos().powi(2);
    assert_relative_eq!(
        deep.tvu,
        200.0 * (2.0 / 1490.0) * secant2 * ONE_DIMENSIONAL_95,
        epsilon = 1.0e-9
    );
}

#[test]
fn the_dominant_term_moves_across_the_swath() {
    let budget = UncertaintyBudget::shallow_water_launch();
    let nadir = propagate(geometry(35.0, 0.0), &budget);
    let edge = propagate(geometry(35.0, 65.0), &budget);
    let nadir_worst = nadir.dominant_vertical().unwrap();
    let edge_worst = edge.dominant_vertical().unwrap();
    assert!(
        ["heave", "tide", "sound speed"].contains(&nadir_worst.name),
        "nadir dominated by {}",
        nadir_worst.name
    );
    assert!(
        ["roll", "sound speed", "face refraction", "beam angle"].contains(&edge_worst.name),
        "edge dominated by {}",
        edge_worst.name
    );
    assert!(edge.tvu > nadir.tvu);
    assert!(edge.dominant_horizontal().is_some());
}

#[test]
fn the_ellipsoidal_route_swaps_the_tide_for_a_separation() {
    let budget = UncertaintyBudget::shallow_water_launch();
    let mut g = geometry(30.0, 20.0);
    let tidal = propagate(g, &budget);
    g.ellipsoidal = true;
    let ellipsoidal = propagate(g, &budget);
    assert!(tidal.vertical.iter().any(|c| c.name == "tide"));
    assert!(!ellipsoidal.vertical.iter().any(|c| c.name == "tide"));
    assert!(ellipsoidal.vertical.iter().any(|c| c.name == "separation"));
}

#[test]
fn the_order_envelopes_are_the_published_ones() {
    // At the surface the envelope is the constant term alone.
    assert_relative_eq!(Order::Exclusive.max_tvu(0.0), 0.15, epsilon = 1.0e-12);
    assert_relative_eq!(Order::Special.max_tvu(0.0), 0.25, epsilon = 1.0e-12);
    assert_relative_eq!(Order::One.max_tvu(0.0), 0.5, epsilon = 1.0e-12);
    assert_relative_eq!(Order::Two.max_tvu(0.0), 1.0, epsilon = 1.0e-12);

    // At a hundred metres the depth dependent part is doing the work.
    let one = Order::One.max_tvu(100.0);
    assert_relative_eq!(one, (0.25f64 + 1.3 * 1.3).sqrt(), epsilon = 1.0e-12);
    assert!(Order::Exclusive.max_tvu(100.0) < one);

    assert_relative_eq!(Order::One.max_thu(100.0), 10.0, epsilon = 1.0e-12);
    assert_relative_eq!(Order::Two.max_thu(100.0), 30.0, epsilon = 1.0e-12);
    assert_relative_eq!(Order::Exclusive.max_thu(100.0), 1.0, epsilon = 1.0e-12);
}

#[test]
fn the_envelope_widens_as_the_order_loosens() {
    for depth in [5.0, 40.0, 300.0] {
        let mut previous = 0.0;
        for order in Order::all() {
            let allowed = order.max_tvu(depth);
            assert!(allowed > previous, "{} at {depth} m", order.name());
            previous = allowed;
        }
    }
}

#[test]
fn compliance_is_a_ratio_as_well_as_a_verdict() {
    let s = sounding(50.0, 0.5, 3.0);
    let c = check(&s, Order::One);
    assert!(c.passes());
    assert_relative_eq!(
        c.vertical_ratio,
        0.5 / Order::One.max_tvu(50.0),
        epsilon = 1.0e-12
    );
    assert!(c.horizontal_ratio < 1.0);

    let bad = sounding(50.0, 2.0, 3.0);
    assert!(!check(&bad, Order::One).passes());
    assert!(!check(&bad, Order::One).vertical_ok);
    assert!(check(&bad, Order::One).horizontal_ok);
}

#[test]
fn the_best_order_is_the_tightest_one_that_passes() {
    assert_eq!(
        best_order(&sounding(20.0, 0.10, 0.5)),
        Some(Order::Exclusive)
    );
    assert_eq!(best_order(&sounding(20.0, 0.25, 0.5)), Some(Order::Special));
    assert_eq!(best_order(&sounding(20.0, 0.40, 0.5)), Some(Order::One));
    assert_eq!(best_order(&sounding(20.0, 0.90, 0.5)), Some(Order::Two));
    assert_eq!(best_order(&sounding(20.0, 5.00, 0.5)), None);
    // A good depth with a hopeless position fails on the horizontal.
    assert_eq!(best_order(&sounding(20.0, 0.05, 500.0)), None);
}

#[test]
fn order_names_round_trip() {
    for order in Order::all() {
        assert_eq!(Order::from_name(order.name()), Some(order));
    }
    assert_eq!(Order::from_name("1a"), Some(Order::One));
    assert_eq!(Order::from_name("nonsense"), None);
    assert!(Order::Two.feature_size(30.0).is_none());
    assert_relative_eq!(
        Order::One.feature_size(30.0).unwrap(),
        2.0,
        epsilon = 1.0e-12
    );
    assert_relative_eq!(
        Order::One.feature_size(100.0).unwrap(),
        10.0,
        epsilon = 1.0e-12
    );
}

#[test]
fn a_budget_knows_when_it_is_nonsense() {
    let mut b = UncertaintyBudget::shallow_water_launch();
    assert!(b.is_valid());
    b.tide = -0.1;
    assert!(!b.is_valid());
    b.tide = f64::NAN;
    assert!(!b.is_valid());
    assert_relative_eq!(
        UncertaintyBudget::shallow_water_launch().heave_sigma(0.0),
        0.05,
        epsilon = 1.0e-12
    );
}
