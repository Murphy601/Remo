//! Comparing casts, and the command that does it.

mod common;

use approx::assert_relative_eq;
use common::TempDir;
use plumbline::svp::compare::compare_casts;
use plumbline::svp::profile::{Sample, SoundSpeedProfile};
use plumbline::units::Angle;

const TWO_CASTS: &str = "\
[SVP_VERSION_2]
casts.svp
Section 2025-146 07:30:00 69:00:00 033:00:00
0.0 1462.0
20.0 1461.0
60.0 1452.0
200.0 1458.0
Section 2025-146 11:30:00 69:00:00 033:00:00
0.0 1466.0
20.0 1462.0
60.0 1450.0
200.0 1458.0
";

fn isovelocity(speed: f64) -> SoundSpeedProfile {
    SoundSpeedProfile::new(vec![Sample::new(0.0, speed), Sample::new(300.0, speed)]).unwrap()
}

#[test]
fn a_cast_compared_against_itself_shows_nothing() {
    let cast = isovelocity(1480.0);
    let c = compare_casts(&cast, &cast, 30.0, 1.5, Angle::from_degrees(60.0), 11).unwrap();
    assert_eq!(c.beams.len(), 11);
    assert_relative_eq!(c.worst_depth_difference(), 0.0, epsilon = 1.0e-12);
    assert_relative_eq!(c.at_nadir().unwrap(), 0.0, epsilon = 1.0e-12);
    assert!(c.within(0.001));
}

#[test]
fn the_trace_lands_near_the_nominal_depth() {
    let cast = isovelocity(1490.0);
    let c = compare_casts(&cast, &cast, 40.0, 2.0, Angle::from_degrees(50.0), 9).unwrap();
    for beam in &c.beams {
        assert!(
            (beam.depth - 40.0).abs() < 0.05,
            "{} degrees landed at {} m",
            beam.angle.degrees(),
            beam.depth
        );
    }
    assert_relative_eq!(c.nominal_depth, 40.0, epsilon = 1.0e-12);
}

#[test]
fn a_faster_cast_reads_deeper_and_the_outer_beams_read_more() {
    let slow = isovelocity(1480.0);
    let fast = isovelocity(1500.0);
    let c = compare_casts(&slow, &fast, 30.0, 1.5, Angle::from_degrees(60.0), 13).unwrap();

    let nadir = c.at_nadir().unwrap();
    assert!(nadir > 0.0, "faster water should read deeper, got {nadir}");
    // Twenty metres per second in fifteen hundred, over about thirty metres.
    assert_relative_eq!(nadir, 30.0 * 20.0 / 1480.0, epsilon = 0.05);
    assert!(c.worst_depth_difference() > nadir.abs());
    assert!(!c.within(0.05));
}

#[test]
fn the_difference_is_reported_as_a_fraction_of_depth_too() {
    let slow = isovelocity(1480.0);
    let fast = isovelocity(1490.0);
    let c = compare_casts(&slow, &fast, 50.0, 1.5, Angle::from_degrees(45.0), 7).unwrap();
    for beam in &c.beams {
        let fraction = beam.fraction_of_depth();
        assert!((0.0..0.05).contains(&fraction), "{fraction}");
    }
}

#[test]
fn two_real_casts_differ_most_at_the_edge_of_the_swath() {
    let morning = SoundSpeedProfile::new(vec![
        Sample::new(0.0, 1462.0),
        Sample::new(20.0, 1461.0),
        Sample::new(60.0, 1452.0),
        Sample::new(200.0, 1458.0),
    ])
    .unwrap();
    let afternoon = SoundSpeedProfile::new(vec![
        Sample::new(0.0, 1466.0),
        Sample::new(20.0, 1462.0),
        Sample::new(60.0, 1450.0),
        Sample::new(200.0, 1458.0),
    ])
    .unwrap();

    let c = compare_casts(
        &morning,
        &afternoon,
        30.0,
        1.5,
        Angle::from_degrees(60.0),
        21,
    )
    .unwrap();
    let nadir = c.at_nadir().unwrap().abs();
    let worst = c.worst_depth_difference();
    assert!(worst > 3.0 * nadir, "nadir {nadir}, worst {worst}");
    // Both edges of the swath, and by roughly the same amount.
    let port = c.beams.first().unwrap().depth_difference;
    let stbd = c.beams.last().unwrap().depth_difference;
    assert_relative_eq!(port, stbd, epsilon = 1.0e-6);
}

#[test]
fn the_cast_command_compares_the_casts_in_one_file() {
    let dir = TempDir::new("cast");
    let path = dir.join("casts.svp");
    std::fs::write(&path, TWO_CASTS).unwrap();

    let output = std::process::Command::new(env!("CARGO_BIN_EXE_plumbline"))
        .args(["cast", &path.to_string_lossy(), "--depth", "30"])
        .output()
        .unwrap();
    assert!(output.status.success());
    let text = String::from_utf8_lossy(&output.stdout);
    assert!(text.contains("comparing 2 casts"), "{text}");
    assert!(text.contains("at nadir"), "{text}");
    assert!(text.contains("not interchangeable"), "{text}");
}

#[test]
fn the_cast_command_needs_two_casts() {
    let dir = TempDir::new("cast");
    let path = dir.join("one.svp");
    std::fs::write(
        &path,
        "[SVP_VERSION_2]\nx.svp\nSection 2025-146 07:30:00\n0.0 1500.0\n100.0 1500.0\n",
    )
    .unwrap();

    let output = std::process::Command::new(env!("CARGO_BIN_EXE_plumbline"))
        .args(["cast", &path.to_string_lossy()])
        .output()
        .unwrap();
    assert_eq!(output.status.code(), Some(1));
    let text = String::from_utf8_lossy(&output.stderr);
    assert!(text.contains("two casts are needed"), "{text}");
}

#[test]
fn the_table_flag_prints_every_beam() {
    let dir = TempDir::new("cast");
    let path = dir.join("casts.svp");
    std::fs::write(&path, TWO_CASTS).unwrap();

    let output = std::process::Command::new(env!("CARGO_BIN_EXE_plumbline"))
        .args(["cast", &path.to_string_lossy(), "--beams", "5", "--table"])
        .output()
        .unwrap();
    assert!(output.status.success());
    let text = String::from_utf8_lossy(&output.stdout);
    assert_eq!(text.matches("difference").count(), 5);
}
