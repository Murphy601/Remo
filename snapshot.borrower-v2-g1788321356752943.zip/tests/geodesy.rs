//! Frame conversions, checked against values that can be worked out by hand.

use approx::assert_relative_eq;
use plumbline::geodesy::ellipsoid::{ecef_to_geodetic, geodetic_to_ecef};
use plumbline::geodesy::frame::{Enu, LocalFrame};
use plumbline::geodesy::utm::{TransverseMercator, UTM_FALSE_EASTING, UTM_SCALE_FACTOR};
use plumbline::geodesy::vincenty;
use plumbline::geodesy::{Ellipsoid, Geodetic};
use plumbline::units::Angle;

#[test]
fn wgs84_derived_constants_match_the_definition() {
    let e = Ellipsoid::WGS84;
    assert_relative_eq!(e.b(), 6_356_752.314_245_179, epsilon = 1.0e-6);
    assert_relative_eq!(e.e2(), 0.006_694_379_990_141_32, epsilon = 1.0e-15);
    assert_relative_eq!(e.ep2(), 0.006_739_496_742_276_43, epsilon = 1.0e-15);
}

#[test]
fn prime_vertical_radius_is_the_semi_major_axis_on_the_equator() {
    let e = Ellipsoid::WGS84;
    assert_relative_eq!(e.prime_vertical_radius(Angle::ZERO), e.a, epsilon = 1.0e-9);
    // At the pole both radii meet at a squared over b.
    let polar = e.a * e.a / e.b();
    assert_relative_eq!(
        e.prime_vertical_radius(Angle::from_degrees(90.0)),
        polar,
        epsilon = 1.0e-6
    );
    assert_relative_eq!(
        e.meridian_radius(Angle::from_degrees(90.0)),
        polar,
        epsilon = 1.0e-6
    );
}

#[test]
fn a_degree_of_latitude_is_about_111_kilometres() {
    let e = Ellipsoid::WGS84;
    let at45 = e.metres_per_degree_latitude(Angle::from_degrees(45.0));
    assert!((111_100.0..111_200.0).contains(&at45), "got {at45}");
    // Meridians converge, so a degree of longitude shrinks with the cosine.
    let lon60 = e.metres_per_degree_longitude(Angle::from_degrees(60.0));
    let lon0 = e.metres_per_degree_longitude(Angle::ZERO);
    assert_relative_eq!(lon60 / lon0, 0.5, epsilon = 2.0e-3);
}

#[test]
fn cartesian_conversion_round_trips() {
    let e = Ellipsoid::WGS84;
    let cases = [
        Geodetic::from_degrees(0.0, 0.0, 0.0),
        Geodetic::from_degrees(69.712_45, 33.083_11, 41.7),
        Geodetic::from_degrees(-33.865_1, 151.209_9, -12.0),
        Geodetic::from_degrees(89.5, -179.9, 3000.0),
    ];
    for p in cases {
        let back = ecef_to_geodetic(geodetic_to_ecef(p, &e), &e);
        assert_relative_eq!(back.lat.degrees(), p.lat.degrees(), epsilon = 1.0e-10);
        assert_relative_eq!(back.lon.degrees(), p.lon.degrees(), epsilon = 1.0e-10);
        assert_relative_eq!(back.height, p.height, epsilon = 1.0e-4);
    }
}

#[test]
fn the_pole_is_on_the_semi_minor_axis() {
    let e = Ellipsoid::WGS84;
    let p = geodetic_to_ecef(Geodetic::from_degrees(90.0, 0.0, 0.0), &e);
    assert_relative_eq!(p.x, 0.0, epsilon = 1.0e-6);
    assert_relative_eq!(p.y, 0.0, epsilon = 1.0e-6);
    assert_relative_eq!(p.z, e.b(), epsilon = 1.0e-6);
}

#[test]
fn local_frame_axes_point_where_they_should() {
    let origin = Geodetic::from_degrees(69.0, 33.0, 0.0);
    let frame = LocalFrame::new(origin, Ellipsoid::WGS84);

    let at_origin = frame.to_local(origin);
    assert_relative_eq!(at_origin.east, 0.0, epsilon = 1.0e-9);
    assert_relative_eq!(at_origin.north, 0.0, epsilon = 1.0e-9);
    assert_relative_eq!(at_origin.up, 0.0, epsilon = 1.0e-9);

    // A point due north should have no easting to speak of.
    let north_of = Geodetic::from_degrees(69.01, 33.0, 0.0);
    let v = frame.to_local(north_of);
    assert!(v.north > 1000.0, "north component {}", v.north);
    assert_relative_eq!(v.east, 0.0, epsilon = 1.0e-6);
    // And it curves away from the tangent plane, so up goes slightly negative.
    assert!(v.up < 0.0, "up component {}", v.up);
}

#[test]
fn local_frame_round_trips_a_kilometre_offset() {
    let origin = Geodetic::from_degrees(69.0, 33.0, 12.0);
    let frame = LocalFrame::new(origin, Ellipsoid::WGS84);
    let offset = Enu::new(1234.5, -987.6, 15.0);
    let back = frame.to_local(frame.to_geodetic(offset));
    assert_relative_eq!(back.east, offset.east, epsilon = 1.0e-6);
    assert_relative_eq!(back.north, offset.north, epsilon = 1.0e-6);
    assert_relative_eq!(back.up, offset.up, epsilon = 1.0e-6);
}

#[test]
fn utm_zone_numbering_follows_the_longitude() {
    let zone = TransverseMercator::zone_for_longitude;
    assert_eq!(zone(Angle::from_degrees(-177.0)), 1);
    assert_eq!(zone(Angle::from_degrees(-180.0)), 1);
    assert_eq!(zone(Angle::from_degrees(33.1)), 36);
    assert_eq!(zone(Angle::from_degrees(179.9)), 60);
    assert_relative_eq!(
        TransverseMercator::zone_central_meridian(36).degrees(),
        33.0,
        epsilon = 1.0e-12
    );
}

#[test]
fn on_the_central_meridian_the_easting_is_the_false_easting() {
    let tm = TransverseMercator::utm(36, true, Ellipsoid::WGS84).unwrap();
    let p = Geodetic::from_degrees(69.0, 33.0, 0.0);
    let grid = tm.forward(p).unwrap();
    assert_relative_eq!(grid.east, UTM_FALSE_EASTING, epsilon = 1.0e-6);
    assert_relative_eq!(tm.point_scale(p), UTM_SCALE_FACTOR, epsilon = 1.0e-12);
    assert_relative_eq!(tm.convergence(p).degrees(), 0.0, epsilon = 1.0e-12);
}

#[test]
fn projection_round_trips_across_a_whole_zone() {
    let tm = TransverseMercator::utm(36, true, Ellipsoid::WGS84).unwrap();
    for lat in [0.5, 30.0, 55.0, 69.5, 80.0] {
        for dlon in [-3.0, -1.5, 0.0, 1.7, 3.0] {
            let p = Geodetic::from_degrees(lat, 33.0 + dlon, 0.0);
            let back = tm.inverse(tm.forward(p).unwrap()).unwrap();
            // Judge the closure on the ground rather than in degrees. The
            // truncated series is worth a couple of millimetres at the edge
            // of a zone and that is the number worth pinning.
            let dnorth = (back.lat.degrees() - lat).abs() * 111_320.0;
            let deast =
                (back.lon.degrees() - (33.0 + dlon)).abs() * 111_320.0 * lat.to_radians().cos();
            assert!(dnorth < 0.005, "northing closure {dnorth} m at {lat}");
            assert!(deast < 0.005, "easting closure {deast} m at {lat}");
        }
    }
}

#[test]
fn convergence_changes_sign_with_the_side_of_the_meridian() {
    let tm = TransverseMercator::utm(36, true, Ellipsoid::WGS84).unwrap();
    let east = tm.convergence(Geodetic::from_degrees(69.0, 35.5, 0.0));
    let west = tm.convergence(Geodetic::from_degrees(69.0, 30.5, 0.0));
    assert!(east.degrees() > 0.0 && west.degrees() < 0.0);
    assert_relative_eq!(east.degrees(), -west.degrees(), epsilon = 5.0e-3);
    // Roughly the longitude difference times the sine of the latitude.
    assert_relative_eq!(
        east.degrees(),
        2.5 * 69.0_f64.to_radians().sin(),
        epsilon = 5.0e-3
    );
}

#[test]
fn utm_zone_must_be_in_range() {
    assert!(TransverseMercator::utm(0, true, Ellipsoid::WGS84).is_err());
    assert!(TransverseMercator::utm(61, true, Ellipsoid::WGS84).is_err());
    assert!(TransverseMercator::utm(1, true, Ellipsoid::WGS84).is_ok());
}

#[test]
fn a_degree_along_the_equator_is_the_radius_times_the_angle() {
    let e = Ellipsoid::WGS84;
    let g = vincenty::inverse(
        Geodetic::from_degrees(0.0, 0.0, 0.0),
        Geodetic::from_degrees(0.0, 1.0, 0.0),
        &e,
    )
    .unwrap();
    assert_relative_eq!(g.distance, e.a * 1.0_f64.to_radians(), epsilon = 1.0e-3);
    assert_relative_eq!(g.initial_bearing.degrees(), 90.0, epsilon = 1.0e-9);
}

#[test]
fn direct_and_inverse_agree() {
    let e = Ellipsoid::WGS84;
    let start = Geodetic::from_degrees(69.712_45, 33.083_11, 0.0);
    for bearing_deg in [0.0, 47.5, 129.0, 250.0, 355.0] {
        for distance in [50.0, 5_000.0, 120_000.0] {
            let bearing = Angle::from_degrees(bearing_deg);
            let end = vincenty::direct(start, bearing, distance, &e);
            let g = vincenty::inverse(start, end, &e).unwrap();
            assert_relative_eq!(g.distance, distance, epsilon = 1.0e-6);
            assert_relative_eq!(
                g.initial_bearing.degrees(),
                bearing.wrapped().degrees(),
                epsilon = 1.0e-8
            );
        }
    }
}

#[test]
fn coincident_points_are_zero_distance() {
    let e = Ellipsoid::WGS84;
    let p = Geodetic::from_degrees(69.0, 33.0, 0.0);
    let g = vincenty::inverse(p, p, &e).unwrap();
    assert_eq!(g.distance, 0.0);
}
